package
{
    public class Platforms
    {
        // [nome exibido, host do site de login]
        public static const LIST:Array = [
            ["Legend Online Brasil", "lobr.creaction-network.com"]
        ];
        // true enquanto o jogo aberto é o Legend Remake (o macro de Planos usa o caminhar controlado)
        public static var remake:Boolean = false;
    }
}
