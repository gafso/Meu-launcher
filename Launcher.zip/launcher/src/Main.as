package
{
    import com.meulauncher.air.Bridge;
    import flash.desktop.NativeApplication;
    import flash.desktop.SystemIdleMode;
    import flash.display.Bitmap;
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Loader;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.HTTPStatusEvent;
    import flash.events.IOErrorEvent;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.events.SecurityErrorEvent;
    import flash.events.StatusEvent;
    import flash.events.TimerEvent;
    import flash.events.UncaughtErrorEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.filters.DropShadowFilter;
    import flash.filters.GlowFilter;
    import flash.geom.Matrix;
    import flash.geom.Rectangle;
    import flash.net.URLLoader;
    import flash.net.navigateToURL;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.net.URLRequestHeader;
    import flash.net.URLRequestMethod;
    import flash.system.ApplicationDomain;
    import flash.system.Capabilities;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.ui.Keyboard;
    import flash.utils.ByteArray;
    import flash.utils.Timer;
    import flash.utils.clearTimeout;
    import flash.utils.getTimer;
    import flash.utils.setTimeout;

    [SWF(width="1352", height="650", frameRate="30", backgroundColor="#0A0A0A")]
    public class Main extends Sprite
    {
        // Reservas empacotadas (você coloca os SEUS arquivos em assets/game/).
        private static const FALLBACKS:Array = [
            "assets/game/Loading.swf",
            "assets/game/Loading_270767.swf",
            "assets/game/Loading_245292.swf",
            "assets/game/Loading_243852.swf",
            "assets/game/Loading_234741.swf"
        ];
        private static const CACHE_TTL_MS:Number = 6 * 60 * 60 * 1000;   // 6 h
        private static const BG_TOP:uint = 0x0A0A0A;      // fundo preto liso
        private static const BG_BOTTOM:uint = 0x0A0A0A;
        private static const VERSION:String = "v6.2";
        // Legend Remake: servidor próprio (HTTP). Se o IP mudar, é só trocar aqui.
        private static const REMAKE:String = "http://45.157.16.32";
        // Tema preto + laranja
        private static const C_OR:uint    = 0xFF7A00;
        private static const C_CARD:uint  = 0x141414;
        private static const C_LINE:uint  = 0x2B2B2B;
        private static const C_MUTED:uint = 0x8C8C8C;

        // Modos do menu nativo (o evento "menu" é compartilhado).
        private static const M_PLATFORM:String = "platform";
        private static const M_SETTINGS:String = "settings";
        private static const M_QUALITY:String  = "quality";
        private static const M_FPS:String      = "fps";
        private static const M_CACHE:String    = "cache";
        private static const M_RES:String      = "res";
        private static const M_EXIT:String     = "exit";
        // Resolução do jogo. 0 = nativa da tela; 100000+n = tamanho fixo "Modo PC" (RES_FIXED[n]),
        // centralizado com barras pretas se a proporção da tela for diferente.
        // O jogo foi feito para ~1250x650: abaixo disso as janelas dele ficam cortadas.
        private static const RES_BASE:int = 100000;
        // 200000+n = resolução "virtual" (RES_VIRT[n]): tenta dar ao palco exatamente esse tamanho
        // (SHOW_ALL) e confere o resultado; se o AIR não aceitar, volta ao Modo PC (ver verifyVirtual).
        private static const RES_VIRT_BASE:int = 200000;
        private static const RES_CUSTOM:int = 300000;     // "Personalizada": altura escolhida na barra (Prefs.customH)
        private static const CUSTOM_MIN:int = 650;
        private static const CUSTOM_MAX:int = 1080;
        private static const RES_OPTIONS:Array = [100000, 0];
        private static const RES_FIXED:Array = [[1352, 650]];
        private static const RES_VIRT:Array = [[1920, 1080, "Full HD"], [2560, 1440, "2K"]];
        private static const FPS_OPTIONS:Array = [15, 24, 30, 60, 120];
        private var bridge:Bridge;
        private var lastStatus:String = "";
        private var inGame:Boolean = false;
        private var platformIdx:int = 0;
        private var ui:Sprite = new Sprite();
        private var status:TextField;
        private var session:Object;
        private var port:int;
        private var fbIndex:int = 0;
        private var swfCandidates:Array = [];
        private var swfIdx:int = 0;
        private var okPath:String = "/client/Loading.swf";
        private static const BRAZIL_LEN:int = 244783;   // tamanho do Loading.swf do servidor do Brasil
        private var gameLoader:Loader;
        private var controls:Controls;
        private var macroPanel:MacroPanel;
        private var menuMode:String = M_PLATFORM;
        private var logLines:Array = [];
        private var zoomLevel:Number = 1;
        private var topTimer:Timer;
        private var bgLayer:Sprite = new Sprite();   // imagem de fundo + sombra (abaixo da UI)
        private var bgBmp:Bitmap;
        private var shade:Shape = new Shape();
        private var topW:Number = -1;
        private var topH:Number = -1;
        private var lastW:Number = -1;
        private var lastH:Number = -1;

        public function Main()
        {
            try { init(); }
            catch (err:Error) { fatal(String(err.message) + stackOf(err)); }
        }

        private function init():void
        {
            if (loaderInfo && loaderInfo.uncaughtErrorEvents)
                loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR, onUncaught);
            applyResolution();
            drawBg();
            bridge = new Bridge();
            initLogFile();
            SwfFixer.logger = log;
            SwfFixer.rootStage = stage;
            SwfFixer.fastNeg = Prefs.fastNeg;
            SwfFixer.install();
            SwfFixer.pruneOld();
            // Sem isto o AIR congela o jogo quando você sai do app (jogo desconecta).
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.NORMAL; } catch (eIdle:Error) {}
            try { NativeApplication.nativeApplication["executeInBackground"] = true; } catch (eBg:Error) { log("segundo plano: " + eBg.message); }
            stage.addEventListener(KeyboardEvent.KEY_DOWN, onKey, false, 100);
            // Em segundo plano o AIR derruba o frameRate (~4 fps) e o macro fica lento/parado.
            // Reaplica a taxa normal ao sair do app e de novo ao voltar.
            stage.addEventListener(Event.DEACTIVATE, onBgChange);
            stage.addEventListener(Event.ACTIVATE, onBgChange);
            platformIdx = Math.min(Prefs.platform, Platforms.LIST.length - 1);
            applyDisplayPrefs();
            bgLayer.addChild(shade);
            addChild(bgLayer);
            drawBg();
            addChild(ui);
            bridge.addEventListener("game", onGame);
            bridge.addEventListener("menu", onMenu);
            bridge.addEventListener("error", onError);
            log("Launcher iniciado. ANE: " + (bridge.available ? "ok" : "ausente (" + bridge.initError + ")"));
            stage.addEventListener(Event.RESIZE, onResize);
            applyResolution();
            applyDisplayPrefs();
            if (isVirtual()) setTimeout(function():void { verifyVirtual(false); }, 1500);
            showHome();
        }

        // Em alguns aparelhos o stage começa com tamanho 0; usa o tamanho real da tela nesse caso.
        private function sw():Number { return stage.stageWidth > 0 ? stage.stageWidth : stage.fullScreenWidth; }
        // Botões maiores em telas de muitos pixels (e menores se a resolução do jogo for reduzida).
        private function uiScale():Number { return Math.max(1, Math.min(2.5, sh() / 650)); }
        private function sh():Number { return stage.stageHeight > 0 ? stage.stageHeight : stage.fullScreenHeight; }

        // Fundo base (degradê preto/vinho). Fora do palco (barras do Modo PC) as cores
        // continuam iguais às pontas do degradê, então não aparece emenda.
        private function drawBg():void
        {
            // Dentro do jogo o fundo do menu sai de cena: o mapa do jogo é desenhado ATRÁS do app e a imagem o cobria.
            if (inGame) { bgLayer.visible = false; graphics.clear(); return; }
            bgLayer.visible = true;
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            var g:Graphics = graphics;
            g.clear();
            g.beginFill(0x0A0A0A); g.drawRect(-4096, -4096, w + 8192, h + 8192); g.endFill();
            layoutBg();
        }

        // Carrega a imagem de fundo empacotada no app (assets/fundo.jpg).
        private function loadBgImage():void
        {
            try
            {
                var l:Loader = new Loader();
                l.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void {
                    try
                    {
                        bgBmp = Bitmap(l.content);
                        bgBmp.smoothing = true;
                        bgLayer.addChildAt(bgBmp, 0);
                        layoutBg();
                    }
                    catch (e2:Error) { log("Fundo: " + e2.message); }
                });
                l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(e:IOErrorEvent):void { log("Fundo: " + e.text); });
                l.load(new URLRequest("app:/assets/fundo.jpg"));
            }
            catch (err:Error) { log("Fundo: " + err.message); }
        }

        // A imagem preenche a tela toda (sem distorcer, cortando o excesso) e recebe uma sombra
        // mais escura à esquerda, onde ficam os botões, para o texto ficar legível.
        private function layoutBg():void
        {
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            bgLayer.scrollRect = new Rectangle(0, 0, w, h);   // não vaza para as barras do Modo PC
            if (bgBmp && bgBmp.bitmapData)
            {
                var sc:Number = Math.max(w / bgBmp.bitmapData.width, h / bgBmp.bitmapData.height);
                bgBmp.scaleX = bgBmp.scaleY = sc;
                bgBmp.x = (w - bgBmp.bitmapData.width * sc) / 2;
                bgBmp.y = (h - bgBmp.bitmapData.height * sc) / 2;
            }
            shade.graphics.clear();   // área de trabalho lisa (sem sombra sobre imagem)
        }

        private function onResize(e:Event):void
        {
            if (sw() == lastW && sh() == lastH) return;
            lastW = sw(); lastH = sh();
            drawBg();
            if (!inGame) showHome();
            else if (controls) controls.layout(sw(), uiScale(), sh());
        }

        private function stackOf(err:Error):String
        {
            var st:String = err.getStackTrace();
            return st ? "\n" + st : "";
        }

        private function onUncaught(e:UncaughtErrorEvent):void
        {
            var m:String = (e.error is Error) ? (Error(e.error).message + stackOf(Error(e.error))) : String(e.error);
            log("ERRO: " + m);
            if (!inGame) { e.preventDefault(); fatal(m); }
        }

        // Mostra o erro na tela (fundo amarelo) em vez de ficar branco sem explicação.
        private function fatal(msg:String):void
        {
            try
            {
                var tf:TextField = new TextField();
                tf.defaultTextFormat = new TextFormat("_sans", 22, 0x000000);
                tf.background = true; tf.backgroundColor = 0xFFEE00;
                tf.multiline = true; tf.wordWrap = true;
                tf.x = 20; tf.y = 20;
                tf.width = Math.max(300, sw() - 40);
                tf.text = "ERRO NO LAUNCHER:\n" + msg;
                addChild(tf);
            }
            catch (e2:Error) {}
        }

        // ---------- log ----------
        public function log(s:String):void
        {
            var d:Date = new Date();
            var line:String = pad(d.hours) + ":" + pad(d.minutes) + ":" + pad(d.seconds) + "  " + s;
            logLines.push(line);
            if (logLines.length > 400) logLines.shift();
            logBuf.push(line);
        }

        // Log em arquivo: sobrevive ao fechar/reabrir o app. launcher.log = sessão atual, launcher_prev.log = a anterior.
        private var logBuf:Array = [];
        private var logTimer:Timer;
        private var prevLog:String = "";
        private function logDir():File { return File.applicationStorageDirectory; }
        private function initLogFile():void
        {
            try
            {
                var cur:File = logDir().resolvePath("launcher.log");
                var prev:File = logDir().resolvePath("launcher_prev.log");
                if (cur.exists && cur.size > 0)
                {
                    var b:ByteArray = readFile(cur);
                    var t:String = b.readUTFBytes(b.length);
                    if (t.length > 60000) t = t.substring(t.length - 60000);   // só o final
                    prevLog = t;
                    cur.moveTo(prev, true);
                }
            }
            catch (e:Error) {}
            logTimer = new Timer(2000);
            logTimer.addEventListener(TimerEvent.TIMER, flushLog);
            logTimer.start();
        }
        private function flushLog(e:TimerEvent = null):void
        {
            if (logBuf.length == 0) return;
            var txt:String = logBuf.join("\n") + "\n";
            logBuf = [];
            try
            {
                var f:File = logDir().resolvePath("launcher.log");
                if (f.exists && f.size > 400000) f.deleteFile();           // limite de tamanho
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.APPEND);
                fs.writeUTFBytes(txt);
                fs.close();
            }
            catch (err:Error) {}
        }
        private function prevLogText():String
        {
            return prevLog.length ? "\n\n----- SESSÃO ANTERIOR (antes de reabrir o app) -----\n" + prevLog : "";
        }
        private function pad(n:int):String { return n < 10 ? "0" + n : String(n); }

        private function onBgChange(e:Event):void
        {
            // Respeita exatamente a preferência do usuário ao alternar de foco.
            try { stage.frameRate = Prefs.fps; } catch (err:Error) {}
            try { NativeApplication.nativeApplication.systemIdleMode = (inGame && e.type == Event.ACTIVATE) ? SystemIdleMode.KEEP_AWAKE : SystemIdleMode.NORMAL; } catch (err2:Error) {}
            try { NativeApplication.nativeApplication["executeInBackground"] = true; } catch (err3:Error) {}
        }

        // ---------- preferências de exibição ----------
        private var lastRequestedHz:int = -1;
        private function applyDisplayPrefs():void
        {
            stage.quality = Prefs.quality;     // StageQuality.LOW / MEDIUM / HIGH
            stage.frameRate = Prefs.fps;
            // Pede à tela do aparelho a taxa mais próxima (60 / 90 / 120 Hz...).
            try
            {
                if (bridge && bridge.available && lastRequestedHz != Prefs.fps)
                {
                    bridge.setRefreshRate(Prefs.fps);
                    lastRequestedHz = Prefs.fps;
                }
            }
            catch (err:Error) {}
        }

        // Texto com a taxa de atualização real da tela (ex.: "120 Hz"), para o menu e o log.
        private function hzText():String
        {
            try
            {
                var hz:Number = (bridge && bridge.available) ? bridge.displayHz() : 0;
                if (hz > 0) return Math.round(hz) + " Hz";
            }
            catch (err:Error) {}
            return "? Hz";
        }

        // =====================================================================
        //  TELAS (preto + laranja)
        //   home        -> título + dois cartões: Legend Online / Legend Remake
        //   online/remake -> contas salvas daquele servidor + "+ Adicionar conta"
        //   remakeLogin -> usuário/senha do Remake (entrar ou criar conta)
        //  Desenhado numa área de 1000x560 e escalado para caber em qualquer tela.
        // =====================================================================
        private var screen:String = "home";
        private var remMode:String = "login";       // login | register
        private var remUserText:String = "";
        private var remPassText:String = "";
        private var remMsgText:String = "";
        private var remUserTf:TextField;
        private var remPassTf:TextField;
        private var remPass2Tf:TextField;
        private var remMsg:TextField;
        private var remBusy:Boolean = false;
        private var curRemakeUser:String = "";      // conta do Remake que está em jogo (para Relogar)

        private function showHome():void
        {
            // guarda o que foi digitado antes de redesenhar (ex.: ao girar a tela)
            if (screen == "remakeLogin")
            {
                if (remUserTf != null) remUserText = remUserTf.text;
                if (remPassTf != null) remPassText = remPassTf.text;
            }
            remUserTf = null; remPassTf = null; remPass2Tf = null; remMsg = null;

            while (ui.numChildren) ui.removeChildAt(0);
            var s:Number = Math.max(0.5, Math.min(sh() / 560, sw() / 1000, 2.5));
            var box:Sprite = new Sprite();
            box.scaleX = box.scaleY = s;
            box.x = (sw() - 1000 * s) / 2;
            box.y = (sh() - 560 * s) / 2;
            ui.addChild(box);

            if (screen == "online") buildServer(box, false);
            else if (screen == "remake") buildServer(box, true);
            else if (screen == "remakeLogin") buildRemakeLogin(box);
            else buildHome(box);

            // linha de status (rodapé)
            status = new TextField();
            var sf:TextFormat = new TextFormat("_sans", 14, C_MUTED, false);
            sf.align = "center";
            status.defaultTextFormat = sf;
            status.width = 800; status.height = 22; status.x = 100; status.y = 524;
            status.multiline = false; status.wordWrap = false;
            status.selectable = false; status.mouseEnabled = false;
            status.text = lastStatus != "" ? lastStatus : (bridge.available ? "" : "ANE indisponível: " + bridge.initError);
            paintStatus();
            box.addChild(status);
            var ver:TextField = Win.label(box, VERSION, 11, 0x555555, 0, 538);
            ver.x = 990 - ver.width;
        }

        private function goScreen(name:String):void { screen = name; accOffset = 0; delPending = ""; showHome(); }

        // ---------- peças ----------
        private function linkText(parent:Sprite, t:String, size:int, color:uint, x:Number, y:Number, fn:Function, bold:Boolean = false):Sprite
        {
            var b:Sprite = new Sprite();
            var tf:TextField = Win.label(b, t, size, color, 0, 0, bold);
            b.graphics.beginFill(0xFFFFFF, 0);
            b.graphics.drawRect(-14, -12, tf.width + 28, tf.height + 24);
            b.graphics.endFill();
            b.x = x; b.y = y;
            b.mouseChildren = false; b.buttonMode = true;
            b.addEventListener(MouseEvent.CLICK, fn);
            parent.addChild(b);
            return b;
        }

        private function bigBtn(parent:Sprite, t:String, x:Number, y:Number, w:Number, h:Number, filled:Boolean, fn:Function):Sprite
        {
            var b:Sprite = new Sprite();
            Win.card(b, 0, 0, w, h, 14, filled ? C_OR : C_CARD, C_OR);
            var tf:TextField = Win.label(b, t, 18, filled ? 0x000000 : 0xFFFFFF, 0, 0, true);
            tf.x = (w - tf.width) / 2; tf.y = (h - tf.height) / 2;
            b.x = x; b.y = y;
            b.mouseChildren = false; b.buttonMode = true;
            b.addEventListener(MouseEvent.CLICK, fn);
            parent.addChild(b);
            return b;
        }

        private function rowBtn(t:String, x:Number, w:Number, color:uint, fn:Function):Sprite
        {
            var b:Sprite = new Sprite();
            b.x = x; b.y = 16;
            Win.card(b, 0, 0, w, 34, 10, 0x1E1E1E, C_LINE);
            var tf:TextField = Win.label(b, t, 13, color, 0, 0, true);
            tf.x = (w - tf.width) / 2; tf.y = (34 - tf.height) / 2;
            b.mouseChildren = false; b.buttonMode = true;
            b.addEventListener(MouseEvent.CLICK, fn);
            return b;
        }

        private function serverCard(name:String, caption:String, count:int, x:Number, y:Number, target:String):Sprite
        {
            var c:Sprite = new Sprite();
            c.x = x; c.y = y;
            Win.card(c, 0, 0, 400, 230, 20, C_CARD, C_LINE);
            c.graphics.lineStyle(0, 0, 0);
            c.graphics.beginFill(C_OR, 1);
            c.graphics.drawRoundRect(28, 34, 5, 62, 5, 5);
            c.graphics.endFill();
            Win.fitLabel(c, name, 32, 0xFFFFFF, 50, 30, 330, true);
            Win.label(c, caption, 15, C_MUTED, 50, 76);
            Win.label(c, count == 0 ? "Nenhuma conta salva" : (count == 1 ? "1 conta salva" : count + " contas salvas"), 13, C_MUTED, 28, 130);
            var go:Sprite = new Sprite();
            Win.card(go, 0, 0, 344, 46, 14, C_OR, C_OR);
            var gt:TextField = Win.label(go, "ENTRAR", 16, 0x000000, 0, 0, true);
            gt.x = (344 - gt.width) / 2; gt.y = (46 - gt.height) / 2;
            go.x = 28; go.y = 164;
            c.addChild(go);
            c.mouseChildren = false; c.buttonMode = true;
            c.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { goScreen(target); });
            return c;
        }

        private function makeField(parent:Sprite, x:Number, y:Number, w:Number, password:Boolean, text:String):TextField
        {
            Win.card(parent, x, y, w, 48, 12, C_CARD, 0x3A3A3A);
            var tf:TextField = new TextField();
            tf.type = TextFieldType.INPUT;
            tf.defaultTextFormat = new TextFormat("_sans", 20, 0xFFFFFF, true);
            tf.width = w - 24; tf.height = 30; tf.x = x + 12; tf.y = y + 9;
            tf.maxChars = 64;
            tf.displayAsPassword = password;
            tf.needsSoftKeyboard = true;
            tf.text = text;
            tf.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                try { stage.focus = tf; tf.requestSoftKeyboard(); } catch (eK:Error) {}
            });
            parent.addChild(tf);
            return tf;
        }

        // ---------- tela inicial ----------
        private function buildHome(box:Sprite):void
        {
            var title:TextField = Win.label(box, "LEGEND", 58, C_OR, 0, 44, true);
            title.x = 500 - title.width / 2;
            box.graphics.beginFill(C_OR, 1);
            box.graphics.drawRoundRect(470, 128, 60, 4, 4, 4);
            box.graphics.endFill();
            var sub:TextField = Win.label(box, "Escolha onde jogar", 16, C_MUTED, 0, 146);
            sub.x = 500 - sub.width / 2;

            var all:Array = Prefs.accounts();
            var nOnline:int = 0;
            var nRemake:int = 0;
            for (var ci:int = 0; ci < all.length; ci++)
            {
                if (all[ci].remake === true) nRemake++; else nOnline++;
            }
            box.addChild(serverCard("Legend Online", "Servidor original", nOnline, 90, 196, "online"));
            box.addChild(serverCard("Legend Remake", "Servidor Remake", nRemake, 510, 196, "remake"));

            linkText(box, "Configurações", 15, C_MUTED, 385, 456, settingsTapped);
            linkText(box, "Ver log", 15, C_MUTED, 535, 456, logTapped);
        }

        // ---------- contas de um servidor ----------
        private function buildServer(box:Sprite, isRemake:Boolean):void
        {
            linkText(box, "‹ Voltar", 18, C_OR, 24, 26, function(e:MouseEvent):void { goScreen("home"); }, true);
            var title:TextField = Win.label(box, isRemake ? "LEGEND REMAKE" : "LEGEND ONLINE", 30, C_OR, 0, 20, true);
            title.x = 500 - title.width / 2;

            var all:Array = Prefs.accounts();
            var list:Array = [];
            for (var ai:int = 0; ai < all.length; ai++)
                if ((all[ai].remake === true) == isRemake) list.push(all[ai]);
            var per:int = 4;
            if (accOffset >= list.length) accOffset = 0;
            if (list.length > per)
            {
                var pages:int = int(Math.ceil(list.length / per));
                linkText(box, (int(accOffset / per) + 1) + "/" + pages + "  ›", 16, C_OR, 880, 28,
                    function(e:MouseEvent):void { accOffset = (accOffset + per < list.length) ? accOffset + per : 0; showHome(); }, true);
            }
            if (list.length == 0)
                Win.wrapLabel(box, "Nenhuma conta salva ainda. Toque em + Adicionar conta.", 16, C_MUTED, 150, 150, 700, 3);

            for (var k:int = accOffset; k < list.length && k < accOffset + per; k++)
            {
                var acc:Object = list[k];
                var id:String = String(acc.id);
                var row:Sprite = new Sprite();
                row.x = 150; row.y = 96 + (k - accOffset) * 76;
                var arm:Boolean = (delPending == id);
                Win.card(row, 0, 0, 700, 66, 16, C_CARD, arm ? 0xFF5A4D : C_LINE);
                var mainW:Number = 540;
                var main:Sprite = new Sprite();
                main.graphics.beginFill(0xFFFFFF, 0); main.graphics.drawRect(0, 0, mainW, 66); main.graphics.endFill();
                Win.fitLabel(main, accName(acc), 20, 0xFFFFFF, 20, 10, mainW - 40, true);
                var subTxt:String = isRemake ? "Toque para entrar"
                    : ("ID " + acc.name + "  -  " + (acc.serverHost != undefined ? String(acc.serverHost) : serverName(int(acc.platform))));
                Win.fitLabel(main, subTxt, 12, C_MUTED, 20, 38, mainW - 40);
                main.mouseChildren = false; main.buttonMode = true;
                main.addEventListener(MouseEvent.CLICK, makeAccEnter(id));
                row.addChild(main);
                row.addChild(rowBtn("Nome", 560, 76, C_OR, makeAccRename(id)));
                row.addChild(rowBtn(arm ? "?" : "x", 644, 44, arm ? 0xFF5A4D : C_MUTED, makeAccDel(id)));
                box.addChild(row);
            }

            bigBtn(box, "+ Adicionar conta", 150, 410, 700, 56, true,
                function(e:MouseEvent):void { if (isRemake) openRemakeLogin("login"); else newAccount(); });
        }

        // ---------- Legend Remake: login ----------
        private function openRemakeLogin(mode:String):void
        {
            remMode = mode; remMsgText = "";
            screen = "remakeLogin";
            showHome();
        }

        private function buildRemakeLogin(box:Sprite):void
        {
            var reg:Boolean = (remMode == "register");
            linkText(box, "‹ Voltar", 18, C_OR, 24, 26, function(e:MouseEvent):void { remPassText = ""; remMsgText = ""; goScreen("remake"); }, true);
            var title:TextField = Win.label(box, reg ? "CRIAR CONTA" : "ENTRAR NO REMAKE", 28, C_OR, 0, 22, true);
            title.x = 500 - title.width / 2;
            linkText(box, reg ? "Já tenho conta" : "Criar conta", 15, C_MUTED, 800, 30,
                function(e:MouseEvent):void { remPassText = ""; openRemakeLogin(reg ? "login" : "register"); });

            Win.label(box, "Usuário", 13, C_MUTED, 300, 84);
            remUserTf = makeField(box, 300, 106, 400, false, remUserText);
            Win.label(box, "Senha", 13, C_MUTED, 300, 166);
            remPassTf = makeField(box, 300, 188, 400, true, remPassText);
            var by:Number = 262;
            if (reg)
            {
                Win.label(box, "Repita a senha", 13, C_MUTED, 300, 248);
                remPass2Tf = makeField(box, 300, 270, 400, true, "");
                by = 342;
            }
            bigBtn(box, reg ? "Criar conta" : "Entrar", 300, by, 400, 54, true,
                function(e:MouseEvent):void { remakeSubmit(reg ? "register" : "login"); });
            remMsg = Win.wrapLabel(box, remMsgText, 14, 0xFF6B4D, 300, by + 66, 400, 3);
        }

        private function setRemMsg(msg:String, isError:Boolean):void
        {
            remMsgText = msg;
            if (remMsg != null) { remMsg.text = msg; remMsg.textColor = isError ? 0xFF6B4D : C_MUTED; }
        }

        // =====================================================================
        //  LEGEND REMAKE (igual ao app oficial do Remake)
        //   1) POST {REMAKE}/launcher/api/login|register {username,password,target:"web"} -> {ok,username,ticket}
        //      contas salvas: /launcher/api/resume {username,ticket}. A senha NUNCA é salva.
        //   2) GET {REMAKE}/client/Loading.swf e carrega com user/key/site/logintype/config...
        // =====================================================================
        private function remakeSubmit(action:String):void
        {
            if (remBusy || remUserTf == null || remPassTf == null) return;
            var user:String = remUserTf.text.replace(/^\s+|\s+$/g, "");
            var pass:String = remPassTf.text;
            if (user.length == 0 || pass.length == 0) { setRemMsg("Preencha usuário e senha.", true); return; }
            if (action == "register" && remPass2Tf != null && remPass2Tf.text != pass)
            { setRemMsg("As senhas não conferem.", true); return; }
            setRemMsg(action == "register" ? "Criando a conta..." : "Entrando...", false);
            remakeApi(action, {username: user, password: pass, target: "web"},
                function(r:Object):void {
                    remPassText = "";
                    if (remPassTf != null) remPassTf.text = "";
                    if (remPass2Tf != null) remPass2Tf.text = "";
                    var u:String = r.username ? String(r.username) : user;
                    saveRemakeAccount(u, String(r.ticket));
                    remakeStart(u, String(r.ticket));
                },
                function(err:String, net:Boolean):void { setRemMsg(err, true); });
        }

        // Toque numa conta salva do Remake: renova o ticket e entra (sem pedir senha).
        private function remakeResume(acc:Object):void
        {
            if (remBusy) return;
            var user:String = String(acc.user != undefined ? acc.user : acc.name);
            setStatus("Entrando como " + user + "...");
            remakeApi("resume", {username: user, ticket: String(acc.ticket)},
                function(r:Object):void {
                    var u:String = r.username ? String(r.username) : user;
                    saveRemakeAccount(u, String(r.ticket));
                    remakeStart(u, String(r.ticket));
                },
                function(err:String, net:Boolean):void {
                    if (net) { setStatus(err); return; }
                    // ticket recusado: pede a senha de novo
                    remUserText = user; remPassText = ""; remMode = "login";
                    remMsgText = err;
                    screen = "remakeLogin";
                    showHome();
                });
        }

        private function remakeApi(action:String, body:Object, onOk:Function, onFail:Function):void
        {
            if (remBusy) return;
            remBusy = true;
            var code:int = 0;
            var req:URLRequest = new URLRequest(REMAKE + "/launcher/api/" + action);
            req.method = URLRequestMethod.POST;
            req.contentType = "application/json";
            req.requestHeaders = [new URLRequestHeader("Accept", "application/json")];
            req.data = JSON.stringify(body);

            var l:URLLoader = new URLLoader();
            var parse:Function = function():Object {
                try { return JSON.parse(String(l.data)); } catch (errP:Error) {}
                return null;
            };
            l.addEventListener(HTTPStatusEvent.HTTP_STATUS, function(ev:HTTPStatusEvent):void { code = ev.status; });
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                remBusy = false;
                var r:Object = parse();
                if (r != null && r.ok && r.ticket) onOk(r);
                else onFail(r != null && r.error ? String(r.error) : "Resposta inválida do servidor.", false);
            });
            var netFail:Function = function(ev:Event):void {
                remBusy = false;
                log("Remake " + action + ": HTTP " + code + " | " + ev);
                var r2:Object = parse();   // o servidor pode mandar o motivo junto com o erro HTTP
                if (r2 != null && r2.error) { onFail(String(r2.error), false); return; }
                if (code >= 400 && code < 500)
                {
                    onFail(action == "register" ? "Não foi possível criar a conta (usuário já existe ou dados inválidos)."
                        : (action == "resume" ? "Sessão expirada. Entre de novo com a senha." : "Usuário ou senha incorretos."), false);
                    return;
                }
                onFail("Sem conexão com o servidor. Confira a internet e tente de novo.", true);
            };
            l.addEventListener(IOErrorEvent.IO_ERROR, netFail);
            l.addEventListener(SecurityErrorEvent.SECURITY_ERROR, netFail);
            l.load(req);
        }

        private function remakeStart(user:String, ticket:String):void
        {
            setRemMsg("Baixando o jogo...", false);
            setStatus("Baixando o jogo do Remake...");
            var params:Object = {
                user: user,
                key: ticket,
                site: "broas_0905",
                logintype: "4",
                p2: "",
                rid: "",
                config: REMAKE + "/client/config.xml?user=" + encodeURIComponent(user)
            };
            var loader:URLLoader = new URLLoader();
            loader.dataFormat = URLLoaderDataFormat.BINARY;
            loader.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var bytes:ByteArray = ByteArray(loader.data);
                log("Remake: Loading.swf " + bytes.length + " bytes");
                if (bytes.length < 1000 || !isSwf(bytes))
                {
                    setStatus("Erro: o servidor do Remake não devolveu o jogo.");
                    setRemMsg("O servidor não devolveu o jogo. Tente de novo.", true);
                    return;
                }
                curRemakeUser = user;
                remPassText = "";
                applyResolution();
                bridge.keepAlive(true);
                try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE; } catch (eIdle:Error) {}
                setStatus("Carregando o jogo...");
                startGame(bytes, params);
            });
            loader.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                log("Remake: falha ao baixar o jogo: " + ev.text);
                setStatus("Erro: não deu para baixar o jogo do Remake.");
                setRemMsg("Não deu para baixar o jogo. Confira a internet e tente de novo.", true);
            });
            loader.load(new URLRequest(REMAKE + "/client/Loading.swf?v=" + new Date().time));
        }

        // Guarda só usuário + ticket (nunca a senha), junto das outras contas.
        private function saveRemakeAccount(user:String, ticket:String):void
        {
            var id:String = "remake:" + user.toLowerCase();
            var old:Object = findAccount(id);
            Prefs.saveAccount({
                id: id, name: user, user: user, ticket: ticket, remake: true,
                label: (old != null && old.label != undefined ? String(old.label) : ""),
                platform: 0, host: REMAKE, serverHost: REMAKE,
                savedAt: new Date().time
            });
            log("Conta do Remake salva: " + user);
        }

        // Carrega o ícone do app (assets/icons/icon512.png) dentro de 'holder', com 'size' px de lado.
        private function loadLogo(holder:Sprite, size:Number):void
        {
            try
            {
                var l:Loader = new Loader();
                l.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void {
                    try
                    {
                        var bm:Bitmap = Bitmap(l.content);
                        bm.smoothing = true;
                        bm.width = size; bm.height = size;
                        holder.addChild(bm);
                    }
                    catch (e2:Error) { log("Logo: " + e2.message); }
                });
                l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(e:IOErrorEvent):void { log("Logo: " + e.text); });
                l.load(new URLRequest("app:/assets/icons/icon512.png"));
            }
            catch (err:Error) { log("Logo: " + err.message); }
        }

        // Mensagens de erro ficam em amarelo; o resto em branco.
        private function paintStatus():void
        {
            if (!status) return;
            status.textColor = /erro|falha|faltam|indispon/i.test(status.text) ? 0xFF6B4D : C_MUTED;
        }

        private function setStatus(s:String):void { lastStatus = s; if (status) { status.text = s; paintStatus(); } log(s); }

        // ---------- contas salvas ----------
        private var accOffset:int = 0;
        private var delPending:String = "";
        private var delTimer:Timer;

        private function accName(acc:Object):String
        {
            var l:String = acc.label != undefined ? String(acc.label) : "";
            return l != "" ? l : String(acc.name);
        }

        private function accButton(t:String, x:Number, w:Number, color:uint, fn:Function):Sprite
        {
            var b:Sprite = new Sprite();
            b.x = x; b.y = 7;
            Win.card(b, 0, 0, w, 28, 8, 0x262626, Win.LINE);
            var tf:TextField = Win.label(b, t, 11, color, 0, 6, true);
            tf.x = (w - tf.width) / 2;
            b.mouseChildren = false; b.buttonMode = true;
            b.addEventListener(MouseEvent.CLICK, fn);
            return b;
        }

        private function makeAccRename(id:String):Function { return function(e:MouseEvent):void { openRename(id); }; }

        // Janela para dar um nome (apelido) à conta.
        private var renamePanel:Sprite;
        private var renameInput:TextField;
        private function openRename(id:String):void
        {
            var acc:Object = findAccount(id);
            if (acc == null) return;
            closeRename();
            renamePanel = new Sprite();
            renamePanel.graphics.beginFill(0x000000, 0.72);
            renamePanel.graphics.drawRect(0, 0, sw(), sh());
            renamePanel.graphics.endFill();
            var card:Sprite = new Sprite();
            card.scaleX = card.scaleY = uiScale();
            card.x = sw() / 2; card.y = sh() * 0.32;
            Win.card(card, -190, -80, 380, 190, 18, 0x212121, 0x5A5A5A);
            Win.label(card, "Nome da conta", 16, 0xFFFFFF, -170, -68, true);
            Win.fitLabel(card, "ID: " + acc.name, 11, Btn.TEXT_MUTED, -170, -44, 340);
            Win.card(card, -172, -20, 344, 38, 10, 0x141414, Btn.ACCENT_LIGHT);
            renameInput = new TextField();
            renameInput.type = TextFieldType.INPUT;
            renameInput.defaultTextFormat = new TextFormat("_sans", 16, 0xFFFFFF, true);
            renameInput.width = 324; renameInput.height = 26; renameInput.x = -162; renameInput.y = -14;
            renameInput.maxChars = 24;
            renameInput.text = acc.label != undefined ? String(acc.label) : "";
            card.addChild(renameInput);
            var cancel:Btn = new Btn(Btn.GHOST, 150, 40, "Cancelar", "", function(e:MouseEvent):void { closeRename(); });
            cancel.x = -90; cancel.y = 70;
            card.addChild(cancel);
            var save:Btn = new Btn(Btn.PRIMARY, 150, 40, "Salvar", "", function(e:MouseEvent):void { saveRename(id); });
            save.x = 90; save.y = 70;
            card.addChild(save);
            renamePanel.addChild(card);
            stage.addChild(renamePanel);
            try { stage.focus = renameInput; renameInput.requestSoftKeyboard(); } catch (eK:Error) {}
        }
        private function closeRename():void
        {
            try { if (renamePanel != null && renamePanel.parent != null) renamePanel.parent.removeChild(renamePanel); } catch (e:Error) {}
            renamePanel = null; renameInput = null;
        }
        private function saveRename(id:String):void
        {
            var acc:Object = findAccount(id);
            var t:String = renameInput != null ? renameInput.text.replace(/^\s+|\s+$/g, "") : "";
            closeRename();
            if (acc == null) return;
            acc.label = t;
            Prefs.saveAccount(acc);
            setStatus(t != "" ? "Conta renomeada: " + t : "Nome removido (volta a mostrar o ID).");
            if (!inGame) showHome();
        }

        private function serverName(i:int):String
        {
            try { return String(Platforms.LIST[i][0]); } catch (e:Error) {}
            return "";
        }

        private function makeAccEnter(id:String):Function { return function(e:MouseEvent):void { enterAccount(id); }; }
        private function makeAccSite(id:String):Function { return function(e:MouseEvent):void { openAccountSite(id); }; }
        private function makeAccDel(id:String):Function
        {
            return function(e:MouseEvent):void
            {
                if (delPending == id)
                {
                    Prefs.removeAccount(id); delPending = "";
                    setStatus("Conta removida.");
                    showHome();
                    return;
                }
                delPending = id;
                if (delTimer != null) delTimer.stop();
                delTimer = new Timer(3000, 1);
                delTimer.addEventListener(TimerEvent.TIMER_COMPLETE, function(ev:TimerEvent):void { delPending = ""; if (!inGame) showHome(); });
                delTimer.start();
                setStatus("Toque em ? de novo para remover a conta.");
                showHome();
            };
        }

        private function findAccount(id:String):Object
        {
            var list:Array = Prefs.accounts();
            for (var i:int = 0; i < list.length; i++) if (String(list[i].id) == id) return list[i];
            return null;
        }

        // Toque na conta: entra direto no jogo com a sessão guardada (sem abrir o site).
        private function enterAccount(id:String):void
        {
            var acc:Object = findAccount(id);
            if (acc == null) return;
            if (acc.remake === true) { remakeResume(acc); return; }
            // Online: a key guardada na conta o servidor recusa ("Falha do Login"). Então o toque renova a sessão pelo site,
            // com os cookies dessa conta, e entra no servidor salvo; a tela "Entrando no jogo..." cobre a página.
            openAccountSite(id);
        }

        // Botão "site": abre o site do servidor já logado com os cookies dessa conta (renova a sessão guardada).
        private function openAccountSite(id:String):void
        {
            var acc:Object = findAccount(id);
            if (acc == null) return;
            platformIdx = int(acc.platform); Prefs.platform = platformIdx;
            setStatus("Entrando com " + accName(acc) + " (renovando a sessão no site)...");
            bridge.login(String(acc.host), acc.cookies ? String(acc.cookies) : "", acc.serverHost != undefined ? String(acc.serverHost) : (acc.session ? String(JSON.parse(String(acc.session)).host) : ""));
        }

        // + Nova conta: apaga a sessão atual do site e abre o login limpo (a conta fica salva ao entrar).
        private function newAccount():void
        {
            bridge.clearSession();
            setStatus("Abrindo login de uma nova conta...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        // ---------- ações da tela inicial ----------
        private function chooseTapped(e:MouseEvent):void { openPlatformMenu(); }

        private function openPlatformMenu():void
        {
            var names:Array = [];
            for each (var p:Array in Platforms.LIST) names.push(p[0]);
            menuMode = M_PLATFORM;
            bridge.showMenu("Escolha a plataforma", names);
        }

        private function settingsTapped(e:MouseEvent):void { openSettings(); }

        private function playTapped(e:MouseEvent):void
        {
            setStatus("Abrindo login...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        private function logoutTapped(e:MouseEvent):void { logout(); }

        private function logTapped(e:MouseEvent):void { bridge.showText("Log", logLines.join("\n") + prevLogText()); }

        private function logout():void
        {
            bridge.clearSession();
            setStatus("Sessão apagada.");
        }

        private function onError(e:StatusEvent):void { setStatus("Erro: " + e.level); }

        // ---------- menu nativo (um evento só, roteado por menuMode) ----------
        private function onMenu(e:StatusEvent):void
        {
            var i:int = int(e.level);
            switch (menuMode)
            {
                case M_PLATFORM:
                    if (i >= 0 && i < Platforms.LIST.length)
                    {
                        platformIdx = i; Prefs.platform = i;
                        if (gameLoader) { bridge.restartApp(); } else { showHome(); }
                    }
                    break;
                case M_SETTINGS: onSettingsChoice(i); break;
                case M_QUALITY:
                    Prefs.quality = ["LOW", "MEDIUM", "HIGH"][i];
                    applyDisplayPrefs(); log("Qualidade: " + Prefs.quality);
                    break;
                case M_FPS:
                    if (i >= 0 && i < FPS_OPTIONS.length)
                    {
                        Prefs.fps = FPS_OPTIONS[i];
                        applyDisplayPrefs();
                        setTimeout(function():void { log("FPS: " + Prefs.fps + " | tela do aparelho: " + hzText()); }, 1200);
                        if (Prefs.fps > 60) bridge.showText("FPS " + Prefs.fps,
                            "O app pede " + Prefs.fps + " FPS e a tela do aparelho em " + hzText() + ".\n\n" +
                            "Só aparece diferença se a tela do aparelho suportar essa taxa (ative o modo de 120 Hz nas configurações de tela do Android). " +
                            "Se o jogo for feito para 30 FPS, as animações podem ficar mais rápidas.");
                    }
                    break;
                case M_CACHE:
                    if (i == 0) clearCache();
                    else if (i == 1)
                    {
                        Prefs.fastNeg = !Prefs.fastNeg;
                        SwfFixer.fastNeg = Prefs.fastNeg;
                        log("Atalho para imagens inexistentes: " + (Prefs.fastNeg ? "ligado" : "desligado"));
                    }
                    break;
                case M_RES:
                    if (i >= 0 && i < RES_OPTIONS.length && RES_OPTIONS[i] == RES_CUSTOM) { openSlider(); break; }
                    if (i >= 0 && i < RES_OPTIONS.length)
                    {
                        Prefs.resHeight = RES_OPTIONS[i];
                        applyResolution();
                        if (isVirtual()) setTimeout(function():void { verifyVirtual(true); }, 900);
                        if (!inGame) showHome();
                        else bridge.showText("Resolução", "Para o jogo se reorganizar por completo, use Configurações > Voltar à tela inicial e entre de novo.");
                    }
                    break;
                case M_EXIT:
                    if (i == 0) { log("Indo para segundo plano"); flushLog(); bridge.toBackground(); }
                    else if (i == 1) { exitCompletely(); }
                    break;
            }
        }

        // Encerramento explícito: não confundir com mandar para segundo plano.
        private function exitCompletely():void
        {
            try { closeGame(); } catch (eGame:Error) {}
            try { if (logTimer != null) logTimer.stop(); } catch (eLog:Error) {}
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.NORMAL; } catch (eIdle:Error) {}
            try { flushLog(); } catch (eFlush:Error) {}
            try { bridge.shutdown(); } catch (eShutdown:Error) {}
            NativeApplication.nativeApplication.exit();
        }

        private function openSettings():void
        {
            menuMode = M_SETTINGS;
            bridge.showMenu("Configurações", [
                "Resolução (" + resLabel(Prefs.resHeight) + ")",
                "Qualidade gráfica (" + Prefs.quality + ")",
                "FPS (" + Prefs.fps + ")",
                "Cache do jogo",
                "Mostrar log",
                "Voltar à tela inicial",
                "Sair do app",
                "Relogar (recarregar o jogo)"
            ]);
        }

        private function onSettingsChoice(i:int):void
        {
            switch (i)
            {
                case 0: openResolutionMenu(); break;
                case 1: menuMode = M_QUALITY; bridge.showMenu("Qualidade gráfica", ["Baixa", "Média", "Alta"]); break;
                case 2: openFpsMenu(); break;
                case 3:
                    menuMode = M_CACHE;
                    bridge.showMenu("Cache do jogo (" + cacheSizeText() + ")", ["Apagar cache",
                        "Atalho p/ imagens inexistentes: " + (Prefs.fastNeg ? "LIGADO" : "desligado"), "Voltar"]);
                    break;
                case 4: bridge.showText("Log", logLines.join("\n") + prevLogText()); break;
                case 5: backToHome(); break;
                case 6: askExit(); break;
                case 7: relog(); break;
            }
        }

        // Relogar: fecha o jogo atual e entra de novo com um login novo (sem reiniciar o app).
        private function relog():void
        {
            if (!inGame || gameLoader == null) { log("Relogar: o jogo não está aberto."); return; }
            log("Relogando...");
            if (curRemakeUser != "")
            {
                var ra:Object = findAccount("remake:" + curRemakeUser.toLowerCase());
                closeGame();
                screen = "remake";
                showHome();
                if (ra != null) remakeResume(ra);
                return;
            }
            closeGame();
            setStatus("Relogando...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        // Voltar à tela inicial: encerra o jogo (reinicia o app) e mostra a tela inicial com as contas salvas.
        private function backToHome():void
        {
            closeRename();
            screen = "home"; curRemakeUser = "";
            if (!inGame || gameLoader == null) { showHome(); return; }
            log("Voltando à tela inicial: encerrando o jogo...");
            try { if (macroPanel != null) macroPanel.stopAll(); } catch (eM2:Error) {}
            // Reinicia o app: é o único jeito de derrubar de verdade a conexão do jogo (o servidor mantém o personagem
            // online e recusa o próximo login). O app reabre na tela inicial com as contas salvas.
            if (bridge.available) { bridge.restartApp(); return; }
            closeGame();
            try { bridge.keepAlive(false); } catch (eK:Error) {}
            setStatus("Pronto");
            showHome();
        }

        // Fecha o jogo atual e limpa o palco (usado por Relogar e por Voltar à tela inicial).
        private function closeGame():void
        {
            try { if (macroPanel != null) macroPanel.stopAll(); } catch (eM:Error) {}
            try { if (topTimer) topTimer.stop(); } catch (eT:Error) {}
            kickGen++;
            try { if (controls != null && controls.parent != null) controls.parent.removeChild(controls); } catch (eC:Error) {}
            controls = null;
            try { SwfFixer.gameDomain = null; } catch (eD:Error) {}
            try { gameLoader.unloadAndStop(true); } catch (eU:Error) {}
            try { if (gameLoader.parent != null) gameLoader.parent.removeChild(gameLoader); } catch (eR:Error) {}
            gameLoader = null;
            // o jogo põe janelas direto no palco: tira tudo que não é o próprio app
            try
            {
                for (var ci:int = stage.numChildren - 1; ci >= 0; ci--)
                {
                    var ch:DisplayObject = stage.getChildAt(ci);
                    if (ch != this) { try { stage.removeChild(ch); } catch (eX:Error) {} }
                }
            }
            catch (eS:Error) {}
            inGame = false;
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.NORMAL; } catch (eIdle:Error) {}
            drawBg();
        }

        // ---------- janela de macros ----------
        // Pop-up por cima do jogo (dentro do app). O botão ▶ ao lado da engrenagem e o item "Macros" do menu abrem/fecham.
        private function openMacros():void
        {
            if (macroPanel == null)
            {
                macroPanel = new MacroPanel();
                macroPanel.logger = log;
                try { macroPanel.dumpDir = bridge.modsPath(); } catch (eMods:Error) {}
                macroPanel.onText = function(title:String, text:String):void { bridge.showText(title, text); };
                macroPanel.onWake = function():void { if (!macroPanel.isOpen) macroPanel.show(stage, sw(), sh(), uiScale()); };
            }
            if (macroPanel.isOpen) { macroPanel.hide(); return; }
            macroPanel.show(stage, sw(), sh(), uiScale());
        }

        private function openFpsMenu():void
        {
            var names:Array = [];
            for each (var f:int in FPS_OPTIONS)
                names.push(f + " FPS" + (f == Prefs.fps ? "  ✓" : "") + (f == 120 ? "  (precisa de tela 120 Hz)" : ""));
            menuMode = M_FPS;
            bridge.showMenu("FPS (tela do aparelho: " + hzText() + ")", names);
        }

        // ---------- resolução ----------
        // A troca de resolução NÃO usa mais o Android (setFixedSize não muda o tamanho do palco do AIR).
        // Modo PC = StageScaleMode.SHOW_ALL: o palco passa a ter o tamanho do SWF (1250x650, definido em
        // [SWF(...)] / -default-size) e o AIR amplia tudo para a tela mantendo a proporção (barras pretas
        // nos lados se a tela for mais larga). O jogo vê um palco de 1250x650 e se organiza para ele.
        private function screenSize():Array
        {
            var w:int = stage.fullScreenWidth > 0 ? stage.fullScreenWidth : int(Capabilities.screenResolutionX);
            var h:int = stage.fullScreenHeight > 0 ? stage.fullScreenHeight : int(Capabilities.screenResolutionY);
            if (h > w) { var t:int = w; w = h; h = t; }
            return [w, h];
        }

        // Valor salvo que não existe mais na lista (de versões antigas) volta para o Modo PC.
        private function validRes():int
        {
            var v:int = Prefs.resHeight;
            if (RES_OPTIONS.indexOf(v) < 0) { v = RES_BASE; Prefs.resHeight = RES_BASE; }
            return v;
        }

        private function isPcMode():Boolean { var v:int = validRes(); return v >= RES_BASE && v < RES_VIRT_BASE; }
        private function isVirtual():Boolean { return validRes() >= RES_VIRT_BASE; }

        private function resLabel(v:int):String
        {
            var s:Array = screenSize();
            if (v == RES_CUSTOM) return "Personalizada " + virtW(customH()) + "x" + customH();
            if (v >= RES_VIRT_BASE && v - RES_VIRT_BASE < RES_VIRT.length)
                return RES_VIRT[v - RES_VIRT_BASE][2] + " " + RES_VIRT[v - RES_VIRT_BASE][0] + "x" + RES_VIRT[v - RES_VIRT_BASE][1];
            if (v >= RES_BASE && v < RES_VIRT_BASE && v - RES_BASE < RES_FIXED.length)
                return "Padrão " + RES_FIXED[v - RES_BASE][0] + "x" + RES_FIXED[v - RES_BASE][1];
            return "Nativa " + s[0] + "x" + s[1];
        }

        private function openResolutionMenu():void
        {
            var cur:int = validRes();
            var names:Array = [];
            for each (var v:int in RES_OPTIONS)
            {
                var n:String = resLabel(v);
                if (v == cur) n += "  ✓";
                names.push(n);
            }
            menuMode = M_RES;
            bridge.showMenu("Resolução (maior = mais área do jogo, itens menores)", names);
        }

        private function wantedScaleMode():String
        {
            return (isPcMode() || isVirtual()) ? StageScaleMode.SHOW_ALL : StageScaleMode.NO_SCALE;
        }

        private function applyResolution():void
        {
            var want:String = wantedScaleMode();
            if (stage.scaleMode != want) stage.scaleMode = want;
            stage.align = StageAlign.TOP_LEFT;
            applyVirtualStage();
            var rl:String = "Resolução: " + resLabel(validRes());
            if (rl != lastResLog) { lastResLog = rl; log(rl); }
            setTimeout(logStage, 300);
            if (inGame) for each (var d:int in [50, 400, 1200]) setTimeout(notifyResize, d);
        }

        // Resolução virtual (1920x1080 / 2560x1440): o jogo só reorganiza a tela se o PALCO mudar de
        // tamanho. O AIR do Android não deixa o app mudar o tamanho da tela por fora (testado: só
        // encolhe a imagem), então tentamos pelo próprio palco e CONFERIMOS o resultado.
        private function baseRatio():Number { return (loaderInfo && loaderInfo.height > 0) ? loaderInfo.width / loaderInfo.height : 2.08; }
        private function customH():int { var h:int = Prefs.customH; return (h >= CUSTOM_MIN && h <= CUSTOM_MAX) ? h : 800; }
        private function virtW(h:int):int { return Math.round(h * baseRatio()); }
        // [largura, altura, nome] da resolução virtual escolhida (Full HD, 2K ou Personalizada)
        private function virtSize():Array
        {
            var v:int = validRes();
            if (v == RES_CUSTOM) return [virtW(customH()), customH(), "Personalizada"];
            return RES_VIRT[v - RES_VIRT_BASE];
        }
        private function applyVirtualStage():void
        {
            if (!isVirtual()) return;
            var r:Array = virtSize();
            try { stage["stageWidth"] = int(r[0]); stage["stageHeight"] = int(r[1]); }
            catch (err:Error) { log("Palco virtual: " + err.message); }
        }

        // Confere se o palco ficou mesmo com o tamanho pedido. Se o aparelho/AIR não aceitar, volta para
        // o Modo PC (em vez de deixar a tela quebrada) e avisa.
        private function verifyVirtual(announce:Boolean):void
        {
            if (!isVirtual() || !stage) return;
            var r:Array = virtSize();
            if (stage.stageWidth == int(r[0]) && stage.stageHeight == int(r[1]))
            {
                log("Resolução " + r[0] + "x" + r[1] + ": ok (palco " + stage.stageWidth + "x" + stage.stageHeight + ")");
                return;
            }
            log("Resolução " + r[0] + "x" + r[1] + " NÃO aceita pelo AIR (palco ficou " + stage.stageWidth + "x" + stage.stageHeight + "). Voltando ao Padrão.");
            Prefs.resHeight = RES_BASE;
            applyResolution();
            if (!inGame) showHome();
            if (announce) bridge.showText("Resolução",
                "Este aparelho não aceitou mudar o tamanho da tela do jogo para " + r[0] + "x" + r[1] + ". Voltei para o Padrão para não quebrar a tela.\n\n" +
                "Opção mais parecida: \"Nativa\" (usa todos os pixels da tela).");
        }

        private var lastResLog:String = "";
        private var lastStageLog:String = "";
        private function logStage():void
        {
            var sc:Array = screenSize();
            var m:String = "Palco: " + stage.stageWidth + "x" + stage.stageHeight + " | tela " + sc[0] + "x" + sc[1] + " | escala " + stage.scaleMode;
            if (m != lastStageLog) { lastStageLog = m; log(m); }
        }

        // O jogo avisa que o palco mudou de tamanho (útil ao trocar de modo com o jogo aberto).
        // O jogo só posiciona alguns botões (ex.: "Explorar" no mapa dos arredores) quando recebe um RESIZE DEPOIS de montar
        // a interface. Avisar durante a montagem (v3.4/v3.5) estragou o mapa, então os avisos são poucos e espaçados
        // (3, 8, 16 e 30 s depois do jogo carregar ou de ele trocar a escala), que é o que o seu "mudar a resolução" fazia.
        private var kickGen:int = 0;
        private var kickLogN:int = 0;
        private function scheduleKicks():void
        {
            if (!Prefs.fixLayout || !inGame) return;
            var gen:int = ++kickGen;
            for each (var d:int in [3000, 8000, 16000, 30000])
                setTimeout(function():void { if (gen == kickGen) kickResize(); }, d);
        }
        private function kickResize():void
        {
            if (!inGame || !stage) return;
            try { stage.dispatchEvent(new Event(Event.RESIZE)); } catch (err:Error) {}
            if (kickLogN < 12) { kickLogN++; log("Aviso de resize ao jogo (layout) #" + kickLogN); }
        }
        private function notifyResize():void
        {
            if (!inGame || !stage) return;
            try { stage.dispatchEvent(new Event(Event.RESIZE)); } catch (err:Error) { log("aviso de resize: " + err.message); }
            if (controls) controls.layout(sw(), uiScale(), sh());
        }

        // O botão da engrenagem fica no palco (stage), por cima de tudo, e é trazido para a
        // frente de tempos em tempos: o jogo adiciona janelas no palco e o cobria.
        private function keepOnTop(e:TimerEvent):void
        {
            if (!controls || !stage) return;
            try
            {
                if (stage.scaleMode != wantedScaleMode())
                {
                    log("Escala foi alterada para " + stage.scaleMode + "; restaurando.");
                    applyResolution();
                    scheduleKicks();
                }
                if (controls.parent != stage) stage.addChild(controls);
                else if (stage.getChildIndex(controls) != stage.numChildren - 1) stage.setChildIndex(controls, stage.numChildren - 1);
                // só reposiciona a engrenagem se o tamanho da tela mudou (antes mexia na lista de exibição a cada tick)
                if (sw() != topW || sh() != topH) { topW = sw(); topH = sh(); controls.layout(topW, uiScale(), topH); }
                if (macroPanel && macroPanel.parent == stage && stage.getChildIndex(macroPanel) != stage.numChildren - 1)
                    stage.setChildIndex(macroPanel, stage.numChildren - 1);
                if (sliderPanel && sliderPanel.parent == stage && stage.getChildIndex(sliderPanel) != stage.numChildren - 1)
                    stage.setChildIndex(sliderPanel, stage.numChildren - 1);
            }
            catch (err:Error) {}
        }

        // ---------- sair do app / segundo plano ----------
        private function onKey(e:KeyboardEvent):void
        {
            if (e.keyCode != Keyboard.BACK) return;
            e.preventDefault();
            e.stopImmediatePropagation();
            if (renamePanel != null) { closeRename(); return; }
            askExit();
        }

        private function askExit():void
        {
            menuMode = M_EXIT;
            bridge.showMenu("Sair do app", ["Deixar o jogo aberto em segundo plano", "Fechar o app de vez", "Cancelar"]);
        }

        // ---------- zoom ----------
        private function zoomBy(delta:Number):void
        {
            zoomLevel = Math.max(0.5, Math.min(2, zoomLevel + delta));
            Prefs.zoom = zoomLevel;
            applyZoom();
        }
        // ---------- barra de resolução personalizada ----------
        private var sliderPanel:SliderPanel;
        private function openSlider():void
        {
            closeSlider();
            var ratio:Number = baseRatio();
            sliderPanel = new SliderPanel("Resolução personalizada", CUSTOM_MIN, CUSTOM_MAX, 10, customH(),
                function(h:int):String { return Math.round(h * ratio) + " x " + h; },
                "menor = itens maiores | maior = mais área do jogo",
                applySlider, closeSlider);
            sliderPanel.scaleX = sliderPanel.scaleY = uiScale();
            sliderPanel.x = sw() / 2;
            sliderPanel.y = sh() / 2;
            stage.addChild(sliderPanel);
        }
        private function closeSlider():void
        {
            if (sliderPanel && sliderPanel.parent) sliderPanel.parent.removeChild(sliderPanel);
            sliderPanel = null;
        }
        private function applySlider(h:int):void
        {
            closeSlider();
            Prefs.customH = h;
            Prefs.resHeight = RES_CUSTOM;
            log("Resolução personalizada: " + virtW(h) + "x" + h);
            applyResolution();
            setTimeout(function():void { verifyVirtual(true); }, 900);
            if (!inGame) showHome();
        }
        private function applyZoom():void
        {
            if (!gameLoader) return;
            gameLoader.scaleX = gameLoader.scaleY = zoomLevel;
        }

        // ---------- cache do Loading.swf (TTL em disco) ----------
        private function cacheDir():File
        {
            var d:File = File.applicationStorageDirectory.resolvePath("cache");
            if (!d.exists) d.createDirectory();
            return d;
        }
        private function cacheFile():File { return cacheDir().resolvePath("Loading.swf"); }

        private function cacheSizeText():String
        {
            var n:Number = SwfFixer.cacheSize();
            if (n <= 0) return "vazio";
            if (n >= 1048576) return (Math.round(n / 104857.6) / 10) + " MB";
            return Math.round(n / 1024) + " KB";
        }
        private function clearCache():void
        {
            SwfFixer.clearCache();
            log("Cache apagado.");
        }
        private function saveCache(b:ByteArray):void
        {
            try {
                var fs:FileStream = new FileStream();
                fs.open(cacheFile(), FileMode.WRITE);
                fs.writeBytes(b); fs.close();
            } catch (err:Error) { log("Falha ao salvar cache: " + err.message); }
        }
        private function readCacheIfFresh():ByteArray
        {
            var f:File = cacheFile();
            if (!f.exists) return null;
            if (new Date().time - f.modificationDate.time > CACHE_TTL_MS) return null;
            return readFile(f);
        }

        private function readFile(f:File):ByteArray
        {
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.READ);
            var ba:ByteArray = new ByteArray();
            fs.readBytes(ba); fs.close();
            return ba;
        }

        // ---------- sessão recebida do ANE ----------
        private function onGame(e:StatusEvent):void
        {
            try { session = JSON.parse(e.level); }
            catch (err:Error) { setStatus("Resposta de login inválida."); return; }
            saveSessionAccount();
            enterGame();
        }

        // Guarda a sessão capturada como uma conta (uma por servidor + usuário; atualiza se já existir).
        private function saveSessionAccount():void
        {
            try
            {
                var u:String = String(session.user != undefined ? session.user : (session.params ? session.params.user : ""));
                if (u == "" || u == "undefined") return;
                var ck:String = session.cookies != undefined ? JSON.stringify(session.cookies) : "";
                var old:Object = findAccount(platformIdx + ":" + u);
                Prefs.saveAccount({
                    id: platformIdx + ":" + u, name: u, label: (old != null && old.label != undefined ? String(old.label) : ""), platform: platformIdx, host: String(Platforms.LIST[platformIdx][1]), serverHost: String(session.host),
                    session: JSON.stringify(session), cookies: (ck != "" ? ck : (old != null ? String(old.cookies) : "")),
                    savedAt: new Date().time
                });
                log("Conta salva: " + u + " (" + serverName(platformIdx) + ")");
            }
            catch (err:Error) { log("Não consegui salvar a conta: " + err.message); }
        }

        private function enterGame():void
        {
            applyResolution();   // o login pausa/recria a tela do app: reaplica a resolução
            port = bridge.startServer(session.host);
            if (port <= 0) { setStatus("Falha ao iniciar servidor local."); return; }
            bridge.keepAlive(true);
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE; } catch (eIdle:Error) {}
            setStatus("Baixando o jogo...");
            fbIndex = 0;
            fetchSwf();
        }

        // 1) servidor (via proxy local, tentando vários caminhos)  2) cache  3) reservas empacotadas
        private function fetchSwf():void
        {
            swfCandidates = [];
            if (session.swf) swfCandidates.push(String(session.swf));
            swfCandidates.push("/client/Loading.swf");
            swfCandidates.push("/Loading.swf");
            swfIdx = 0;
            log("Sessão: host=" + session.host + " swf=" + (session.swf ? session.swf : "(nenhum)") + " porta=" + port);
            tryServer();
        }

        private function isSwf(b:ByteArray):Boolean
        {
            if (b.length < 3) return false;
            var h:String = String.fromCharCode(b[0], b[1], b[2]);
            return h == "FWS" || h == "CWS" || h == "ZWS";
        }

        private function tryServer():void
        {
            if (swfIdx >= swfCandidates.length)
            {
                log("Servidor não respondeu; usando a cópia do app.");
                launchWith(0);
                return;
            }
            var path:String = String(swfCandidates[swfIdx++]);
            log("Tentando https://" + session.host + path);
            var code:int = 0;
            var l:URLLoader = new URLLoader();
            l.dataFormat = URLLoaderDataFormat.BINARY;
            l.addEventListener(HTTPStatusEvent.HTTP_STATUS, function(ev:HTTPStatusEvent):void { code = ev.status; });
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var b:ByteArray = ByteArray(l.data);
                log("Recebido " + b.length + " bytes (HTTP " + code + ")");
                if (!isSwf(b)) { log("A resposta não é um SWF."); tryServer(); return; }
                okPath = path;
                launchWith(b.length);
            });
            l.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                log("Falhou (HTTP " + code + "): " + ev.text);
                tryServer();
            });
            l.load(new URLRequest("http://127.0.0.1:" + port + path));
        }

        // O Loading.swf do servidor NÃO é executado: serve só para saber a versão (pelo tamanho).
        // Quem roda é a cópia modificada que vem no app (assets/game), a mesma versão do servidor.
        private function launchWith(serverLen:int):void
        {
            var name:String = "assets/game/Loading.swf";
            if (serverLen > 0 && serverLen != BRAZIL_LEN)
            {
                var alt:String = "assets/game/Loading_" + serverLen + ".swf";
                if (File.applicationDirectory.resolvePath(alt).exists)
                {
                    name = alt;
                    log("Versão deste servidor: " + serverLen + " bytes (cópia própria no app)");
                }
                else
                {
                    log("AVISO: a versão do Loading.swf deste servidor (" + serverLen + " bytes) não está no app. Usando a do Brasil.");
                }
            }
            else if (serverLen == BRAZIL_LEN)
            {
                log("Versão deste servidor: a mesma do Brasil");
            }
            var f:File = File.applicationDirectory.resolvePath(name);
            if (!f.exists)
            {
                setStatus("Faltam os arquivos do jogo no app (" + name + "). Toque em Ver log.");
                return;
            }
            setStatus("Carregando o jogo...");
            startGame(readFile(f));
        }

        private function startGame(bytes:ByteArray, gameParams:Object = null):void
        {
            inGame = true;
            Platforms.remake = (gameParams != null);   // o macro de Planos usa o caminhar controlado só no Remake
            drawBg();
            while (ui.numChildren) ui.removeChildAt(0);
            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;
            var params:Object = {};
            if (gameParams != null)
            {
                // Legend Remake: parâmetros prontos (user, key, site, config...)
                for (var gk:String in gameParams) params[gk] = String(gameParams[gk]);
            }
            else
            {
                var p:String = okPath;
                var qi:int = p.indexOf("?");
                if (qi >= 0) p = p.substring(0, qi);
                var dir:String = "https://" + session.host + p.substring(0, p.lastIndexOf("/") + 1);
                for each (var pn:String in ["user", "key", "site", "p2", "rid", "logintype"])
                {
                    if (session.params && session.params[pn] != undefined) params[pn] = String(session.params[pn]);
                }
                params["http"] = "https:";
                params["config"] = dir + "config.xml";
                params["base"] = dir;
            }
            log("Jogo: " + bytes.length + " bytes | config " + params["config"]);
            applyResolution();
            ctx.parameters = params;
            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                SwfFixer.gameDomain = gameLoader.contentLoaderInfo.applicationDomain;
                applyResolution();
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, function(ev:Event):void {
                zoomLevel = 1; Prefs.zoom = 1;
                addChild(gameLoader);
                applyZoom();
                controls = new Controls(openSettings, openMacros);
                controls.layout(sw(), uiScale(), sh());
                topW = sw(); topH = sh();
                stage.addChild(controls);
                scheduleKicks();
                if (topTimer) topTimer.stop();
                topTimer = new Timer(1000);
                topTimer.addEventListener(TimerEvent.TIMER, keepOnTop);
                topTimer.start();
                log("Jogo carregado.");
            });
            gameLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                inGame = false; gameLoader = null; curRemakeUser = ""; screen = "home"; drawBg(); showHome(); setStatus("Falha ao carregar o jogo.");
            });
            gameLoader.loadBytes(bytes, ctx);
        }
    }
}
