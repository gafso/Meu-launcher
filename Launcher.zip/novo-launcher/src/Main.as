package
{
    import com.meulauncher.air.Bridge;
    import flash.desktop.NativeApplication;
    import flash.desktop.SystemIdleMode;
    import flash.display.Loader;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageQuality;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.net.URLLoader;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.system.ApplicationDomain;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.utils.ByteArray;

    [SWF(width="1280", height="720", frameRate="30", backgroundColor="#0D1117")]
    public class Main extends Sprite
    {
        private static const VERSION:String = "Nexus 1.0";
        private static const HOST:String = "lobr.creaction-network.com";

        private var bridge:Bridge;
        private var session:Object;
        private var accounts:Array = [];
        private var ui:Sprite = new Sprite();
        private var gameLoader:Loader;
        private var inGame:Boolean = false;
        private var port:int = 0;

        // Macros
        private var vipMacro:VipMacro;
        private var planesBot:PlanesBot;
        private var macroOverlay:Sprite;

        public function Main()
        {
            stage.align = StageAlign.TOP_LEFT;
            stage.scaleMode = StageScaleMode.NO_SCALE;
            stage.quality = StageQuality.LOW;
            stage.frameRate = 30;

            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.NORMAL; } catch (e:Error) {}

            bridge = new Bridge();
            bridge.addEventListener("game", onGameSession);
            bridge.addEventListener("error", onError);

            loadAccounts();
            SwfFixer.install();

            addChild(ui);
            showHome();
        }

        private function showHome():void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            drawBackground();

            var title:TextField = makeText("NEXUS LAUNCHER", 28, 0x00D4FF, true);
            title.x = 40; title.y = 40;
            ui.addChild(title);

            var sub:TextField = makeText("Acesso ao jogo + contas salvas + macros VIP e Minas", 16, 0x8B949E);
            sub.x = 40; sub.y = 80;
            ui.addChild(sub);

            // Contas salvas
            var y:Number = 140;
            if (accounts.length == 0)
            {
                var empty:TextField = makeText("Nenhuma conta salva ainda.", 16, 0x8B949E);
                empty.x = 40; empty.y = y;
                ui.addChild(empty);
                y += 40;
            }
            else
            {
                for (var i:int = 0; i < accounts.length; i++)
                {
                    var acc:Object = accounts[i];
                    var btn:Sprite = makeButton(acc.name || "Conta", 0x161B22, 0x30363D);
                    btn.x = 40; btn.y = y;
                    btn.addEventListener(MouseEvent.CLICK, makeAccountClick(acc));
                    ui.addChild(btn);
                    y += 60;
                }
            }

            var newBtn:Sprite = makeButton("+ Nova conta / Login", 0x00D4FF, 0x0D1117);
            newBtn.x = 40; newBtn.y = y + 20;
            newBtn.addEventListener(MouseEvent.CLICK, onNewLogin);
            ui.addChild(newBtn);

            var setBtn:Sprite = makeButton("Configurações (FPS / Qualidade)", 0x21262D, 0x8B949E);
            setBtn.x = 40; setBtn.y = y + 90;
            setBtn.addEventListener(MouseEvent.CLICK, showSettings);
            ui.addChild(setBtn);
        }

        private function onNewLogin(e:MouseEvent):void
        {
            bridge.login(HOST);
        }

        private function makeAccountClick(acc:Object):Function
        {
            return function(e:MouseEvent):void
            {
                try {
                    session = JSON.parse(String(acc.session));
                    enterGame();
                } catch (err:Error) {
                    trace("Conta inválida");
                }
            };
        }

        private function onGameSession(e:StatusEvent):void
        {
            try {
                session = JSON.parse(e.level);
                saveCurrentAccount();
                enterGame();
            } catch (err:Error) {
                trace("Erro sessão: " + err.message);
            }
        }

        private function enterGame():void
        {
            if (!session || !session.host) return;
            port = bridge.startServer(session.host);
            if (port <= 0) return;

            // Não inicia KeepAlive automaticamente (economia de bateria)
            fetchAndLoadSwf();
        }

        private function fetchAndLoadSwf():void
        {
            // Tenta via proxy local; se falhar, usa o SWF empacotado
            var loader:URLLoader = new URLLoader();
            loader.dataFormat = URLLoaderDataFormat.BINARY;
            loader.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var bytes:ByteArray = ByteArray(loader.data);
                if (bytes.length > 1000 && (bytes[0] == 0x46 || bytes[0] == 0x43 || bytes[0] == 0x5A)) // FWS/CWS/ZWS
                    startGame(bytes);
                else
                    loadFallbackSwf();
            });
            loader.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void { loadFallbackSwf(); });
            loader.load(new URLRequest("http://127.0.0.1:" + port + "/client/Loading.swf"));
        }

        private function loadFallbackSwf():void
        {
            var f:File = File.applicationDirectory.resolvePath("assets/game/Loading.swf");
            if (f.exists) {
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.READ);
                var b:ByteArray = new ByteArray();
                fs.readBytes(b);
                fs.close();
                startGame(b);
            }
        }

        private function startGame(bytes:ByteArray):void
        {
            inGame = true;
            while (ui.numChildren) ui.removeChildAt(0);

            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;

            var params:Object = {};
            if (session.params) {
                for (var k:String in session.params) params[k] = String(session.params[k]);
            }
            params["http"] = "https:";
            params["config"] = "https://" + session.host + "/client/config.xml";
            params["base"] = "https://" + session.host + "/client/";
            ctx.parameters = params;

            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                SwfFixer.gameDomain = gameLoader.contentLoaderInfo.applicationDomain;
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, onGameLoaded);
            gameLoader.loadBytes(bytes, ctx);
            addChild(gameLoader);

            createMacroOverlay();
        }

        private function onGameLoaded(e:Event):void
        {
            // Macros disponíveis
            vipMacro = new VipMacro();
            vipMacro.logger = function(s:String):void { trace("[VIP] " + s); };

            var ad:GamePlanesAdapter = new GamePlanesAdapter();
            planesBot = new PlanesBot(ad, "Minas");
            planesBot.logger = function(s:String):void { trace("[MINAS] " + s); };
            planesBot.opts.portal = 3;
        }

        private function createMacroOverlay():void
        {
            macroOverlay = new Sprite();
            macroOverlay.x = 20;
            macroOverlay.y = 20;

            var vipBtn:Sprite = makeButton("VIP", 0x238636, 0xFFFFFF);
            vipBtn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                if (vipMacro && !vipMacro.running) vipMacro.start();
            });
            macroOverlay.addChild(vipBtn);

            var mineBtn:Sprite = makeButton("MINAS", 0x1F6FEB, 0xFFFFFF);
            mineBtn.x = 120;
            mineBtn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                if (planesBot && !planesBot.running) {
                    // Modo minas (portal = 3)
                    try {
                        planesBot.opts = planesBot.opts || {};
                        planesBot.opts.portal = 3;
                        planesBot.start();
                    } catch (err:Error) { trace("Erro minas: " + err.message); }
                }
            });
            macroOverlay.addChild(mineBtn);

            var fpsBtn:Sprite = makeButton("60 FPS", 0x21262D, 0x00D4FF);
            fpsBtn.x = 240;
            fpsBtn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                stage.frameRate = 60;
            });
            macroOverlay.addChild(fpsBtn);

            stage.addChild(macroOverlay);
        }

        private function showSettings():void
        {
            // Simple settings overlay
            var panel:Sprite = new Sprite();
            panel.graphics.beginFill(0x161B22, 0.95);
            panel.graphics.drawRoundRect(200, 150, 400, 300, 16);
            panel.graphics.endFill();

            var t:TextField = makeText("Configurações", 22, 0x00D4FF, true);
            t.x = 220; t.y = 170;
            panel.addChild(t);

            var fps30:Sprite = makeButton("FPS 30", 0x21262D, 0xFFFFFF);
            fps30.x = 220; fps30.y = 230;
            fps30.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { stage.frameRate = 30; });
            panel.addChild(fps30);

            var fps60:Sprite = makeButton("FPS 60", 0x00D4FF, 0x0D1117);
            fps60.x = 360; fps60.y = 230;
            fps60.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { stage.frameRate = 60; });
            panel.addChild(fps60);

            var close:Sprite = makeButton("Fechar", 0x21262D, 0x8B949E);
            close.x = 220; close.y = 360;
            close.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { ui.removeChild(panel); });
            panel.addChild(close);

            ui.addChild(panel);
        }

        // ---------- helpers ----------
        private function drawBackground():void
        {
            var bg:Shape = new Shape();
            bg.graphics.beginFill(0x0D1117);
            bg.graphics.drawRect(0, 0, stage.stageWidth, stage.stageHeight);
            bg.graphics.endFill();
            ui.addChild(bg);
        }

        private function makeText(txt:String, size:int, color:uint, bold:Boolean = false):TextField
        {
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            tf.text = txt;
            tf.selectable = false;
            tf.autoSize = "left";
            return tf;
        }

        private function makeButton(label:String, bg:uint, fg:uint):Sprite
        {
            var s:Sprite = new Sprite();
            s.graphics.beginFill(bg);
            s.graphics.drawRoundRect(0, 0, 280, 48, 12);
            s.graphics.endFill();
            var t:TextField = makeText(label, 16, fg, true);
            t.x = 16; t.y = 12;
            s.addChild(t);
            s.buttonMode = true;
            return s;
        }

        private function loadAccounts():void
        {
            var f:File = File.applicationStorageDirectory.resolvePath("accounts.json");
            if (!f.exists) return;
            try {
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.READ);
                accounts = JSON.parse(fs.readUTFBytes(fs.bytesAvailable)) as Array;
                fs.close();
            } catch (e:Error) { accounts = []; }
        }

        private function saveCurrentAccount():void
        {
            if (!session) return;
            var user:String = session.user || (session.params && session.params.user) || "Conta";
            var entry:Object = {
                name: user,
                host: session.host,
                session: JSON.stringify(session),
                saved: new Date().time
            };
            // Update or add
            var found:Boolean = false;
            for (var i:int = 0; i < accounts.length; i++) {
                if (accounts[i].name == user) { accounts[i] = entry; found = true; break; }
            }
            if (!found) accounts.push(entry);
            saveAccounts();
        }

        private function saveAccounts():void
        {
            var f:File = File.applicationStorageDirectory.resolvePath("accounts.json");
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.WRITE);
            fs.writeUTFBytes(JSON.stringify(accounts));
            fs.close();
        }

        private function onError(e:StatusEvent):void
        {
            trace("Erro nativo: " + e.level);
        }
    }
}
