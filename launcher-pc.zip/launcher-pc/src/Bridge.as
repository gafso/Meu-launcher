package
{
    import flash.desktop.Clipboard;
    import flash.desktop.ClipboardFormats;
    import flash.desktop.NativeApplication;
    import flash.display.Sprite;
    import flash.display.Stage;
    import flash.events.Event;
    import flash.events.EventDispatcher;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.filesystem.File;
    import flash.html.HTMLLoader;
    import flash.net.URLRequest;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.ui.Keyboard;

    // Versão PC da "ponte" do launcher. No Android isto é um ANE em Java; no Windows tudo é ActionScript:
    //   login       -> janela com navegador embutido (LoginWindow)
    //   showMenu    -> painel de opções desenhado dentro do app
    //   showText    -> painel de texto (log) com Copiar / Fechar
    // Eventos (StatusEvent): "game" (level = JSON da sessão), "menu" (level = índice), "error" (level = mensagem).
    public class Bridge extends EventDispatcher
    {
        public var initError:String = "";
        public var stage:Stage;
        // No PC o jogo e o Loading.swf são baixados direto do servidor (não precisa de servidor local).
        public const direct:Boolean = true;

        private var loginWin:LoginWindow;
        private var dialog:Sprite;
        private var dialogOnClose:Function;
        private var lastHost:String = "";
        private var cookieLoader:HTMLLoader;

        public function get available():Boolean { return true; }

        // ---------- login ----------
        public function login(host:String):void
        {
            lastHost = host;
            if (loginWin != null) { loginWin.focus(); return; }
            var lw:LoginWindow = new LoginWindow(host);
            loginWin = lw;
            lw.onSession = function(json:String):void
            {
                loginWin = null;
                dispatchEvent(new StatusEvent("game", false, false, "game", json));
            };
            lw.onClosed = function():void
            {
                loginWin = null;
                dispatchEvent(new StatusEvent("error", false, false, "error", "Login cancelado."));
            };
            lw.open();
        }

        // Sem servidor local no PC: devolve um número qualquer maior que zero.
        public function startServer(host:String):int { return 1; }
        public function captureImages(on:Boolean):void {}

        // Pasta "mods" fica em Documentos\LegendPC\mods (fácil de abrir no Explorer).
        public function modsPath():String
        {
            try
            {
                var d:File = File.documentsDirectory.resolvePath("LegendPC").resolvePath("mods");
                if (!d.exists) d.createDirectory();
                return d.nativePath;
            }
            catch (e:Error) {}
            return "";
        }

        public function keepAlive(on:Boolean):void {}
        public function setSurfaceSize(w:int, h:int):void {}
        public function setRefreshRate(fps:int):void {}
        public function displayHz():Number { return 0; }

        // "Segundo plano" no PC = minimizar a janela.
        public function toBackground():void
        {
            try { stage.nativeWindow.minimize(); } catch (e:Error) {}
        }

        public function restartApp():void
        {
            showText("Reiniciar o app", "O app vai fechar agora.\n\nAbra o Legend PC de novo para entrar.", function():void
            {
                NativeApplication.nativeApplication.exit();
            });
        }

        // Apaga os cookies que o navegador embutido deixa ver (cookies "HttpOnly" não dá para apagar daqui).
        public function clearSession():void
        {
            try
            {
                var host:String = lastHost != "" ? lastHost : String(Platforms.LIST[0][1]);
                var h:HTMLLoader = new HTMLLoader();
                cookieLoader = h;
                h.addEventListener(Event.COMPLETE, function(e:Event):void
                {
                    try
                    {
                        var doc:Object = h.window.document;
                        var cs:Array = String(doc.cookie).split(";");
                        for each (var c:String in cs)
                        {
                            var nm:String = String(c.split("=")[0]).replace(/^\s+|\s+$/g, "");
                            if (nm != "") doc.cookie = nm + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/";
                        }
                    }
                    catch (e2:Error) {}
                    cookieLoader = null;
                });
                h.load(new URLRequest("https://" + host + "/"));
            }
            catch (e3:Error) {}
        }

        // ---------- painéis dentro do app ----------
        private function openDialog(dlg:Sprite):void
        {
            dialog = dlg;
            stage.addChild(dlg);
            stage.addEventListener(KeyboardEvent.KEY_DOWN, onDlgKey, false, 500);
        }

        private function closeDialog():void
        {
            if (dialog == null) return;
            try { stage.removeEventListener(KeyboardEvent.KEY_DOWN, onDlgKey); } catch (e0:Error) {}
            try { if (dialog.parent != null) dialog.parent.removeChild(dialog); } catch (e1:Error) {}
            dialog = null;
            var cb:Function = dialogOnClose;
            dialogOnClose = null;
            if (cb != null) cb();
        }

        private function onDlgKey(e:KeyboardEvent):void
        {
            if (e.keyCode == Keyboard.ESCAPE)
            {
                e.stopImmediatePropagation();
                closeDialog();
            }
        }

        private function makePick(i:int):Function
        {
            return function(e:MouseEvent):void
            {
                closeDialog();
                dispatchEvent(new StatusEvent("menu", false, false, "menu", String(i)));
            };
        }

        public function showMenu(title:String, items:Array):void
        {
            if (stage == null) return;
            closeDialog();
            var sw:Number = stage.stageWidth;
            var sh:Number = stage.stageHeight;
            var dlg:Sprite = new Sprite();
            dlg.graphics.beginFill(0x000000, 0.62);
            dlg.graphics.drawRect(-4096, -4096, sw + 8192, sh + 8192);
            dlg.graphics.endFill();
            var W:Number = 460;
            var rowH:Number = 40;
            var H:Number = 58 + items.length * rowH + 14;
            var pnl:Sprite = new Sprite();
            Win.card(pnl, 0, 0, W, H, 18, 0x0F0E28, 0x3B3A78);
            Win.fitLabel(pnl, title, 15, Btn.TEXT, 20, 16, W - 40, true);
            for (var i:int = 0; i < items.length; i++)
            {
                var b:Btn = new Btn(Btn.GHOST, W - 40, 34, String(items[i]), "", makePick(i));
                b.x = W / 2;
                b.y = 58 + i * rowH + 17;
                pnl.addChild(b);
            }
            var s:Number = Math.min(1, (sh - 20) / H);
            s = Math.min(s, (sw - 20) / W);
            pnl.scaleX = pnl.scaleY = s;
            pnl.x = (sw - W * s) / 2;
            pnl.y = (sh - H * s) / 2;
            dlg.addChild(pnl);
            dlg.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { if (e.target == dlg) closeDialog(); });
            openDialog(dlg);
        }

        public function showText(title:String, text:String, onClose:Function = null):void
        {
            if (stage == null) return;
            closeDialog();
            dialogOnClose = onClose;
            var sw:Number = stage.stageWidth;
            var sh:Number = stage.stageHeight;
            var dlg:Sprite = new Sprite();
            dlg.graphics.beginFill(0x000000, 0.62);
            dlg.graphics.drawRect(-4096, -4096, sw + 8192, sh + 8192);
            dlg.graphics.endFill();
            var W:Number = 900;
            var H:Number = 540;
            var pnl:Sprite = new Sprite();
            Win.card(pnl, 0, 0, W, H, 18, 0x0F0E28, 0x3B3A78);
            Win.fitLabel(pnl, title, 16, Btn.TEXT, 20, 14, W - 40, true);
            var full:String = text;
            var t:String = full.length > 60000 ? full.substring(full.length - 60000) : full;
            var tf:TextField = new TextField();
            tf.multiline = true;
            tf.wordWrap = true;
            tf.selectable = true;
            tf.background = true;
            tf.backgroundColor = 0x0E0D26;
            tf.border = true;
            tf.borderColor = 0x2A2955;
            tf.defaultTextFormat = new TextFormat("_typewriter", 12, 0xD8D8E8);
            tf.x = 20; tf.y = 50;
            tf.width = W - 40;
            tf.height = H - 50 - 64;
            tf.text = t;
            pnl.addChild(tf);
            tf.scrollV = tf.maxScrollV;
            var copyBtn:Btn = new Btn(Btn.GHOST, 200, 36, "Copiar", "", function(e:MouseEvent):void
            {
                try { Clipboard.generalClipboard.setData(ClipboardFormats.TEXT_FORMAT, full); } catch (e2:Error) {}
                copyBtn.setText("Copiado!");
            });
            copyBtn.x = W / 2 - 110; copyBtn.y = H - 34;
            pnl.addChild(copyBtn);
            var closeBtn:Btn = new Btn(Btn.PRIMARY, 200, 36, "Fechar", "", function(e:MouseEvent):void { closeDialog(); });
            closeBtn.x = W / 2 + 110; closeBtn.y = H - 34;
            pnl.addChild(closeBtn);
            var s:Number = Math.min(1, (sh - 20) / H);
            s = Math.min(s, (sw - 20) / W);
            pnl.scaleX = pnl.scaleY = s;
            pnl.x = (sw - W * s) / 2;
            pnl.y = (sh - H * s) / 2;
            dlg.addChild(pnl);
            openDialog(dlg);
        }
    }
}
