package
{
    import flash.display.Bitmap;
    import flash.display.BitmapData;
    import flash.display.Loader;
    import flash.display.PNGEncoderOptions;
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.system.ApplicationDomain;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.events.Event;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.net.URLRequest;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.filters.DropShadowFilter;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.ByteArray;
    import flash.utils.Timer;

    // Janela de macros (pop-up por cima do jogo, arrastável pela barra de cima).
    // Fechar só esconde a janela: os macros continuam rodando. Origem (0,0) = centro da janela.
    public class MacroPanel extends Sprite
    {
        private static const PW:Number = 780;
        private static const PH:Number = 580;
        private static const MAP:Number = 240;      // lado da área do mapa
        private static const MAP_CX:Number = 244;
        private static const MAP_CY:Number = 43;

        public var logger:Function;       // recebe cada linha de log (vai para o log do app)
        public var onText:Function;       // (titulo, texto): mostra um texto grande (caixa nativa, com copiar)
        public var onMirrorMacro:Function; // (action:String) líder → seguidoras
        public var onBeforeAction:Function; // liga stage/domínio desta janela antes do macro
        public var hostStage:DisplayObjectContainer = null;
        public var hostDomain:ApplicationDomain = null;

        private var realAd:GamePlanesAdapter = new GamePlanesAdapter();
        private var simAd:SimPlanesAdapter = new SimPlanesAdapter();
        private var real:PlanesBot;
        private var sim:PlanesBot;
        private var cycle:PlanesCycle;
        private var vip:VipMacro;
        private var btnVip:Btn;
        private var goalBtns:Array = [];
        private var itemCards:Array = [];
        private var itemIcons:Array = [];
        private var goalLblTf:TextField;
        private var customTf:TextField;
        private var customBox:Sprite;
        private var goalMode:int = 0;   // 0=100, 1=300, 2=500, 3=personalizado
        private var vipStatusTf:TextField;
        private var vipLogTf:TextField;
        private var tabVip:Sprite = new Sprite();
        private var popup:Sprite = new Sprite();
        private var pendingPopup:Array = null;
        private var capBtn:Btn;
        public var onWake:Function;       // reabre a janela quando um macro para sozinho com ela fechada
        private var btnCycle:Btn;
        private var opts:Object = {cycle: true, element: "", discardClosed: true, box: true, res: true, mon: true, boss: false, portal: 0, autoBuy: false, maxBuys: 0, buyBelow: 40, bind: true};

        private var bar:Sprite = new Sprite();
        private var statusTf:TextField;
        private var mapTitle:TextField;
        private var logTf:TextField;
        private var bgMap:Shape = new Shape();
        private var markLayer:Shape = new Shape();
        private var cellTfs:Array = [];
        private var mapCols:int = -1;
        private var mapRows:int = -1;
        private var cellSize:Number = 0;
        private var mapX0:Number = 0;
        private var mapY0:Number = 0;

        private var btnReal:Btn;
        private var btnSim:Btn;
        private var btnBox:Btn;
        private var btnRes:Btn;
        private var btnMon:Btn;
        private var btnBoss:Btn;
        private var btnPortal:Btn;
        private var btnEnergy:Btn;
        private var segNormal:Btn;
        private var segMinas:Btn;
        private var segFechar:Btn;
        private var tabPlanos:Sprite = new Sprite();
        private var tabCiclo:Sprite = new Sprite();
        private var tabBtns:Array = [];
        private var curTab:int = 0;
        private var bannerTitle:TextField;
        private var bannerDesc:TextField;
        private var chipTf:TextField;
        private var bannerArt:Sprite = new Sprite();

        private var lines:Array = [];
        private var timer:Timer;

        public function MacroPanel()
        {
            real = new PlanesBot(realAd, "Planos");
            sim = new PlanesBot(simAd, "Simulação");
            real.opts = opts;
            cycle = new PlanesCycle(realAd);
            cycle.logger = say;
            cycle.onEnter = function():void { real.start(); refresh(); };
            real.onEnd = function(kind:String):void
            {
                var pm:int = int(opts.portal);
                cycle.mode = pm; cycle.element = String(opts.element);
                // MINAS: achou a mina -> NÃO descarta, só sai e vai para o próximo plano; sem olho / sem mina -> descarta este
                if (pm == 3) { cycle.begin(kind != "mine", realAd.layerId); refresh(); return; }
                // FECHAR PLANOS: só troca quando o plano foi fechado por completo (e aí pega outro plano grande)
                if (pm == 4 && kind == "closed") { cycle.begin(Boolean(opts.discardClosed), realAd.layerId); refresh(); }
            };
            // paradas automáticas: aviso em janelinha com o motivo
            cycle.onFinish = function(code:String, reason:String):void
            {
                if (code == "minesFull") alertStop("Macro parado", "Espaços de minas completos");
                refresh();
            };
            real.onStopped = function(reason:String):void
            {
                if (/sem energia|energia insuficiente|limite diário de energia|sem diamantes|limite de compras/.test(reason)) alertStop("Macro parado", "Acabou os passos");
                refresh();
            };
            vip = new VipMacro();
            vip.logger = say;
            vip.onFinish = function(code:String, reason:String):void
            {
                if (code == "goal") alertStop("Macro VIP concluído", "Meta atingida: " + vip.collected + " x " + VipMacro.ITEMS[vip.itemIdx].label);
                else if (code == "noCoin") alertStop("Macro VIP parado", "Acabaram as moedas VIP");
                else if (code == "limit") alertStop("Macro VIP parado", "Limite de segurança atingido");
                else alertStop("Macro VIP parado", reason);
                refresh();
            };
            sim.opts = opts;
            real.logger = say;
            sim.logger = say;
            build();
            addEventListener(Event.ADDED_TO_STAGE, onAdded);
            addEventListener(Event.REMOVED_FROM_STAGE, onRemoved);
        }

        // ---------- log ----------
        public function say(s:String):void
        {
            lines.push(s);
            if (lines.length > 300) lines.shift();
            if (logger != null) logger("MACRO " + s);
        }

        // ---------- construção da janela ----------
        private function text(t:String, size:int, color:uint, x:Number, y:Number, w:Number = 0):TextField
        {
            var f:TextField = new TextField();
            f.defaultTextFormat = new TextFormat("_sans", size, color, true);
            f.selectable = false;
            f.mouseEnabled = false;
            f.autoSize = TextFieldAutoSize.LEFT;
            if (w > 0) { f.multiline = true; f.wordWrap = true; f.width = w; }
            f.text = t;
            f.x = x;
            f.y = y;
            return f;
        }

        private function build():void
        {
            var L:Number = -PW / 2;
            var T:Number = -PH / 2;

            // janela de vidro (meio transparente: dá para ver o jogo atrás)
            var bg:Sprite = new Sprite();
            Win.glass(bg, L, T, PW, PH, 0.86);
            bg.filters = [new DropShadowFilter(0, 90, 0x000000, 0.5, 24, 24, 1, 2)];
            addChild(bg);

            // cabeçalho (arraste por ele)
            bar.graphics.beginFill(0xFFFFFF, 0);
            bar.graphics.drawRect(L, T, PW, 72);
            bar.graphics.endFill();
            bar.addEventListener(MouseEvent.MOUSE_DOWN, onBarDown);
            addChild(bar);
            var gl:Shape = new Shape();
            Win.glyph(gl.graphics, "bolt", L + 44, T + 38, 40, Btn.ACCENT_LIGHT);
            addChild(gl);
            addChild(text("Macros", 24, 0xFFFFFF, L + 76, T + 10));
            addChild(text("Automatize suas ações e ganhe mais tempo.", 12, Btn.TEXT_MUTED, L + 76, T + 42));
            statusTf = text("", 11, Btn.TEXT_SOFT, L + 76, T + 56);
            statusTf.visible = false;

            // contador de macros ativas
            var chip:Sprite = new Sprite();
            Win.card(chip, 0, 0, 190, 40, 14, 0x12112E, 0x4B3AA8);
            chip.graphics.lineStyle(0, 0, 0);
            chip.graphics.beginFill(Btn.ACCENT_LIGHT, 1); chip.graphics.drawCircle(18, 20, 5); chip.graphics.endFill();
            chip.x = PW / 2 - 190 - 142; chip.y = T + 16;
            addChild(chip);
            Win.label(chip, "Macros ativas", 12, Btn.TEXT_SOFT, 32, 11);
            chipTf = Win.label(chip, "0/3", 14, 0xFFFFFF, 140, 9, true);
            var logBtn:Btn = new Btn(Btn.GHOST, 96, 40, "Ver log", "", function(e:MouseEvent):void { showLog(); });
            logBtn.x = PW / 2 - 48 - 46; logBtn.y = T + 36;
            addChild(logBtn);
            var closeX:Sprite = Win.closeButton(36, 40, function(e:MouseEvent):void { hide(); });
            closeX.x = PW / 2 - 40; closeX.y = T + 16;
            addChild(closeX);

            // barra lateral com uma aba por macro
            var side:Sprite = new Sprite();
            Win.card(side, L + 12, T + 84, 158, PH - 96, 16, 0x0D0C24, 0x2A2955);
            addChild(side);
            var tabs:Array = [["Planos", "app:/assets/macro/mina.png"], ["Ciclo de missões", "app:/assets/macro/missao.png"], ["Moeda VIP", "app:/assets/macro/vip.png"]];
            for (var ti:int = 0; ti < tabs.length; ti++)
            {
                var tb:Sprite = makeTab(String(tabs[ti][0]), String(tabs[ti][1]), ti);
                tb.x = L + 22; tb.y = T + 90 + ti * 122;
                addChild(tb);
                tabBtns.push(tb);
            }

            // área principal (esquerda da janela = barra lateral)
            var MX:Number = L + 186;     // início da área principal
            var MW:Number = PW - 186 - 14;
            addChild(tabPlanos);
            addChild(tabCiclo);
            addChild(tabVip);

            // ---- banner (comum às abas; imagem e textos trocam com a aba/modo) ----
            var banner:Sprite = new Sprite();
            banner.x = MX; banner.y = T + 84;
            addChild(banner);
            Win.card(banner, 0, 0, MW, 100, 16, 0x120F33, 0x3B2F85);
            banner.addChild(bannerArt);
            bannerTitle = text("Minas", 26, 0xFFFFFF, 24, 14);
            banner.addChild(bannerTitle);
            bannerDesc = text("", 12, Btn.TEXT_SOFT, 24, 52, 260);
            banner.addChild(bannerDesc);

            // ---- aba 1: Planos ----
            var cl:Number = MX;               // coluna esquerda: controles
            var cw:Number = 310;
            var y0:Number = T + 196;
            var secs:Sprite = new Sprite(); tabPlanos.addChild(secs);
            Win.section(secs, "MODO", cl, y0, cw);
            segNormal = new Btn(Btn.GHOST, 100, 32, "Normal", "", function(e:MouseEvent):void { opts.portal = 0; refresh(); });
            segMinas  = new Btn(Btn.GHOST, 100, 32, "Minas", "", function(e:MouseEvent):void { opts.portal = 3; refresh(); });
            segFechar = new Btn(Btn.GHOST, 100, 32, "Fechar planos", "", function(e:MouseEvent):void { opts.portal = 4; refresh(); });
            segNormal.x = cl + 50;  segNormal.y = y0 + 34;
            segMinas.x  = cl + 155; segMinas.y  = y0 + 34;
            segFechar.x = cl + 260; segFechar.y = y0 + 34;
            tabPlanos.addChild(segNormal); tabPlanos.addChild(segMinas); tabPlanos.addChild(segFechar);

            Win.section(secs, "OPÇÕES", cl, y0 + 58, cw);
            btnBox = new Btn(Btn.GHOST, 152, 32, "", "", function(e:MouseEvent):void { if (int(opts.portal) >= 3) { cycleElement(); return; } opts.box = !opts.box; refresh(); });
            btnRes = new Btn(Btn.GHOST, 152, 32, "", "", function(e:MouseEvent):void { if (int(opts.portal) >= 3) return; opts.res = !opts.res; refresh(); });
            btnMon = new Btn(Btn.GHOST, 152, 32, "", "", function(e:MouseEvent):void { if (int(opts.portal) >= 3) return; opts.mon = !opts.mon; refresh(); });
            btnBoss = new Btn(Btn.GHOST, 152, 32, "", "", function(e:MouseEvent):void { if (int(opts.portal) >= 3) return; opts.boss = !opts.boss; refresh(); });
            btnBox.x = cl + 76;  btnBox.y = y0 + 92;
            btnRes.x = cl + 234; btnRes.y = y0 + 92;
            btnMon.x = cl + 76;  btnMon.y = y0 + 130;
            btnBoss.x = cl + 234; btnBoss.y = y0 + 130;
            tabPlanos.addChild(btnBox); tabPlanos.addChild(btnRes); tabPlanos.addChild(btnMon); tabPlanos.addChild(btnBoss);

            Win.section(secs, "FERRAMENTAS", cl, y0 + 154, cw);
            btnEnergy = new Btn(Btn.GHOST, cw, 32, "", "", function(e:MouseEvent):void { cycleEnergy(); });
            btnEnergy.x = cl + cw / 2; btnEnergy.y = y0 + 188;
            tabPlanos.addChild(btnEnergy);
            var dump:Btn = new Btn(Btn.GHOST, cw, 32, "", "", function(e:MouseEvent):void { opts.discardClosed = !opts.discardClosed; refresh(); });
            dump.x = cl + cw / 2; dump.y = y0 + 226;
            btnCycle = dump;
            tabPlanos.addChild(dump);
            btnSim = new Btn(Btn.GHOST, 152, 32, "Gravar meus passos", "", function(e:MouseEvent):void { toggleRec(); });
            btnSim.x = cl + 76; btnSim.y = y0 + 264;
            tabPlanos.addChild(btnSim);
            var diag:Btn = new Btn(Btn.GHOST, 152, 32, "Diagnóstico (só lê)", "", function(e:MouseEvent):void { diagnose(); });
            diag.x = cl + 234; diag.y = y0 + 264;
            tabPlanos.addChild(diag);
            btnReal = new Btn(Btn.PRIMARY, cw, 50, "INICIAR", "", function(e:MouseEvent):void { toggleReal(); });
            btnReal.x = cl + cw / 2; btnReal.y = y0 + 320;
            tabPlanos.addChild(btnReal);
            btnPortal = btnReal;     // (o antigo botão de modo foi trocado pelos três botões de MODO)

            // coluna direita: mapa
            var mapBox:Sprite = new Sprite();
            Win.field(mapBox, MAP_CX - MAP / 2 - 3, MAP_CY - MAP / 2 - 3, MAP + 6, MAP + 6);
            tabPlanos.addChild(mapBox);
            mapTitle = text("MAPA", 11, Btn.ACCENT_LIGHT, MAP_CX - MAP / 2 - 3, MAP_CY - MAP / 2 - 24);
            mapTitle.autoSize = TextFieldAutoSize.NONE; mapTitle.width = MAP + 6; mapTitle.height = 18;
            tabPlanos.addChild(mapTitle);
            tabPlanos.addChild(bgMap);
            tabPlanos.addChild(markLayer);
            tabPlanos.addChild(text("ouro=baú verde=recurso vermelho=monstro roxo=chefe\nazul=entrada/saída ciano=mercado X=feito", 9, Btn.TEXT_MUTED, MAP_CX - MAP / 2 - 3, MAP_CY + MAP / 2 + 8, MAP + 20));

            // log curto (últimas linhas)
            var lg:Sprite = new Sprite();
            Win.field(lg, MAP_CX - MAP / 2 - 3, 204, MAP + 6, 76);
            tabPlanos.addChild(lg);
            logTf = text("", 10, 0xD0D0D0, MAP_CX - MAP / 2 + 5, 208, MAP - 10);
            logTf.defaultTextFormat = new TextFormat("_typewriter", 10, 0xD0D0D0);
            logTf.autoSize = TextFieldAutoSize.NONE;
            logTf.height = 68;
            tabPlanos.addChild(logTf);

            // ---- aba 2: Ciclo de missões ----
            Win.section(tabCiclo, "MISSÕES DE CICLO", MX, T + 196, MW);
            var cm:TextField = text("Em desenvolvimento.\n\nO macro vai pegar a Missão de Ciclo no diálogo do NPC e fazer as 200 missões em sequência, uma por uma.\n\nPara eu conseguir montar: ligue o gravador (aba Planos > Gravar meus passos), faça de 10 a 15 missões seguidas e anote o nome de cada uma. Depois mande o log.", 13, Btn.TEXT_SOFT, MX, T + 226, MW - 10);
            tabCiclo.addChild(cm);
            var soon:Btn = new Btn(Btn.PRIMARY, MW, 50, "Iniciar (em breve)", "", function(e:MouseEvent):void { say("Ciclo de missões: ainda não disponível."); });
            soon.x = MX + MW / 2; soon.y = T + PH - 52;
            soon.alpha = 0.45;
            tabCiclo.addChild(soon);

            // ---- aba 3: Moeda VIP ----
            Win.section(tabVip, "MOEDA VIP · CLIQUE NA IMAGEM PARA ESCOLHER O ITEM", MX, T + 196, MW);
            var cardW:Number = (MW - 12) / 2;
            for (var ci:int = 0; ci < VipMacro.ITEMS.length; ci++)
            {
                var card:Sprite = new Sprite();
                card.x = MX + ci * (cardW + 12); card.y = T + 222;
                card.mouseChildren = false; card.buttonMode = true;
                card.addEventListener(MouseEvent.CLICK, makeItemHandler(ci));
                var holder:Sprite = new Sprite();
                holder.x = 10; holder.y = 8;
                card.addChild(holder);
                var nm:TextField = text(String(VipMacro.ITEMS[ci].label), 14, 0xFFFFFF, 86, 14, cardW - 96);
                card.addChild(nm);
                card.addChild(text("rende " + VipMacro.ITEMS[ci].per + " por coleta", 11, Btn.TEXT_MUTED, 86, 50));
                tabVip.addChild(card);
                itemCards.push(card);
                itemIcons.push(holder);
                loadItemIcon(ci);
            }
            tabVip.addChild(text("A mochila abre sozinha (atalho B). O macro usa as Moedas VIP, eleva e habilita até a meta.", 12, Btn.TEXT_MUTED, MX, T + 304, MW - 10));
            goalLblTf = text("META (quantidade de itens)", 12, Btn.TEXT_SOFT, MX, T + 326, MW - 10);
            tabVip.addChild(goalLblTf);
            var goalNames:Array = ["100", "300", "500", "Outro"];
            for (var gi:int = 0; gi < 4; gi++)
            {
                var gb:Btn = new Btn(Btn.GHOST, 100, 32, String(goalNames[gi]), "", makeGoalHandler(gi));
                gb.x = MX + 50 + gi * 110; gb.y = T + 360;
                tabVip.addChild(gb);
                goalBtns.push(gb);
            }
            customBox = new Sprite();
            Win.field(customBox, MX + 456, T + 344, 124, 32);
            tabVip.addChild(customBox);
            customTf = new TextField();
            customTf.type = TextFieldType.INPUT;
            customTf.restrict = "0-9";
            customTf.maxChars = 6;
            customTf.needsSoftKeyboard = true;
            customTf.defaultTextFormat = new TextFormat("_sans", 17, 0xFFFFFF, true);
            customTf.text = "1000";
            customTf.x = MX + 464; customTf.y = T + 349; customTf.width = 108; customTf.height = 24;
            customTf.addEventListener(Event.CHANGE, function(e:Event):void { applyGoal(); });
            tabVip.addChild(customTf);
            vipStatusTf = text("parado", 13, Btn.ACCENT_LIGHT, MX, T + 382, MW - 10);
            tabVip.addChild(vipStatusTf);
            var vlg:Sprite = new Sprite();
            Win.field(vlg, MX, T + 404, MW, 60);
            tabVip.addChild(vlg);
            vipLogTf = text("", 10, 0xD0D0D0, MX + 8, T + 407, MW - 16);
            vipLogTf.defaultTextFormat = new TextFormat("_typewriter", 10, 0xD0D0D0);
            vipLogTf.autoSize = TextFieldAutoSize.NONE;
            vipLogTf.height = 56;
            tabVip.addChild(vipLogTf);
            var btnDiag:Btn = new Btn(Btn.GHOST, 280, 28, "Diagnóstico da mochila", "", function(e:MouseEvent):void { vip.diagnose(); refresh(); });
            btnDiag.x = MX + 140; btnDiag.y = T + 484;
            tabVip.addChild(btnDiag);
            capBtn = new Btn(Btn.GHOST, 280, 28, "", "", function(e:MouseEvent):void { toggleCapture(); });
            capBtn.x = MX + MW - 140; capBtn.y = T + 484;
            tabVip.addChild(capBtn);
            capBtn.setText("Exportar imagens do jogo");
            btnVip = new Btn(Btn.PRIMARY, MW, 50, "INICIAR", "", function(e:MouseEvent):void { toggleVip(); });
            btnVip.x = MX + MW / 2; btnVip.y = T + PH - 52;
            tabVip.addChild(btnVip);
            vip.onIcon = onItemIcon;
            setGoalMode(0);
            setItem(0);

            // janelinha de aviso (por cima de tudo)
            addChild(popup);
            popup.visible = false;

            selectTab(0, false);
        }

        // Copia as imagens que o jogo já guardou no cache do app para mods/_capturas/ (a pasta aparece na hora).
        private var exporting:Boolean = false;
        private function toggleCapture():void
        {
            if (exporting) return;
            if (dumpDir == "") { showPopup("Exportar imagens", "Não achei a pasta mods do app."); return; }
            exporting = true;
            capBtn.setText("Exportando...");
            var dest:String = new File(dumpDir).resolvePath("_capturas").nativePath;
            say("exportando as imagens do cache para " + dest);
            SwfFixer.exportImages(dest, function(found:int, added:int, err:String):void
            {
                exporting = false;
                capBtn.setText("Exportar imagens do jogo");
                if (err != "")
                {
                    say("exportar imagens: " + err);
                    showPopup("Exportar imagens", "Falhou: " + err);
                    return;
                }
                say("exportei " + added + " imagens novas (" + found + " imagens no cache)");
                if (found == 0)
                    showPopup("Exportar imagens", "A pasta _capturas foi criada, mas o cache ainda não tem imagens. Abra a mochila e a Roleta no jogo, espere carregar e clique de novo.\n\nPasta: " + dest);
                else
                    showPopup("Exportar imagens", added + " imagens novas copiadas (" + found + " no cache).\n\nPasta: " + dest);
            });
        }

        private function makeItemHandler(i:int):Function
        {
            return function(e:MouseEvent):void { if (!vip.running) { setItem(i); refresh(); } };
        }

        // Escolhe o item que o macro pega (e redesenha os cartões).
        private function setItem(i:int):void
        {
            vip.setItem(i);
            for (var k:int = 0; k < itemCards.length; k++)
            {
                var cw:Number = (580 - 12) / 2;
                var c:Sprite = Sprite(itemCards[k]);
                c.graphics.clear();
                var on:Boolean = (k == i);
                c.graphics.lineStyle(on ? 3 : 1, on ? Btn.ACCENT_LIGHT : Win.LINE, 1);
                c.graphics.beginFill(on ? 0x1D1B4A : 0x0F0E28, 1);
                c.graphics.drawRoundRect(0, 0, cw, 76, 22, 22);
                c.graphics.endFill();
                c.alpha = on ? 1 : 0.75;
            }
            goalLblTf.text = "META (quantidade de itens; cada coleta rende " + VipMacro.ITEMS[i].per + ")";
        }

        // Imagem do cartão: a capturada do jogo (salva), senão o desenho padrão do app.
        private function loadItemIcon(i:int):void
        {
            var holder:Sprite = Sprite(itemIcons[i]);
            var key:String = String(VipMacro.ITEMS[i].key);
            var l:Loader = new Loader();
            l.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void { fitIcon(holder, l.content); });
            try
            {
                var bytes:ByteArray = null;
                // 1) imagem sua: coloque mods/item_pedra.png e/ou mods/item_ordem.png
                if (dumpDir != "")
                {
                    var f:File = new File(dumpDir).resolvePath("item_" + key + ".png");
                    if (f.exists)
                    {
                        bytes = new ByteArray();
                        var fs:FileStream = new FileStream();
                        fs.open(f, FileMode.READ); fs.readBytes(bytes); fs.close();
                    }
                }
                // 2) imagem capturada do jogo
                if (bytes == null || bytes.length == 0) bytes = Prefs.iconBytes(key);
                if (bytes != null && bytes.length > 0) l.loadBytes(bytes);
                else l.load(new URLRequest("app:/assets/macro/" + VipMacro.ITEMS[i].art + ".png"));   // 3) desenho do app
            }
            catch (err:Error) {}
        }

        private function reloadIcons():void { for (var i:int = 0; i < itemIcons.length; i++) loadItemIcon(i); }

        private function fitIcon(holder:Sprite, c:DisplayObject):void
        {
            while (holder.numChildren) holder.removeChildAt(0);
            if (c is Bitmap) Bitmap(c).smoothing = true;
            var sc:Number = Math.min(60 / c.width, 60 / c.height);
            c.scaleX = c.scaleY = sc;
            c.x = (60 - c.width) / 2; c.y = (60 - c.height) / 2;
            holder.addChild(c);
        }

        private function onItemIcon(key:String, bd:BitmapData):void
        {
            for (var i:int = 0; i < VipMacro.ITEMS.length; i++)
            {
                if (String(VipMacro.ITEMS[i].key) != key) continue;
                try { Prefs.setIconBytes(key, bd.encode(bd.rect, new PNGEncoderOptions())); } catch (e:Error) {}
                fitIcon(Sprite(itemIcons[i]), new Bitmap(bd));
            }
        }

        private function makeGoalHandler(i:int):Function
        {
            return function(e:MouseEvent):void { setGoalMode(i); refresh(); };
        }

        private function setGoalMode(i:int):void
        {
            goalMode = i;
            for (var k:int = 0; k < goalBtns.length; k++) Btn(goalBtns[k]).selected = (k == i);
            customBox.visible = (i == 3);
            customTf.visible = (i == 3);
            applyGoal();
        }

        // Meta em ITENS: 100 / 300 / 500 ou o número digitado.
        private function applyGoal():void
        {
            var g:int = 100;
            if (goalMode == 1) g = 300;
            else if (goalMode == 2) g = 500;
            else if (goalMode == 3) { g = int(customTf.text); if (g < 1) g = 1; }
            vip.goal = g;
        }

        private function toggleVip():void
        {
            bindCtx();
            if (vip.running) { vip.stop("parado pelo usuário"); refresh(); notifyMirror("stop_vip"); return; }
            try { stage.focus = null; } catch (eF:Error) {}
            vip.start();
            refresh();
            notifyMirror("vip");
        }

        private function notifyMirror(action:String):void
        {
            try { if (onMirrorMacro != null) onMirrorMacro(action); } catch (e:Error) {}
        }

        private function bindCtx():void
        {
            try { if (onBeforeAction != null) onBeforeAction(); } catch (e:Error) {}
            var hs:DisplayObjectContainer = hostStage != null ? hostStage : stage;
            if (hs == null) return;
            if (realAd != null) { realAd.hostStage = hs; realAd.hostDomain = hostDomain; }
            if (vip != null) vip.hostStage = hs;
            if (cycle != null) cycle.hostStage = hs;
        }

        public function isRunning():Boolean
        {
            return (vip != null && vip.running) || (real != null && real.running)
                || (cycle != null && cycle.running) || (sim != null && sim.running);
        }

        // Chamado pelas janelas seguidoras (espelho de macros).
        public function remoteAction(action:String):void
        {
            bindCtx();
            if (action == "planes")
            {
                if (real.running || cycle.running) return;
                // não usa toggleReal: evita notifyMirror de novo na seguidora
                if ((int(opts.portal) == 3 || int(opts.portal) == 4) && !realAd.ready
                    && realAd.sceneName() == "CASTLE_SCENE")
                {
                    cycle.mode = int(opts.portal); cycle.element = String(opts.element);
                    cycle.startFromCastle(); refresh();
                    return;
                }
                if (!realAd.ready) say("Planos (espelho): mapa ainda não aberto; aguardando...");
                real.start();
                refresh();
                return;
            }
            if (action == "vip")
            {
                if (vip.running) return;
                try { stage.focus = null; } catch (eF:Error) {}
                vip.start();
                refresh();
                return;
            }
            if (action == "stop" || action == "stop_planes")
            {
                if (real.running || cycle.running) { real.stop("espelho: parou"); cycle.stop("espelho: parou"); refresh(); }
                return;
            }
            if (action == "stop_vip")
            {
                if (vip.running) { vip.stop("espelho: parou"); refresh(); }
                return;
            }
            if (action == "stop_all")
            {
                stopAll();
                return;
            }
        }

        // ---------- aviso de parada (janelinha com o motivo) ----------
        private function alertStop(title:String, msg:String):void
        {
            say("AVISO: " + msg);
            if (!isOpen) { pendingPopup = [title, msg]; if (onWake != null) onWake(); return; }
            showPopup(title, msg);
        }

        private function showPopup(title:String, msg:String):void
        {
            pendingPopup = null;
            while (popup.numChildren) popup.removeChildAt(0);
            popup.graphics.clear();
            popup.graphics.beginFill(0x000000, 0.45);
            popup.graphics.drawRect(-PW / 2, -PH / 2, PW, PH);
            popup.graphics.endFill();
            var box:Sprite = new Sprite();
            Win.card(box, -170, -80, 340, 160, 18, 0x14123A, 0x7C3AED);
            popup.addChild(box);
            var tt:TextField = text(title, 12, Btn.TEXT_MUTED, -150, -66);
            popup.addChild(tt);
            var mm:TextField = text(msg, 20, 0xFFFFFF, -150, -38, 300);
            popup.addChild(mm);
            var ok:Btn = new Btn(Btn.PRIMARY, 140, 40, "OK", "", function(e:MouseEvent):void { popup.visible = false; });
            ok.x = 0; ok.y = 50;
            popup.addChild(ok);
            popup.visible = true;
            setChildIndex(popup, numChildren - 1);
        }

        // Miniatura da aba na barra lateral.
        private function makeTab(label:String, img:String, idx:int):Sprite
        {
            var t:Sprite = new Sprite();
            var art:Sprite = new Sprite();
            art.x = 6; art.y = 6;
            t.addChild(art);
            Win.cover(art, img, 126, 76, 10);
            var tf:TextField = text(label, 12, 0xFFFFFF, 0, 86);
            tf.x = (138 - tf.width) / 2;
            t.addChild(tf);
            t.mouseChildren = false; t.buttonMode = true;
            t.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { selectTab(idx); });
            return t;
        }

        private function paintTab(t:Sprite, on:Boolean):void
        {
            t.graphics.clear();
            t.graphics.lineStyle(on ? 2 : 1, on ? Btn.ACCENT_LIGHT : 0x2A2955, 1);
            t.graphics.beginFill(on ? 0x1C1650 : 0x0B0A1E, 1);
            t.graphics.drawRoundRect(0, 0, 138, 108, 20, 20);
            t.graphics.endFill();
        }

        private function selectTab(i:int, doRefresh:Boolean = true):void
        {
            curTab = i;
            tabPlanos.visible = (i == 0);
            tabCiclo.visible = (i == 1);
            tabVip.visible = (i == 2);
            for (var k:int = 0; k < tabBtns.length; k++) paintTab(Sprite(tabBtns[k]), k == i);
            if (doRefresh) refresh();
        }

        private var bannerShown:String = "";
        private function setBanner(title:String, desc:String, img:String):void
        {
            bannerTitle.text = title;
            bannerDesc.text = desc;
            if (bannerShown != img)
            {
                bannerShown = img;
                while (bannerArt.numChildren) bannerArt.removeChildAt(0);
                bannerArt.mask = null;
                Win.cover(bannerArt, img, PW - 186 - 14, 100, 16);
                bannerArt.x = 0; bannerArt.y = 0;
            }
        }

        // ---------- mostrar / esconder ----------
        public function get isOpen():Boolean { return parent != null; }

        public function show(host:DisplayObjectContainer, stageW:Number, stageH:Number, uiScale:Number):void
        {
            var s:Number = Math.min(uiScale, (stageH - 16) / PH, (stageW - 16) / PW);
            s = Math.max(0.5, s);
            scaleX = scaleY = s;
            if (parent == null)
            {
                x = stageW / 2;
                y = stageH / 2;
                host.addChild(this);
            }
            reloadIcons();
            refresh();
            if (pendingPopup != null) showPopup(String(pendingPopup[0]), String(pendingPopup[1]));
        }

        // Para todos os macros (usado antes de relogar).
        public function stopAll():void
        {
            try { vip.stop("parado (relogando)"); } catch (e1:Error) {}
            try { real.stop("parado (relogando)"); } catch (e2:Error) {}
            try { cycle.stop("parado (relogando)"); } catch (e3:Error) {}
            try { sim.stop("parado (relogando)"); } catch (e4:Error) {}
            hide();
        }

        public function hide():void
        {
            stopDragging();
            if (parent != null) parent.removeChild(this);
        }

        private function onAdded(e:Event):void
        {
            if (timer == null)
            {
                timer = new Timer(500);
                timer.addEventListener(TimerEvent.TIMER, function(ev:TimerEvent):void { refresh(); });
            }
            timer.start();
        }

        private function onRemoved(e:Event):void
        {
            if (timer != null) timer.stop();
        }

        // ---------- arrastar ----------
        private function onBarDown(e:MouseEvent):void
        {
            startDrag();
            if (stage != null) stage.addEventListener(MouseEvent.MOUSE_UP, onDragUp);
        }

        private function onDragUp(e:MouseEvent):void { stopDragging(); }

        private function stopDragging():void
        {
            stopDrag();
            if (stage != null) stage.removeEventListener(MouseEvent.MOUSE_UP, onDragUp);
        }

        // ---------- ações ----------
        private function toggleReal():void
        {
            bindCtx();
            if (real.running || cycle.running)
            {
                real.stop("parado pelo usuário"); cycle.stop("parado pelo usuário"); refresh();
                notifyMirror("stop_planes");
                return;
            }
            if ((int(opts.portal) == 3 || int(opts.portal) == 4) && !realAd.ready)
            {
                if (realAd.sceneName() == "CASTLE_SCENE")
                {
                    cycle.mode = int(opts.portal); cycle.element = String(opts.element);
                    cycle.startFromCastle(); refresh();
                    notifyMirror("planes");
                    return;
                }
            }
            if (!realAd.ready) say("Planos: o mapa de Planos ainda não está aberto no jogo; o macro espera ele aparecer.");
            if (stage != null) say("FPS do app: " + int(stage.frameRate));
            real.start();
            refresh();
            notifyMirror("planes");
        }

        private function toggleRec():void
        {
            if (ClickRecorder.on) ClickRecorder.stop();
            else ClickRecorder.start(stage, say, realAd);
            refresh();
        }

        private function toggleSim():void
        {
            if (sim.running) { sim.stop("parado pelo usuário"); refresh(); return; }
            simAd.reset();
            sim.start();
            refresh();
        }

        // Pasta onde o relatório de classes é gravado (a mesma pasta "mods" do app, acessível pelo gerenciador de arquivos).
        public var dumpDir:String = "";

        private function dumpClasses():void
        {
            var r:String = ClassDump.run(dumpDir);
            say("Lista de classes gerada (" + r.split("\n").length + " linhas)");
            if (onText != null) onText("Classes do jogo", r);
        }

        private function diagnose():void
        {
            var r:String = realAd.report() + "\n\n" + realAd.planesReport() + "\n\n" + realAd.bagReport() + "\n\nJANELAS NO PALCO: " + realAd.windowNames().join(", ");
            say("Diagnóstico executado");
            if (logger != null) logger("MACRO " + r);
            if (onText != null) onText("Diagnóstico dos macros", r);
        }

        private function showLog():void
        {
            if (onText != null) onText("Log dos macros", lines.join("\n"));
        }

        // ---------- atualização periódica ----------
        private function onOff(label:String, v:Boolean):String { return label + ": " + (v ? "SIM" : "NÃO"); }

        // Liga/desliga a compra de passos (energia de dentro do plano), usada SÓ quando falta energia para pegar uma mina.
        private function cycleEnergy():void
        {
            opts.autoBuy = !opts.autoBuy;
            opts.maxBuys = opts.autoBuy ? 99 : 0;
            say(opts.autoBuy ? "Compra de passos (só para minas) LIGADA: só compra quando vê uma mina e faltam passos para pegá-la (gasta diamantes; para se faltar dado, diamante ou passar o limite diário)" : "Compra de passos desligada");
            refresh();
        }

        // Escolhe o elemento do plano (Fechar planos / Minas): VARIA -> elementos conhecidos -> VARIA...
        private function cycleElement():void
        {
            var seq:Array = [""];
            var base:Array = ["luz", "trevas", "fogo", "choque", "vento", "água"];
            var i:int;
            for (i = 0; i < base.length; i++) seq.push(base[i]);
            for (i = 0; i < GamePlanesAdapter.seenElements.length; i++)
            {
                var e:String = String(GamePlanesAdapter.seenElements[i]);
                var dup:Boolean = false;
                for (var j:int = 0; j < seq.length; j++) if (GamePlanesAdapter.norm(String(seq[j])) == e) dup = true;
                if (!dup) seq.push(e);
            }
            var cur:int = 0;
            for (i = 0; i < seq.length; i++) if (String(seq[i]) == String(opts.element)) cur = i;
            opts.element = String(seq[(cur + 1) % seq.length]);
            say("Elemento do plano: " + (String(opts.element).length > 0 ? String(opts.element) : "varia entre os da bolsa"));
            refresh();
        }

        public function refresh():void
        {
            var running:Boolean = real.running || cycle.running;
            chipTf.text = ((running ? 1 : 0) + (vip.running ? 1 : 0)) + "/3";
            if (curTab == 2)
            {
                setBanner("Moeda VIP", "Usa as Moedas VIP e eleva até sair a Pedra secreta; habilita e repete.", "app:/assets/macro/vip.png");
                btnVip.setText(vip.running ? "PARAR" : "INICIAR");
                vipStatusTf.text = (vip.running ? vip.status : "parado") + "  ·  " + VipMacro.ITEMS[vip.itemIdx].label + ": " + vip.collected + " / " + vip.goal;
                var vl:Array = [];
                for (var vi:int = lines.length - 1; vi >= 0 && vl.length < 4; vi--) if (String(lines[vi]).indexOf("[VIP]") == 0) vl.unshift(lines[vi]);
                vipLogTf.text = vl.join("\n");
                return;
            }
            if (curTab == 1)
            {
                setBanner("Ciclo de missões", "Faz as 200 missões de ciclo, uma após a outra.", "app:/assets/macro/missao.png");
                return;
            }
            var pm:int = int(opts.portal);
            var mn:Boolean = pm == 3 || pm == 4;
            if (pm == 3) setBanner("Minas", "Procura a mina no plano, coleta o minério e passa para o próximo plano.", "app:/assets/macro/mina.png");
            else if (pm == 4) setBanner("Fechar planos", "Fecha o plano por completo (torres e baús primeiro) e troca por outro.", "app:/assets/macro/mina.png");
            else setBanner("Planos", "Percorre o mapa em grade do plano aberto no jogo.", "app:/assets/macro/mina.png");
            segNormal.selected = (pm == 0);
            segMinas.selected = (pm == 3);
            segFechar.selected = (pm == 4);
            btnReal.setText(running ? "PARAR" : "INICIAR");
            btnCycle.setText(opts.discardClosed ? "Plano fechado: descarta" : "Plano fechado: mantém");
            btnCycle.selected = Boolean(opts.discardClosed);
            btnSim.setText(ClickRecorder.on ? "Parar gravação" : "Gravar meus passos");
            btnSim.selected = ClickRecorder.on;
            btnBox.setText(mn ? "Elemento: " + (String(opts.element).length > 0 ? String(opts.element) : "VARIA") : onOff("Baús", opts.box));
            btnBox.selected = mn ? false : Boolean(opts.box);
            btnRes.setText(mn ? "Recursos: —" : onOff("Recursos", opts.res));
            btnRes.selected = mn ? false : Boolean(opts.res);
            btnMon.setText(mn ? "Monstros: —" : onOff("Monstros", opts.mon));
            btnMon.selected = mn ? false : Boolean(opts.mon);
            btnBoss.setText(mn ? "Chefe: —" : onOff("Chefe", opts.boss));
            btnBoss.selected = mn ? false : Boolean(opts.boss);
            btnEnergy.setText("Compra de passos (só minas): " + (opts.autoBuy ? "SIM" : "NÃO"));
            btnEnergy.selected = Boolean(opts.autoBuy);
            var st:String = "";
            if (real.running) st = "Planos: " + real.status;
            else if (cycle.running) st = cycle.status;
            else if (sim.running) st = "Simulação: " + sim.status;
            else st = "parado";
            statusTf.text = st.length > 52 ? st.substr(0, 52) : st;
            var ln:Array = lines.slice(Math.max(0, lines.length - 5));
            if (running || sim.running) ln.unshift("» " + (st.length > 40 ? st.substr(0, 40) : st));
            logTf.text = ln.slice(Math.max(0, ln.length - 5)).join("\n");
            drawMap();
        }

        private static function cellColor(type:int, id:int):uint
        {
            if (id == 0 && type == 0) return 0x1B1A47;
            var c:String = PlanesBot.category(type);
            if (c == "box") return 0xB8860B;
            if (c == "res") return 0x2E8B57;
            if (c == "mon") return 0xB5322E;
            if (c == "boss") return 0x8E2BC4;
            if (c == "portal") return 0xE8D44D;
            if (c == "exit") return 0x2F6DB5;
            if (c == "market") return 0x1E8EA3;
            if (c == "wall") return 0x0A0918;
            return 0x4A4880;
        }

        private function buildCells(cols:int, rows:int):void
        {
            var i:int;
            for (i = 0; i < cellTfs.length; i++) if (cellTfs[i].parent) cellTfs[i].parent.removeChild(cellTfs[i]);
            cellTfs = [];
            mapCols = cols; mapRows = rows;
            cellSize = Math.floor(Math.min(MAP / cols, MAP / rows));
            mapX0 = MAP_CX - cols * cellSize / 2;
            mapY0 = MAP_CY - rows * cellSize / 2;
            var size:int = Math.max(8, int(cellSize * 0.36));
            var f:TextFormat = new TextFormat("_sans", size, 0xFFFFFF, true, null, null, null, null, "center");
            for (i = 0; i < cols * rows; i++)
            {
                var t:TextField = new TextField();
                t.defaultTextFormat = f;
                t.selectable = false; t.mouseEnabled = false;
                t.width = cellSize; t.height = cellSize;
                t.x = mapX0 + int(i / rows) * cellSize;
                t.y = mapY0 + (i % rows) * cellSize + (cellSize - size * 1.3) / 2;
                cellTfs.push(t);
                tabPlanos.addChild(t);   // dentro da aba Planos: some junto com ela
            }
        }

        private function drawMap():void
        {
            var ad:IPlanesAdapter;
            var bot:PlanesBot;
            if (sim.running) { ad = simAd; bot = sim; mapTitle.text = "MAPA: simulação"; }
            else if (realAd.ready)
            {
                ad = realAd; bot = real;
                var eyeTxt:String = "";
                try
                {
                    var cl:Array = realAd.cells();
                    eyeTxt = "  ·  SEM OLHO neste piso";
                    for (var q:int = 0; q < cl.length; q++)
                        if (cl[q].type == 8) { eyeTxt = "  ·  OLHO em (" + cl[q].x + "," + cl[q].y + ")"; break; }
                }
                catch (e1:Error) {}
                mapTitle.text = "MAPA: jogo real" + eyeTxt;
            }
            else { ad = simAd; bot = sim; mapTitle.text = "MAPA: demonstração"; }

            var cols:int = ad.cols;
            var rows:int = ad.rows;
            if (cols <= 0 || rows <= 0) return;
            if (cols != mapCols || rows != mapRows) buildCells(cols, rows);

            var byKey:Object = {};
            var list:Array = ad.cells();
            var i:int;
            var c:Object;
            for (i = 0; i < list.length; i++) { c = list[i]; byKey[c.x * 100 + c.y] = c; }

            bgMap.graphics.clear();
            markLayer.graphics.clear();
            var x:int;
            var y:int;
            var px:Number;
            var py:Number;
            var tf:TextField;
            for (x = 0; x < cols; x++)
            {
                for (y = 0; y < rows; y++)
                {
                    c = byKey[x * 100 + y];
                    px = mapX0 + x * cellSize;
                    py = mapY0 + y * cellSize;
                    bgMap.graphics.lineStyle(1, 0x000000, 0.6);
                    bgMap.graphics.beginFill(c == null ? 0x14133A : cellColor(c.type, c.id), 1);
                    bgMap.graphics.drawRect(px, py, cellSize, cellSize);
                    bgMap.graphics.endFill();
                    if (c != null && !c.opened)
                    {
                        bgMap.graphics.lineStyle(0, 0, 0);
                        bgMap.graphics.beginFill(0x000000, 0.65);
                        bgMap.graphics.drawRect(px, py, cellSize, cellSize);
                        bgMap.graphics.endFill();
                    }
                    tf = cellTfs[x * rows + y];
                    if (c == null) tf.text = "";
                    else if (c.type == -1) tf.text = "#";
                    else if (c.type == 0 && c.id == 0) tf.text = "";
                    else tf.text = String(c.type);
                    if (bot.done[x * 100 + y])
                    {
                        markLayer.graphics.lineStyle(2, 0xFFFFFF, 0.8);
                        markLayer.graphics.moveTo(px + 4, py + 4); markLayer.graphics.lineTo(px + cellSize - 4, py + cellSize - 4);
                        markLayer.graphics.moveTo(px + cellSize - 4, py + 4); markLayer.graphics.lineTo(px + 4, py + cellSize - 4);
                    }
                }
            }
            if (bot.target != null)
            {
                markLayer.graphics.lineStyle(3, 0xFF3B3B, 1);
                markLayer.graphics.drawRect(mapX0 + bot.target.x * cellSize + 2, mapY0 + bot.target.y * cellSize + 2, cellSize - 4, cellSize - 4);
            }
            if (ad.posX >= 0 && ad.posY >= 0)
            {
                markLayer.graphics.lineStyle(3, 0xFFFFFF, 1);
                markLayer.graphics.drawCircle(mapX0 + (ad.posX + 0.5) * cellSize, mapY0 + (ad.posY + 0.5) * cellSize, cellSize * 0.32);
            }
        }
    }
}
