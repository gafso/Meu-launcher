package
{
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.SecurityErrorEvent;
    import flash.net.URLLoader;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;

    // Lê as notícias da página de login do servidor (https://<host>/) e devolve uma lista
    // [{title, date, url}]. Como o HTML do site não é conhecido de antemão, o leitor é genérico:
    // pega os links com texto de título e, perto de cada um, procura uma data.
    // Se não achar nada, grava no log um resumo do HTML para ajustarmos depois.
    public class NewsFeed
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        private static const DATE_RE:RegExp = /\d{1,2}[\/.\-]\d{1,2}[\/.\-]\d{2,4}|\d{4}[\/.\-]\d{1,2}[\/.\-]\d{1,2}/;
        private static const SKIP_RE:RegExp = /^(in[ií]cio|home|login|entrar|cadastr|registr|download|baixar|suporte|ajuda|contato|termos|pol[ií]tica|facebook|youtube|instagram|discord|mais|ver todas|more|ok|play|jogar|fechar|voltar)/i;

        public static var logger:Function;
        private static var cache:Object = {};
        private static var loading:Object = {};

        // null = ainda não carregou; [] = carregou mas não achou nada.
        public static function items(host:String):Array { return cache[host] as Array; }
        public static function isLoading(host:String):Boolean { return loading[host] == true; }
        public static function reset(host:String):void { delete cache[host]; }

        private static function say(s:String):void { if (logger != null) logger("Notícias: " + s); }

        public static function load(host:String, onDone:Function):void
        {
            if (cache[host] != null || loading[host] == true) return;
            loading[host] = true;
            var ld:URLLoader = new URLLoader();
            ld.dataFormat = URLLoaderDataFormat.TEXT;
            var req:URLRequest = new URLRequest("https://" + host + "/");
            try { req.userAgent = UA; } catch (e0:Error) {}
            var finish:Function = function(list:Array):void
            {
                cache[host] = list;
                delete loading[host];
                try { onDone(); } catch (e3:Error) {}
            };
            ld.addEventListener(Event.COMPLETE, function(e:Event):void
            {
                var list:Array = [];
                try { list = parse(String(ld.data), host); }
                catch (e1:Error) { say("erro ao ler a página: " + e1.message); }
                say(list.length + " item(ns) em " + host);
                finish(list);
            });
            ld.addEventListener(IOErrorEvent.IO_ERROR, function(e:IOErrorEvent):void { say("sem acesso a " + host + ": " + e.text); finish([]); });
            ld.addEventListener(SecurityErrorEvent.SECURITY_ERROR, function(e:SecurityErrorEvent):void { say("bloqueado: " + e.text); finish([]); });
            try { ld.load(req); }
            catch (e2:Error) { say("falhou: " + e2.message); finish([]); }
        }

        private static function clean(h:String):String
        {
            var t:String = h.replace(/<[^>]*>/g, " ");
            t = t.replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&quot;/gi, "\"").replace(/&#39;|&apos;/gi, "'")
                 .replace(/&lt;/gi, "<").replace(/&gt;/gi, ">");
            t = t.replace(/&#(\d+);/g, function():String { return String.fromCharCode(int(arguments[1])); });
            t = t.replace(/\s+/g, " ");
            return t.replace(/^\s+|\s+$/g, "");
        }

        private static function absolute(u:String, host:String):String
        {
            if (/^https?:\/\//i.test(u)) return u;
            if (u.indexOf("//") == 0) return "https:" + u;
            if (u.charAt(0) == "/") return "https://" + host + u;
            return "https://" + host + "/" + u;
        }

        private static function parse(html:String, host:String):Array
        {
            var h:String = html.replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<!--[\s\S]*?-->/g, " ");
            var re:RegExp = /<a\b[^>]*?href\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
            var withDate:Array = [];
            var noDate:Array = [];
            var seen:Object = {};
            var m:Object = re.exec(h);
            var guard:int = 0;
            while (m != null && guard++ < 600)
            {
                var href:String = String(m[1]);
                var title:String = clean(String(m[2]));
                var after:String = clean(h.substr(m.index + String(m[0]).length, 260));
                var before:String = clean(h.substr(Math.max(0, m.index - 160), 160));
                m = re.exec(h);
                if (/^(#|javascript:|mailto:|tel:)/i.test(href)) continue;
                var dm:Object = DATE_RE.exec(title);
                var date:String = "";
                if (dm != null) { date = String(dm[0]); title = clean(title.replace(DATE_RE, " ")); }
                if (title.length < 14 || title.length > 140 || SKIP_RE.test(title) || seen[title] == true) continue;
                if (date == "")
                {
                    var d2:Object = DATE_RE.exec(after);
                    if (d2 == null) d2 = DATE_RE.exec(before);
                    if (d2 != null) date = String(d2[0]);
                }
                seen[title] = true;
                var it:Object = {title: title, date: date, url: absolute(href, host)};
                if (date != "") withDate.push(it); else noDate.push(it);
            }
            var out:Array = withDate.length >= 2 ? withDate : withDate.concat(noDate);
            if (out.length == 0)
            {
                var plain:String = clean(h);
                say("nada encontrado. Início do texto da página: " + plain.substr(0, 500));
                say("iframes: " + (h.match(/<iframe/gi) || []).length + " | links: " + (h.match(/<a\b/gi) || []).length);
            }
            return out.slice(0, 5);
        }
    }
}
