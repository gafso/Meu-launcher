package
{
    import flash.desktop.Clipboard;
    import flash.desktop.ClipboardFormats;
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.LocationChangeEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.media.StageWebView;
    import flash.net.URLRequest;
    import flash.net.navigateToURL;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Login PC 64-bit — modelo alinhado ao celular:
    // 1) StageWebView (Edge/WebView2) abre o site com cookies da conta.
    // 2) Voce loga e/ou escolhe servidor la (cliques no motor do sistema).
    // 3) Qualquer URL/navegacao com user= e key= (ex.: Loading.swf?...) captura a sessao.
    // 4) Atalhos nativos: digitar codigo do servidor (ex. 1065) abre /serverlist/s1065
    //    com a mesma sessao do WebView (igual abrir o link depois de logado no site).
    public class LoginWindow
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        private static const BAR:int = 88;
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];
        private static const RE_SWF_LOADING:RegExp = /([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/;
        private static const RE_SWF_ANY:RegExp = /([\w.\/:\-%]+\.swf)/;

        public var onSession:Function;
        public var onClosed:Function;

        private var host:String;
        private var win:NativeWindow;
        private var web:StageWebView;
        private var bar:Sprite;
        private var statusTf:TextField;
        private var serverInput:TextField;
        private var done:Boolean = false;
        private var seenSwf:String = null;
        private var scanTimer:Timer;
        private var notes:Array = [];

        public function LoginWindow(host:String)
        {
            this.host = host;
        }

        public function focus():void
        {
            try { if (win != null) win.activate(); } catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login - " + host;
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(1100, b.width - 40);
            win.height = Math.min(800, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            buildBar();
            win.stage.addEventListener(Event.RESIZE, onResize);
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();

            if (!StageWebView.isSupported)
            {
                statusTf.text = "StageWebView indisponivel. Instale o WebView2 Runtime da Microsoft.";
                layout();
                return;
            }

            web = new StageWebView();
            web.stage = win.stage;
            web.addEventListener(LocationChangeEvent.LOCATION_CHANGING, onLocChanging);
            web.addEventListener(LocationChangeEvent.LOCATION_CHANGE, onLoc);
            web.addEventListener(Event.COMPLETE, onComplete);
            web.addEventListener(ErrorEvent.ERROR, onErr);
            layout();
            web.loadURL("https://" + host + "/");
            statusTf.text = "Site aberto. Faca login e clique no servidor. Ou digite o codigo (ex. 1065) e Enter servidor.";

            scanTimer = new Timer(1500);
            scanTimer.addEventListener(TimerEvent.TIMER, onScanTick);
            scanTimer.start();
        }

        private function buildBar():void
        {
            bar = new Sprite();
            win.stage.addChild(bar);

            statusTf = new TextField();
            statusTf.defaultTextFormat = new TextFormat("_sans", 12, 0xC9C4EE, false);
            statusTf.mouseEnabled = false;
            statusTf.wordWrap = true;
            statusTf.multiline = true;
            statusTf.x = 12; statusTf.y = 6;
            statusTf.height = 36;
            bar.addChild(statusTf);

            var lab:TextField = new TextField();
            lab.defaultTextFormat = new TextFormat("_sans", 12, 0xFFFFFF, true);
            lab.mouseEnabled = false;
            lab.text = "Servidor:";
            lab.width = 70; lab.height = 24;
            lab.x = 12; lab.y = 48;
            bar.addChild(lab);

            serverInput = new TextField();
            serverInput.type = TextFieldType.INPUT;
            serverInput.border = true;
            serverInput.borderColor = 0x3B3A78;
            serverInput.background = true;
            serverInput.backgroundColor = 0x0E0D26;
            serverInput.defaultTextFormat = new TextFormat("_sans", 14, 0xFFFFFF);
            serverInput.text = "1065";
            serverInput.width = 100;
            serverInput.height = 26;
            serverInput.x = 80; serverInput.y = 46;
            bar.addChild(serverInput);

            var goBtn:Btn = new Btn(Btn.PRIMARY, 140, 32, "Entrar servidor", "", function(e:MouseEvent):void {
                goServerList();
            });
            goBtn.x = 200 + 70; goBtn.y = 58;
            bar.addChild(goBtn);

            var homeBtn:Btn = new Btn(Btn.GHOST, 100, 32, "Inicio site", "", function(e:MouseEvent):void {
                if (web != null) web.loadURL("https://" + host + "/");
                statusTf.text = "Voltando ao inicio do site...";
            });
            homeBtn.x = 360 + 50; homeBtn.y = 58;
            bar.addChild(homeBtn);

            var pasteBtn:Btn = new Btn(Btn.GHOST, 100, 32, "Colar URL", "", function(e:MouseEvent):void {
                try
                {
                    if (Clipboard.generalClipboard.hasFormat(ClipboardFormats.TEXT_FORMAT))
                    {
                        var t:String = String(Clipboard.generalClipboard.getData(ClipboardFormats.TEXT_FORMAT));
                        if (usePasted(t)) return;
                        // se for so serverlist/sXXXX, navega no webview
                        var m:Array = t.match(/serverlist\/s(\d+)/i);
                        if (m != null)
                        {
                            serverInput.text = String(m[1]);
                            goServerList();
                            return;
                        }
                        statusTf.text = "Cole uma URL com user= e key= ou serverlist/sXXXX.";
                    }
                }
                catch (err:Error) {}
            });
            pasteBtn.x = 480 + 50; pasteBtn.y = 58;
            bar.addChild(pasteBtn);
        }

        private function goServerList():void
        {
            var raw:String = serverInput != null ? serverInput.text.replace(/^\s+|\s+$/g, "") : "";
            raw = raw.replace(/^s/i, "").replace(/^OAS/i, "");
            if (raw.length < 2)
            {
                statusTf.text = "Digite o numero do servidor (ex. 1065).";
                return;
            }
            var url:String = "https://" + host + "/serverlist/s" + raw;
            statusTf.text = "Abrindo " + url + " ...";
            if (web != null)
            {
                web.loadURL(url);
                // depois que a pagina do servidor montar o embed Flash, extrai user/key
                try
                {
                    var t2:Timer = new Timer(2000, 1);
                    t2.addEventListener(TimerEvent.TIMER, function(ev:TimerEvent):void {
                        if (!done) extractFromPage();
                    });
                    t2.start();
                    var t3:Timer = new Timer(4000, 1);
                    t3.addEventListener(TimerEvent.TIMER, function(ev:TimerEvent):void {
                        if (!done) extractFromPage();
                    });
                    t3.start();
                }
                catch (eT:Error) {}
            }
            else try { navigateToURL(new URLRequest(url)); } catch (e:Error) {}
        }

        private function onResize(e:Event):void { layout(); }

        private function layout():void
        {
            if (win == null || win.stage == null) return;
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight;
            if (w <= 0 || h <= 0) return;
            bar.y = h - BAR;
            bar.graphics.clear();
            bar.graphics.beginFill(0x12112E, 1);
            bar.graphics.drawRect(0, 0, w, BAR);
            bar.graphics.endFill();
            statusTf.width = w - 24;
            if (web != null)
                web.viewPort = new Rectangle(0, 0, w, Math.max(50, h - BAR));
        }

        private function onLocChanging(e:LocationChangeEvent):void
        {
            var u:String = e.location;
            note(u);
            // Qualquer SWF ou URL com sessao: NAO deixa o WebView tentar tocar Flash — vai pro AIR
            if (u != null && (u.toLowerCase().indexOf(".swf") >= 0 || (u.indexOf("user=") >= 0 && u.indexOf("key=") >= 0)))
            {
                try { e.preventDefault(); } catch (e1:Error) {}
                if (check(u)) return;
                // SWF sem query visivel: ainda bloqueia o Flash no browser
                statusTf.text = "SWF detectado — extraindo sessao...";
                extractFromPage();
            }
            else if (check(u))
            {
                try { e.preventDefault(); } catch (e2:Error) {}
            }
        }

        private function onLoc(e:LocationChangeEvent):void
        {
            var u:String = e.location;
            note(u);
            if (u != null && u.indexOf("__legend_capture__") >= 0)
            {
                extracting = false;
                handleCaptureUrl(u);
                return;
            }
            check(u);
            var m:Array = String(u).match(/serverlist\/s(\d+)/i);
            if (m != null && serverInput != null) serverInput.text = String(m[1]);
        }

        private function handleCaptureUrl(u:String):void
        {
            try
            {
                var qi:int = u.indexOf("?");
                if (qi < 0) return;
                var q:String = u.substring(qi + 1);
                var params:Object = {};
                for each (var kv:String in q.split("&"))
                {
                    var i:int = kv.indexOf("=");
                    if (i > 0) params[dec(kv.substring(0, i))] = dec(kv.substring(i + 1));
                }
                // flashvars pode trazer user/key
                var fv:String = params["fv"] != undefined ? String(params["fv"]) : "";
                if (fv.length > 0)
                {
                    for each (var pair:String in fv.split("&"))
                    {
                        var j:int = pair.indexOf("=");
                        if (j > 0)
                        {
                            var pk:String = pair.substring(0, j).toLowerCase();
                            var pv:String = pair.substring(j + 1);
                            if (pk == "user" || pk == "key" || pk == "p2" || pk == "rid") params[pk] = pv;
                        }
                    }
                }
                var user:String = params["user"] != undefined ? String(params["user"]) : "";
                var key:String = params["key"] != undefined ? String(params["key"]) : "";
                var swf:String = params["swf"] != undefined ? String(params["swf"]) : "";
                if (swf.length > 0) seenSwf = swf;
                if (user.length > 0 && key.length > 4)
                {
                    var o:Object = { user: user, key: key };
                    if (params["p2"] != undefined) o["p2"] = params["p2"];
                    if (params["rid"] != undefined) o["rid"] = params["rid"];
                    finishWith(host, o, seenSwf != null ? seenSwf : swf);
                    return;
                }
                // so SWF na pagina: tenta montar URL e check
                if (swf.length > 0 && (swf.indexOf("user=") >= 0 || swf.indexOf("key=") >= 0))
                {
                    if (check(swf.indexOf("http") == 0 ? swf : ("https://" + host + (swf.charAt(0) == "/" ? swf : "/" + swf))))
                        return;
                }
                statusTf.text = "Ainda sem user/key na pagina. Clique de novo em Entrar servidor ou no JOGAR do site.";
                // volta ao serverlist para o usuario tentar de novo
                if (serverInput != null && serverInput.text.length > 1)
                    web.loadURL("https://" + host + "/serverlist/s" + serverInput.text.replace(/^s/i, ""));
            }
            catch (e:Error) { note("capture:" + e.message); }
        }

        private function onComplete(e:Event):void
        {
            if (done) return;
            try
            {
                if (web != null) note("complete:" + web.location);
                check(web != null ? web.location : "");
                // Pagina do servidor (sem Flash): tenta achar user/key no HTML via JS
                var loc:String = web != null ? String(web.location) : "";
                if (loc.indexOf("serverlist") >= 0 || loc.indexOf("Loading") >= 0)
                    extractFromPage();
            }
            catch (e1:Error) {}
        }

        // StageWebView nao expoe o DOM. Truque: javascript: coloca trecho da pagina no hash
        // e lemos web.location em seguida para achar user/key / Loading.swf.
        private var extracting:Boolean = false;
        private function extractFromPage():void
        {
            if (done || web == null || extracting) return;
            extracting = true;
            try
            {
                // JS sem aspas duplas internas problemáticas — só aspas simples no JS
                var js:String = "javascript:try{"
                    + "var h=(document.documentElement&&document.documentElement.outerHTML)||(document.body&&document.body.innerHTML)||'';"
                    + "var s='';"
                    + "var i=h.toLowerCase().indexOf('loading');"
                    + "if(i>=0){var j=h.toLowerCase().indexOf('.swf',i);if(j>i){s=h.substring(i,j+4);var q=h.indexOf('?',i);if(q>i&&q<j+80)s=h.substring(i,Math.min(j+200,h.length));}}"
                    + "var u='';var k='';var fv='';"
                    + "var iu=h.toLowerCase().indexOf('user');"
                    + "if(iu>=0){var cu=h.substring(iu,iu+40).replace(/[^0-9a-zA-Z=_\\-]/g,'');var pu=cu.indexOf('=');if(pu>0)u=cu.substring(pu+1).split(/[^0-9a-zA-Z_\\-]/)[0];}"
                    + "var ik=h.toLowerCase().indexOf('key');"
                    + "if(ik>=0){var ck=h.substring(ik,ik+80).replace(/[^0-9a-zA-Z=_\\-]/g,'');var pk=ck.indexOf('=');if(pk>0)k=ck.substring(pk+1).split(/[^0-9a-zA-Z_\\-]/)[0];}"
                    + "var ifv=h.toLowerCase().indexOf('flashvars');"
                    + "if(ifv>=0)fv=h.substring(ifv,ifv+300);"
                    + "window.location='https://" + host + "/__legend_capture__?swf='+encodeURIComponent(s)"
                    + "+'&user='+encodeURIComponent(u)+'&key='+encodeURIComponent(k)"
                    + "+'&fv='+encodeURIComponent(fv.substring(0,400));"
                    + "}catch(e){window.location='https://" + host + "/__legend_capture__?err=1';}";
                web.loadURL(js);
            }
            catch (e:Error)
            {
                extracting = false;
                note("extract:" + e.message);
            }
            try
            {
                var tmr:Timer = new Timer(2500, 1);
                tmr.addEventListener(TimerEvent.TIMER, function(ev:TimerEvent):void { extracting = false; });
                tmr.start();
            }
            catch (e2:Error) { extracting = false; }
        }

        private function onErr(e:ErrorEvent):void
        {
            statusTf.text = "Erro no WebView: " + e.text;
            note("err:" + e.text);
        }

        private function onScanTick(e:TimerEvent):void
        {
            if (done || web == null) return;
            try { check(web.location); } catch (e1:Error) {}
        }

        private function note(url:String):void
        {
            if (url == null) return;
            notes.push(url);
            if (notes.length > 50) notes.shift();
            var p:String = pathOf(url).toLowerCase();
            if (p.indexOf("loading") >= 0 && p.indexOf(".swf") >= 0)
            {
                var qi:int = url.indexOf("?");
                seenSwf = qi >= 0 ? pathOf(url) + url.substring(qi) : pathOf(url);
            }
        }

        private function pathOf(url:String):String
        {
            if (url == null) return "";
            return url.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function isAsset(lp:String):Boolean
        {
            for each (var ext:String in [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".svg"])
                if (lp.length >= ext.length && lp.lastIndexOf(ext) == lp.length - ext.length) return true;
            return false;
        }

        private function check(url:String):Boolean
        {
            if (done || url == null || url.length < 8) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            var site:String = m != null ? String(m[1]) : host;
            if (lp.indexOf(".swf") >= 0) seenSwf = pathOf(url) + (qi >= 0 ? url.substring(qi) : "");
            finishWith(site, params, seenSwf);
            return true;
        }

        private function usePasted(t:String):Boolean
        {
            if (t == null) return false;
            var urls:Array = t.match(/https?:\/\/[^\s\"'<>]+/g);
            if (urls != null)
            {
                for each (var u:String in urls)
                    if (check(u.replace(/&amp;/g, "&"))) return true;
            }
            if (t.indexOf("user=") >= 0 && t.indexOf("key=") >= 0)
            {
                if (check("https://" + host + "/x?" + t.replace(/^[\s\S]*?(user=)/, "$1"))) return true;
            }
            return false;
        }

        private function finishWith(site:String, params:Object, swfPath:String):void
        {
            if (done) return;
            done = true;
            try { if (scanTimer != null) scanTimer.stop(); } catch (e0:Error) {}
            var o:Object = {};
            for each (var k:String in KEYS)
                if (params[k] != undefined) o[k] = params[k];
            o["site"] = site;
            o["host"] = site;
            if (swfPath != null && swfPath.length > 0)
            {
                if (swfPath.indexOf("http") == 0)
                {
                    var m:Array = swfPath.match(/^[a-zA-Z]+:\/\/([^\/]+)(\/.*)$/);
                    if (m != null) { o["site"] = String(m[1]); o["host"] = String(m[1]); swfPath = String(m[2]); }
                }
                o["swf"] = swfPath;
            }
            statusTf.text = "Sessao capturada! Abrindo o jogo...";
            var json:String = JSON.stringify(o);
            try
            {
                if (web != null) { web.stage = null; web.dispose(); web = null; }
            }
            catch (e1:Error) {}
            try { if (win != null) win.close(); } catch (e2:Error) {}
            if (onSession != null) onSession(json);
        }

        private function onWinClose(e:Event):void
        {
            try { if (scanTimer != null) scanTimer.stop(); } catch (e0:Error) {}
            try
            {
                if (web != null) { web.stage = null; web.dispose(); web = null; }
            }
            catch (e1:Error) {}
            if (!done && onClosed != null) onClosed();
        }
    }
}
