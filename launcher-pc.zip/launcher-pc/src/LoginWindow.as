package
{
    import flash.desktop.Clipboard;
    import flash.desktop.ClipboardFormats;
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.html.HTMLLoader;
    import flash.net.URLRequest;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    public class LoginWindow
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36";
        private static const BAR:int = 72;
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];

        public var onSession:Function;
        public var onClosed:Function;

        private var host:String;
        private var win:NativeWindow;
        private var html:HTMLLoader;
        private var bar:Sprite;
        private var statusTf:TextField;
        private var serverInput:TextField;
        private var done:Boolean = false;
        private var seenSwf:String = null;
        private var scanTimer:Timer;
        private var scans:int = 0;

        public function LoginWindow(host:String) { this.host = host; }

        public function focus():void
        {
            try { if (win != null) win.activate(); if (html != null) win.stage.focus = html; } catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login — Legend PC";
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(1120, b.width - 40);
            win.height = Math.min(820, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            html = new HTMLLoader();
            html.userAgent = UA;
            html.placeLoadStringContentInApplicationSandbox = false;
            html.addEventListener(Event.HTML_DOM_INITIALIZE, onDomInit);
            html.addEventListener(Event.LOCATION_CHANGE, onLoc);
            html.addEventListener(Event.COMPLETE, onComplete);
            html.addEventListener(ErrorEvent.ERROR, onErr);
            html.addEventListener(IOErrorEvent.IO_ERROR, onErr);
            win.stage.addChildAt(html, 0);

            buildBar();
            win.stage.addEventListener(Event.RESIZE, function(e:Event):void { layout(); });
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();
            layout();
            html.load(new URLRequest("https://" + host + "/"));
            try { win.stage.focus = html; } catch (e:Error) {}
            statusTf.text = "Logue no site e clique no servidor — ou digite o código e Entrar.";
        }

        private function buildBar():void
        {
            bar = new Sprite();
            win.stage.addChild(bar);
            statusTf = new TextField();
            statusTf.defaultTextFormat = new TextFormat("_sans", 12, 0xD4D0F0);
            statusTf.mouseEnabled = false;
            statusTf.x = 12; statusTf.y = 6; statusTf.height = 22;
            bar.addChild(statusTf);

            var lab:TextField = new TextField();
            lab.defaultTextFormat = new TextFormat("_sans", 12, 0xFFFFFF, true);
            lab.mouseEnabled = false;
            lab.text = "Servidor:";
            lab.x = 12; lab.y = 36; lab.width = 70; lab.height = 24;
            bar.addChild(lab);

            serverInput = new TextField();
            serverInput.type = TextFieldType.INPUT;
            serverInput.border = true; serverInput.borderColor = 0x8B5CF6;
            serverInput.background = true; serverInput.backgroundColor = 0x16122A;
            serverInput.defaultTextFormat = new TextFormat("_sans", 14, 0xFFFFFF);
            serverInput.text = "1065";
            serverInput.width = 90; serverInput.height = 26;
            serverInput.x = 80; serverInput.y = 34;
            bar.addChild(serverInput);

            var go:Btn = new Btn(Btn.PRIMARY, 130, 30, "Entrar", "", function(e:MouseEvent):void { goServer(); });
            go.x = 200 + 65; go.y = 46;
            bar.addChild(go);

            var paste:Btn = new Btn(Btn.GHOST, 120, 30, "Colar URL", "", function(e:MouseEvent):void {
                try
                {
                    if (Clipboard.generalClipboard.hasFormat(ClipboardFormats.TEXT_FORMAT))
                    {
                        var t:String = String(Clipboard.generalClipboard.getData(ClipboardFormats.TEXT_FORMAT));
                        if (usePasted(t)) return;
                        var m:Array = t.match(/serverlist\/s(\d+)/i);
                        if (m) { serverInput.text = String(m[1]); goServer(); return; }
                        statusTf.text = "Cole uma URL com user= e key= ou serverlist/sXXXX.";
                    }
                } catch (err:Error) {}
            });
            paste.x = 360 + 60; paste.y = 46;
            bar.addChild(paste);
        }

        private function goServer():void
        {
            if (done) return;
            var raw:String = serverInput.text.replace(/^\s+|\s+$/g, "").replace(/^s/i, "").replace(/^OAS/i, "");
            if (raw.length < 2) { statusTf.text = "Digite o número do servidor."; return; }
            var url:String = "https://" + host + "/serverlist/s" + raw;
            statusTf.text = "Abrindo servidor s" + raw + "...";
            scans = 0;
            try { html.load(new URLRequest(url)); } catch (e:Error) { statusTf.text = "Erro: " + e.message; }
            startScan();
        }

        private function onDomInit(e:Event):void
        {
            try
            {
                var js:String = "window.__lf=1;"
                    + "try{Object.defineProperty(navigator,'plugins',{configurable:true,get:function(){var p={0:{name:'Shockwave Flash',description:'Shockwave Flash 32.0 r0',filename:'NPSWF32.dll',length:1},length:1,'Shockwave Flash':null};p['Shockwave Flash']=p[0];p.item=function(i){return this[i];};p.namedItem=function(n){return this[n];};return p;}});}catch(e){}"
                    + "try{Object.defineProperty(navigator,'mimeTypes',{configurable:true,get:function(){var m={0:{type:'application/x-shockwave-flash',suffixes:'swf',description:'Shockwave Flash',enabledPlugin:{name:'Shockwave Flash'}},length:1};m['application/x-shockwave-flash']=m[0];m.item=function(i){return this[i];};m.namedItem=function(n){return this[n];};return m;}});}catch(e){}"
                    + "window.swfobject=window.swfobject||{};swfobject.hasFlashPlayerVersion=function(){return true;};swfobject.getFlashPlayerVersion=function(){return{major:32,minor:0,release:0};};";
                html.window.eval(js);
            }
            catch (err:Error) {}
        }

        private function startScan():void
        {
            if (scanTimer != null) scanTimer.stop();
            scanTimer = new Timer(800);
            scanTimer.addEventListener(TimerEvent.TIMER, onScan);
            scanTimer.start();
        }

        private function onScan(e:TimerEvent):void
        {
            if (done) { scanTimer.stop(); return; }
            scans++;
            try { check(html.location); } catch (e0:Error) {}
            scanHtml(collectHtml());
            try
            {
                var embeds:* = html.window.document.getElementsByTagName("embed");
                for (var i:int = 0; i < int(embeds.length); i++)
                {
                    var src:String = "";
                    try { src = String(embeds[i].getAttribute("src") || embeds[i].src); } catch (e1:Error) {}
                    if (src && src.length > 4)
                    {
                        if (src.indexOf("http") != 0) src = "https://" + host + (src.charAt(0) == "/" ? src : "/" + src);
                        check(src);
                    }
                    try { var fv:String = String(embeds[i].getAttribute("flashvars")); if (fv) scanHtml("flashvars=" + fv); } catch (e2:Error) {}
                }
                var objs:* = html.window.document.getElementsByTagName("object");
                for (var j:int = 0; j < int(objs.length); j++)
                {
                    try { var d:String = String(objs[j].data); if (d) check(d); } catch (e3:Error) {}
                }
            } catch (e4:Error) {}
            if (scans == 8 || scans == 15)
                statusTf.text = "Aguardando sessão do jogo... (" + scans + ")";
        }

        private function layout():void
        {
            if (win == null || win.stage == null) return;
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight;
            if (w <= 0 || h <= 0) return;
            html.x = 0; html.y = 0;
            html.width = w; html.height = Math.max(40, h - BAR);
            bar.y = h - BAR;
            bar.graphics.clear();
            bar.graphics.beginFill(0x0F0E1A, 1);
            bar.graphics.drawRect(0, 0, w, BAR);
            bar.graphics.endFill();
            bar.graphics.lineStyle(1, 0x8B5CF6, 0.4);
            bar.graphics.moveTo(0, 0); bar.graphics.lineTo(w, 0);
            statusTf.width = w - 24;
        }

        private function onLoc(e:Event):void { if (html) check(html.location); }
        private function onComplete(e:Event):void
        {
            if (done) return;
            startScan();
            scanHtml(collectHtml());
            try { win.stage.focus = html; } catch (e1:Error) {}
        }
        private function onErr(e:Event):void { statusTf.text = "Erro ao carregar o site."; }

        private function collectHtml():String
        {
            try { return String(html.window.document.documentElement.outerHTML); } catch (e:Error) {}
            return "";
        }

        private function pathOf(url:String):String
        {
            if (url == null) return "";
            return url.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function isAsset(lp:String):Boolean
        {
            for each (var ext:String in [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".svg"])
                if (lp.length >= ext.length && lp.lastIndexOf(ext) == lp.length - ext.length) return true;
            return false;
        }

        private function check(url:String):Boolean
        {
            if (done || url == null || url.length < 8) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            var site:String = m != null ? String(m[1]) : host;
            if (lp.indexOf(".swf") >= 0) seenSwf = pathOf(url) + url.substring(qi);
            finishWith(site, params, seenSwf);
            return true;
        }

        private function plausible(v:String):Boolean
        {
            if (v == null) return false;
            var l:String = v.toLowerCase();
            return !(l == "function" || l == "null" || l == "undefined" || l == "true" || l == "false"
                || l == "this" || l == "document" || l == "window" || l == "var");
        }

        private function scanHtml(t:String):Boolean
        {
            if (done || t == null || t.length < 30) return false;
            var swf:String = seenSwf;
            var m:Array = t.match(/([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/i);
            if (m != null) swf = String(m[1]);
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
                    mm = re.exec(t);
                }
            }
            var fv:Array = t.match(/flashvars[\s\"'=]+([^\"'<]+)/i);
            if (fv != null)
            {
                for each (var pair:String in String(fv[1]).split("&"))
                {
                    var j:int = pair.indexOf("=");
                    if (j > 0)
                    {
                        var pk:String = pair.substring(0, j).toLowerCase();
                        if (pk == "user" || pk == "key" || pk == "p2" || pk == "rid") params[pk] = pair.substring(j + 1);
                    }
                }
            }
            var sm:Array = t.match(/[\w.\/:\-%]+\.swf\?([^\"'\s<>]+)/i);
            if (sm != null)
            {
                for each (var pair2:String in String(sm[1]).split("&"))
                {
                    var j2:int = pair2.indexOf("=");
                    if (j2 > 0)
                    {
                        var pk2:String = pair2.substring(0, j2).toLowerCase();
                        if (pk2 == "user" || pk2 == "key" || pk2 == "p2" || pk2 == "rid") params[pk2] = pair2.substring(j2 + 1);
                    }
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8) return false;
            finishWith(host, params, swf);
            return true;
        }

        private function usePasted(t:String):Boolean
        {
            if (t == null) return false;
            var urls:Array = t.match(/https?:\/\/[^\s\"'<>]+/g);
            if (urls != null)
            {
                for each (var u:String in urls) if (check(u.replace(/&amp;/g, "&"))) return true;
            }
            if (t.indexOf("user=") >= 0 && t.indexOf("key=") >= 0)
            {
                if (check("https://" + host + "/x?" + t.replace(/^[\s\S]*?(user=)/, "$1"))) return true;
                if (scanHtml(t)) return true;
            }
            return scanHtml(t);
        }

        private function finishWith(site:String, params:Object, swfPath:String):void
        {
            if (done) return;
            if (params == null || params["user"] == undefined || params["key"] == undefined) return;
            if (String(params["key"]).length < 4) return;
            done = true;
            try { if (scanTimer != null) scanTimer.stop(); } catch (e0:Error) {}
            var o:Object = {};
            for each (var k:String in KEYS)
                if (params[k] != undefined) o[k] = params[k];
            o["site"] = site; o["host"] = site;
            if (swfPath != null && swfPath.length > 0)
            {
                if (swfPath.indexOf("http") == 0)
                {
                    var m:Array = swfPath.match(/^[a-zA-Z]+:\/\/([^\/]+)(\/.*)$/);
                    if (m != null) { o["site"] = String(m[1]); o["host"] = String(m[1]); swfPath = String(m[2]); }
                }
                var qpos:int = swfPath.indexOf("?");
                if (qpos > 0) swfPath = swfPath.substring(0, qpos);
                o["swf"] = swfPath;
            }
            if (o["swf"] == undefined) o["swf"] = "/client/Loading.swf";
            statusTf.text = "Sessão capturada! Abrindo o jogo...";
            var json:String = JSON.stringify(o);
            try { if (html != null && html.parent) html.parent.removeChild(html); } catch (e1:Error) {}
            try { if (win != null) win.close(); } catch (e2:Error) {}
            if (onSession != null) onSession(json);
        }

        private function onWinClose(e:Event):void
        {
            try { if (scanTimer != null) scanTimer.stop(); } catch (e0:Error) {}
            if (!done && onClosed != null) onClosed();
        }
    }
}
