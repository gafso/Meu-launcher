package
{
    import flash.desktop.Clipboard;
    import flash.desktop.ClipboardFormats;
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.html.HTMLLoader;
    import flash.net.URLRequest;
    import flash.net.navigateToURL;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Janela de login do PC: navegador embutido (HTMLLoader) que abre o site do servidor.
    // Você entra normalmente; o launcher captura user/key e o caminho do Loading.swf (URL da página e HTML,
    // inclusive iframes). Nenhuma senha é lida nem guardada.
    // Se o navegador embutido não funcionar com o site, "Colar link / código" aceita a URL do jogo ou o
    // código-fonte da página (Ctrl+U no navegador normal) e extrai os mesmos dados.
    public class LoginWindow
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        private static const BAR_H:int = 52;
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];
        private static const RE_SWF_LOADING:RegExp = /([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/;
        private static const RE_SWF_ANY:RegExp = /([\w.\/:\-%]+\.swf)/;
        private static const ASSET_EXT:Array = [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".woff2", ".svg", ".webp"];

        public var onSession:Function;   // (json:String)
        public var onClosed:Function;    // () fechou sem capturar

        private var host:String;
        private var win:NativeWindow;
        private var html:HTMLLoader;
        private var bar:Sprite;
        private var barBg:Sprite;
        private var barHint:TextField;
        private var pasteBtn:Btn;
        private var diagBtn:Btn;
        private var browserBtn:Btn;
        private var autoShown:Boolean = false;
        private var overlay:Sprite;
        private var overlayInput:TextField;
        private var overlayMsg:TextField;
        private var done:Boolean = false;
        private var scans:int = 0;
        private var timer:Timer;
        private var seenSwf:String = null;

        public function LoginWindow(host:String)
        {
            this.host = host;
        }

        public function focus():void
        {
            try { win.activate(); } catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login - " + host;
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(1100, b.width - 40);
            win.height = Math.min(800, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            html = new HTMLLoader();
            html.userAgent = UA;
            html.addEventListener(Event.LOCATION_CHANGE, onLoc);
            html.addEventListener(Event.COMPLETE, onComplete);
            html.addEventListener(ErrorEvent.ERROR, onLoadError);
            html.addEventListener(IOErrorEvent.IO_ERROR, onLoadError);
            html.addEventListener("httpResponseStatus", onHttpStatus);
            win.stage.addChild(html);

            buildBar();
            win.stage.addEventListener(Event.RESIZE, onResize);
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();
            layout();
            html.load(new URLRequest("https://" + host + "/"));
        }

        // ---------- barra de baixo ----------
        private function buildBar():void
        {
            bar = new Sprite();
            barBg = new Sprite();
            bar.addChild(barBg);
            barHint = new TextField();
            barHint.defaultTextFormat = new TextFormat("_sans", 13, 0xC9C4EE, false);
            barHint.selectable = false;
            barHint.mouseEnabled = false;
            barHint.text = "Entre normalmente. O jogo abre sozinho depois do login.";
            barHint.width = 520; barHint.height = 22; barHint.x = 16; barHint.y = 16;
            bar.addChild(barHint);
            pasteBtn = new Btn(Btn.GHOST, 190, 34, "Colar link / código", "", function(e:MouseEvent):void { openPaste(); });
            bar.addChild(pasteBtn);
            browserBtn = new Btn(Btn.GHOST, 190, 34, "Abrir no navegador", "", function(e:MouseEvent):void { openInBrowser(); });
            bar.addChild(browserBtn);
            diagBtn = new Btn(Btn.GHOST, 130, 34, "Diagnóstico", "", function(e:MouseEvent):void { openDiag(); });
            bar.addChild(diagBtn);
            win.stage.addChild(bar);
        }

        private function onResize(e:Event):void { layout(); }

        private function layout():void
        {
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight;
            if (w <= 0 || h <= 0) return;
            html.width = w;
            html.height = Math.max(50, h - BAR_H);
            bar.y = h - BAR_H;
            barBg.graphics.clear();
            barBg.graphics.beginFill(0x12112E, 1);
            barBg.graphics.drawRect(0, 0, w, BAR_H);
            barBg.graphics.endFill();
            diagBtn.x = w - 16 - 65; diagBtn.y = BAR_H / 2;
            pasteBtn.x = diagBtn.x - 65 - 12 - 95; pasteBtn.y = BAR_H / 2;
            browserBtn.x = pasteBtn.x - 95 - 12 - 95; browserBtn.y = BAR_H / 2;
            if (overlay != null) drawOverlayBg();
        }

        // ---------- painel de texto (colar / diagnóstico) ----------
        private function hideOverlay():void
        {
            if (overlay != null && overlay.parent != null) overlay.parent.removeChild(overlay);
            overlay = null;
            overlayInput = null;
            overlayMsg = null;
        }

        private function drawOverlayBg():void
        {
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight - BAR_H;
            overlay.graphics.clear();
            overlay.graphics.beginFill(0x07061A, 0.98);
            overlay.graphics.drawRect(0, 0, w, h);
            overlay.graphics.endFill();
        }

        private function mkTf(t:String, size:int, color:uint, bold:Boolean, x:Number, y:Number, w:Number):TextField
        {
            var f:TextField = new TextField();
            f.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            f.selectable = false;
            f.mouseEnabled = false;
            f.multiline = true;
            f.wordWrap = true;
            f.width = w;
            f.x = x; f.y = y;
            f.text = t;
            f.height = f.textHeight + 6;
            return f;
        }

        private function showOverlay(title:String, hint:String, text:String, readOnly:Boolean, okLabel:String, onOk:Function):void
        {
            hideOverlay();
            overlay = new Sprite();
            drawOverlayBg();
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight - BAR_H;
            overlay.addChild(mkTf(title, 18, 0xFFFFFF, true, 24, 16, w - 48));
            var hf:TextField = mkTf(hint, 13, 0xC9C4EE, false, 24, 48, w - 48);
            overlay.addChild(hf);
            var y0:Number = hf.y + hf.height + 8;
            overlayInput = new TextField();
            overlayInput.multiline = true;
            overlayInput.wordWrap = true;
            overlayInput.type = readOnly ? TextFieldType.DYNAMIC : TextFieldType.INPUT;
            overlayInput.selectable = true;
            overlayInput.background = true;
            overlayInput.backgroundColor = 0x0E0D26;
            overlayInput.border = true;
            overlayInput.borderColor = 0x3B3A78;
            overlayInput.defaultTextFormat = new TextFormat("_typewriter", 12, 0xE6E6F5);
            overlayInput.x = 24; overlayInput.y = y0;
            overlayInput.width = w - 48;
            overlayInput.height = Math.max(60, h - y0 - 84);
            overlayInput.text = text;
            overlay.addChild(overlayInput);
            overlayMsg = mkTf("", 13, 0xFFE066, true, 24, y0 + overlayInput.height + 6, w - 48);
            overlay.addChild(overlayMsg);
            var cancel:Btn = new Btn(Btn.GHOST, 150, 34, "Fechar", "", function(e:MouseEvent):void { hideOverlay(); });
            cancel.x = w - 24 - 75; cancel.y = h - 28;
            overlay.addChild(cancel);
            if (onOk != null)
            {
                var ok:Btn = new Btn(Btn.PRIMARY, 190, 34, okLabel, "", function(e:MouseEvent):void { onOk(); });
                ok.x = cancel.x - 75 - 12 - 95; ok.y = h - 28;
                overlay.addChild(ok);
            }
            win.stage.addChild(overlay);
            win.stage.addChild(bar);
            try { win.stage.focus = overlayInput; } catch (e2:Error) {}
        }

        private function openPaste():void
        {
            showOverlay("Colar link ou código da página",
                "Use isto se o login aqui dentro não funcionar. No seu navegador normal (botão Abrir no navegador): entre no site e abra a página do jogo. " +
                "Primeiro tente copiar o endereço (URL) da barra do navegador, se ele tiver user= e key=. " +
                "Se não tiver, aperte Ctrl+U (código-fonte), Ctrl+A e Ctrl+C. Cole aqui com Ctrl+V e clique em Usar.",
                "", false, "Usar", function():void
                {
                    var t:String = overlayInput != null ? overlayInput.text : "";
                    if (t.length == 0) { if (overlayMsg) overlayMsg.text = "Cole alguma coisa primeiro."; return; }
                    if (!usePasted(t) && overlayMsg != null) overlayMsg.text = "Não achei user= e key= nesse texto.";
                });
        }

        private function openInBrowser():void
        {
            try { navigateToURL(new URLRequest("https://" + host + "/")); } catch (e:Error) {}
            openPaste();
        }

        // O navegador embutido é antigo: se o site recusar (403 etc.), vai direto para o modo "colar".
        private function onLoadError(e:Event):void { fallbackToPaste(); }

        private function onHttpStatus(e:Event):void
        {
            var st:int = 0;
            try { st = int(e["status"]); } catch (e1:Error) {}
            if (st >= 400) fallbackToPaste();
        }

        private function fallbackToPaste():void
        {
            if (done || autoShown) return;
            autoShown = true;
            try { navigateToURL(new URLRequest("https://" + host + "/")); } catch (e:Error) {}
            openPaste();
            if (overlayMsg != null) overlayMsg.text = "O site recusou o navegador embutido (erro 403). Abri o site no seu navegador normal: entre lá e cole aqui o link ou o código.";
        }

        private function openDiag():void
        {
            var d:String = diagText();
            try { Clipboard.generalClipboard.setData(ClipboardFormats.TEXT_FORMAT, d); } catch (e:Error) {}
            showOverlay("Diagnóstico", "Já foi copiado para a área de transferência (valores de user/key aparecem como ***).", d, true, "", null);
        }

        // ---------- captura ----------
        private function onLoc(e:Event):void
        {
            var u:String = html.location;
            note(u);
            check(u);
        }

        private function onComplete(e:Event):void
        {
            if (done) return;
            scans = 0;
            if (timer == null)
            {
                timer = new Timer(2000);
                timer.addEventListener(TimerEvent.TIMER, scanTick);
            }
            timer.reset();
            timer.start();
            try { win.title = "Login - " + String(html.window.document.title); } catch (e2:Error) {}
        }

        private function scanTick(e:TimerEvent):void
        {
            if (done) return;
            scans++;
            scanHtml(collectHtml(), false);
            if (scans >= 40) timer.stop();
        }

        private function collectHtml():String
        {
            var o:Array = [];
            try { o.push(String(html.window.document.documentElement.outerHTML)); } catch (e1:Error) {}
            try
            {
                var fr:* = html.window.document.getElementsByTagName("iframe");
                for (var i:int = 0; i < fr.length; i++)
                {
                    try { o.push(String(fr[i].contentDocument.documentElement.outerHTML)); } catch (e2:Error) {}
                }
            }
            catch (e3:Error) {}
            return o.join("\n");
        }

        private function isAsset(lowerPath:String):Boolean
        {
            for each (var ext:String in ASSET_EXT)
            {
                if (lowerPath.length >= ext.length && lowerPath.lastIndexOf(ext) == lowerPath.length - ext.length) return true;
            }
            return false;
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function pathOf(url:String):String
        {
            var qi:int = url.indexOf("?");
            var p:String = qi >= 0 ? url.substring(0, qi) : url;
            return p.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        // Guarda o caminho do Loading.swf visto nas páginas.
        private function note(url:String):void
        {
            if (url == null) return;
            var p:String = pathOf(url).toLowerCase();
            if (p.indexOf("loading") >= 0 && p.lastIndexOf(".swf") == p.length - 4)
            {
                var qi:int = url.indexOf("?");
                var raw:String = pathOf(url);
                seenSwf = qi >= 0 ? raw + url.substring(qi) : raw;
            }
        }

        // Qualquer URL (que não seja imagem/css/js) com user= e key= vira a sessão.
        private function check(url:String):Boolean
        {
            if (done || url == null) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            finishWith(m != null ? String(m[1]) : host, params, seenSwf);
            return true;
        }

        private function plausible(v:String):Boolean
        {
            if (v == null) return false;
            var l:String = v.toLowerCase();
            return !(l == "function" || l == "null" || l == "undefined" || l == "true" || l == "false"
                || l == "this" || l == "document" || l == "window" || l == "var");
        }

        // Procura user/key (e o Loading.swf) no HTML. force = aceita sem saber o caminho do swf.
        private function scanHtml(t:String, force:Boolean):Boolean
        {
            if (done || t == null || t.length == 0) return false;
            var swf:String = null;
            var m:Array = t.match(RE_SWF_LOADING);
            if (m != null) swf = String(m[1]);
            else
            {
                m = t.match(RE_SWF_ANY);
                if (m != null) swf = String(m[1]);
            }
            if (swf == null) swf = seenSwf;
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
                    mm = re.exec(t);
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8) return false;
            if (swf == null && scans < 10 && !force) return false;   // espera mais um pouco pelo caminho do swf
            finishWith(host, params, swf);
            return true;
        }

        // Texto colado pelo usuário: URLs com user=/key= ou HTML completo.
        private function usePasted(t:String):Boolean
        {
            var urls:Array = t.match(/https?:\/\/[^\s"'<>]+/g);
            if (urls != null)
            {
                for each (var u:String in urls)
                {
                    note(u.replace(/&amp;/g, "&"));
                }
                for each (var u2:String in urls)
                {
                    if (check(u2.replace(/&amp;/g, "&"))) return true;
                }
            }
            return scanHtml(t, true);
        }

        // ---------- entrega ----------
        private function finishWith(gameHost:String, params:Object, swf:String):void
        {
            if (done) return;
            done = true;
            var outHost:String = gameHost;
            var swfPath:String = null;
            if (swf != null)
            {
                var u:String = swf;
                if (u.indexOf("//") == 0) u = "https:" + u;
                var m:Array = u.match(/^https?:\/\/([^\/?#]+)(.*)$/i);
                if (m != null)
                {
                    outHost = String(m[1]);
                    swfPath = String(m[2]).replace(/#.*$/, "");
                    if (swfPath == "") swfPath = "/Loading.swf";
                }
                else swfPath = "/" + u.replace(/^\/+/, "").replace(/#.*$/, "");
            }
            var out:Object = {host: outHost, params: params, user: params["user"], key: params["key"]};
            if (swfPath != null) out["swf"] = swfPath;
            var json:String = JSON.stringify(out);
            shutdown();
            if (onSession != null) onSession(json);
        }

        private function shutdown():void
        {
            try { if (timer != null) timer.stop(); } catch (e1:Error) {}
            try { html["dispose"](); } catch (e2:Error) {}
            try { win.close(); } catch (e3:Error) {}
        }

        private function onWinClose(e:Event):void
        {
            if (done) return;
            done = true;
            try { if (timer != null) timer.stop(); } catch (e1:Error) {}
            if (onClosed != null) onClosed();
        }

        // ---------- diagnóstico ----------
        private function mask(s:String):String
        {
            return s.replace(/(user|key|pass\w*|token|sid|sign|auth\w*|session\w*|cookie)(["']?\s*[:=]\s*["']?)[^"'&<>\s,;]+/gi, "$1$2***");
        }

        private function diagText():String
        {
            var s:String = "URL: " + html.location + "\ncapturado=" + done + " swfVisto=" + seenSwf + "\n";
            var h:String = collectHtml();
            var low:String = h.toLowerCase();
            s += "HTML: " + h.length + " caracteres\n";
            for each (var k:String in [".swf", "flashvars", "swfobject", "<iframe", "<embed", "<object"])
            {
                var p:int = 0;
                var n:int = 0;
                while (n < 4)
                {
                    var i:int = low.indexOf(k, p);
                    if (i < 0) break;
                    s += "[" + k + "] " + h.substr(Math.max(0, i - 120), 300).replace(/[\r\n]+/g, " ") + "\n";
                    p = i + k.length;
                    n++;
                }
            }
            return mask(s);
        }
    }
}
