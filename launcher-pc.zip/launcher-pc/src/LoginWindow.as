package
{
    import flash.desktop.Clipboard;
    import flash.desktop.ClipboardFormats;
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.html.HTMLLoader;
    import flash.net.URLRequest;
    import flash.net.navigateToURL;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Login no PC — mesmo modelo do 32-bit: HTMLLoader (navegador embutido do AIR).
    // Cookies/sessão ficam no app. Clipboard + "Abrir no navegador" só como reserva.
    public class LoginWindow
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        private static const BAR_H:int = 52;
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];
        private static const RE_SWF_LOADING:RegExp = /([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/;
        private static const RE_SWF_ANY:RegExp = /([\w.\/:\-%]+\.swf)/;
        private static const ASSET_EXT:Array = [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".woff2", ".svg", ".webp"];

        public var onSession:Function;
        public var onClosed:Function;

        private var host:String;
        private var win:NativeWindow;
        private var html:HTMLLoader;
        private var bar:Sprite;
        private var barBg:Sprite;
        private var barHint:TextField;
        private var overlay:Sprite;
        private var overlayInput:TextField;
        private var overlayMsg:TextField;
        private var done:Boolean = false;
        private var seenSwf:String = null;
        private var timer:Timer;
        private var scans:int = 0;
        private var notes:Array = [];
        private var clipTimer:Timer;
        private var lastClip:String = "";
        private var autoShown:Boolean = false;

        public function LoginWindow(host:String)
        {
            this.host = host;
        }

        public function focus():void
        {
            try
            {
                if (win != null) win.activate();
                if (html != null) win.stage.focus = html;
            }
            catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login - " + host;
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(1100, b.width - 40);
            win.height = Math.min(800, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            html = new HTMLLoader();
            html.userAgent = UA;
            html.placeLoadStringContentInApplicationSandbox = false;
            html.addEventListener(Event.LOCATION_CHANGE, onLoc);
            html.addEventListener(Event.COMPLETE, onComplete);
            html.addEventListener(ErrorEvent.ERROR, onLoadError);
            html.addEventListener(IOErrorEvent.IO_ERROR, onLoadError);
            html.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                try { win.stage.focus = html; } catch (e2:Error) {}
            }, true);
            win.stage.addChildAt(html, 0);

            buildBar();
            win.stage.addEventListener(Event.RESIZE, onResize);
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();
            layout();
            // carrega o site no HTMLLoader (mesmo caminho do 32-bit)
            html.load(new URLRequest("https://" + host + "/"));
            startClipWatch();
            try { win.stage.focus = html; } catch (e3:Error) {}
        }

        private function buildBar():void
        {
            bar = new Sprite();
            barBg = new Sprite();
            bar.addChild(barBg);
            barHint = new TextField();
            barHint.defaultTextFormat = new TextFormat("_sans", 12, 0xC9C4EE, false);
            barHint.selectable = false;
            barHint.mouseEnabled = false;
            barHint.text = "Já logado: clique no seu servidor. O jogo abre no launcher depois.";
            barHint.width = 520; barHint.height = 36; barHint.x = 16; barHint.y = 8;
            bar.addChild(barHint);

            var pasteBtn:Btn = new Btn(Btn.GHOST, 170, 34, "Colar link / código", "", function(e:MouseEvent):void { openPaste(); });
            bar.addChild(pasteBtn);
            var browserBtn:Btn = new Btn(Btn.GHOST, 170, 34, "Abrir no navegador", "", function(e:MouseEvent):void {
                try { navigateToURL(new URLRequest("https://" + host + "/")); } catch (err:Error) {}
                barHint.text = "No navegador: entre, clique no servidor, COPIE a URL se tiver user= e key= (capturo sozinho).";
                startClipWatch();
            });
            bar.addChild(browserBtn);
            var diagBtn:Btn = new Btn(Btn.GHOST, 120, 34, "Diagnóstico", "", function(e:MouseEvent):void { openDiag(); });
            bar.addChild(diagBtn);
            bar.name = "bar";
            // store refs on bar for layout
            pasteBtn.name = "paste"; browserBtn.name = "browser"; diagBtn.name = "diag";
            win.stage.addChild(bar);
        }

        private function onResize(e:Event):void { layout(); }

        private function layout():void
        {
            if (win == null || win.stage == null) return;
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight;
            if (w <= 0 || h <= 0) return;
            if (html != null)
            {
                html.x = 0; html.y = 0;
                html.width = w;
                html.height = Math.max(50, h - BAR_H);
            }
            bar.y = h - BAR_H;
            barBg.graphics.clear();
            barBg.graphics.beginFill(0x12112E, 1);
            barBg.graphics.drawRect(0, 0, w, BAR_H);
            barBg.graphics.endFill();
            var diag:Btn = bar.getChildByName("diag") as Btn;
            var paste:Btn = bar.getChildByName("paste") as Btn;
            var browser:Btn = bar.getChildByName("browser") as Btn;
            if (diag != null) { diag.x = w - 16 - 60; diag.y = BAR_H / 2; }
            if (paste != null) { paste.x = (diag != null ? diag.x : w - 16) - 12 - 85; paste.y = BAR_H / 2; }
            if (browser != null) { browser.x = (paste != null ? paste.x : w - 16) - 12 - 85; browser.y = BAR_H / 2; }
            if (overlay != null) drawOverlayBg();
        }

        private function hideOverlay():void
        {
            if (overlay != null && overlay.parent != null) overlay.parent.removeChild(overlay);
            overlay = null; overlayInput = null; overlayMsg = null;
            if (html != null) { try { html.visible = true; win.stage.focus = html; } catch (e:Error) {} }
        }

        private function drawOverlayBg():void
        {
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight - BAR_H;
            overlay.graphics.clear();
            overlay.graphics.beginFill(0x07061A, 0.98);
            overlay.graphics.drawRect(0, 0, w, h);
            overlay.graphics.endFill();
        }

        private function mkTf(t:String, size:int, color:uint, bold:Boolean, x:Number, y:Number, w:Number):TextField
        {
            var f:TextField = new TextField();
            f.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            f.selectable = false; f.mouseEnabled = false;
            f.multiline = true; f.wordWrap = true;
            f.width = w; f.x = x; f.y = y; f.text = t;
            f.height = f.textHeight + 6;
            return f;
        }

        private function showOverlay(title:String, hint:String, text:String, readOnly:Boolean, okLabel:String, onOk:Function):void
        {
            hideOverlay();
            if (html != null) html.visible = false;
            overlay = new Sprite();
            drawOverlayBg();
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight - BAR_H;
            overlay.addChild(mkTf(title, 18, 0xFFFFFF, true, 24, 16, w - 48));
            var hf:TextField = mkTf(hint, 13, 0xC9C4EE, false, 24, 48, w - 48);
            overlay.addChild(hf);
            var y0:Number = hf.y + hf.height + 8;
            overlayInput = new TextField();
            overlayInput.multiline = true; overlayInput.wordWrap = true;
            overlayInput.type = readOnly ? TextFieldType.DYNAMIC : TextFieldType.INPUT;
            overlayInput.selectable = true;
            overlayInput.background = true; overlayInput.backgroundColor = 0x0E0D26;
            overlayInput.border = true; overlayInput.borderColor = 0x3B3A78;
            overlayInput.defaultTextFormat = new TextFormat("_typewriter", 12, 0xE6E6F5);
            overlayInput.x = 24; overlayInput.y = y0;
            overlayInput.width = w - 48;
            overlayInput.height = Math.max(60, h - y0 - 84);
            overlayInput.text = text;
            overlay.addChild(overlayInput);
            var by:Number = h - 52;
            if (onOk != null)
            {
                var ok:Btn = new Btn(Btn.PRIMARY, 160, 36, okLabel != "" ? okLabel : "Usar", "", function(e:MouseEvent):void {
                    var t:String = overlayInput != null ? overlayInput.text : "";
                    hideOverlay();
                    onOk(t);
                });
                ok.x = 24 + 80; ok.y = by + 18;
                overlay.addChild(ok);
            }
            var cancel:Btn = new Btn(Btn.GHOST, 120, 36, "Fechar", "", function(e:MouseEvent):void { hideOverlay(); });
            cancel.x = w - 24 - 60; cancel.y = by + 18;
            overlay.addChild(cancel);
            overlayMsg = mkTf("", 12, 0xF0A0A0, false, 24, by - 20, w - 200);
            overlay.addChild(overlayMsg);
            win.stage.addChild(overlay);
        }

        private function openPaste():void
        {
            showOverlay(
                "Colar link / código",
                "Cole a URL do jogo (com user= e key=) ou o código-fonte da página (Ctrl+U).",
                "",
                false,
                "Usar",
                function(t:String):void {
                    if (!usePasted(t) && overlayMsg != null)
                        overlayMsg.text = "Não achei user= e key= nesse texto.";
                }
            );
        }

        private function openDiag():void
        {
            var d:String = "host=" + host + " htmlLoader=true\n" + notes.join("\n");
            try { Clipboard.generalClipboard.setData(ClipboardFormats.TEXT_FORMAT, d); } catch (e:Error) {}
            showOverlay("Diagnóstico", "Copiado para a área de transferência.", d, true, "", null);
        }

        private function onLoc(e:Event):void
        {
            if (html == null) return;
            var u:String = html.location;
            note(u);
            check(u);
        }

        private function onComplete(e:Event):void
        {
            if (done) return;
            scans = 0;
            if (timer == null)
            {
                timer = new Timer(2000);
                timer.addEventListener(TimerEvent.TIMER, scanTick);
            }
            timer.reset();
            timer.start();
            try { win.title = "Login - " + String(html.window.document.title); } catch (e2:Error) {}
            try { win.stage.focus = html; } catch (e3:Error) {}
            // força redesenho / foco (ajuda no 64-bit)
            layout();
        }

        private function onLoadError(e:Event):void
        {
            note("erro:" + String(e));
            if (done || autoShown) return;
            autoShown = true;
            try { navigateToURL(new URLRequest("https://" + host + "/")); } catch (e0:Error) {}
            openPaste();
            if (overlayMsg != null)
                overlayMsg.text = "Falha no navegador embutido. Entre no navegador normal e cole aqui a URL com user= e key=.";
        }

        private function scanTick(e:TimerEvent):void
        {
            if (done) return;
            scans++;
            scanHtml(collectHtml(), false);
            if (scans >= 40) timer.stop();
        }

        private function collectHtml():String
        {
            if (html == null) return "";
            var o:Array = [];
            try { o.push(String(html.window.document.documentElement.outerHTML)); } catch (e1:Error) {}
            try
            {
                var fr:* = html.window.document.getElementsByTagName("iframe");
                for (var i:int = 0; i < fr.length; i++)
                {
                    try { o.push(String(fr[i].contentDocument.documentElement.outerHTML)); } catch (e2:Error) {}
                }
            }
            catch (e3:Error) {}
            return o.join("\n");
        }

        private function startClipWatch():void
        {
            stopClipWatch();
            clipTimer = new Timer(800);
            clipTimer.addEventListener(TimerEvent.TIMER, onClipTick);
            clipTimer.start();
        }

        private function stopClipWatch():void
        {
            try
            {
                if (clipTimer != null)
                {
                    clipTimer.stop();
                    clipTimer.removeEventListener(TimerEvent.TIMER, onClipTick);
                    clipTimer = null;
                }
            }
            catch (e:Error) {}
        }

        private function onClipTick(e:TimerEvent):void
        {
            if (done) { stopClipWatch(); return; }
            try
            {
                if (!Clipboard.generalClipboard.hasFormat(ClipboardFormats.TEXT_FORMAT)) return;
                var t:String = String(Clipboard.generalClipboard.getData(ClipboardFormats.TEXT_FORMAT));
                if (t == null || t.length < 8 || t == lastClip) return;
                if (t.indexOf("user=") < 0 || t.indexOf("key=") < 0) return;
                lastClip = t;
                if (usePasted(t))
                {
                    if (barHint != null) barHint.text = "Sessão capturada da área de transferência!";
                    stopClipWatch();
                }
            }
            catch (e1:Error) {}
        }

        private function isAsset(lowerPath:String):Boolean
        {
            for each (var ext:String in ASSET_EXT)
                if (lowerPath.length >= ext.length && lowerPath.lastIndexOf(ext) == lowerPath.length - ext.length) return true;
            return false;
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function pathOf(url:String):String
        {
            if (url == null) return "";
            return url.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function note(url:String):void
        {
            if (url == null) return;
            notes.push(url);
            if (notes.length > 40) notes.shift();
            var p:String = pathOf(url).toLowerCase();
            if (p.indexOf("loading") >= 0 && p.lastIndexOf(".swf") == p.length - 4)
            {
                var qi:int = url.indexOf("?");
                var raw:String = pathOf(url);
                seenSwf = qi >= 0 ? raw + url.substring(qi) : raw;
            }
        }

        private function check(url:String):Boolean
        {
            if (done || url == null) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            finishWith(m != null ? String(m[1]) : host, params, seenSwf);
            return true;
        }

        private function plausible(v:String):Boolean
        {
            if (v == null) return false;
            var l:String = v.toLowerCase();
            return !(l == "function" || l == "null" || l == "undefined" || l == "true" || l == "false"
                || l == "this" || l == "document" || l == "window" || l == "var");
        }

        private function scanHtml(t:String, force:Boolean):Boolean
        {
            if (done || t == null || t.length == 0) return false;
            var swf:String = null;
            var m:Array = t.match(RE_SWF_LOADING);
            if (m != null) swf = String(m[1]);
            else { m = t.match(RE_SWF_ANY); if (m != null) swf = String(m[1]); }
            if (swf == null) swf = seenSwf;
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
                    mm = re.exec(t);
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8) return false;
            if (swf == null && scans < 10 && !force) return false;
            finishWith(host, params, swf);
            return true;
        }

        private function usePasted(t:String):Boolean
        {
            if (t == null) return false;
            var urls:Array = t.match(/https?:\/\/[^\s\"'<>]+/g);
            if (urls != null)
            {
                for each (var u:String in urls) note(u.replace(/&amp;/g, "&"));
                for each (var u2:String in urls)
                    if (check(u2.replace(/&amp;/g, "&"))) return true;
            }
            if (t.indexOf("user=") >= 0 && t.indexOf("key=") >= 0)
            {
                if (check("https://" + host + "/?" + t.replace(/^[\s\S]*?(user=)/, "$1"))) return true;
            }
            return scanHtml(t, true);
        }

        private function finishWith(site:String, params:Object, swfPath:String):void
        {
            if (done) return;
            done = true;
            stopClipWatch();
            try { if (timer != null) timer.stop(); } catch (e0:Error) {}
            var o:Object = {};
            for each (var k:String in KEYS)
                if (params[k] != undefined) o[k] = params[k];
            o["site"] = site;
            o["host"] = site;
            if (swfPath != null && swfPath.length > 0)
            {
                if (swfPath.indexOf("http") == 0)
                {
                    var m:Array = swfPath.match(/^[a-zA-Z]+:\/\/([^\/]+)(\/.*)$/);
                    if (m != null) { o["site"] = String(m[1]); o["host"] = String(m[1]); swfPath = String(m[2]).replace(/#.*$/, ""); }
                    else swfPath = "/" + swfPath.replace(/^\/+/, "").replace(/#.*$/, "");
                }
                o["swf"] = swfPath;
            }
            var json:String = JSON.stringify(o);
            try { if (html != null && html.parent != null) html.parent.removeChild(html); } catch (e1:Error) {}
            try { if (win != null) win.close(); } catch (e2:Error) {}
            if (onSession != null) onSession(json);
        }

        private function onWinClose(e:Event):void
        {
            stopClipWatch();
            try { if (timer != null) timer.stop(); } catch (e0:Error) {}
            if (!done && onClosed != null) onClosed();
        }
    }
}
