package
{
    import flash.desktop.Clipboard;
    import flash.desktop.ClipboardFormats;
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.net.URLRequest;
    import flash.net.navigateToURL;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Login no PC (64-bit): o WebView embutido do AIR nao recebe clique nesse site.
    // Abre o navegador do Windows (Chrome/Edge) no site do jogo. Voce faz login la.
    // Quando a URL tiver user= e key=, copie (Ctrl+C) — o launcher captura e abre o jogo.
    public class LoginWindow
    {
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];
        private static const RE_SWF_LOADING:RegExp = /([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/;
        private static const RE_SWF_ANY:RegExp = /([\w.\/:\-%]+\.swf)/;

        public var onSession:Function;
        public var onClosed:Function;

        private var host:String;
        private var win:NativeWindow;
        private var input:TextField;
        private var statusTf:TextField;
        private var done:Boolean = false;
        private var seenSwf:String = null;
        private var clipTimer:Timer;
        private var lastClip:String = "";

        public function LoginWindow(host:String)
        {
            this.host = host;
        }

        public function focus():void
        {
            try { if (win != null) win.activate(); } catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login - " + host;
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(700, b.width - 40);
            win.height = Math.min(480, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            var root:Sprite = new Sprite();
            win.stage.addChild(root);
            var bg:Sprite = new Sprite();
            root.addChild(bg);

            function paint():void
            {
                var w:Number = win.stage.stageWidth;
                var h:Number = win.stage.stageHeight;
                bg.graphics.clear();
                bg.graphics.beginFill(0x0B0A1E, 1);
                bg.graphics.drawRect(0, 0, w, h);
                bg.graphics.endFill();
                if (input != null)
                {
                    input.width = Math.max(200, w - 48);
                    input.height = Math.max(80, h - 260);
                }
            }

            root.addChild(tf("Login no site do jogo", 20, 0xFFFFFF, true, 24, 18, 640));
            root.addChild(tf(
                "1) O navegador do Windows abre em https://" + host + "/\n" +
                "2) Faca login e clique no seu servidor (OAS...)\n" +
                "3) Na barra de endereco, se aparecer user= e key=, copie a URL (Ctrl+L, Ctrl+C)\n" +
                "4) O launcher detecta sozinho — ou cole abaixo e clique Usar",
                13, 0xC9C4EE, false, 24, 52, 640));

            input = new TextField();
            input.type = TextFieldType.INPUT;
            input.multiline = true;
            input.wordWrap = true;
            input.background = true;
            input.backgroundColor = 0x0E0D26;
            input.border = true;
            input.borderColor = 0x3B3A78;
            input.defaultTextFormat = new TextFormat("_typewriter", 12, 0xE6E6F5);
            input.x = 24;
            input.y = 160;
            input.width = 640;
            input.height = 160;
            root.addChild(input);

            statusTf = tf("Abrindo o site no navegador...", 12, 0xA5F3A5, false, 24, 330, 640);
            root.addChild(statusTf);

            var useBtn:Btn = new Btn(Btn.PRIMARY, 140, 40, "Usar texto", "", function(e:MouseEvent):void {
                if (!usePasted(input.text))
                    statusTf.text = "Nao achei user= e key=. Cole a URL completa da barra de endereco.";
            });
            useBtn.x = 24 + 70; useBtn.y = 380;
            root.addChild(useBtn);

            var openBtn:Btn = new Btn(Btn.GHOST, 180, 40, "Abrir site de novo", "", function(e:MouseEvent):void {
                openSite();
                statusTf.text = "Site reaberto no navegador.";
            });
            openBtn.x = 200 + 90; openBtn.y = 380;
            root.addChild(openBtn);

            var pasteBtn:Btn = new Btn(Btn.GHOST, 140, 40, "Colar", "", function(e:MouseEvent):void {
                try
                {
                    if (Clipboard.generalClipboard.hasFormat(ClipboardFormats.TEXT_FORMAT))
                    {
                        var t:String = String(Clipboard.generalClipboard.getData(ClipboardFormats.TEXT_FORMAT));
                        input.text = t;
                        if (usePasted(t)) return;
                        statusTf.text = "Colado. Se nao entrou, a URL ainda nao tem user= e key=.";
                    }
                    else statusTf.text = "Area de transferencia vazia.";
                }
                catch (err:Error) { statusTf.text = "Nao deu para ler a area de transferencia."; }
            });
            pasteBtn.x = 420 + 70; pasteBtn.y = 380;
            root.addChild(pasteBtn);

            win.stage.addEventListener(Event.RESIZE, function(e:Event):void { paint(); });
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();
            paint();

            openSite();
            startClipWatch();
            statusTf.text = "Site aberto. Faca login no navegador e copie a URL com user= e key=.";
        }

        private function openSite():void
        {
            try { navigateToURL(new URLRequest("https://" + host + "/")); } catch (e:Error) {}
        }

        private function tf(t:String, size:int, color:uint, bold:Boolean, x:Number, y:Number, w:Number):TextField
        {
            var f:TextField = new TextField();
            f.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            f.selectable = false;
            f.mouseEnabled = false;
            f.multiline = true;
            f.wordWrap = true;
            f.width = w;
            f.x = x; f.y = y;
            f.text = t;
            f.height = f.textHeight + 8;
            return f;
        }

        private function startClipWatch():void
        {
            stopClipWatch();
            clipTimer = new Timer(600);
            clipTimer.addEventListener(TimerEvent.TIMER, onClipTick);
            clipTimer.start();
        }

        private function stopClipWatch():void
        {
            try
            {
                if (clipTimer != null)
                {
                    clipTimer.stop();
                    clipTimer.removeEventListener(TimerEvent.TIMER, onClipTick);
                    clipTimer = null;
                }
            }
            catch (e:Error) {}
        }

        private function onClipTick(e:TimerEvent):void
        {
            if (done) { stopClipWatch(); return; }
            try
            {
                if (!Clipboard.generalClipboard.hasFormat(ClipboardFormats.TEXT_FORMAT)) return;
                var t:String = String(Clipboard.generalClipboard.getData(ClipboardFormats.TEXT_FORMAT));
                if (t == null || t.length < 8 || t == lastClip) return;
                if (t.indexOf("user=") < 0 || t.indexOf("key=") < 0) return;
                lastClip = t;
                if (input != null) input.text = t;
                if (usePasted(t))
                    statusTf.text = "Sessao capturada! Abrindo o jogo no launcher...";
            }
            catch (e1:Error) {}
        }

        private function pathOf(url:String):String
        {
            if (url == null) return "";
            return url.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function isAsset(p:String):Boolean
        {
            var low:String = p.toLowerCase();
            for each (var ext:String in [".png", ".jpg", ".css", ".js", ".ico", ".gif", ".woff"])
                if (low.length >= ext.length && low.lastIndexOf(ext) == low.length - ext.length) return true;
            return false;
        }

        private function check(url:String):Boolean
        {
            if (done || url == null) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(pathOf(url).toLowerCase())) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            var site:String = m != null ? String(m[1]) : host;
            // swf na propria url?
            var pth:String = pathOf(url);
            if (pth.toLowerCase().indexOf(".swf") >= 0) seenSwf = pth;
            finishWith(site, params, seenSwf);
            return true;
        }

        private function scanHtml(t:String):Boolean
        {
            if (done || t == null || t.length == 0) return false;
            var swf:String = seenSwf;
            var m:Array = t.match(RE_SWF_LOADING);
            if (m != null) swf = String(m[1]);
            else { m = t.match(RE_SWF_ANY); if (m != null) swf = String(m[1]); }
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    var v:String = String(mm[1]);
                    var low:String = v.toLowerCase();
                    if (low != "function" && low != "null" && low != "undefined")
                    { params[k] = v; break; }
                    mm = re.exec(t);
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8) return false;
            finishWith(host, params, swf);
            return true;
        }

        private function usePasted(t:String):Boolean
        {
            if (t == null) return false;
            var urls:Array = t.match(/https?:\/\/[^\s\"'<>]+/g);
            if (urls != null)
            {
                for each (var u:String in urls)
                    if (check(u.replace(/&amp;/g, "&"))) return true;
            }
            if (t.indexOf("user=") >= 0 && t.indexOf("key=") >= 0)
            {
                if (check("https://" + host + "/x?" + t.replace(/^[\s\S]*?(user=)/, "$1"))) return true;
                if (scanHtml(t)) return true;
            }
            return scanHtml(t);
        }

        private function finishWith(site:String, params:Object, swfPath:String):void
        {
            if (done) return;
            done = true;
            stopClipWatch();
            var o:Object = {};
            for each (var k:String in KEYS)
                if (params[k] != undefined) o[k] = params[k];
            o["site"] = site;
            o["host"] = site;
            if (swfPath != null && swfPath.length > 0)
            {
                if (swfPath.indexOf("http") == 0)
                {
                    var m:Array = swfPath.match(/^[a-zA-Z]+:\/\/([^\/]+)(\/.*)$/);
                    if (m != null) { o["site"] = String(m[1]); o["host"] = String(m[1]); swfPath = String(m[2]); }
                }
                o["swf"] = swfPath;
            }
            var json:String = JSON.stringify(o);
            try { if (win != null) win.close(); } catch (e:Error) {}
            if (onSession != null) onSession(json);
        }

        private function onWinClose(e:Event):void
        {
            stopClipWatch();
            if (!done && onClosed != null) onClosed();
        }
    }
}
