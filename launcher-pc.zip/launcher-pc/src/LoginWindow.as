package
{
    import flash.desktop.Clipboard;
    import flash.desktop.ClipboardFormats;
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.html.HTMLLoader;
    import flash.net.URLRequest;
    import flash.net.navigateToURL;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.Timer;
    import flash.utils.setTimeout;

    // Login 64-bit: o HTMLLoader do AIR carrega o site (cookies/sessão), mas os cliques nele falham.
    // Solução: lê a lista "Meus Servidores" no DOM e mostra botões NATIVOS clicáveis.
    // Ao tocar num servidor, dispara o clique via JavaScript no HTMLLoader.
    public class LoginWindow
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];
        private static const RE_SWF_LOADING:RegExp = /([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/;
        private static const RE_SWF_ANY:RegExp = /([\w.\/:\-%]+\.swf)/;
        private static const ASSET_EXT:Array = [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".woff2", ".svg", ".webp"];

        public var onSession:Function;
        public var onClosed:Function;

        private var host:String;
        private var win:NativeWindow;
        private var html:HTMLLoader;
        private var ui:Sprite;
        private var listBox:Sprite;
        private var statusTf:TextField;
        private var titleTf:TextField;
        private var done:Boolean = false;
        private var seenSwf:String = null;
        private var timer:Timer;
        private var scans:int = 0;
        private var notes:Array = [];
        private var clipTimer:Timer;
        private var lastClip:String = "";
        private var servers:Array = []; // {label, href, js}
        private var pollTimer:Timer;

        public function LoginWindow(host:String)
        {
            this.host = host;
        }

        public function focus():void
        {
            try { if (win != null) win.activate(); } catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login - " + host;
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(640, b.width - 40);
            win.height = Math.min(560, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            // HTMLLoader "invisível" — só para cookies + DOM + JS
            html = new HTMLLoader();
            html.userAgent = UA;
            html.width = 8;
            html.height = 8;
            html.x = -100;
            html.y = -100;
            html.alpha = 0.01;
            html.addEventListener(Event.LOCATION_CHANGE, onLoc);
            html.addEventListener(Event.COMPLETE, onComplete);
            html.addEventListener(ErrorEvent.ERROR, onLoadError);
            html.addEventListener(IOErrorEvent.IO_ERROR, onLoadError);
            win.stage.addChild(html);

            buildUi();
            win.stage.addEventListener(Event.RESIZE, onResize);
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();
            layout();

            statusTf.text = "Carregando sessão no site...";
            html.load(new URLRequest("https://" + host + "/"));
            startClipWatch();
            startPollServers();
        }

        private function buildUi():void
        {
            ui = new Sprite();
            win.stage.addChild(ui);

            var bg:Sprite = new Sprite();
            bg.name = "bg";
            ui.addChild(bg);

            titleTf = mkTf("Escolha o servidor", 20, 0xFFFFFF, true, 24, 20, 580);
            ui.addChild(titleTf);

            statusTf = mkTf("Aguardando lista de servidores...", 13, 0xC9C4EE, false, 24, 52, 580);
            ui.addChild(statusTf);

            listBox = new Sprite();
            listBox.x = 24;
            listBox.y = 90;
            ui.addChild(listBox);

            var rowY:Number = 420;
            var refreshBtn:Btn = new Btn(Btn.GHOST, 140, 36, "Atualizar lista", "", function(e:MouseEvent):void {
                statusTf.text = "Atualizando...";
                scanServers();
            });
            refreshBtn.name = "refresh";
            refreshBtn.x = 24 + 70; refreshBtn.y = rowY;
            ui.addChild(refreshBtn);

            var browserBtn:Btn = new Btn(Btn.GHOST, 160, 36, "Abrir no navegador", "", function(e:MouseEvent):void {
                try { navigateToURL(new URLRequest("https://" + host + "/")); } catch (err:Error) {}
                statusTf.text = "Navegador aberto. Se entrar por lá, copie a URL com user= e key=.";
            });
            browserBtn.name = "browser";
            browserBtn.x = 200 + 80; browserBtn.y = rowY;
            ui.addChild(browserBtn);

            var pasteBtn:Btn = new Btn(Btn.GHOST, 140, 36, "Colar URL", "", function(e:MouseEvent):void {
                openPaste();
            });
            pasteBtn.name = "paste";
            pasteBtn.x = 400 + 70; pasteBtn.y = rowY;
            ui.addChild(pasteBtn);
        }

        private function onResize(e:Event):void { layout(); }

        private function layout():void
        {
            if (win == null || win.stage == null || ui == null) return;
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight;
            if (w <= 0 || h <= 0) return;
            var bg:Sprite = ui.getChildByName("bg") as Sprite;
            if (bg != null)
            {
                bg.graphics.clear();
                bg.graphics.beginFill(0x0B0A1E, 1);
                bg.graphics.drawRect(0, 0, w, h);
                bg.graphics.endFill();
            }
            var ry:Number = h - 48;
            for each (var n:String in ["refresh", "browser", "paste"])
            {
                var b:Btn = ui.getChildByName(n) as Btn;
                if (b != null) b.y = ry;
            }
        }

        private function mkTf(t:String, size:int, color:uint, bold:Boolean, x:Number, y:Number, w:Number):TextField
        {
            var f:TextField = new TextField();
            f.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            f.selectable = false; f.mouseEnabled = false;
            f.multiline = true; f.wordWrap = true;
            f.width = w; f.x = x; f.y = y; f.text = t;
            f.height = f.textHeight + 8;
            return f;
        }

        private function startPollServers():void
        {
            pollTimer = new Timer(1500);
            pollTimer.addEventListener(TimerEvent.TIMER, function(e:TimerEvent):void {
                if (done) return;
                scanServers();
            });
            pollTimer.start();
        }

        private function scanServers():void
        {
            if (html == null || done) return;
            var found:Array = [];
            try
            {
                var doc:* = html.window.document;
                // pega todos os elementos e procura texto tipo OAS1234:...
                var all:* = doc.getElementsByTagName("*");
                var n:int = int(all.length);
                var seen:Object = {};
                for (var i:int = 0; i < n && found.length < 30; i++)
                {
                    var el:* = all[i];
                    var txt:String = "";
                    try { txt = String(el.innerText != undefined ? el.innerText : el.textContent); } catch (e0:Error) { continue; }
                    if (txt == null) continue;
                    txt = txt.replace(/^\s+|\s+$/g, "").replace(/\s+/g, " ");
                    if (txt.length < 6 || txt.length > 80) continue;
                    if (!/^OAS\d+/i.test(txt) && txt.indexOf("OAS") < 0) continue;
                    // evita pegar o container pai com vários servidores
                    if (txt.indexOf("\n") >= 0 || txt.split("OAS").length > 2) continue;
                    var key:String = txt.toLowerCase();
                    if (seen[key]) continue;
                    seen[key] = true;
                    var href:String = "";
                    try
                    {
                        var a:* = el;
                        for (var d:int = 0; d < 5 && a != null; d++)
                        {
                            if (a.href != undefined && String(a.href).indexOf("http") == 0)
                            { href = String(a.href); break; }
                            a = a.parentNode;
                        }
                    }
                    catch (e1:Error) {}
                    found.push({ label: txt, href: href, index: i });
                }
            }
            catch (e:Error)
            {
                note("scan:" + e.message);
            }

            if (found.length == 0)
            {
                // tenta links com servidor no href
                try
                {
                    var links:* = html.window.document.getElementsByTagName("a");
                    for (var j:int = 0; j < int(links.length) && found.length < 30; j++)
                    {
                        var L:* = links[j];
                        var lt:String = String(L.innerText != undefined ? L.innerText : L.textContent);
                        lt = lt.replace(/^\s+|\s+$/g, "");
                        var lh:String = L.href != undefined ? String(L.href) : "";
                        if (lt.length > 2 && (lt.indexOf("OAS") >= 0 || lh.indexOf("server") >= 0 || lh.indexOf("play") >= 0))
                            found.push({ label: lt != "" ? lt : lh, href: lh, index: j });
                    }
                }
                catch (e2:Error) {}
            }

            if (found.length > 0)
            {
                servers = found;
                redrawServerList();
                statusTf.text = found.length + " servidor(es). Clique no seu para entrar.";
            }
            else
            {
                statusTf.text = "Ainda sem lista (sessão carregando ou site sem 'Meus Servidores'). Use Colar URL se precisar.";
            }
        }

        private function redrawServerList():void
        {
            while (listBox.numChildren > 0) listBox.removeChildAt(0);
            var y:Number = 0;
            for (var i:int = 0; i < servers.length; i++)
            {
                var s:Object = servers[i];
                var row:Sprite = new Sprite();
                row.y = y;
                row.buttonMode = true;
                row.mouseChildren = false;
                row.graphics.beginFill(0x1A1838, 1);
                row.graphics.lineStyle(1, 0x3B3A78, 1);
                row.graphics.drawRoundRect(0, 0, 560, 40, 10, 10);
                row.graphics.endFill();
                var tf:TextField = mkTf(String(s.label), 14, 0xFFFFFF, true, 14, 10, 520);
                row.addChild(tf);
                row.addEventListener(MouseEvent.CLICK, makeEnter(s));
                listBox.addChild(row);
                y += 48;
            }
        }

        private function makeEnter(s:Object):Function
        {
            return function(e:MouseEvent):void { enterServer(s); };
        }

        private function enterServer(s:Object):void
        {
            if (done) return;
            statusTf.text = "Entrando em " + s.label + "...";
            note("enter:" + s.label + " href=" + s.href);

            // 1) se tem href direto com user/key
            if (s.href && check(String(s.href))) return;

            // 2) clica no elemento via JS (mesmo sem mouse no HTMLLoader)
            try
            {
                var label:String = String(s.label);
                // escapa aspas
                var esc:String = label.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
                var js:String =
                    "(function(){" +
                    "var all=document.getElementsByTagName('*');" +
                    "for(var i=0;i<all.length;i++){" +
                    "var t=(all[i].innerText||all[i].textContent||'').replace(/\\s+/g,' ').replace(/^ | $/g,'');" +
                    "if(t==='" + esc + "'){all[i].click();return 'ok';}" +
                    "}" +
                    "return 'miss';" +
                    "})()";
                var r:* = html.window.eval(js);
                note("js-click:" + String(r));
            }
            catch (e:Error) { note("js:" + e.message); }

            // 3) se tem href, navega
            if (s.href != null && String(s.href).length > 8)
            {
                try { html.load(new URLRequest(String(s.href))); } catch (e2:Error) {}
            }

            // 4) espera location/HTML com user+key
            statusTf.text = "Servidor acionado. Aguardando user/key...";
        }

        private function openPaste():void
        {
            var panel:Sprite = new Sprite();
            panel.graphics.beginFill(0x07061A, 0.98);
            panel.graphics.drawRect(0, 0, win.stage.stageWidth, win.stage.stageHeight);
            panel.graphics.endFill();
            var msg:TextField = mkTf("Cole a URL com user= e key= e clique Usar", 14, 0xFFFFFF, true, 24, 40, 560);
            panel.addChild(msg);
            var inp:TextField = new TextField();
            inp.type = TextFieldType.INPUT;
            inp.multiline = true; inp.wordWrap = true;
            inp.background = true; inp.backgroundColor = 0x0E0D26;
            inp.border = true; inp.borderColor = 0x3B3A78;
            inp.defaultTextFormat = new TextFormat("_typewriter", 12, 0xE6E6F5);
            inp.x = 24; inp.y = 80; inp.width = 560; inp.height = 200;
            panel.addChild(inp);
            try
            {
                if (Clipboard.generalClipboard.hasFormat(ClipboardFormats.TEXT_FORMAT))
                    inp.text = String(Clipboard.generalClipboard.getData(ClipboardFormats.TEXT_FORMAT));
            }
            catch (e:Error) {}
            var use:Btn = new Btn(Btn.PRIMARY, 140, 36, "Usar", "", function(e:MouseEvent):void {
                if (usePasted(inp.text)) { try { win.stage.removeChild(panel); } catch (e0:Error) {} }
                else statusTf.text = "Não achei user= e key= no texto.";
            });
            use.x = 24 + 70; use.y = 300;
            panel.addChild(use);
            var close:Btn = new Btn(Btn.GHOST, 120, 36, "Fechar", "", function(e:MouseEvent):void {
                try { win.stage.removeChild(panel); } catch (e1:Error) {}
            });
            close.x = 200 + 60; close.y = 300;
            panel.addChild(close);
            win.stage.addChild(panel);
        }

        private function onLoc(e:Event):void
        {
            if (html == null) return;
            var u:String = html.location;
            note(u);
            check(u);
            setTimeout(function():void { if (!done) scanServers(); }, 400);
        }

        private function onComplete(e:Event):void
        {
            if (done) return;
            scans = 0;
            if (timer == null)
            {
                timer = new Timer(2000);
                timer.addEventListener(TimerEvent.TIMER, scanTick);
            }
            timer.reset();
            timer.start();
            scanServers();
            try { win.title = "Login - " + host; } catch (e2:Error) {}
        }

        private function onLoadError(e:Event):void
        {
            note("erro:" + String(e));
            statusTf.text = "Falha ao carregar o site no motor embutido. Use Abrir no navegador + Colar URL.";
        }

        private function scanTick(e:TimerEvent):void
        {
            if (done) return;
            scans++;
            scanHtml(collectHtml(), false);
            scanServers();
            if (scans >= 60) timer.stop();
        }

        private function collectHtml():String
        {
            if (html == null) return "";
            var o:Array = [];
            try { o.push(String(html.window.document.documentElement.outerHTML)); } catch (e1:Error) {}
            return o.join("\n");
        }

        private function startClipWatch():void
        {
            stopClipWatch();
            clipTimer = new Timer(800);
            clipTimer.addEventListener(TimerEvent.TIMER, onClipTick);
            clipTimer.start();
        }

        private function stopClipWatch():void
        {
            try
            {
                if (clipTimer != null)
                {
                    clipTimer.stop();
                    clipTimer.removeEventListener(TimerEvent.TIMER, onClipTick);
                    clipTimer = null;
                }
            }
            catch (e:Error) {}
        }

        private function onClipTick(e:TimerEvent):void
        {
            if (done) { stopClipWatch(); return; }
            try
            {
                if (!Clipboard.generalClipboard.hasFormat(ClipboardFormats.TEXT_FORMAT)) return;
                var t:String = String(Clipboard.generalClipboard.getData(ClipboardFormats.TEXT_FORMAT));
                if (t == null || t.length < 8 || t == lastClip) return;
                if (t.indexOf("user=") < 0 || t.indexOf("key=") < 0) return;
                lastClip = t;
                if (usePasted(t)) statusTf.text = "Sessão capturada da área de transferência!";
            }
            catch (e1:Error) {}
        }

        private function isAsset(lowerPath:String):Boolean
        {
            for each (var ext:String in ASSET_EXT)
                if (lowerPath.length >= ext.length && lowerPath.lastIndexOf(ext) == lowerPath.length - ext.length) return true;
            return false;
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function pathOf(url:String):String
        {
            if (url == null) return "";
            return url.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function note(url:String):void
        {
            if (url == null) return;
            notes.push(url);
            if (notes.length > 40) notes.shift();
            var p:String = pathOf(url).toLowerCase();
            if (p.indexOf("loading") >= 0 && p.lastIndexOf(".swf") == p.length - 4)
            {
                var qi:int = url.indexOf("?");
                var raw:String = pathOf(url);
                seenSwf = qi >= 0 ? raw + url.substring(qi) : raw;
            }
        }

        private function check(url:String):Boolean
        {
            if (done || url == null) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            finishWith(m != null ? String(m[1]) : host, params, seenSwf);
            return true;
        }

        private function plausible(v:String):Boolean
        {
            if (v == null) return false;
            var l:String = v.toLowerCase();
            return !(l == "function" || l == "null" || l == "undefined" || l == "true" || l == "false"
                || l == "this" || l == "document" || l == "window" || l == "var");
        }

        private function scanHtml(t:String, force:Boolean):Boolean
        {
            if (done || t == null || t.length == 0) return false;
            var swf:String = null;
            var m:Array = t.match(RE_SWF_LOADING);
            if (m != null) swf = String(m[1]);
            else { m = t.match(RE_SWF_ANY); if (m != null) swf = String(m[1]); }
            if (swf == null) swf = seenSwf;
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
                    mm = re.exec(t);
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8) return false;
            if (swf == null && scans < 10 && !force) return false;
            finishWith(host, params, swf);
            return true;
        }

        private function usePasted(t:String):Boolean
        {
            if (t == null) return false;
            var urls:Array = t.match(/https?:\/\/[^\s\"'<>]+/g);
            if (urls != null)
            {
                for each (var u:String in urls) note(u.replace(/&amp;/g, "&"));
                for each (var u2:String in urls)
                    if (check(u2.replace(/&amp;/g, "&"))) return true;
            }
            if (t.indexOf("user=") >= 0 && t.indexOf("key=") >= 0)
            {
                if (check("https://" + host + "/?" + t.replace(/^[\s\S]*?(user=)/, "$1"))) return true;
            }
            return scanHtml(t, true);
        }

        private function finishWith(site:String, params:Object, swfPath:String):void
        {
            if (done) return;
            done = true;
            stopClipWatch();
            try { if (timer != null) timer.stop(); } catch (e0:Error) {}
            try { if (pollTimer != null) pollTimer.stop(); } catch (e1:Error) {}
            var o:Object = {};
            for each (var k:String in KEYS)
                if (params[k] != undefined) o[k] = params[k];
            o["site"] = site;
            o["host"] = site;
            if (swfPath != null && swfPath.length > 0)
            {
                if (swfPath.indexOf("http") == 0)
                {
                    var m:Array = swfPath.match(/^[a-zA-Z]+:\/\/([^\/]+)(\/.*)$/);
                    if (m != null) { o["site"] = String(m[1]); o["host"] = String(m[1]); swfPath = String(m[2]).replace(/#.*$/, ""); }
                    else swfPath = "/" + swfPath.replace(/^\/+/, "").replace(/#.*$/, "");
                }
                o["swf"] = swfPath;
            }
            var json:String = JSON.stringify(o);
            try { if (html != null && html.parent != null) html.parent.removeChild(html); } catch (e2:Error) {}
            try { if (win != null) win.close(); } catch (e3:Error) {}
            if (onSession != null) onSession(json);
        }

        private function onWinClose(e:Event):void
        {
            stopClipWatch();
            try { if (timer != null) timer.stop(); } catch (e0:Error) {}
            try { if (pollTimer != null) pollTimer.stop(); } catch (e1:Error) {}
            if (!done && onClosed != null) onClosed();
        }
    }
}
