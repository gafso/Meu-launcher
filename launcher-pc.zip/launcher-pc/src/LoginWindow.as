package
{
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.html.HTMLLoader;
    import flash.net.URLRequest;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Login 32-bit: HTMLLoader com Flash do AIR — clique no site + captura user/key do Loading.swf.
    public class LoginWindow
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        private static const BAR:int = 56;
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];

        public var onSession:Function;
        public var onClosed:Function;

        private var host:String;
        private var win:NativeWindow;
        private var html:HTMLLoader;
        private var bar:Sprite;
        private var statusTf:TextField;
        private var done:Boolean = false;
        private var seenSwf:String = null;
        private var scanTimer:Timer;
        private var scans:int = 0;

        public function LoginWindow(host:String) { this.host = host; }

        public function focus():void
        {
            try { if (win != null) win.activate(); if (html != null) win.stage.focus = html; } catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login — " + host;
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(1120, b.width - 40);
            win.height = Math.min(820, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            html = new HTMLLoader();
            html.userAgent = UA;
            html.placeLoadStringContentInApplicationSandbox = false;
            html.addEventListener(Event.LOCATION_CHANGE, onLoc);
            html.addEventListener(Event.COMPLETE, onComplete);
            html.addEventListener(ErrorEvent.ERROR, onErr);
            html.addEventListener(IOErrorEvent.IO_ERROR, onErr);
            win.stage.addChildAt(html, 0);

            bar = new Sprite();
            win.stage.addChild(bar);
            statusTf = new TextField();
            statusTf.defaultTextFormat = new TextFormat("_sans", 13, 0xD4D0F0, false);
            statusTf.mouseEnabled = false;
            statusTf.x = 16; statusTf.y = 16;
            statusTf.height = 28;
            statusTf.text = "Faça login e clique no seu servidor. O jogo abre no launcher automaticamente.";
            bar.addChild(statusTf);

            var closeHint:TextField = new TextField();
            closeHint.defaultTextFormat = new TextFormat("_sans", 11, 0x9B97C7, false);
            closeHint.mouseEnabled = false;
            closeHint.text = "Legend PC · sessão segura";
            bar.addChild(closeHint);
            closeHint.name = "hint";

            win.stage.addEventListener(Event.RESIZE, onResize);
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();
            layout();
            html.load(new URLRequest("https://" + host + "/"));
            try { win.stage.focus = html; } catch (e:Error) {}
        }

        private function onResize(e:Event):void { layout(); }

        private function layout():void
        {
            if (win == null || win.stage == null) return;
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight;
            if (w <= 0 || h <= 0) return;
            html.x = 0; html.y = 0;
            html.width = w;
            html.height = Math.max(50, h - BAR);
            bar.y = h - BAR;
            bar.graphics.clear();
            bar.graphics.beginFill(0x0F0E1A, 0.98);
            bar.graphics.drawRect(0, 0, w, BAR);
            bar.graphics.endFill();
            bar.graphics.lineStyle(1, 0x8B5CF6, 0.35);
            bar.graphics.moveTo(0, 0);
            bar.graphics.lineTo(w, 0);
            statusTf.width = w - 180;
            var hint:TextField = bar.getChildByName("hint") as TextField;
            if (hint != null) { hint.x = w - 160; hint.y = 18; hint.width = 150; }
        }

        private function onLoc(e:Event):void
        {
            if (html == null) return;
            check(html.location);
        }

        private function onComplete(e:Event):void
        {
            if (done) return;
            if (scanTimer == null)
            {
                scanTimer = new Timer(1200);
                scanTimer.addEventListener(TimerEvent.TIMER, onScan);
            }
            scanTimer.reset();
            scanTimer.start();
            scanHtml(collectHtml());
            try { win.stage.focus = html; } catch (e1:Error) {}
        }

        private function onScan(e:TimerEvent):void
        {
            if (done) { scanTimer.stop(); return; }
            scans++;
            try { check(html.location); } catch (e0:Error) {}
            scanHtml(collectHtml());
            try
            {
                var embeds:* = html.window.document.getElementsByTagName("embed");
                for (var i:int = 0; i < int(embeds.length); i++)
                {
                    var src:String = "";
                    try { src = String(embeds[i].src); } catch (e1:Error) {}
                    if (src != null && src.length > 4) check(src.indexOf("http") == 0 ? src : ("https://" + host + (src.charAt(0) == "/" ? src : "/" + src)));
                    try
                    {
                        var fv:String = String(embeds[i].getAttribute("flashvars"));
                        if (fv) scanHtml("flashvars=" + fv);
                    } catch (e2:Error) {}
                }
            } catch (e3:Error) {}
        }

        private function onErr(e:Event):void
        {
            statusTf.text = "Falha ao carregar o site. Feche e tente de novo.";
        }

        private function collectHtml():String
        {
            try { return String(html.window.document.documentElement.outerHTML); } catch (e:Error) {}
            return "";
        }

        private function pathOf(url:String):String
        {
            if (url == null) return "";
            return url.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function isAsset(lp:String):Boolean
        {
            for each (var ext:String in [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".svg"])
                if (lp.length >= ext.length && lp.lastIndexOf(ext) == lp.length - ext.length) return true;
            return false;
        }

        private function check(url:String):Boolean
        {
            if (done || url == null || url.length < 8) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            var site:String = m != null ? String(m[1]) : host;
            if (lp.indexOf(".swf") >= 0) seenSwf = pathOf(url) + url.substring(qi);
            finishWith(site, params, seenSwf);
            return true;
        }

        private function plausible(v:String):Boolean
        {
            if (v == null) return false;
            var l:String = v.toLowerCase();
            return !(l == "function" || l == "null" || l == "undefined" || l == "true" || l == "false"
                || l == "this" || l == "document" || l == "window" || l == "var");
        }

        private function scanHtml(t:String):Boolean
        {
            if (done || t == null || t.length < 30) return false;
            var swf:String = seenSwf;
            var m:Array = t.match(/([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/i);
            if (m != null) swf = String(m[1]);
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
                    mm = re.exec(t);
                }
            }
            var fv:Array = t.match(/flashvars[\s\"'=]+([^\"'<]+)/i);
            if (fv != null)
            {
                for each (var pair:String in String(fv[1]).split("&"))
                {
                    var j:int = pair.indexOf("=");
                    if (j > 0)
                    {
                        var pk:String = pair.substring(0, j).toLowerCase();
                        if (pk == "user" || pk == "key" || pk == "p2" || pk == "rid")
                            params[pk] = pair.substring(j + 1);
                    }
                }
            }
            var sm:Array = t.match(/[\w.\/:\-%]+\.swf\?([^\"'\s<>]+)/i);
            if (sm != null)
            {
                for each (var pair2:String in String(sm[1]).split("&"))
                {
                    var j2:int = pair2.indexOf("=");
                    if (j2 > 0)
                    {
                        var pk2:String = pair2.substring(0, j2).toLowerCase();
                        if (pk2 == "user" || pk2 == "key" || pk2 == "p2" || pk2 == "rid")
                            params[pk2] = pair2.substring(j2 + 1);
                    }
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8)
                return false;
            finishWith(host, params, swf);
            return true;
        }

        private function finishWith(site:String, params:Object, swfPath:String):void
        {
            if (done) return;
            if (params == null || params["user"] == undefined || params["key"] == undefined) return;
            if (String(params["key"]).length < 4) return;
            done = true;
            try { if (scanTimer != null) scanTimer.stop(); } catch (e0:Error) {}
            var o:Object = {};
            for each (var k:String in KEYS)
                if (params[k] != undefined) o[k] = params[k];
            o["site"] = site;
            o["host"] = site;
            if (swfPath != null && swfPath.length > 0)
            {
                if (swfPath.indexOf("http") == 0)
                {
                    var m:Array = swfPath.match(/^[a-zA-Z]+:\/\/([^\/]+)(\/.*)$/);
                    if (m != null) { o["site"] = String(m[1]); o["host"] = String(m[1]); swfPath = String(m[2]); }
                }
                var qpos:int = swfPath.indexOf("?");
                if (qpos > 0) swfPath = swfPath.substring(0, qpos);
                o["swf"] = swfPath;
            }
            if (o["swf"] == undefined) o["swf"] = "/client/Loading.swf";
            statusTf.text = "Sessão ok — abrindo o jogo...";
            var json:String = JSON.stringify(o);
            try { if (html != null && html.parent) html.parent.removeChild(html); } catch (e1:Error) {}
            try { if (win != null) win.close(); } catch (e2:Error) {}
            if (onSession != null) onSession(json);
        }

        private function onWinClose(e:Event):void
        {
            try { if (scanTimer != null) scanTimer.stop(); } catch (e0:Error) {}
            if (!done && onClosed != null) onClosed();
        }
    }
}
