package
{
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.html.HTMLLoader;
    import flash.net.URLRequest;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Login no PC — tudo no HTMLLoader (mesmo cookie jar + Flash do AIR).
    // StageWebView/Edge NAO tem Flash e NAO expoe cookies HttpOnly.
    // Fluxo:
    //  1) Abre o site no HTMLLoader (cookies da conta ficam aqui).
    //  2) Voce loga (teclado se o mouse falhar no 64-bit) OU ja vem logado.
    //  3) Digite o servidor e "Entrar servidor" — navega para /serverlist/sXXXX
    //     SEM sair do HTMLLoader (mesmos cookies).
    //  4) A pagina traz Loading.swf / flashvars com user e key — capturamos e
    //     o jogo abre no AIR (nao no browser).
    public class LoginWindow
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        private static const BAR:int = 92;
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];

        public var onSession:Function;
        public var onClosed:Function;

        private var host:String;
        private var win:NativeWindow;
        private var html:HTMLLoader;
        private var bar:Sprite;
        private var statusTf:TextField;
        private var serverInput:TextField;
        private var done:Boolean = false;
        private var seenSwf:String = null;
        private var scanTimer:Timer;
        private var notes:Array = [];
        private var scans:int = 0;

        public function LoginWindow(host:String)
        {
            this.host = host;
        }

        public function focus():void
        {
            try
            {
                if (win != null) win.activate();
                if (html != null) win.stage.focus = html;
            }
            catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login - " + host;
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(1100, b.width - 40);
            win.height = Math.min(800, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            html = new HTMLLoader();
            html.userAgent = UA;
            html.placeLoadStringContentInApplicationSandbox = false;
            html.addEventListener(Event.LOCATION_CHANGE, onLoc);
            html.addEventListener(Event.COMPLETE, onComplete);
            html.addEventListener(ErrorEvent.ERROR, onErr);
            html.addEventListener(IOErrorEvent.IO_ERROR, onErr);
            win.stage.addChildAt(html, 0);

            buildBar();
            win.stage.addEventListener(Event.RESIZE, onResize);
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();
            layout();

            html.load(new URLRequest("https://" + host + "/"));
            try { win.stage.focus = html; } catch (e:Error) {}
            statusTf.text = "Site no launcher (AIR). Logue se precisar. Depois: numero do servidor + Entrar servidor.";
        }

        private function buildBar():void
        {
            bar = new Sprite();
            win.stage.addChild(bar);

            statusTf = new TextField();
            statusTf.defaultTextFormat = new TextFormat("_sans", 12, 0xC9C4EE, false);
            statusTf.mouseEnabled = false;
            statusTf.wordWrap = true;
            statusTf.multiline = true;
            statusTf.x = 12; statusTf.y = 4;
            statusTf.height = 36;
            bar.addChild(statusTf);

            var lab:TextField = new TextField();
            lab.defaultTextFormat = new TextFormat("_sans", 12, 0xFFFFFF, true);
            lab.mouseEnabled = false;
            lab.text = "Servidor:";
            lab.width = 70; lab.height = 24;
            lab.x = 12; lab.y = 48;
            bar.addChild(lab);

            serverInput = new TextField();
            serverInput.type = TextFieldType.INPUT;
            serverInput.border = true;
            serverInput.borderColor = 0x3B3A78;
            serverInput.background = true;
            serverInput.backgroundColor = 0x0E0D26;
            serverInput.defaultTextFormat = new TextFormat("_sans", 14, 0xFFFFFF);
            serverInput.text = "1065";
            serverInput.width = 100;
            serverInput.height = 26;
            serverInput.x = 80; serverInput.y = 46;
            bar.addChild(serverInput);

            var goBtn:Btn = new Btn(Btn.PRIMARY, 160, 32, "Entrar servidor", "", function(e:MouseEvent):void {
                goServer();
            });
            goBtn.x = 200 + 80; goBtn.y = 58;
            bar.addChild(goBtn);

            var homeBtn:Btn = new Btn(Btn.GHOST, 90, 32, "Inicio", "", function(e:MouseEvent):void {
                html.load(new URLRequest("https://" + host + "/"));
                statusTf.text = "Inicio do site.";
            });
            homeBtn.x = 380 + 45; homeBtn.y = 58;
            bar.addChild(homeBtn);

            var focusBtn:Btn = new Btn(Btn.GHOST, 120, 32, "Focar pagina", "", function(e:MouseEvent):void {
                try { win.stage.focus = html; } catch (e1:Error) {}
                statusTf.text = "Foco na pagina. Use o teclado se o mouse nao clicar.";
            });
            focusBtn.x = 500 + 60; focusBtn.y = 58;
            bar.addChild(focusBtn);
        }

        private function goServer():void
        {
            if (done) return;
            var raw:String = serverInput.text.replace(/^\s+|\s+$/g, "");
            raw = raw.replace(/^s/i, "").replace(/^OAS/i, "");
            if (raw.length < 2)
            {
                statusTf.text = "Digite o numero do servidor (ex. 1065).";
                return;
            }
            var url:String = "https://" + host + "/serverlist/s" + raw;
            statusTf.text = "Abrindo " + url + " (mesmos cookies, Flash do AIR)...";
            scans = 0;
            try { html.load(new URLRequest(url)); }
            catch (e:Error) { statusTf.text = "Erro: " + e.message; }
            // tenta tambem via JS (mesmo documento / cookies)
            try
            {
                html.window.location.href = url;
            }
            catch (e2:Error) {}
            startScan();
        }

        private function startScan():void
        {
            if (scanTimer != null) scanTimer.stop();
            scanTimer = new Timer(700);
            scanTimer.addEventListener(TimerEvent.TIMER, onScan);
            scanTimer.start();
        }

        private function onScan(e:TimerEvent):void
        {
            if (done) { scanTimer.stop(); return; }
            scans++;
            try { check(html.location); } catch (e0:Error) {}
            scanHtml(collectHtml());
            // tenta achar embed e forcar leitura do src
            try
            {
                var doc:* = html.window.document;
                var embeds:* = doc.getElementsByTagName("embed");
                for (var i:int = 0; i < int(embeds.length); i++)
                {
                    var src:String = "";
                    try { src = String(embeds[i].src); } catch (e1:Error) {}
                    try { if (src == "") src = String(embeds[i].getAttribute("src")); } catch (e2:Error) {}
                    if (src != null && src.length > 4)
                    {
                        note("embed:" + src);
                        check(src);
                        if (src.indexOf("http") != 0 && src.indexOf("/") == 0)
                            check("https://" + host + src);
                    }
                    var fv:String = "";
                    try { fv = String(embeds[i].getAttribute("flashvars")); } catch (e3:Error) {}
                    if (fv != null && fv.indexOf("user") >= 0) scanHtml("flashvars=" + fv);
                }
                var objs:* = doc.getElementsByTagName("object");
                for (var j:int = 0; j < int(objs.length); j++)
                {
                    var data:String = "";
                    try { data = String(objs[j].data); } catch (e4:Error) {}
                    if (data != null && data.length > 4) { note("object:" + data); check(data); }
                    var params:* = objs[j].getElementsByTagName("param");
                    for (var k:int = 0; k < int(params.length); k++)
                    {
                        var nm:String = "";
                        var val:String = "";
                        try { nm = String(params[k].name); val = String(params[k].value); } catch (e5:Error) {}
                        if (nm != null && nm.toLowerCase().indexOf("flashvars") >= 0)
                            scanHtml("flashvars=" + val);
                        if (val != null && val.toLowerCase().indexOf(".swf") >= 0)
                            check(val);
                    }
                }
            }
            catch (e6:Error) {}
            if (scans > 40)
            {
                statusTf.text = "Ainda sem sessao na pagina. Confirme que esta logado no site e tente Entrar servidor de novo.";
            }
        }

        private function onResize(e:Event):void { layout(); }

        private function layout():void
        {
            if (win == null || win.stage == null) return;
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight;
            if (w <= 0 || h <= 0) return;
            if (html != null)
            {
                html.x = 0; html.y = 0;
                html.width = w;
                html.height = Math.max(50, h - BAR);
            }
            bar.y = h - BAR;
            bar.graphics.clear();
            bar.graphics.beginFill(0x12112E, 1);
            bar.graphics.drawRect(0, 0, w, BAR);
            bar.graphics.endFill();
            statusTf.width = w - 24;
        }

        private function onLoc(e:Event):void
        {
            if (html == null) return;
            var u:String = html.location;
            note(u);
            check(u);
        }

        private function onComplete(e:Event):void
        {
            if (done) return;
            startScan();
            scanHtml(collectHtml());
            try { win.stage.focus = html; } catch (e1:Error) {}
            try { win.title = "Login - " + host; } catch (e2:Error) {}
        }

        private function onErr(e:Event):void
        {
            statusTf.text = "Erro ao carregar a pagina.";
            note("err");
        }

        private function collectHtml():String
        {
            try { return String(html.window.document.documentElement.outerHTML); }
            catch (e:Error) {}
            return "";
        }

        private function pathOf(url:String):String
        {
            if (url == null) return "";
            return url.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function isAsset(lp:String):Boolean
        {
            for each (var ext:String in [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".svg"])
                if (lp.length >= ext.length && lp.lastIndexOf(ext) == lp.length - ext.length) return true;
            return false;
        }

        private function note(url:String):void
        {
            if (url == null) return;
            notes.push(url);
            if (notes.length > 50) notes.shift();
            var p:String = pathOf(url).toLowerCase();
            if (p.indexOf("loading") >= 0 && p.indexOf(".swf") >= 0)
            {
                var qi:int = url.indexOf("?");
                seenSwf = qi >= 0 ? pathOf(url) + url.substring(qi) : pathOf(url);
            }
        }

        private function check(url:String):Boolean
        {
            if (done || url == null || url.length < 8) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            var site:String = m != null ? String(m[1]) : host;
            if (lp.indexOf(".swf") >= 0)
                seenSwf = pathOf(url) + url.substring(qi);
            finishWith(site, params, seenSwf);
            return true;
        }

        private function plausible(v:String):Boolean
        {
            if (v == null) return false;
            var l:String = v.toLowerCase();
            return !(l == "function" || l == "null" || l == "undefined" || l == "true" || l == "false"
                || l == "this" || l == "document" || l == "window" || l == "var");
        }

        private function scanHtml(t:String):Boolean
        {
            if (done || t == null || t.length < 30) return false;
            var swf:String = seenSwf;
            var m:Array = t.match(/([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/i);
            if (m != null) swf = String(m[1]);
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
                    mm = re.exec(t);
                }
            }
            var fv:Array = t.match(/flashvars[\s\"'=]+([^\"'<]+)/i);
            if (fv != null)
            {
                for each (var pair:String in String(fv[1]).split("&"))
                {
                    var j:int = pair.indexOf("=");
                    if (j > 0)
                    {
                        var pk:String = pair.substring(0, j).toLowerCase();
                        if (pk == "user" || pk == "key" || pk == "p2" || pk == "rid")
                            params[pk] = pair.substring(j + 1);
                    }
                }
            }
            // query em qualquer .swf no HTML
            var sm:Array = t.match(/[\w.\/:\-%]+\.swf\?([^\"'\s<>]+)/i);
            if (sm != null)
            {
                for each (var pair2:String in String(sm[1]).split("&"))
                {
                    var j2:int = pair2.indexOf("=");
                    if (j2 > 0)
                    {
                        var pk2:String = pair2.substring(0, j2).toLowerCase();
                        if (pk2 == "user" || pk2 == "key" || pk2 == "p2" || pk2 == "rid")
                            params[pk2] = pair2.substring(j2 + 1);
                    }
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8)
                return false;
            finishWith(host, params, swf);
            return true;
        }

        private function finishWith(site:String, params:Object, swfPath:String):void
        {
            if (done) return;
            // so fecha se TEM user e key de verdade
            if (params == null || params["user"] == undefined || params["key"] == undefined) return;
            if (String(params["key"]).length < 4) return;

            done = true;
            try { if (scanTimer != null) scanTimer.stop(); } catch (e0:Error) {}

            var o:Object = {};
            for each (var k:String in KEYS)
                if (params[k] != undefined) o[k] = params[k];
            o["site"] = site;
            o["host"] = site;
            if (swfPath != null && swfPath.length > 0)
            {
                if (swfPath.indexOf("http") == 0)
                {
                    var m:Array = swfPath.match(/^[a-zA-Z]+:\/\/([^\/]+)(\/.*)$/);
                    if (m != null)
                    {
                        o["site"] = String(m[1]);
                        o["host"] = String(m[1]);
                        swfPath = String(m[2]);
                    }
                }
                // limpa query do path swf se veio completa
                var qpos:int = swfPath.indexOf("?");
                if (qpos > 0) swfPath = swfPath.substring(0, qpos);
                o["swf"] = swfPath;
            }
            if (o["swf"] == undefined) o["swf"] = "/client/Loading.swf";

            statusTf.text = "Sessao capturada! Abrindo o jogo no AIR...";
            var json:String = JSON.stringify(o);
            try
            {
                if (html != null && html.parent != null) html.parent.removeChild(html);
            }
            catch (e1:Error) {}
            try { if (win != null) win.close(); } catch (e2:Error) {}
            if (onSession != null) onSession(json);
        }

        private function onWinClose(e:Event):void
        {
            try { if (scanTimer != null) scanTimer.stop(); } catch (e0:Error) {}
            if (!done && onClosed != null) onClosed();
        }
    }
}
