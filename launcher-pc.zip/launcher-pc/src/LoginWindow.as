package
{
    import flash.desktop.Clipboard;
    import flash.desktop.ClipboardFormats;
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.Screen;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.LocationChangeEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.html.HTMLLoader;
    import flash.media.StageWebView;
    import flash.net.URLRequest;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Login 64-bit no launcher (modelo hibrido, estilo celular):
    // 1) StageWebView (Edge) — voce faz login no site (cliques funcionam).
    // 2) Botao "Entrar servidor" — NAO tenta Flash no WebView.
    // 3) Exporta cookies do WebView e carrega /serverlist/sXXXX num HTMLLoader oculto.
    // 4) HTMLLoader intercepta Loading.swf?user=&key= e o HTML com flashvars.
    // 5) Fecha o login e o jogo abre no AIR (nao no navegador).
    public class LoginWindow
    {
        private static const UA:String = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        private static const BAR:int = 88;
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];

        public var onSession:Function;
        public var onClosed:Function;

        private var host:String;
        private var win:NativeWindow;
        private var web:StageWebView;
        private var html:HTMLLoader;
        private var bar:Sprite;
        private var statusTf:TextField;
        private var serverInput:TextField;
        private var done:Boolean = false;
        private var seenSwf:String = null;
        private var savedCookies:String = "";
        private var extracting:Boolean = false;
        private var scanTimer:Timer;
        private var htmlScanTimer:Timer;
        private var notes:Array = [];
        private var pendingServer:String = "";

        public function LoginWindow(host:String)
        {
            this.host = host;
        }

        public function focus():void
        {
            try { if (win != null) win.activate(); } catch (e:Error) {}
        }

        public function open():void
        {
            var o:NativeWindowInitOptions = new NativeWindowInitOptions();
            win = new NativeWindow(o);
            win.title = "Login - " + host;
            win.stage.scaleMode = StageScaleMode.NO_SCALE;
            win.stage.align = StageAlign.TOP_LEFT;
            var b:Rectangle = Screen.mainScreen.visibleBounds;
            win.width = Math.min(1100, b.width - 40);
            win.height = Math.min(800, b.height - 40);
            win.x = b.x + (b.width - win.width) / 2;
            win.y = b.y + (b.height - win.height) / 2;

            // HTMLLoader oculto: so para capturar sessao apos cookies
            html = new HTMLLoader();
            html.userAgent = UA;
            html.width = 16;
            html.height = 16;
            html.x = -200;
            html.y = -200;
            html.alpha = 0;
            html.addEventListener(Event.LOCATION_CHANGE, onHtmlLoc);
            html.addEventListener(Event.COMPLETE, onHtmlComplete);
            html.addEventListener(ErrorEvent.ERROR, function(e:Event):void { note("htmlErr"); });
            html.addEventListener(IOErrorEvent.IO_ERROR, function(e:Event):void { note("htmlIO"); });
            win.stage.addChild(html);

            buildBar();
            win.stage.addEventListener(Event.RESIZE, onResize);
            win.addEventListener(Event.CLOSE, onWinClose);
            win.activate();

            if (!StageWebView.isSupported)
            {
                statusTf.text = "Instale o WebView2 Runtime (Microsoft) para o login.";
                layout();
                return;
            }

            web = new StageWebView();
            web.stage = win.stage;
            web.addEventListener(LocationChangeEvent.LOCATION_CHANGING, onWebChanging);
            web.addEventListener(LocationChangeEvent.LOCATION_CHANGE, onWebLoc);
            web.addEventListener(Event.COMPLETE, onWebComplete);
            web.addEventListener(ErrorEvent.ERROR, onWebErr);
            layout();
            web.loadURL("https://" + host + "/");
            statusTf.text = "1) Faca login no site acima  2) Digite o servidor (ex. 1065)  3) Entrar servidor";
        }

        private function buildBar():void
        {
            bar = new Sprite();
            win.stage.addChild(bar);

            statusTf = new TextField();
            statusTf.defaultTextFormat = new TextFormat("_sans", 12, 0xC9C4EE, false);
            statusTf.mouseEnabled = false;
            statusTf.wordWrap = true;
            statusTf.multiline = true;
            statusTf.x = 12; statusTf.y = 4;
            statusTf.height = 36;
            bar.addChild(statusTf);

            var lab:TextField = new TextField();
            lab.defaultTextFormat = new TextFormat("_sans", 12, 0xFFFFFF, true);
            lab.mouseEnabled = false;
            lab.text = "Servidor:";
            lab.width = 70; lab.height = 24;
            lab.x = 12; lab.y = 46;
            bar.addChild(lab);

            serverInput = new TextField();
            serverInput.type = TextFieldType.INPUT;
            serverInput.border = true;
            serverInput.borderColor = 0x3B3A78;
            serverInput.background = true;
            serverInput.backgroundColor = 0x0E0D26;
            serverInput.defaultTextFormat = new TextFormat("_sans", 14, 0xFFFFFF);
            serverInput.text = "1065";
            serverInput.width = 100;
            serverInput.height = 26;
            serverInput.x = 80; serverInput.y = 44;
            bar.addChild(serverInput);

            var goBtn:Btn = new Btn(Btn.PRIMARY, 160, 32, "Entrar servidor", "", function(e:MouseEvent):void {
                beginServerEnter();
            });
            goBtn.x = 200 + 80; goBtn.y = 56;
            bar.addChild(goBtn);

            var homeBtn:Btn = new Btn(Btn.GHOST, 100, 32, "Inicio", "", function(e:MouseEvent):void {
                if (web != null) web.loadURL("https://" + host + "/");
                statusTf.text = "Inicio do site.";
            });
            homeBtn.x = 380 + 50; homeBtn.y = 56;
            bar.addChild(homeBtn);
        }

        private function onResize(e:Event):void { layout(); }

        private function layout():void
        {
            if (win == null || win.stage == null) return;
            var w:Number = win.stage.stageWidth;
            var h:Number = win.stage.stageHeight;
            if (w <= 0 || h <= 0) return;
            bar.y = h - BAR;
            bar.graphics.clear();
            bar.graphics.beginFill(0x12112E, 1);
            bar.graphics.drawRect(0, 0, w, BAR);
            bar.graphics.endFill();
            statusTf.width = w - 24;
            if (web != null)
                web.viewPort = new Rectangle(0, 0, w, Math.max(50, h - BAR));
        }

        // ---- botao Entrar servidor: cookies do WebView + HTMLLoader no serverlist ----
        private function beginServerEnter():void
        {
            if (done) return;
            var raw:String = serverInput != null ? serverInput.text.replace(/^\s+|\s+$/g, "") : "";
            raw = raw.replace(/^s/i, "").replace(/^OAS/i, "");
            if (raw.length < 2)
            {
                statusTf.text = "Digite o numero do servidor (ex. 1065).";
                return;
            }
            pendingServer = raw;
            statusTf.text = "Capturando sessao do site e entrando no servidor " + raw + "...";
            exportCookiesThenLoadServer();
        }

        private function exportCookiesThenLoadServer():void
        {
            if (web == null)
            {
                loadServerInHtmlLoader("");
                return;
            }
            if (extracting) return;
            extracting = true;
            try
            {
                // Exporta document.cookie via navegacao controlada
                var js:String = "javascript:try{window.location='https://"
                    + host + "/__legend_cookies__?c='+encodeURIComponent(document.cookie||'');}catch(e){window.location='https://"
                    + host + "/__legend_cookies__?c=';}";
                web.loadURL(js);
            }
            catch (e:Error)
            {
                extracting = false;
                loadServerInHtmlLoader("");
            }
            try
            {
                var t:Timer = new Timer(3000, 1);
                t.addEventListener(TimerEvent.TIMER, function(ev:TimerEvent):void {
                    if (extracting)
                    {
                        extracting = false;
                        loadServerInHtmlLoader(savedCookies);
                    }
                });
                t.start();
            }
            catch (e2:Error) {}
        }

        private function onWebChanging(e:LocationChangeEvent):void
        {
            var u:String = e.location;
            note(u);
            if (u != null && u.indexOf("__legend_cookies__") >= 0)
            {
                try { e.preventDefault(); } catch (e0:Error) {}
                handleCookieExport(u);
                return;
            }
            if (u != null && (u.toLowerCase().indexOf(".swf") >= 0 || (u.indexOf("user=") >= 0 && u.indexOf("key=") >= 0)))
            {
                try { e.preventDefault(); } catch (e1:Error) {}
                if (check(u)) return;
            }
            if (check(u))
            {
                try { e.preventDefault(); } catch (e2:Error) {}
            }
        }

        private function onWebLoc(e:LocationChangeEvent):void
        {
            var u:String = e.location;
            note(u);
            if (u != null && u.indexOf("__legend_cookies__") >= 0)
            {
                handleCookieExport(u);
                return;
            }
            check(u);
        }

        private function handleCookieExport(u:String):void
        {
            extracting = false;
            try
            {
                var qi:int = u.indexOf("c=");
                if (qi >= 0)
                {
                    var rest:String = u.substring(qi + 2);
                    var amp:int = rest.indexOf("&");
                    if (amp >= 0) rest = rest.substring(0, amp);
                    savedCookies = dec(rest);
                }
            }
            catch (e:Error) {}
            note("cookies-len=" + (savedCookies != null ? savedCookies.length : 0));
            loadServerInHtmlLoader(savedCookies);
        }

        private function loadServerInHtmlLoader(cookies:String):void
        {
            if (done || html == null) return;
            var sid:String = pendingServer != "" ? pendingServer : "1065";
            statusTf.text = "Carregando servidor s" + sid + " no motor de captura (sem Flash)...";

            // 1) abre o host para poder setar cookies no dominio
            html.addEventListener(Event.COMPLETE, onCookieSeedComplete, false, 0, true);
            try { html.load(new URLRequest("https://" + host + "/")); }
            catch (e:Error)
            {
                statusTf.text = "Falha ao preparar captura: " + e.message;
            }
        }

        private function onCookieSeedComplete(e:Event):void
        {
            html.removeEventListener(Event.COMPLETE, onCookieSeedComplete);
            try
            {
                if (savedCookies != null && savedCookies.length > 0)
                {
                    // aplica cookies no HTMLLoader (mesmo dominio)
                    var parts:Array = savedCookies.split(";");
                    for each (var part:String in parts)
                    {
                        var p:String = part.replace(/^\s+|\s+$/g, "");
                        if (p.length > 2)
                        {
                            try { html.window.document.cookie = p + "; path=/"; } catch (e0:Error) {}
                        }
                    }
                    note("cookies-applied");
                }
            }
            catch (e1:Error) { note("cookieSet:" + e1.message); }

            var sid:String = pendingServer != "" ? pendingServer : "1065";
            var url:String = "https://" + host + "/serverlist/s" + sid;
            try { html.load(new URLRequest(url)); }
            catch (e2:Error) { statusTf.text = "Falha serverlist: " + e2.message; }

            if (htmlScanTimer != null) htmlScanTimer.stop();
            htmlScanTimer = new Timer(800);
            htmlScanTimer.addEventListener(TimerEvent.TIMER, onHtmlScanTick);
            htmlScanTimer.start();
        }

        private function onHtmlLoc(e:Event):void
        {
            if (html == null) return;
            var u:String = html.location;
            note("html:" + u);
            check(u);
        }

        private function onHtmlComplete(e:Event):void
        {
            if (done) return;
            scanHtml(collectHtml());
            check(html != null ? html.location : "");
        }

        private function onHtmlScanTick(e:TimerEvent):void
        {
            if (done) { htmlScanTimer.stop(); return; }
            scanHtml(collectHtml());
            try { check(html.location); } catch (e1:Error) {}
        }

        private function collectHtml():String
        {
            if (html == null) return "";
            try { return String(html.window.document.documentElement.outerHTML); }
            catch (e:Error) {}
            return "";
        }

        private function onWebComplete(e:Event):void
        {
            try { if (web != null) check(web.location); } catch (e1:Error) {}
        }

        private function onWebErr(e:ErrorEvent):void
        {
            statusTf.text = "WebView: " + e.text;
        }

        private function pathOf(url:String):String
        {
            if (url == null) return "";
            return url.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function isAsset(lp:String):Boolean
        {
            for each (var ext:String in [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".svg"])
                if (lp.length >= ext.length && lp.lastIndexOf(ext) == lp.length - ext.length) return true;
            return false;
        }

        private function note(url:String):void
        {
            if (url == null) return;
            notes.push(url);
            if (notes.length > 60) notes.shift();
            var p:String = pathOf(url).toLowerCase();
            if (p.indexOf("loading") >= 0 && p.indexOf(".swf") >= 0)
            {
                var qi:int = url.indexOf("?");
                seenSwf = qi >= 0 ? pathOf(url) + url.substring(qi) : pathOf(url);
            }
        }

        private function check(url:String):Boolean
        {
            if (done || url == null || url.length < 8) return false;
            if (url.indexOf("__legend_") >= 0) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            var site:String = m != null ? String(m[1]) : host;
            if (lp.indexOf(".swf") >= 0)
                seenSwf = pathOf(url) + (qi >= 0 ? url.substring(qi) : "");
            finishWith(site, params, seenSwf);
            return true;
        }

        private function plausible(v:String):Boolean
        {
            if (v == null) return false;
            var l:String = v.toLowerCase();
            return !(l == "function" || l == "null" || l == "undefined" || l == "true" || l == "false"
                || l == "this" || l == "document" || l == "window" || l == "var");
        }

        private function scanHtml(t:String):Boolean
        {
            if (done || t == null || t.length < 20) return false;
            var swf:String = seenSwf;
            var m:Array = t.match(/([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/i);
            if (m != null) swf = String(m[1]);
            else
            {
                m = t.match(/([\w.\/:\-%]+\.swf)/i);
                if (m != null) swf = String(m[1]);
            }
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
                    mm = re.exec(t);
                }
            }
            // flashvars=user=...&key=...
            var fv:Array = t.match(/flashvars[\s\"'=]+([^\"'<]+)/i);
            if (fv != null)
            {
                for each (var pair:String in String(fv[1]).split("&"))
                {
                    var j:int = pair.indexOf("=");
                    if (j > 0)
                    {
                        var pk:String = pair.substring(0, j).toLowerCase();
                        if (pk == "user" || pk == "key" || pk == "p2" || pk == "rid")
                            params[pk] = pair.substring(j + 1);
                    }
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8)
                return false;
            finishWith(host, params, swf);
            return true;
        }

        private function finishWith(site:String, params:Object, swfPath:String):void
        {
            if (done) return;
            done = true;
            try { if (htmlScanTimer != null) htmlScanTimer.stop(); } catch (e0:Error) {}
            try { if (scanTimer != null) scanTimer.stop(); } catch (e1:Error) {}

            var o:Object = {};
            for each (var k:String in KEYS)
                if (params[k] != undefined) o[k] = params[k];
            o["site"] = site;
            o["host"] = site;
            // se o host do jogo for o server (s1065oas...), preferir isso
            if (site != null && site.indexOf("oas") >= 0) { o["host"] = site; o["site"] = site; }

            if (swfPath != null && swfPath.length > 0)
            {
                if (swfPath.indexOf("http") == 0)
                {
                    var m:Array = swfPath.match(/^[a-zA-Z]+:\/\/([^\/]+)(\/.*)$/);
                    if (m != null)
                    {
                        o["site"] = String(m[1]);
                        o["host"] = String(m[1]);
                        swfPath = String(m[2]);
                    }
                }
                o["swf"] = swfPath;
            }
            // fallback swf padrao do client
            if (o["swf"] == undefined)
                o["swf"] = "/client/Loading.swf";

            statusTf.text = "Sessao OK! Abrindo o jogo no launcher...";
            var json:String = JSON.stringify(o);
            disposeAll();
            try { if (win != null) win.close(); } catch (e2:Error) {}
            if (onSession != null) onSession(json);
        }

        private function disposeAll():void
        {
            try
            {
                if (web != null)
                {
                    web.stage = null;
                    web.dispose();
                    web = null;
                }
            }
            catch (e:Error) {}
            try
            {
                if (html != null)
                {
                    if (html.parent) html.parent.removeChild(html);
                    html = null;
                }
            }
            catch (e2:Error) {}
        }

        private function onWinClose(e:Event):void
        {
            try { if (htmlScanTimer != null) htmlScanTimer.stop(); } catch (e0:Error) {}
            disposeAll();
            if (!done && onClosed != null) onClosed();
        }
    }
}
