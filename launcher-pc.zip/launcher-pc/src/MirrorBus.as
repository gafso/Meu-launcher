package
{
    // Coordena espelho entre janelas (até 4).
    // - Líder: a janela onde você joga / inicia macros
    // - Seguidores: outras janelas logadas que recebem cliques e/ou macros
    // Clique é experimental (o jogo pode ignorar eventos sintéticos).
    // Macro é o caminho sólido (mesma ação nas outras contas).
    public class MirrorBus
    {
        public static var leaderSlot:int = 0;     // windowSlot do líder (0 = ninguém)
        public static var mirrorClicks:Boolean = true;
        public static var mirrorMacros:Boolean = true;
        public static var logger:Function;

        private static function say(m:String):void
        {
            if (logger != null) try { logger(m); } catch (e:Error) {}
        }

        public static function setLeader(slot:int):void
        {
            leaderSlot = slot;
            say("ESPELHO: líder = janela " + slot + " | cliques " + (mirrorClicks ? "ON" : "off") + " | macros " + (mirrorMacros ? "ON" : "off"));
        }

        public static function clearLeader():void
        {
            leaderSlot = 0;
            say("ESPELHO: sem líder");
        }

        public static function isLeaderSlot(slot:int):Boolean
        {
            return leaderSlot > 0 && leaderSlot == slot;
        }

        // Clique no líder → outras janelas (em jogo) recebem o mesmo ponto (escala por tamanho do palco).
        public static function broadcastClick(fromSlot:int, type:String, stageX:Number, stageY:Number, fromW:Number, fromH:Number):void
        {
            if (!mirrorClicks || !isLeaderSlot(fromSlot)) return;
            if (type != "mouseDown" && type != "mouseUp" && type != "click") return;
            var list:Array = Main.mirrorTargets(fromSlot);
            if (list.length == 0) return;
            say("ESPELHO clique " + type + " (" + int(stageX) + "," + int(stageY) + ") → " + list.length + " janela(s)");
            for each (var m:Main in list)
            {
                try { m.injectMirrorClick(type, stageX, stageY, fromW, fromH); } catch (e:Error) {}
            }
        }

        // Macro no líder → seguidores disparam a mesma ação.
        public static function broadcastMacro(fromSlot:int, action:String):void
        {
            if (!mirrorMacros || !isLeaderSlot(fromSlot)) return;
            var list:Array = Main.mirrorTargets(fromSlot);
            if (list.length == 0)
            {
                say("ESPELHO macro '" + action + "': nenhuma outra janela em jogo");
                return;
            }
            say("ESPELHO macro '" + action + "' → " + list.length + " janela(s)");
            for each (var m:Main in list)
            {
                try { m.injectMirrorMacro(action); } catch (e:Error) {}
            }
        }
    }
}
