package
{
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.system.ApplicationDomain;
    import flash.utils.describeType;

    // Lista as classes do jogo ligadas a Planos / Transmissor, direto da memória do jogo rodando.
    // SÓ LÊ: mostra nomes de classes, métodos e constantes (não o código). Serve para descobrir quais classes
    // existem e em qual arquivo baixar. Abra o Transmissor no jogo ANTES de rodar (o jogo cria as classes ao abrir).
    public class ClassDump
    {
        private static const NAME_RE:RegExp = /plane|transf|transmi|portal|crisis|energ|strength|fortal/i;
        private static const DEEP_RE:RegExp = /transf|transmi|planes(list|bag|item|invade|resource|frame|main|energy|view)|plane.*(frame|list|view|bag)/i;
        private static const MAX_DEEP:int = 30;
        private static const MAX_MEMBERS:int = 90;

        private static function domains():Array
        {
            var out:Array = [];
            var cand:Array = [SwfFixer.gameDomain, ApplicationDomain.currentDomain];
            var i:int;
            for (i = 0; i < SwfFixer.moduleDomains.length; i++) cand.push(SwfFixer.moduleDomains[i]);
            for (i = 0; i < cand.length; i++)
                if (cand[i] != null && out.indexOf(cand[i]) < 0) out.push(cand[i]);
            return out;
        }

        // Devolve o texto do relatório; se dir não for vazio, também grava dir/classes_planes.txt.
        public static function run(dir:String):String
        {
            var L:Array = [];
            var names:Object = {};
            var doms:Array = domains();
            var total:int = 0;
            var i:int;
            var j:int;
            var d:ApplicationDomain;
            var list:Object;
            var n:String;
            L.push("CLASSES DO JOGO (somente leitura) - domínios: " + doms.length);
            for (i = 0; i < doms.length; i++)
            {
                d = doms[i];
                try { list = d.getQualifiedDefinitionNames(); }
                catch (e:Error) { L.push("domínio " + i + ": não deu para listar (" + e.message + ")"); continue; }
                total += list.length;
                for (j = 0; j < list.length; j++)
                {
                    n = String(list[j]).replace("::", ".");
                    if (n.indexOf("asset.") == 0 || n.indexOf("_fla.") > 0) continue;
                    if (NAME_RE.test(n)) names[n] = i;
                }
            }
            L.push("definições vistas: " + total);

            var sorted:Array = [];
            for (n in names) sorted.push(n);
            sorted.sort();
            L.push("");
            L.push("== CLASSES COM planes/transfer/portal/crisis/energy no nome (" + sorted.length + ") ==");
            for (i = 0; i < sorted.length; i++) L.push(sorted[i]);

            L.push("");
            L.push("== DETALHE (métodos / variáveis / constantes) ==");
            var deepN:int = 0;
            for (i = 0; i < sorted.length && deepN < MAX_DEEP; i++)
            {
                n = sorted[i];
                if (!DEEP_RE.test(n)) continue;
                deepN++;
                L.push("");
                L.push("# " + n);
                try { L.push(describe(n, doms)); }
                catch (e2:Error) { L.push("  erro ao descrever: " + e2.message); }
            }
            if (deepN == 0) L.push("(nenhuma classe de Transmissor encontrada: abra o Transmissor/Bolsa do Plano no jogo e rode de novo)");

            var txt:String = L.join("\n");
            if (dir != null && dir.length > 0)
            {
                try
                {
                    var f:File = new File(dir).resolvePath("classes_planes.txt");
                    var fs:FileStream = new FileStream();
                    fs.open(f, FileMode.WRITE);
                    fs.writeUTFBytes(txt);
                    fs.close();
                    txt += "\n\n(salvo em " + f.nativePath + ")";
                }
                catch (e3:Error) { txt += "\n\n(não consegui salvar o arquivo: " + e3.message + ")"; }
            }
            return txt;
        }

        private static function describe(name:String, doms:Array):String
        {
            var c:Object = null;
            var i:int;
            for (i = 0; i < doms.length && c == null; i++)
                if (doms[i].hasDefinition(name)) c = doms[i].getDefinition(name);
            if (c == null) return "  (definição não encontrada)";
            var x:XML = describeType(c);
            var out:Array = [];
            var m:XML;
            var p:XML;
            var ps:Array;
            var cnt:int = 0;
            var ec:XMLList = x.factory.extendsClass;
            out.push("  extends " + (ec.length() > 0 ? String(ec[0].@type) : "?"));
            for each (m in x.constant)
            {
                if (cnt++ >= MAX_MEMBERS) break;
                var v:String = "";
                try { v = " = " + String(c[String(m.@name)]); } catch (e:Error) {}
                out.push("  static const " + m.@name + ":" + m.@type + v);
            }
            for each (m in x.method)
            {
                if (cnt++ >= MAX_MEMBERS) break;
                out.push("  static " + m.@name + "()");
            }
            for each (m in x.factory.method)
            {
                if (cnt++ >= MAX_MEMBERS) break;
                ps = [];
                for each (p in m.parameter) ps.push(String(p.@type));
                out.push("  " + m.@name + "(" + ps.join(",") + "):" + m.@returnType);
            }
            for each (m in x.factory.accessor)
            {
                if (cnt++ >= MAX_MEMBERS) break;
                out.push("  get/set " + m.@name + ":" + m.@type);
            }
            for each (m in x.factory.variable)
            {
                if (cnt++ >= MAX_MEMBERS) break;
                out.push("  var " + m.@name + ":" + m.@type);
            }
            if (cnt >= MAX_MEMBERS) out.push("  ... (cortado em " + MAX_MEMBERS + " itens)");
            return out.join("\n");
        }
    }
}
