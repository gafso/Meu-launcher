package
{
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;

    // Lista de contas salvas no PC (accounts.json). Cada conta tem a sua própria "pasta" de login no
    // Chromium (cookies separados), então dá para alternar sem digitar a senha de novo.
    public class Accounts
    {
        private static var items:Array = [];     // [{id, name}]
        private static var lastId:String = "";
        private static var loaded:Boolean = false;

        // Lista compartilhada entre todas as instâncias do app (cada instância tem a sua pasta de dados).
        private static function file():File
        {
            try
            {
                var d:File = File.userDirectory.resolvePath("AppData/Local/LegendPC");
                if (!d.exists) d.createDirectory();
                return d.resolvePath("accounts.json");
            }
            catch (e:Error) {}
            return File.applicationStorageDirectory.resolvePath("accounts.json");
        }

        public static function load():void
        {
            loaded = true;
            items = []; lastId = "";
            try
            {
                var f:File = file();
                if (!f.exists) f = File.applicationStorageDirectory.resolvePath("accounts.json");   // lista antiga (versões anteriores)
                if (!f.exists) return;
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.READ);
                var t:String = fs.readUTFBytes(fs.bytesAvailable);
                fs.close();
                var o:Object = JSON.parse(t);
                if (o.items is Array) items = o.items as Array;
                if (o.last != undefined) lastId = String(o.last);
            }
            catch (e:Error) {}
        }

        public static function save():void
        {
            try
            {
                var fs:FileStream = new FileStream();
                fs.open(file(), FileMode.WRITE);
                fs.writeUTFBytes(JSON.stringify({items: items, last: lastId}));
                fs.close();
            }
            catch (e:Error) {}
        }

        public static function all():Array { if (!loaded) load(); return items; }
        public static function get last():String { if (!loaded) load(); return lastId; }
        public static function set last(v:String):void { if (!loaded) load(); lastId = v; save(); }

        public static function find(id:String):Object
        {
            for each (var a:Object in all()) if (String(a.id) == id) return a;
            return null;
        }

        public static function upsert(id:String, name:String):void
        {
            var a:Object = find(id);
            if (a == null) { a = {id: id, name: name}; items.push(a); }
            else a.name = name;
            lastId = id;
            save();
        }

        public static function remove(id:String):void
        {
            var out:Array = [];
            for each (var a:Object in all()) if (String(a.id) != id) out.push(a);
            items = out;
            if (lastId == id) lastId = out.length > 0 ? String(out[0].id) : "";
            save();
        }

        // A primeira conta usa "legend" (compatível com o login antigo); as outras ganham um id novo.
        public static function newId():String
        {
            if (all().length == 0) return "legend";
            return "a" + new Date().getTime().toString(36);
        }
    }
}
