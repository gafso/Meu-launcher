package
{
    import flash.net.SharedObject;

    // Contas no PC: id local + nome + sessão JSON opcional (login rápido).
    public class Accounts
    {
        private static var so:SharedObject = SharedObject.getLocal("meulauncher_accounts_pc");

        private static function list():Array
        {
            if (so.data.list == undefined || !(so.data.list is Array)) so.data.list = [];
            return so.data.list as Array;
        }

        public static function all():Array
        {
            return list().concat();
        }

        public static function newId():String
        {
            return "a" + new Date().time + "_" + int(Math.random() * 1e6);
        }

        public static function upsert(id:String, name:String, sessionJson:String = ""):void
        {
            if (id == null || id == "") id = newId();
            var L:Array = list();
            var found:Boolean = false;
            for (var i:int = 0; i < L.length; i++)
            {
                if (String(L[i].id) == id)
                {
                    L[i].name = name != null && name != "" ? name : L[i].name;
                    if (sessionJson != null && sessionJson != "") L[i].session = sessionJson;
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                var o:Object = { id: id, name: (name != null && name != "" ? name : "Conta"), session: sessionJson != null ? sessionJson : "" };
                L.push(o);
            }
            so.data.list = L;
            so.flush();
        }

        public static function saveSession(id:String, sessionJson:String):void
        {
            if (id == null || id == "") return;
            var L:Array = list();
            for (var i:int = 0; i < L.length; i++)
            {
                if (String(L[i].id) == id)
                {
                    L[i].session = sessionJson;
                    so.data.list = L;
                    so.flush();
                    return;
                }
            }
            upsert(id, "Conta", sessionJson);
        }

        public static function getSession(id:String):String
        {
            var L:Array = list();
            for (var i:int = 0; i < L.length; i++)
                if (String(L[i].id) == id) return L[i].session != undefined ? String(L[i].session) : "";
            return "";
        }

        public static function remove(id:String):void
        {
            var L:Array = list();
            var out:Array = [];
            for (var i:int = 0; i < L.length; i++)
                if (String(L[i].id) != id) out.push(L[i]);
            so.data.list = out;
            so.flush();
        }

        public static function find(id:String):Object
        {
            var L:Array = list();
            for (var i:int = 0; i < L.length; i++)
                if (String(L[i].id) == id) return L[i];
            return null;
        }
    }
}
