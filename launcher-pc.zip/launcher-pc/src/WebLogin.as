package
{
    import flash.display.Stage;
    import flash.events.ErrorEvent;
    import flash.events.Event;
    import flash.events.LocationChangeEvent;
    import flash.events.TimerEvent;
    import flash.geom.Rectangle;
    import flash.media.StageWebView;
    import flash.utils.Timer;

    // Login dentro da própria janela do app: StageWebView (no Windows usa o Microsoft Edge WebView2, um
    // Chromium atual — precisa de <UseWebView2> no app.xml). Você entra normalmente; o launcher captura
    // user/key e o caminho do Loading.swf pela URL e, quando o WebView2 deixa, pelo HTML da página.
    // Nenhuma senha é lida nem guardada.
    public class WebLogin
    {
        private static const KEYS:Array = ["user", "key", "site", "p2", "rid", "logintype"];
        private static const RE_SWF_LOADING:RegExp = /([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/;
        private static const RE_SWF_ANY:RegExp = /([\w.\/:\-%]+\.swf)/;
        private static const ASSET_EXT:Array = [".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".woff2", ".svg", ".webp"];
        // Roda dentro da página: manda a URL e o HTML (com iframes) de volta para o app.
        private static const JS:String = "(function(){try{var t=document.documentElement.outerHTML;var f=document.querySelectorAll('iframe');for(var i=0;i<f.length;i++){try{t+=f[i].contentDocument.documentElement.outerHTML}catch(e){}}window.chrome.webview.postMessage(JSON.stringify({u:location.href,h:t.substring(0,400000)}))}catch(e){}})();";

        public var onSession:Function;   // (json:String)
        public var onFail:Function;      // (motivo:String) -> o app cai para o Chromium em janela
        public var log:Function;

        private var web:StageWebView;
        private var st:Stage;
        private var host:String;
        private var vp:Rectangle;
        private var done:Boolean = false;
        private var scans:int = 0;
        private var seenSwf:String = null;
        private var injectOff:Boolean = false;
        private var injected:Boolean = false;
        private var timer:Timer;

        public static function get supported():Boolean
        {
            try { return StageWebView.isSupported; } catch (e:Error) {}
            return false;
        }

        public function get active():Boolean { return web != null && !done; }

        private function say(s:String):void { if (log != null) log("[login] " + s); }

        public function open(stage:Stage, host:String, viewPort:Rectangle):void
        {
            this.st = stage;
            this.host = host;
            this.vp = viewPort;
            try
            {
                web = new StageWebView(true);
                web.stage = stage;
                web.viewPort = viewPort;
                web.addEventListener(LocationChangeEvent.LOCATION_CHANGING, onLoc);
                web.addEventListener(LocationChangeEvent.LOCATION_CHANGE, onLoc);
                web.addEventListener(Event.COMPLETE, onComplete);
                web.addEventListener(ErrorEvent.ERROR, onErr);
                web.addEventListener("webViewMessage", onMsg);
                web.loadURL("https://" + host + "/");
                say("aberto em " + viewPort);
            }
            catch (e:Error)
            {
                say("falhou ao abrir: " + e.message);
                var cb:Function = onFail;
                web = null;
                if (cb != null) cb(e.message);
            }
        }

        public function setViewPort(r:Rectangle):void
        {
            vp = r;
            try { if (web != null && web.stage != null) web.viewPort = r; } catch (e:Error) {}
        }

        // Some enquanto um painel do app está aberto (a janela nativa ficaria por cima dele).
        public function suspend(v:Boolean):void
        {
            if (web == null || done) return;
            try
            {
                if (v) web.stage = null;
                else { web.stage = st; web.viewPort = vp; }
            }
            catch (e:Error) {}
        }

        public function close():void
        {
            done = true;
            try { if (timer != null) timer.stop(); } catch (e0:Error) {}
            if (web == null) return;
            try { web.removeEventListener("webViewMessage", onMsg); } catch (e1:Error) {}
            try { web.stage = null; } catch (e2:Error) {}
            try { web.dispose(); } catch (e3:Error) {}
            web = null;
        }

        // ---------- eventos ----------
        private function onLoc(e:LocationChangeEvent):void
        {
            var u:String = e.location;
            if (u == null) return;
            if (injected && (u.indexOf("javascript:") == 0 || u == "about:blank"))
            {
                injectOff = true;   // este controle trata javascript: como navegação: não insistir
                say("injeção de script desligada (" + u.substring(0, 20) + ")");
                if (web != null) { try { web.historyBack(); } catch (e1:Error) {} }
                return;
            }
            note(u);
            check(u);
        }

        private function onComplete(e:Event):void
        {
            if (done) return;
            scans++;
            if (injectOff) return;
            if (timer == null)
            {
                timer = new Timer(1300, 1);
                timer.addEventListener(TimerEvent.TIMER_COMPLETE, function(ev:TimerEvent):void { inject(); });
            }
            timer.reset();
            timer.start();
        }

        private function inject():void
        {
            if (done || injectOff || web == null) return;
            try
            {
                injected = true;
                web.loadURL("javascript:" + encodeURIComponent(JS));
            }
            catch (e:Error) { injectOff = true; say("injeção: " + e.message); }
        }

        private function onErr(e:ErrorEvent):void { say("erro de carga: " + e.text); }

        private function payload(e:Event):String
        {
            for each (var k:String in ["data", "message", "body", "text", "value"])
            {
                try
                {
                    var v:* = e[k];
                    if (v != undefined && v != null) return String(v);
                }
                catch (x:Error) {}
            }
            return String(e);
        }

        private function onMsg(e:Event):void
        {
            if (done) return;
            try
            {
                var raw:String = payload(e);
                var o:Object = JSON.parse(raw);
                var u:String = String(o.u);
                var h:String = String(o.h);
                note(u);
                if (check(u)) return;
                var urls:Array = h.match(/https?:\/\/[^\s"'<>]+/g);
                if (urls != null)
                {
                    for each (var x:String in urls) note(x.replace(/&amp;/g, "&"));
                    for each (var y:String in urls) { if (check(y.replace(/&amp;/g, "&"))) return; }
                }
                scanHtml(h, false);
            }
            catch (err:Error) { say("mensagem inválida: " + err.message); }
        }

        // ---------- captura (mesma lógica do navegador antigo) ----------
        private function isAsset(lowerPath:String):Boolean
        {
            for each (var ext:String in ASSET_EXT)
                if (lowerPath.length >= ext.length && lowerPath.lastIndexOf(ext) == lowerPath.length - ext.length) return true;
            return false;
        }

        private function dec(s:String):String
        {
            try { return decodeURIComponent(s.replace(/\+/g, " ")); } catch (e:Error) {}
            return s;
        }

        private function pathOf(url:String):String
        {
            var qi:int = url.indexOf("?");
            var p:String = qi >= 0 ? url.substring(0, qi) : url;
            return p.replace(/^[a-zA-Z]+:\/\/[^\/]*/, "");
        }

        private function note(url:String):void
        {
            if (url == null) return;
            var p:String = pathOf(url).toLowerCase();
            if (p.indexOf("loading") >= 0 && p.lastIndexOf(".swf") == p.length - 4)
            {
                var qi:int = url.indexOf("?");
                var raw:String = pathOf(url);
                seenSwf = qi >= 0 ? raw + url.substring(qi) : raw;
            }
        }

        private function check(url:String):Boolean
        {
            if (done || url == null) return false;
            var qi:int = url.indexOf("?");
            if (qi < 0) return false;
            var hi:int = url.indexOf("#", qi);
            var q:String = url.substring(qi + 1, hi >= 0 ? hi : url.length);
            var lp:String = pathOf(url).toLowerCase();
            if (q.indexOf("user=") < 0 || q.indexOf("key=") < 0 || isAsset(lp)) return false;
            var params:Object = {};
            for each (var kv:String in q.split("&"))
            {
                var i:int = kv.indexOf("=");
                if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
            }
            if (params["key"] == undefined || String(params["key"]).length < 4) return false;
            var m:Array = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
            finishWith(m != null ? String(m[1]) : host, params, seenSwf);
            return true;
        }

        private function plausible(v:String):Boolean
        {
            if (v == null) return false;
            var l:String = v.toLowerCase();
            return !(l == "function" || l == "null" || l == "undefined" || l == "true" || l == "false"
                || l == "this" || l == "document" || l == "window" || l == "var");
        }

        private function scanHtml(t:String, force:Boolean):Boolean
        {
            if (done || t == null || t.length == 0) return false;
            var swf:String = null;
            var m:Array = t.match(RE_SWF_LOADING);
            if (m != null) swf = String(m[1]);
            else
            {
                m = t.match(RE_SWF_ANY);
                if (m != null) swf = String(m[1]);
            }
            if (swf == null) swf = seenSwf;
            var params:Object = {};
            for each (var k:String in KEYS)
            {
                var re:RegExp = new RegExp("\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)", "gi");
                var mm:Object = re.exec(t);
                while (mm != null)
                {
                    if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
                    mm = re.exec(t);
                }
            }
            if (params["user"] == undefined || params["key"] == undefined || String(params["key"]).length < 8) return false;
            if (swf == null && scans < 6 && !force) return false;
            finishWith(host, params, swf);
            return true;
        }

        private function finishWith(gameHost:String, params:Object, swf:String):void
        {
            if (done) return;
            done = true;
            var outHost:String = gameHost;
            var swfPath:String = null;
            if (swf != null)
            {
                var u:String = swf;
                if (u.indexOf("//") == 0) u = "https:" + u;
                var m:Array = u.match(/^https?:\/\/([^\/?#]+)(.*)$/i);
                if (m != null)
                {
                    outHost = String(m[1]);
                    swfPath = String(m[2]).replace(/#.*$/, "");
                    if (swfPath == "") swfPath = "/Loading.swf";
                }
                else swfPath = "/" + u.replace(/^\/+/, "").replace(/#.*$/, "");
            }
            var out:Object = {host: outHost, params: params, user: params["user"], key: params["key"]};
            if (swfPath != null) out["swf"] = swfPath;
            var json:String = JSON.stringify(out);
            say("sessão capturada");
            var cb:Function = onSession;
            if (cb != null) cb(json);
        }
    }
}
