package
{
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.filters.GlowFilter;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
        import flash.geom.Matrix;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;

    // Botão do launcher. A origem (0,0) fica no CENTRO do botão.
    //   PRIMARY = botão de destaque (JOGAR)      CARD = cartão com legenda + seta (plataforma)
    //   GHOST   = botão discreto (ações secundárias)
    public class Btn extends Sprite
    {
        public static const PRIMARY:int = 0;
        public static const CARD:int    = 1;
        public static const GHOST:int   = 2;

        // Paleta do launcher (tema violeta escuro; usada também pela tela inicial e pelos painéis).
        public static const ACCENT:uint      = 0x7C3AED;
        public static const ACCENT_LIGHT:uint = 0xA855F7;
        public static const ACCENT_DARK:uint = 0x5B21B6;
        public static const TEXT:uint        = 0xF4F1FF;
        public static const TEXT_SOFT:uint   = 0xC9C4EE;
        public static const TEXT_MUTED:uint  = 0x8A86B8;
        public static const SURFACE:uint     = 0x12112E;
        public static const BORDER:uint      = 0x2A2955;
        public static const GREEN:uint       = 0x22E3A0;

        private var _sel:Boolean = false;
        // Botão GHOST "ligado" (opção ativa / aba escolhida): fundo violeta.
        public function set selected(v:Boolean):void { if (_sel != v) { _sel = v; draw(); } }
        public function get selected():Boolean { return _sel; }

        private var over:Boolean = false;
        private var down:Boolean = false;
        private var kind:int;
        private var lbl:TextField;
        private var lblDx:Number = 0;
        private var bw:Number;
        private var bh:Number;

        public function Btn(kind:int, w:Number, h:Number, text:String, caption:String = "", onClick:Function = null)
        {
            this.kind = kind; bw = w; bh = h;
            mouseChildren = false;
            buttonMode = true;
            draw();
            if (kind == PRIMARY) addPrimaryLabel(text);
            else if (kind == CARD) addCardLabel(text, caption);
            else addCenterLabel(text, 13, TEXT);
            if (onClick != null) addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            addEventListener(MouseEvent.MOUSE_DOWN, onDown);
            addEventListener(MouseEvent.MOUSE_UP, onUp);
            addEventListener(MouseEvent.ROLL_OVER, onOver);
            addEventListener(MouseEvent.ROLL_OUT, onOut);
        }

        private function onDown(e:MouseEvent):void { down = true; draw(); }
        private function onUp(e:MouseEvent):void   { down = false; draw(); }
        private function onOver(e:MouseEvent):void { over = true; draw(); }
        private function onOut(e:MouseEvent):void  { over = false; down = false; draw(); }

        // ---------- desenho do fundo ----------
        private function draw():void
        {
            var g:Graphics = graphics;
            g.clear();
            filters = [];
            var m:Matrix = new Matrix();
            if (kind == PRIMARY)
            {
                m.createGradientBox(bw, bh, Math.PI / 2, -bw / 2, -bh / 2);
                var c1:uint = down ? ACCENT_DARK : (over ? 0x9B5CF6 : ACCENT_LIGHT);
                var c2:uint = down ? 0x3B1685 : (over ? 0x6D28D9 : ACCENT_DARK);
                g.lineStyle(1, over ? 0xC4A1FF : 0x8B5CF6, 1);
                g.beginGradientFill(GradientType.LINEAR, [c1, c2], [1, 1], [0, 255], m);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, 14, 14);
                g.endFill();
                filters = [new GlowFilter(ACCENT, over ? 0.55 : 0.3, 14, 14, 1.4, 2)];
            }
            else if (kind == CARD)
            {
                g.lineStyle(1, (over || down) ? ACCENT_LIGHT : BORDER, 1);
                g.beginFill(down ? 0x1A1944 : (over ? 0x17163C : 0x10102A), 1);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, 12, 12);
                g.endFill();
                // seta de lista suspensa (v) à direita
                var cx:Number = bw / 2 - 22;
                g.lineStyle(2, TEXT_SOFT, 1, false, "normal", "round", "round");
                g.moveTo(cx - 5, -2); g.lineTo(cx, 3); g.lineTo(cx + 5, -2);
            }
            else
            {
                g.lineStyle(1, (over || down || _sel) ? ACCENT_LIGHT : BORDER, 1);
                g.beginFill(_sel ? (down ? 0x4C1D95 : 0x5B21B6) : (down ? 0x1D1B4A : (over ? 0x1A1944 : 0x12112E)), 1);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, 10, 10);
                g.endFill();
            }
        }

        // ---------- textos ----------
        private function makeText(t:String, size:int, color:uint, spacing:Number = 0):TextField
        {
            var tf:TextField = new TextField();
            var f:TextFormat = new TextFormat("_sans", size, color, true);
            f.letterSpacing = spacing;
            tf.defaultTextFormat = f;
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            return tf;
        }

        private function addCenterLabel(t:String, size:int, color:uint):void
        {
            var tf:TextField = makeText(t, size, color);
            var sz:int = size;
            while (tf.width > bw - 16 && sz > 8)
            {
                sz--;
                var fm:TextFormat = new TextFormat("_sans", sz, color, true);
                tf.defaultTextFormat = fm;
                tf.setTextFormat(fm);
            }
            tf.x = -tf.width / 2; tf.y = -tf.height / 2;
            addChild(tf);
            lbl = tf; lblDx = 0;
        }

        // Troca o texto de um botão GHOST ou PRIMARY (o texto fica centralizado).
        public function setText(t:String):void
        {
            if (lbl == null || lbl.text == t) return;
            lbl.text = t;
            var tfm:TextFormat = lbl.defaultTextFormat;
            var sz:int = int(tfm.size);
            while (lbl.width > 142 && sz > 8)
            {
                sz--;
                tfm.size = sz;
                lbl.defaultTextFormat = tfm;
                lbl.setTextFormat(tfm);
            }
            lbl.x = -lbl.width / 2 + lblDx;
            lbl.y = -lbl.height / 2;
        }

        // Texto do botão principal: maiúsculas com espaçamento largo, centralizado.
        private function addPrimaryLabel(t:String):void
        {
            var tf:TextField = makeText(t, 16, TEXT, 0);
            tf.x = -tf.width / 2; tf.y = -tf.height / 2;
            addChild(tf);
            lbl = tf; lblDx = 0;
        }

        // Legenda pequena (ex.: SERVIDOR) + nome em destaque.
        private function addCardLabel(name:String, caption:String):void
        {
            var cap:TextField = makeText(caption, 10, TEXT_MUTED, 0);
            var nm:TextField = makeText(name, 15, TEXT);
            var total:Number = cap.height + nm.height - 2;
            cap.x = -bw / 2 + 20; cap.y = -total / 2;
            nm.x = -bw / 2 + 20;  nm.y = cap.y + cap.height - 2;
            addChild(cap); addChild(nm);
        }
    }
}
