package
{
    import flash.display.BitmapData;
    import flash.display.DisplayObject;
    import flash.display.InteractiveObject;
    import flash.display.Stage;
    import flash.display.DisplayObjectContainer;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Matrix;
    import flash.geom.Point;
    import flash.geom.Rectangle;
    import flash.text.TextField;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Macro do Ciclo de missões (v1, montado a partir da gravação do jogador).
    // O que ele sabe fazer:
    //   - Lê o painel de missões (TaskTraceView) e acha a missão de ciclo (a que tem "ciclos" no texto).
    //   - "(Entregar)": toca no título da missão para ir entregar.
    //   - Mata-Rato: toca no objetivo para abrir o minijogo e fica tocando nos buracos (HamsterGameFrame);
    //     quando a rodada acaba sem bater a meta, aperta o botão de tentar de novo.
    //   - Qualquer outra missão: avisa no log que ainda não sabe e espera você fazer à mão (não toca em nada).
    public class MissionMacro
    {
        public var logger:Function;
        public var running:Boolean = false;
        public var status:String = "parado";
        public var ratRounds:int = 0;        // rodadas de rato jogadas desde que iniciou
        public var ratTotal:int = 0;         // vezes que o minijogo foi aberto

        // Os 8 buracos do minijogo (3 em cima, 2 no meio, 3 embaixo), em coordenadas de palco tiradas do print.
        // Referência: botão X da janela em ~(988,170). Só servem de reserva quando a detecção do rato não acha nada.
        // Buracos / área do minijogo (coordenadas de palco do log gravado — PC).
        private static const HOLES:Array = [
            [990, 470], [1050, 470], [1110, 470], [1170, 470],
            [960, 510], [1020, 510], [1080, 510], [1140, 510],
            [930, 550], [1000, 550], [1070, 550], [1140, 550],
            [980, 430], [1040, 430], [1100, 430], [1160, 430]
        ];
        private static const FIELD_X:Number = 840;
        private static const FIELD_Y:Number = 390;
        private static const FIELD_W:Number = 420;
        private static const FIELD_H:Number = 220;
        private static const REF_X:Number = 988;
        private static const REF_Y:Number = 170;
        private static const MAX_ROUNDS:int = 15;   // tentativas seguidas de uma mesma missão de rato

        private var timer:Timer;
        private var frame:DisplayObject = null;      // janela do rato aberta (guardada para não procurar a cada toque)
        private var gback:DisplayObject = null;
        private var closeBtn:DisplayObject = null;
        private var dx:Number = 0;
        private var dy:Number = 0;
        private var holeIdx:int = 0;
        private var lastFind:int = 0;
        private var lastTrace:int = 0;
        private var lastPress:int = 0;
        private var lastRetry:int = 0;
        private var lastRatLog:int = 0;
        private var roundsThisWindow:int = 0;
        private var lastSig:String = "";
        private var lastWarn:String = "";
        private var qteSeen:Boolean = false;
        private var lastDetect:int = 0;
        private var openedAt:int = 0;
        private var ratSeen:int = 0;
        private var tapCount:int = 0;
        private var dumped:Boolean = false;
        private var warnedColor:Boolean = false;

        private function say(s:String):void { if (logger != null) logger("[MISSÕES] " + s); }
        private function root():DisplayObjectContainer { return SwfFixer.rootStage; }

        public function start():void
        {
            if (running) return;
            running = true;
            status = "procurando a missão de ciclo...";
            frame = null; gback = null; closeBtn = null;
            roundsThisWindow = 0; lastSig = ""; lastWarn = ""; qteSeen = false;
            ratRounds = 0; ratTotal = 0;
            timer = new Timer(180); // 60ms era agressivo demais e contribuía para lag/crash no AIR 32-bit
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            say("ligado");
        }

        public function stop(reason:String = "parado"):void
        {
            if (!running) return;
            running = false;
            status = reason;
            if (timer != null) { timer.stop(); timer.removeEventListener(TimerEvent.TIMER, onTick); timer = null; }
            frame = null; gback = null; closeBtn = null;
            say(reason);
        }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("erro: " + err.message); }
        }

        private function step():void
        {
            var r:DisplayObjectContainer = root();
            if (r == null) return;
            var now:int = getTimer();

            // 1) minijogo do rato aberto: toca nos buracos (usa a referência guardada; só procura de novo a cada 0,4 s)
            if (frame != null && (frame.stage == null || !frame.visible)) { frame = null; gback = null; closeBtn = null; onRatClosed(); }
            if (frame == null && now - lastFind > 400)
            {
                lastFind = now;
                var f:DisplayObject = UiHelper.find(r, "HamsterGameFrame", 10);
                if (f != null) onRatOpened(f);
            }
            if (frame != null) { ratStep(now); return; }

            // 2) treino QTE: ainda não sei ler as setas; descreve a janela uma vez para eu montar depois
            if (now - lastTrace > 1000)
            {
                lastTrace = now;
                var q:DisplayObject = UiHelper.find(r, "QTETraining", 8);
                if (q == null) q = UiHelper.find(r, "QteTrainingFrame", 8);
                if (q == null) q = UiHelper.find(r, "TrainingQTEView", 8);
                if (q != null)
                {
                    status = "QTE aberto: faça à mão (WASD / setas)";
                    if (!qteSeen) { qteSeen = true; say("QTE aberto. Descrevendo a janela:"); dump(q as DisplayObjectContainer, 0, 5, [0]); }
                    return;
                }
                qteSeen = false;
                traceStep(r, now);
            }
        }

        // ---------- rato ----------
        private function onRatOpened(f:DisplayObject):void
        {
            frame = f;
            ratTotal++;
            gback = UiHelper.find(f as DisplayObjectContainer, "GameBack", 6);
            if (gback == null) gback = UiHelper.find(f as DisplayObjectContainer, "HamsterGame", 4);
            closeBtn = null;
            dx = 0; dy = 0;
            if (gback != null)
            {
                // acha o botão X (BaseButton dentro do GameBack) para corrigir a posição se a janela estiver deslocada
                closeBtn = UiHelper.find(f as DisplayObjectContainer, "BaseButton", 6);
            if (closeBtn == null && gback != null) closeBtn = UiHelper.find(gback as DisplayObjectContainer, "BaseButton", 4);
                if (closeBtn != null && closeBtn.stage != null)
                {
                    var rc:Rectangle = closeBtn.getBounds(closeBtn.stage);
                    var ddx:Number = rc.x + rc.width / 2 - REF_X;
                    var ddy:Number = rc.y + rc.height / 2 - REF_Y;
                    if (Math.abs(ddx) <= 300 && Math.abs(ddy) <= 300) { dx = ddx; dy = ddy; }
                    say("rato aberto: botão X em (" + int(rc.x + rc.width / 2) + "," + int(rc.y + rc.height / 2) + "), deslocamento (" + int(dx) + "," + int(dy) + ")");
                }
                else say("rato aberto (sem botão X reconhecido; uso as posições da gravação)");
            }
            else say("rato aberto, mas não achei o GameBack para tocar");
            roundsThisWindow = 0;
            lastRetry = getTimer();
            openedAt = getTimer(); ratSeen = 0; tapCount = 0; dumped = false; warnedColor = false;
        }

        private function onRatClosed():void
        {
            say("janela do rato fechou (rodadas nesta missão: " + (roundsThisWindow + 1) + ")");
            roundsThisWindow = 0;
            lastPress = getTimer();   // dá um tempo para o painel de missões atualizar antes de mexer nele
            lastTrace = getTimer();
        }

        private function readRat(out:Object):void
        {
            var tx:Array = [];
            scanTexts(frame, tx, 0);
            out.score = -1; out.goal = -1; out.secs = -1;
            var re:RegExp = /^\s*(\d+)\s*\/\s*(\d+)\s*$/;
            var re2:RegExp = /^\s*(\d{1,2})\s*$/;
            for (var i:int = 0; i < tx.length; i++)
            {
                var s:String = String(tx[i]);
                var m:Object = re.exec(s);
                if (m != null && out.score < 0) { out.score = int(m[1]); out.goal = int(m[2]); continue; }
                var m2:Object = re2.exec(s);
                if (m2 != null && out.secs < 0) out.secs = int(m2[1]);
            }
        }

        private function ratStep(now:int):void
        {
            var info:Object = {};
            readRat(info);
            status = "Mata-Rato: " + (info.score >= 0 ? info.score + "/" + info.goal : "?") + (info.secs >= 0 ? " · " + info.secs + "s" : "") + " · rodada " + (roundsThisWindow + 1);
            if (now - lastRatLog > 3000) { lastRatLog = now; say(status); }

            // fim da rodada: botão "tentar de novo" (IconButton direto na janela) aparece quando o tempo zera
            var retry:DisplayObject = null;
            if (info.secs == 0 || info.secs < 0)
            {
                var arr:Array = [];
                UiHelper.findAll(frame as DisplayObjectContainer, "IconButton", arr, 3, 4);
                if (arr.length > 0) retry = arr[0];
            }
            if (retry != null && info.secs == 0 && now - lastRetry > 1500)
            {
                lastRetry = now;
                roundsThisWindow++;
                ratRounds++;
                if (roundsThisWindow >= MAX_ROUNDS) { stop("Mata-Rato: " + MAX_ROUNDS + " rodadas sem bater a meta; parei"); return; }
                say("rodada acabou em " + info.score + "/" + info.goal + "; tentando de novo (" + roundsThisWindow + ")");
                UiHelper.press(retry);
                return;
            }
            if (info.secs == 0) return;   // fim de rodada sem botão ainda: espera

            if (gback == null || gback.stage == null) return;

            // descreve a estrutura da janela uma vez (para eu poder trocar a detecção por objetos do jogo, se existirem)
            if (!dumped && now - openedAt > 1500)
            {
                dumped = true;
                say("estrutura da janela do rato:");
                dump(frame as DisplayObjectContainer, 0, 4, [0]);
            }

            // procura o rato na imagem (laranja) a cada ~80 ms e toca em cima dele
            var targets:Array = [];
            if (now - lastDetect >= 50) { lastDetect = now; targets = detectRats(); }
            if (targets.length > 0)
            {
                for (var k:int = 0; k < targets.length; k++)
                {
                    var t:Array = targets[k] as Array;
                    ratSeen++;
                    tapCount++;
                    if (ratSeen <= 4) say("rato visto em (" + int(Number(t[0])) + "," + int(Number(t[1])) + ")");
                    tap(gback, Number(t[0]), Number(t[1]));
                }
                return;
            }
            if (!warnedColor && now - openedAt > 8000 && ratSeen == 0)
            {
                warnedColor = true;
                say("não vi nenhum rato pela cor nos primeiros 8 s; estou só tocando nos buracos. Me avise se o placar não sobe.");
            }
            // reserva: toca nos buracos (log gravado) e também varre o retângulo do GameBack
            var sx:Number;
            var sy:Number;
            if (holeIdx % 3 == 2)
            {
                // varredura pelo retângulo real do GameBack
                try
                {
                    var rb:Rectangle = gback.getBounds(gback.stage);
                    var pad:Number = 40;
                    var col:int = (holeIdx % 20) % 5;
                    var row:int = int((holeIdx % 20) / 5);
                    sx = rb.x + pad + (rb.width - pad * 2) * (col + 0.5) / 5;
                    sy = rb.y + pad + (rb.height - pad * 2) * (row + 0.5) / 4;
                }
                catch (eB:Error)
                {
                    var h2:Array = HOLES[holeIdx % HOLES.length] as Array;
                    sx = Number(h2[0]) + dx; sy = Number(h2[1]) + dy;
                }
            }
            else
            {
                var h:Array = HOLES[holeIdx % HOLES.length] as Array;
                sx = Number(h[0]) + dx; sy = Number(h[1]) + dy;
            }
            holeIdx++;
            tap(gback, sx, sy);
        }

        // Desenha a área dos ratos num bitmap e procura o laranja do rato. Devolve até 3 pontos [x, y] (coordenadas de palco).
        private function detectRats():Array
        {
            var out:Array = [];
            if (frame == null || frame.stage == null) return out;
            var rx:Number = FIELD_X + dx;
            var ry:Number = FIELD_Y + dy;
            var w:int = int(FIELD_W);
            var h:int = int(FIELD_H);
            // area real do GameBack (mais confiavel que constantes fixas)
            try
            {
                if (gback != null && gback.stage != null)
                {
                    var gb:Rectangle = gback.getBounds(gback.stage);
                    // corta titulo/placar: 12% topo e 18% base
                    rx = gb.x + gb.width * 0.08;
                    ry = gb.y + gb.height * 0.18;
                    w = int(gb.width * 0.84);
                    h = int(gb.height * 0.62);
                }
            }
            catch (eF:Error) {}
            var bd:BitmapData = null;
            try
            {
                bd = new BitmapData(w, h, true, 0x00000000);
                var m:Matrix = frame.transform.concatenatedMatrix.clone();
                m.translate(-rx, -ry);
                bd.draw(frame, m, null, null, new Rectangle(0, 0, w, h), false);
            }
            catch (e:Error) { if (bd != null) bd.dispose(); return out; }

            var cell:int = 48;
            var cols:int = int(Math.ceil(w / cell));
            var rows:int = int(Math.ceil(h / cell));
            var cnt:Array = [];
            var sxs:Array = [];
            var sys:Array = [];
            var n:int = cols * rows;
            var q:int;
            for (q = 0; q < n; q++) { cnt.push(0); sxs.push(0); sys.push(0); }
            for (var yy:int = 0; yy < h; yy += 3)
            {
                for (var xx:int = 0; xx < w; xx += 3)
                {
                    var px:uint = bd.getPixel32(xx, yy);
                    if (((px >>> 24) & 0xFF) < 200) continue;
                    var r:int = (px >>> 16) & 0xFF;
                    var g:int = (px >>> 8) & 0xFF;
                    var b:int = px & 0xFF;
                    // rato bege/amarelo (nao o presunto rosa nem o fundo)
                    if (r >= 160 && g >= 120 && b <= 140 && r >= g - 20 && g > b + 30 && r > b + 40)
                    {
                        var ci:int = int(yy / cell) * cols + int(xx / cell);
                        cnt[ci]++; sxs[ci] += xx; sys[ci] += yy;
                    }
                }
            }
            bd.dispose();

            var cand:Array = [];
            for (q = 0; q < n; q++)
            {
                if (int(cnt[q]) >= 12) cand.push({n: int(cnt[q]), x: rx + Number(sxs[q]) / int(cnt[q]), y: ry + Number(sys[q]) / int(cnt[q])});
            }
            cand.sortOn("n", Array.NUMERIC | Array.DESCENDING);
            for (q = 0; q < cand.length && out.length < 3; q++)
            {
                var ok:Boolean = true;
                for (var z:int = 0; z < out.length; z++)
                {
                    var ddx:Number = Number(cand[q].x) - Number(out[z][0]);
                    var ddy:Number = Number(cand[q].y) - Number(out[z][1]);
                    if (ddx * ddx + ddy * ddy < 56 * 56) { ok = false; break; }
                }
                if (ok) out.push([cand[q].x, cand[q].y]);
            }
            return out;
        }

        private function tap(target:DisplayObject, sx:Number, sy:Number):void
        {
            // Clique "de verdade": pega o objeto no ponto (como o mouse) e manda o evento nele.
            try
            {
                var st:Stage = null;
                if (target != null && target.stage != null) st = target.stage;
                else if (frame != null && frame.stage != null) st = frame.stage;
                if (st != null)
                {
                    var under:Array = st.getObjectsUnderPoint(new Point(sx, sy));
                    var i:int;
                    for (i = under.length - 1; i >= 0; i--)
                    {
                        var o:DisplayObject = under[i] as DisplayObject;
                        if (o == null) continue;
                        if (!(o is InteractiveObject)) continue;
                        if (!InteractiveObject(o).mouseEnabled) continue;
                        var nm:String = UiHelper.sn(o);
                        if (nm == "TextField" || nm == "Sidebar" || nm == "Btn") continue;
                        var lp:Point = o.globalToLocal(new Point(sx, sy));
                        o.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_DOWN, true, false, lp.x, lp.y, null, false, false, false, true));
                        o.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_UP, true, false, lp.x, lp.y, null, false, false, false, false));
                        o.dispatchEvent(new MouseEvent(MouseEvent.CLICK, true, false, lp.x, lp.y));
                        return;
                    }
                }
            }
            catch (e0:Error) {}
            // fallback no alvo
            if (target == null) return;
            try
            {
                var p:Point = target.globalToLocal(new Point(sx, sy));
                target.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_DOWN, true, false, p.x, p.y, null, false, false, false, true));
                target.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_UP, true, false, p.x, p.y));
                target.dispatchEvent(new MouseEvent(MouseEvent.CLICK, true, false, p.x, p.y));
            }
            catch (e1:Error) {}
        }

        // ---------- painel de missões ----------
        private function traceStep(r:DisplayObjectContainer, now:int):void
        {
            var items:Array = [];
            UiHelper.findAll(r, "TaskTraceItem", items, 16, 12);
            if (items.length == 0)
            {
                status = "painel de missões vazio ou fechado";
                warnOnce("não achei o painel de missões (TaskTraceView). Abra a lista de missões do lado direito.");
                return;
            }
            var cyc:DisplayObject = null;
            var cycText:String = "";
            var sig:Array = [];
            for (var i:int = 0; i < items.length; i++)
            {
                var tx:Array = [];
                scanTexts(items[i], tx, 0);
                var joined:String = tx.join(" / ");
                sig.push(joined);
                var nn:String = GamePlanesAdapter.norm(joined);
                if (nn.indexOf("ciclo") >= 0 || nn.indexOf("mata") >= 0 || nn.indexOf("qte") >= 0 || nn.indexOf("guilda") >= 0)
                {
                    // prioriza entregaveis
                    if (nn.indexOf("entregar") >= 0) { cyc = items[i]; cycText = joined; }
                    else if (cyc == null) { cyc = items[i]; cycText = joined; }
                    else if (GamePlanesAdapter.norm(cycText).indexOf("entregar") < 0 && nn.indexOf("entregar") >= 0)
                    { cyc = items[i]; cycText = joined; }
                }
            }
            var sg:String = sig.join(" || ");
            if (sg != lastSig) { lastSig = sg; say("painel: " + (sg.length > 200 ? sg.substr(0, 200) : sg)); }

            if (cyc == null)
            {
                status = "sem missão de ciclo no painel: pegue no NPC";
                warnOnce("não vejo a missão de ciclo no painel (procuro o texto \"ciclos\"). Pegue a missão com o NPC.");
                return;
            }
            var n:String = GamePlanesAdapter.norm(cycText);
            var shortTxt:String = cycText.length > 60 ? cycText.substr(0, 60) : cycText;

            // 1) entregáveis primeiro
            if (n.indexOf("entregar") >= 0)
            {
                status = "entregando: " + shortTxt;
                if (now - lastPress > 2500)
                {
                    lastPress = now;
                    var head:DisplayObject = UiHelper.find(cyc as DisplayObjectContainer, "Scale9CornerImage", 4);
                    say("missão pronta, tocando para entregar: " + shortTxt);
                    UiHelper.press(head != null ? head : cyc);
                }
                return;
            }
            // 2) Mata-Rato: no log, o clique no titulo (Scale9CornerImage) ja abre o minijogo
            if (/mata.?rato|hamster/.test(n))
            {
                status = "abrindo o Mata-Rato: " + shortTxt;
                if (now - lastPress > 3000)
                {
                    lastPress = now;
                    var head2:DisplayObject = UiHelper.find(cyc as DisplayObjectContainer, "Scale9CornerImage", 4);
                    say("tocando no titulo do Mata-Rato (abre o minijogo)");
                    UiHelper.press(head2 != null ? head2 : cyc);
                }
                return;
            }
            // 3) Treinamento QTE: abre pelo titulo; o minijogo ainda e manual se aparecer
            if (/qte|treinamento/.test(n))
            {
                status = "abrindo QTE: " + shortTxt;
                if (now - lastPress > 4000)
                {
                    lastPress = now;
                    var head3:DisplayObject = UiHelper.find(cyc as DisplayObjectContainer, "Scale9CornerImage", 4);
                    say("tocando no titulo do QTE");
                    UiHelper.press(head3 != null ? head3 : cyc);
                }
                return;
            }
            // 4) Contribuicao guilda
            if (/contribui|guilda|consortia/.test(n))
            {
                // se a janela de contribuir ja abriu, tenta confirmar
                var cg:DisplayObject = UiHelper.find(r, "ConsortiaContributeFrame", 8);
                if (cg != null)
                {
                    status = "contribuindo na guilda...";
                    if (now - lastPress > 2000)
                    {
                        lastPress = now;
                        var btn:DisplayObject = UiHelper.find(cg as DisplayObjectContainer, "SelectedButton", 6);
                        if (btn == null) btn = UiHelper.find(cg as DisplayObjectContainer, "BaseButton", 6);
                        say("janela de contribuicao aberta; tocando confirmar");
                        UiHelper.press(btn != null ? btn : cg);
                    }
                    return;
                }
                status = "abrindo contribuicao guilda: " + shortTxt;
                if (now - lastPress > 4000)
                {
                    lastPress = now;
                    var tgt:DisplayObject = UiHelper.find(cyc as DisplayObjectContainer, "TraceTaskTargetItem", 8);
                    if (tgt == null) tgt = UiHelper.find(cyc as DisplayObjectContainer, "Scale9CornerImage", 4);
                    say("tocando objetivo da guilda");
                    UiHelper.press(tgt != null ? tgt : cyc);
                }
                return;
            }
            // 5) outras missoes de ciclo: tenta abrir pelo titulo
            status = "abrindo missao de ciclo: " + shortTxt;
            if (now - lastPress > 5000)
            {
                lastPress = now;
                var head4:DisplayObject = UiHelper.find(cyc as DisplayObjectContainer, "Scale9CornerImage", 4);
                say("tocando missao de ciclo: " + shortTxt);
                UiHelper.press(head4 != null ? head4 : cyc);
            }
        }

        private function warnOnce(s:String):void
        {
            if (s == lastWarn) return;
            lastWarn = s;
            say(s);
        }

        // ---------- utilidades ----------
        private function scanTexts(o:DisplayObject, out:Array, depth:int):void
        {
            if (o == null || depth > 8 || out.length >= 40) return;
            if (o is TextField)
            {
                var t:String = TextField(o).text;
                if (t != null && t.length > 0) out.push(t);
                return;
            }
            if (o is DisplayObjectContainer)
            {
                var c:DisplayObjectContainer = o as DisplayObjectContainer;
                for (var i:int = 0; i < c.numChildren; i++)
                {
                    try { scanTexts(c.getChildAt(i), out, depth + 1); } catch (e:Error) {}
                }
            }
        }

        // Descreve a árvore de uma janela (classe, posição no palco e texto) para o log.
        private function dump(o:DisplayObjectContainer, depth:int, maxDepth:int, count:Array):void
        {
            if (o == null || depth > maxDepth || count[0] >= 50) return;
            var n:int = 0;
            try { n = o.numChildren; } catch (e0:Error) { return; }
            for (var i:int = 0; i < n && count[0] < 50; i++)
            {
                try
                {
                    var ch:DisplayObject = o.getChildAt(i);
                    if (ch == null || !ch.visible) continue;
                    var rc:Rectangle = ch.getBounds(ch.stage);
                    var tx:String = (ch is TextField) ? (" \"" + TextField(ch).text + "\"") : "";
                    var pad:String = "";
                    for (var d:int = 0; d < depth; d++) pad += " ";
                    say(pad + UiHelper.sn(ch) + " @" + int(rc.x) + "," + int(rc.y) + " " + int(rc.width) + "x" + int(rc.height) + tx);
                    count[0]++;
                    if (ch is DisplayObjectContainer) dump(ch as DisplayObjectContainer, depth + 1, maxDepth, count);
                }
                catch (e:Error) {}
            }
        }
    }
}
