package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.display.Stage;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.text.TextField;
    import flash.utils.Timer;
    import flash.utils.getQualifiedClassName;

    // "Gravar meus passos": SÓ OBSERVA. Registra no log cada clique seu (cadeia de objetos clicados + textos de botões por perto)
    // e, a cada 0,6 s, mudanças de estado (cena, dentro do plano, lista de planos, camada) e janelas que abrem/fecham.
    // Serve para eu descobrir como se abre o Transmissor, usa e entra num plano, e quais classes/botões existem.
    public class ClickRecorder
    {
        public static var on:Boolean = false;
        private static var st:Stage;
        private static var log:Function;
        private static var ad:GamePlanesAdapter;
        private static var timer:Timer;
        private static var lastState:String = "";
        private static var lastWins:Object = {};
        private static var t0:int = 0;

        private static function sn(o:Object):String
        {
            var n:String = getQualifiedClassName(o);
            var i:int = n.lastIndexOf("::");
            return i >= 0 ? n.substr(i + 2) : n;
        }

        public static function start(stage:Stage, logger:Function, adapter:GamePlanesAdapter):void
        {
            if (on || stage == null) return;
            st = stage; log = logger; ad = adapter; on = true;
            lastState = ""; lastWins = {};
            st.addEventListener(MouseEvent.MOUSE_DOWN, onDown, true, 1000);
            timer = new Timer(600);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            log("GRAVADOR ligado: faça o passo a passo à mão (abrir Transmissor, usar plano, entrar, sair, descartar) e depois mande o log");
            onTick(null);
        }

        public static function stop():void
        {
            if (!on) return;
            on = false;
            try { st.removeEventListener(MouseEvent.MOUSE_DOWN, onDown, true); } catch (e:Error) {}
            if (timer != null) { timer.stop(); timer.removeEventListener(TimerEvent.TIMER, onTick); timer = null; }
            log("GRAVADOR desligado");
        }

        private static function texts(c:DisplayObjectContainer, depth:int, out:Array):void
        {
            if (depth > 3 || out.length >= 4) return;
            for (var i:int = 0; i < c.numChildren && out.length < 4; i++)
            {
                var ch:DisplayObject;
                try { ch = c.getChildAt(i); } catch (e:Error) { continue; }
                if (ch is TextField) { var t:String = TextField(ch).text; if (t != null && t.length > 0 && t.length < 40) out.push(t); }
                else if (ch is DisplayObjectContainer) texts(ch as DisplayObjectContainer, depth + 1, out);
            }
        }

        private static function onDown(e:MouseEvent):void
        {
            try
            {
                var t:DisplayObject = e.target as DisplayObject;
                if (t == null) return;
                var chain:Array = [];
                var o:DisplayObject = t;
                var n:int = 0;
                while (o != null && n < 8)
                {
                    if (o is MacroPanel || o is Controls) return;   // clique nos botões do próprio app: ignora
                    var nm:String = sn(o);
                    var inst:String = (o.name != null && o.name.indexOf("instance") != 0) ? ("#" + o.name) : "";
                    chain.push(nm + inst);
                    o = o.parent;
                    n++;
                }
                var tx:Array = [];
                if (t is TextField) tx.push(TextField(t).text);
                else if (t is DisplayObjectContainer) texts(t as DisplayObjectContainer, 0, tx);
                if (tx.length == 0 && t.parent != null) texts(t.parent, 0, tx);
                log("CLIQUE (" + int(e.stageX) + "," + int(e.stageY) + "): " + chain.join(" < ") + (tx.length > 0 ? " | textos: " + tx.join(" / ") : ""));
            }
            catch (err:Error) {}
        }

        private static function onTick(e:TimerEvent):void
        {
            try
            {
                var s:String = ad.stateLine();
                if (s != lastState) { lastState = s; log("ESTADO: " + s); }
                var now:Object = {};
                var names:Array = ad.windowNames();
                var i:int;
                for (i = 0; i < names.length; i++)
                {
                    now[names[i]] = true;
                    if (!lastWins[names[i]]) log("JANELA ABRIU: " + names[i]);
                }
                for (var k:String in lastWins) if (!now[k]) log("JANELA FECHOU: " + k);
                lastWins = now;
            }
            catch (err:Error) {}
        }
    }
}
