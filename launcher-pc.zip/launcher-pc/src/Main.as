package
{
    import flash.desktop.NativeApplication;
    import flash.desktop.NativeProcess;
    import flash.desktop.NativeProcessStartupInfo;
    import flash.desktop.SystemIdleMode;
    import flash.display.Bitmap;
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Loader;
    import flash.display.NativeWindow;
    import flash.display.NativeWindowInitOptions;
    import flash.display.NativeWindowSystemChrome;
    import flash.display.NativeWindowType;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.display.StageDisplayState;
    import flash.events.Event;
    import flash.events.InvokeEvent;
    import flash.events.HTTPStatusEvent;
    import flash.events.IOErrorEvent;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.events.TimerEvent;
    import flash.events.UncaughtErrorEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.filters.DropShadowFilter;
    import flash.filters.GlowFilter;
    import flash.geom.Matrix;
    import flash.geom.Point;
    import flash.geom.Rectangle;
    import flash.net.URLLoader;
    import flash.net.navigateToURL;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.system.ApplicationDomain;
    import flash.system.Capabilities;
    import flash.system.LoaderContext;
    import flash.system.System;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.ui.Keyboard;
    import flash.utils.ByteArray;
    import flash.utils.Timer;
    import flash.utils.clearTimeout;
    import flash.utils.getTimer;
    import flash.utils.setTimeout;

    [SWF(width="1352", height="650", frameRate="30", backgroundColor="#07061A")]
    public class Main extends Sprite
    {
        // Reservas empacotadas (você coloca os SEUS arquivos em assets/game/).
        private static const FALLBACKS:Array = [
            "assets/game/Loading.swf",
            "assets/game/Loading_270767.swf",
            "assets/game/Loading_245292.swf",
            "assets/game/Loading_243852.swf",
            "assets/game/Loading_234741.swf"
        ];
        private static const CACHE_TTL_MS:Number = 6 * 60 * 60 * 1000;   // 6 h
        private static const BG_TOP:uint = 0x0B0A1E;      // fundo: topo do degradê
        private static const BG_BOTTOM:uint = 0x07061A;   // fundo: base do degradê
        private static const VERSION:String = "v5.3 PC";
        // Até 4 janelas (uma conta / um jogo por janela). O AIR só permite 1 processo:
        // a 2ª abertura do .exe vira InvokeEvent e abrimos outra NativeWindow aqui.
        private static const MAX_WINDOWS:int = 4;
        private static var instances:Array = [];
        private static var bootDone:Boolean = false;
        private static var logInited:Boolean = false;
        private static var fixerInstalled:Boolean = false;
        private static var nextSlot:int = 1;
        private var windowSlot:int = 0;
        private var secondary:Boolean = false;
        // Espelho: durante inject não retransmitir (evita loop).
        private var mirrorInjecting:Boolean = false;
        private var mirrorMouseHooked:Boolean = false;
        // Domínio AS3 desta janela (cada conta tem o seu). Macros usam isto, não o da “última janela”.
        private var myGameDomain:ApplicationDomain = null;

        // Modos do menu nativo (o evento "menu" é compartilhado).
        private static const M_PLATFORM:String = "platform";
        private static const M_SETTINGS:String = "settings";
        private static const M_QUALITY:String  = "quality";
        private static const M_FPS:String      = "fps";
        private static const M_CACHE:String    = "cache";
        private static const M_RES:String      = "res";
        private static const M_EXIT:String     = "exit";
        private static const M_ACC:String      = "acc";
        private static const M_ACCDEL:String   = "accdel";
        // Resolução do jogo. 0 = nativa da tela; 100000+n = tamanho fixo "Modo PC" (RES_FIXED[n]),
        // centralizado com barras pretas se a proporção da tela for diferente.
        // O jogo foi feito para ~1250x650: abaixo disso as janelas dele ficam cortadas.
        private static const RES_BASE:int = 100000;
        // 200000+n = resolução "virtual" (RES_VIRT[n]): tenta dar ao palco exatamente esse tamanho
        // (SHOW_ALL) e confere o resultado; se o AIR não aceitar, volta ao Modo PC (ver verifyVirtual).
        private static const RES_VIRT_BASE:int = 200000;
        private static const RES_CUSTOM:int = 300000;     // "Personalizada": altura escolhida na barra (Prefs.customH)
        private static const CUSTOM_MIN:int = 650;
        private static const CUSTOM_MAX:int = 1080;
        private static const RES_OPTIONS:Array = [100000, 0];
        private static const RES_FIXED:Array = [[1352, 650]];
        private static const RES_VIRT:Array = [[1920, 1080, "Full HD"], [2560, 1440, "2K"]];
        private static const FPS_OPTIONS:Array = [15, 24, 30, 60, 120];
        private var bridge:Bridge;
        private var lastStatus:String = "";
        private var inGame:Boolean = false;
        private var platformIdx:int = 0;
        private var ui:Sprite = new Sprite();
        private var status:TextField;
        private var session:Object;
        private var port:int;
        private var fbIndex:int = 0;
        private var swfCandidates:Array = [];
        private var swfIdx:int = 0;
        private var okPath:String = "/client/Loading.swf";
        private static const BRAZIL_LEN:int = 244783;   // tamanho do Loading.swf do servidor do Brasil
        private var gameLoader:Loader;
        private var controls:Sidebar;
        private var curAcc:String = "";
        private var accMenuIds:Array = [];
        private var macroPanel:MacroPanel;
        private var menuMode:String = M_PLATFORM;
        private var logLines:Array = [];
        private var zoomLevel:Number = 1;
        private var topTimer:Timer;
        private var bgLayer:Sprite = new Sprite();   // imagem de fundo + sombra (abaixo da UI)
        private var bgBmp:Bitmap;
        private var shade:Shape = new Shape();
        private var topW:Number = -1;
        private var topH:Number = -1;
        private var lastW:Number = -1;
        private var lastH:Number = -1;

        public function Main(secondaryWindow:Boolean = false)
        {
            secondary = secondaryWindow;
            if (stage != null) startWhenReady();
            else addEventListener(Event.ADDED_TO_STAGE, onAddedToStage);
        }

        private function onAddedToStage(e:Event):void
        {
            removeEventListener(Event.ADDED_TO_STAGE, onAddedToStage);
            startWhenReady();
        }

        private function startWhenReady():void
        {
            try { init(); }
            catch (err:Error) { fatal(String(err.message) + stackOf(err)); }
        }

        // Janelas em jogo, exceto a de fromSlot (seguidoras do espelho).
        public static function mirrorTargets(fromSlot:int):Array
        {
            var out:Array = [];
            for each (var m:Main in instances)
            {
                if (m == null || m.windowSlot == fromSlot) continue;
                if (!m.inGame || m.stage == null) continue;
                out.push(m);
            }
            return out;
        }

        // Abre outra janela (nova conta). Também é chamado quando o usuário abre o .exe de novo.
        public static function openExtraWindow():void
        {
            if (instances.length >= MAX_WINDOWS)
            {
                try
                {
                    if (instances.length > 0)
                        Main(instances[0]).log("Limite de " + MAX_WINDOWS + " janelas atingido.");
                }
                catch (e0:Error) {}
                return;
            }
            try
            {
                var opts:NativeWindowInitOptions = new NativeWindowInitOptions();
                opts.systemChrome = NativeWindowSystemChrome.STANDARD;
                opts.type = NativeWindowType.NORMAL;
                opts.resizable = true;
                opts.maximizable = true;
                opts.minimizable = true;
                opts.transparent = false;
                var win:NativeWindow = new NativeWindow(opts);
                win.title = "Legend PC";
                win.width = 1366;
                win.height = 700;
                win.stage.align = StageAlign.TOP_LEFT;
                win.stage.scaleMode = StageScaleMode.NO_SCALE;
                var m:Main = new Main(true);
                win.stage.addChild(m);
                win.activate();
            }
            catch (err:Error)
            {
                try { if (instances.length > 0) Main(instances[0]).log("Falha ao abrir janela: " + err.message); } catch (e1:Error) {}
            }
        }

        private static function onAppInvoke(e:InvokeEvent):void
        {
            // O primeiro INVOKE é o boot do app; só os seguintes pedem janela nova.
            if (!bootDone) return;
            openExtraWindow();
        }

        private function registerWindow():void
        {
            windowSlot = nextSlot++;
            instances.push(this);
            try
            {
                var nw:NativeWindow = stage.nativeWindow;
                if (nw != null)
                {
                    nw.title = instances.length <= 1 ? "Legend PC" : ("Legend PC (" + windowSlot + ")");
                    nw.addEventListener(Event.CLOSING, onWindowClosing);
                    nw.addEventListener(Event.CLOSE, onWindowClosed);
                    try { nw.addEventListener("displayStateChange", onWinBounds); } catch (eDs:Error) {}
                    try { nw.addEventListener("resize", onWinBounds); } catch (eRs:Error) {}
                }
            }
            catch (e:Error) {}
        }

        private function onWindowClosing(e:Event):void
        {
            // Libera o jogo desta janela; as outras continuam.
            try { shutdownWindow(false); } catch (err:Error) {}
        }

        private function onWindowClosed(e:Event):void
        {
            var ix:int = instances.indexOf(this);
            if (ix >= 0) instances.splice(ix, 1);
            if (MirrorBus.isLeaderSlot(windowSlot))
            {
                if (instances.length > 0) MirrorBus.setLeader(Main(instances[0]).windowSlot);
                else MirrorBus.clearLeader();
            }
            try { hookMirrorMouse(false); } catch (eH:Error) {}
        }

        // partial=true: só fecha o jogo e volta ao menu; false: janela está fechando de vez.
        private function shutdownWindow(partial:Boolean):void
        {
            try { if (topTimer) topTimer.stop(); } catch (eT:Error) {}
            try { if (gameLoader) { gameLoader.unloadAndStop(true); if (gameLoader.parent) gameLoader.parent.removeChild(gameLoader); } } catch (eU:Error) {}
            gameLoader = null;
            inGame = false;
            session = null;
            try { if (controls && controls.parent) controls.parent.removeChild(controls); } catch (eC:Error) {}
            try { if (macroPanel && macroPanel.parent) macroPanel.parent.removeChild(macroPanel); } catch (eM:Error) {}
            try { if (sliderPanel && sliderPanel.parent) sliderPanel.parent.removeChild(sliderPanel); } catch (eS:Error) {}
            if (partial) { showHome(); }
        }

        private function closeThisWindow():void
        {
            try
            {
                shutdownWindow(false);
                var nw:NativeWindow = stage != null ? stage.nativeWindow : null;
                if (nw != null) nw.close();
            }
            catch (e:Error) { log("Fechar janela: " + e.message); }
        }

        private function init():void
        {
            if (loaderInfo && loaderInfo.uncaughtErrorEvents)
                loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR, onUncaught);
            Accounts.load();
            applyResolution();
            drawBg();
            bridge = new Bridge();
            bridge.stage = stage;
            if (!logInited) { initLogFile(); logInited = true; }
            SwfFixer.logger = log;
            SwfFixer.rootStage = stage;
            SwfFixer.fastNeg = Prefs.fastNeg;
            if (!fixerInstalled) { SwfFixer.install(); SwfFixer.pruneOld(); fixerInstalled = true; }
            // Sem isto o AIR congela o jogo quando você sai do app (jogo desconecta).
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE; } catch (eIdle:Error) {}
            try { NativeApplication.nativeApplication["executeInBackground"] = true; } catch (eBg:Error) { log("segundo plano: " + eBg.message); }
            stage.addEventListener(KeyboardEvent.KEY_DOWN, onKey, false, 100);
            // Em segundo plano o AIR derruba o frameRate (~4 fps) e o macro fica lento/parado.
            // Reaplica a taxa normal ao sair do app e de novo ao voltar.
            stage.addEventListener(Event.DEACTIVATE, onBgChange);
            stage.addEventListener(Event.ACTIVATE, onBgChange);
            platformIdx = Math.min(Prefs.platform, Platforms.LIST.length - 1);
            applyDisplayPrefs();
            bgLayer.addChild(shade);
            addChild(bgLayer);
            drawBg();
            addChild(ui);
            bridge.addEventListener("game", onGame);
            bridge.addEventListener("menu", onMenu);
            bridge.addEventListener("error", onError);
            registerWindow();
            MirrorBus.logger = log;
            // Primeira janela vira líder automaticamente; as próximas são seguidoras.
            if (MirrorBus.leaderSlot == 0) MirrorBus.setLeader(windowSlot);
            hookMirrorMouse(true);
            log("Launcher iniciado" + (secondary ? " (janela " + windowSlot + ")" : "") + ". Janelas: " + instances.length + "/" + MAX_WINDOWS + ". ANE: " + (bridge.available ? "ok" : "ausente (" + bridge.initError + ")"));
            log("Espelho: " + (MirrorBus.isLeaderSlot(windowSlot) ? "LÍDER" : "seguidor") + " | cliques " + (MirrorBus.mirrorClicks ? "ON" : "off") + " | macros " + (MirrorBus.mirrorMacros ? "ON" : "off"));
            stage.addEventListener(Event.RESIZE, onResize);
            try { stage.nativeWindow.addEventListener("resize", onWinBounds); } catch (eNW:Error) {}
            applyResolution();
            applyDisplayPrefs();
            if (isVirtual()) setTimeout(function():void { verifyVirtual(false); }, 1500);
            controls = new Sidebar([
                ["play", "Entrar / Relogar", onPlayItem],
                ["bolt", "Macros", openMacros],
                ["user", "Contas", openAccounts],
                ["gear", "Configurações", openSettings],
                ["doc", "Ver log", function():void { bridge.showText("Log", logLines.join("\n") + prevLogText()); }],
                ["home", "Tela cheia (F11)", toggleFullscreen],
                ["server", "Fixar/soltar barra (F10)", function():void { if (controls != null) controls.togglePinned(); }],
                ["exit", "Sair desta conta", logout]
            ]);
            controls.layout(sw(), uiScale());
            stage.addChild(controls);
            showHome();
            // Já abre o login do site (Chromium) logo no início.
            setTimeout(function():void { if (!inGame && session == null) playTapped(null); }, 700);
            if (!bootDone)
            {
                bootDone = true;
                try { NativeApplication.nativeApplication.addEventListener(InvokeEvent.INVOKE, onAppInvoke); } catch (eInv:Error) {}
            }
        }

        private function onPlayItem():void
        {
            if (inGame) relog(); else playTapped(null);
        }

        // Em alguns aparelhos o stage começa com tamanho 0; usa o tamanho real da tela nesse caso.
        private function sw():Number { return stage.stageWidth > 0 ? stage.stageWidth : stage.fullScreenWidth; }
        // Botões maiores em telas de muitos pixels (e menores se a resolução do jogo for reduzida).
        private function uiScale():Number { return Math.max(1, Math.min(2.5, sh() / 650)); }
        private function sh():Number { return stage.stageHeight > 0 ? stage.stageHeight : stage.fullScreenHeight; }

        // Fundo base (degradê preto/vinho). Fora do palco (barras do Modo PC) as cores
        // continuam iguais às pontas do degradê, então não aparece emenda.
        private function drawBg():void
        {
            // Dentro do jogo o fundo do menu sai de cena: o mapa do jogo é desenhado ATRÁS do app e a imagem o cobria.
            if (inGame) { bgLayer.visible = false; graphics.clear(); return; }
            bgLayer.visible = true;
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            var g:Graphics = graphics;
            g.clear();
            g.beginFill(BG_TOP);    g.drawRect(-4096, -4096, w + 8192, 4096); g.endFill();
            g.beginFill(BG_BOTTOM); g.drawRect(-4096, h, w + 8192, 4096);     g.endFill();
            var m:Matrix = new Matrix();
            m.createGradientBox(w + 8192, h, Math.PI / 2, -4096, 0);
            g.beginGradientFill(GradientType.LINEAR, [BG_TOP, BG_BOTTOM], [1, 1], [0, 255], m);
            g.drawRect(-4096, 0, w + 8192, h); g.endFill();
            m = new Matrix();
            m.createGradientBox(w * 1.1, h * 1.3, 0, w * 0.3 - w * 0.55, h * 0.45 - h * 0.65);
            g.beginGradientFill(GradientType.RADIAL, [0x7C3AED, 0x7C3AED], [0.22, 0], [0, 255], m);
            g.drawRect(0, 0, w, h); g.endFill();
            layoutBg();
        }

        // Carrega a imagem de fundo empacotada no app (assets/fundo.jpg).
        private function loadBgImage():void
        {
            try
            {
                var l:Loader = new Loader();
                l.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void {
                    try
                    {
                        bgBmp = Bitmap(l.content);
                        bgBmp.smoothing = true;
                        bgLayer.addChildAt(bgBmp, 0);
                        layoutBg();
                    }
                    catch (e2:Error) { log("Fundo: " + e2.message); }
                });
                l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(e:IOErrorEvent):void { log("Fundo: " + e.text); });
                l.load(new URLRequest("app:/assets/fundo.jpg"));
            }
            catch (err:Error) { log("Fundo: " + err.message); }
        }

        // A imagem preenche a tela toda (sem distorcer, cortando o excesso) e recebe uma sombra
        // mais escura à esquerda, onde ficam os botões, para o texto ficar legível.
        private function layoutBg():void
        {
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            bgLayer.scrollRect = new Rectangle(0, 0, w, h);   // não vaza para as barras do Modo PC
            if (bgBmp && bgBmp.bitmapData)
            {
                var sc:Number = Math.max(w / bgBmp.bitmapData.width, h / bgBmp.bitmapData.height);
                bgBmp.scaleX = bgBmp.scaleY = sc;
                bgBmp.x = (w - bgBmp.bitmapData.width * sc) / 2;
                bgBmp.y = (h - bgBmp.bitmapData.height * sc) / 2;
            }
            shade.graphics.clear();   // área de trabalho lisa (sem sombra sobre imagem)
        }

        // A janela mudou de tamanho (arrastar/maximizar): troca entre "sem zoom" e "ajustar" se precisar.
        private function onWinBounds(e:Event):void
        {
            // Snap do Windows / redimensionar: reaplica escala e avisa o jogo + UI.
            try { applyResolution(); } catch (e1:Error) {}
            try
            {
                if (controls != null) controls.layout(sw(), uiScale());
                topW = sw(); topH = sh();
            }
            catch (e2:Error) {}
            if (inGame)
            {
                notifyResize();
                scheduleKicks();
            }
        }

        private function onResize(e:Event):void
        {
            if (stage.scaleMode != wantedScaleMode()) applyResolution();
            if (sw() == lastW && sh() == lastH) return;
            lastW = sw(); lastH = sh();
            drawBg();
            if (!inGame) showHome();
            if (controls) controls.layout(sw(), uiScale());
            if (inGame) notifyResize();
        }

        private function stackOf(err:Error):String
        {
            var st:String = err.getStackTrace();
            return st ? "\n" + st : "";
        }

        private function onUncaught(e:UncaughtErrorEvent):void
        {
            // Sempre engole o erro: se não der preventDefault, o runtime AIR pode FECHAR o app inteiro.
            try { e.preventDefault(); } catch (e0:Error) {}
            var m:String = (e.error is Error) ? (Error(e.error).message + stackOf(Error(e.error))) : String(e.error);
            log("ERRO: " + m);
            if (!inGame) fatal(m);
        }

        // Mostra o erro na tela (fundo amarelo) em vez de ficar branco sem explicação.
        private function fatal(msg:String):void
        {
            try
            {
                var tf:TextField = new TextField();
                tf.defaultTextFormat = new TextFormat("_sans", 22, 0x000000);
                tf.background = true; tf.backgroundColor = 0xFFEE00;
                tf.multiline = true; tf.wordWrap = true;
                tf.x = 20; tf.y = 20;
                tf.width = Math.max(300, sw() - 40);
                tf.text = "ERRO NO LAUNCHER:\n" + msg;
                addChild(tf);
            }
            catch (e2:Error) {}
        }

        // ---------- log ----------
        public function log(s:String):void
        {
            var d:Date = new Date();
            var line:String = pad(d.hours) + ":" + pad(d.minutes) + ":" + pad(d.seconds) + "  " + s;
            logLines.push(line);
            if (logLines.length > 400) logLines.shift();
            logBuf.push(line);
        }

        // Log em arquivo: sobrevive ao fechar/reabrir o app. launcher.log = sessão atual, launcher_prev.log = a anterior.
        private var logBuf:Array = [];
        private var logTimer:Timer;
        private var prevLog:String = "";
        private function logDir():File { return File.applicationStorageDirectory; }
        private function initLogFile():void
        {
            try
            {
                var cur:File = logDir().resolvePath("launcher.log");
                var prev:File = logDir().resolvePath("launcher_prev.log");
                if (cur.exists && cur.size > 0)
                {
                    var b:ByteArray = readFile(cur);
                    var t:String = b.readUTFBytes(b.length);
                    if (t.length > 60000) t = t.substring(t.length - 60000);   // só o final
                    prevLog = t;
                    cur.moveTo(prev, true);
                }
            }
            catch (e:Error) {}
            logTimer = new Timer(2000);
            logTimer.addEventListener(TimerEvent.TIMER, flushLog);
            logTimer.start();
        }
        private function flushLog(e:TimerEvent = null):void
        {
            if (logBuf.length == 0) return;
            var txt:String = logBuf.join("\n") + "\n";
            logBuf = [];
            try
            {
                var f:File = logDir().resolvePath("launcher.log");
                if (f.exists && f.size > 400000) f.deleteFile();           // limite de tamanho
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.APPEND);
                fs.writeUTFBytes(txt);
                fs.close();
            }
            catch (err:Error) {}
        }
        private function prevLogText():String
        {
            return prevLog.length ? "\n\n----- SESSÃO ANTERIOR (antes de reabrir o app) -----\n" + prevLog : "";
        }
        private function pad(n:int):String { return n < 10 ? "0" + n : String(n); }

        private function onBgChange(e:Event):void
        {
            try { stage.frameRate = Math.max(Prefs.fps, 24); } catch (err:Error) {}
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE; } catch (err2:Error) {}
            try { NativeApplication.nativeApplication["executeInBackground"] = true; } catch (err3:Error) {}
        }

        // ---------- preferências de exibição ----------
        private function applyDisplayPrefs():void
        {
            stage.quality = Prefs.quality;     // StageQuality.LOW / MEDIUM / HIGH
            stage.frameRate = Prefs.fps;
            // Pede à tela do aparelho a taxa mais próxima (60 / 90 / 120 Hz...).
            try { if (bridge && bridge.available) bridge.setRefreshRate(Prefs.fps); } catch (err:Error) {}
        }

        // Texto com a taxa de atualização real da tela (ex.: "120 Hz"), para o menu e o log.
        private function hzText():String
        {
            try
            {
                var hz:Number = (bridge && bridge.available) ? bridge.displayHz() : 0;
                if (hz > 0) return Math.round(hz) + " Hz";
            }
            catch (err:Error) {}
            return "? Hz";
        }

        // ---------- UI inicial ----------
        // Layout desenhado numa área de 1000x560 (cabeçalho, barra lateral, destaque, acesso rápido,
        // informações e barra de status) e escalado para caber em qualquer tela.
        private function showHome():void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            if (inGame) return;
            var s:Number = Math.max(0.6, Math.min(sh() / 560, sw() / 900, 2.5));
            var box:Sprite = new Sprite();
            box.scaleX = box.scaleY = s;
            box.x = sw() / 2; box.y = sh() / 2;
            ui.addChild(box);

            var logo:Sprite = new Sprite();
            logo.x = -40; logo.y = -200;
            box.addChild(logo);
            loadLogo(logo, 80);
            var t:TextField = Win.label(box, "LEGEND", 34, 0xFFFFFF, 0, -108, true);
            t.x = -t.textWidth / 2 - 2;
            var sub:TextField = Win.label(box, "V E R S Ã O   P C", 12, Btn.ACCENT_LIGHT, 0, -62, true);
            sub.x = -sub.textWidth / 2 - 2;

            status = new TextField();
            status.defaultTextFormat = new TextFormat("_sans", 14, 0xFFFFFF, false, null, null, null, null, "center");
            status.width = 640; status.height = 26; status.x = -320; status.y = 4;
            status.multiline = false; status.wordWrap = false;
            status.selectable = false; status.mouseEnabled = false;
            status.text = lastStatus != "" ? lastStatus : "Abrindo o login do site...";
            paintStatus();
            box.addChild(status);

            var go:Btn = new Btn(Btn.PRIMARY, 320, 56, "ENTRAR NO JOGO", "", playTapped);
            go.x = 0; go.y = 90;
            box.addChild(go);
            Win.wrapLabel(box, "Entre com a sua conta na janela que abre. Depois do login o jogo abre sozinho aqui. A barra à esquerda tem os macros, as configurações e o log (F10 esconde a barra).", 12, Btn.TEXT_MUTED, -270, 140, 540, 4);
            var ver:TextField = Win.label(box, VERSION, 12, Btn.TEXT_MUTED, 0, 230);
            ver.x = -ver.textWidth / 2 - 2;
        }

        // ---------- abas da tela inicial ----------
        private var homeTab:String = "inicio";
        private function setTab(t:String):void { homeTab = t; showHome(); }
        private function pickServer(i:int):void
        {
            if (i < 0 || i >= Platforms.LIST.length) return;
            platformIdx = i; Prefs.platform = i;
            showHome();
        }

        // Aba Início: destaque, informações e notícias.
        private function buildInicio(box:Sprite, pname:String):void
        {
            // ----- destaque -----
            var hero:Sprite = new Sprite();
            hero.x = 216; hero.y = 86;
            box.addChild(hero);
            var hm:Matrix = new Matrix();
            hm.createGradientBox(500, 190, 0, 0, 0);
            hero.graphics.lineStyle(1, 0x3B2F85, 1);
            hero.graphics.beginGradientFill(GradientType.LINEAR, [0x2E1A6E, 0x120F33], [1, 1], [0, 255], hm);
            hero.graphics.drawRoundRect(0, 0, 500, 190, 32, 32);
            hero.graphics.endFill();
            Win.label(hero, "SERVIDOR SELECIONADO", 12, Btn.ACCENT_LIGHT, 28, 22, true);
            Win.fitLabel(hero, pname, 34, 0xFFFFFF, 28, 42, 290, true);
            Win.wrapLabel(hero, "Entre com a conta que você logou no site e continue sua aventura.", 13, Btn.TEXT_SOFT, 28, 92, 280, 2);
            var play:Btn = new Btn(Btn.PRIMARY, 150, 46, "JOGAR", "", playTapped);
            play.x = 28 + 75; play.y = 152;
            hero.addChild(play);
            var swap:Btn = new Btn(Btn.GHOST, 130, 40, "Trocar servidor", "", function(e:MouseEvent):void { setTab("jogo"); });
            swap.x = 28 + 150 + 12 + 65; swap.y = 152;
            hero.addChild(swap);
            var art:Sprite = new Sprite();
            art.x = 330; art.y = 10;
            art.filters = [new GlowFilter(0xFF2D55, 0.45, 24, 24, 1.5, 2)];
            hero.addChild(art);
            loadLogo(art, 170);

            // ----- informações (sob o destaque) -----
            var info:Sprite = new Sprite();
            info.x = 216; info.y = 288;
            box.addChild(info);
            Win.card(info, 0, 0, 500, 196, 18);
            Win.heading(info, "server", "Informações", 18, 12);
            var cacheTxt:String = "?";
            try { cacheTxt = cacheSizeText(); } catch (eC:Error) {}
            var rows:Array = [["Servidor", pname], ["Conexão", bridge.available ? "Pronta" : "ANE ausente"], ["Cache do jogo", cacheTxt], ["Versão do app", VERSION]];
            for (var ri:int = 0; ri < rows.length; ri++)
            {
                var cx0:Number = 18 + (ri % 2) * 242;
                var cy0:Number = 52 + int(ri / 2) * 70;
                Win.card(info, cx0, cy0, 230, 60, 12, 0x0B0A1E);
                Win.label(info, String(rows[ri][0]), 11, Btn.TEXT_MUTED, cx0 + 14, cy0 + 8);
                Win.fitLabel(info, String(rows[ri][1]), 15, (ri == 1 && bridge.available) ? Btn.GREEN : Btn.TEXT, cx0 + 14, cy0 + 28, 204, true);
            }

            // ----- notícias da página de login (direita) -----
            var host:String = String(Platforms.LIST[platformIdx][1]);
            var news:Sprite = new Sprite();
            news.x = 732; news.y = 86;
            box.addChild(news);
            Win.card(news, 0, 0, 252, 398, 18);
            Win.heading(news, "doc", "Últimas Notícias", 18, 14);
            var reload:Sprite = new Sprite();
            var rl:TextField = Win.label(reload, "Atualizar", 11, Btn.ACCENT_LIGHT, 0, 0, true);
            reload.x = 234 - rl.width; reload.y = 18;
            reload.mouseChildren = false; reload.buttonMode = true;
            reload.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { NewsFeed.reset(host); showHome(); });
            news.addChild(reload);
            var list:Array = NewsFeed.items(host);
            if (list == null)
            {
                Win.label(news, "Carregando notícias...", 13, Btn.TEXT_MUTED, 18, 62);
                NewsFeed.logger = log;
                NewsFeed.load(host, function():void { if (!inGame) showHome(); });
            }
            else if (list.length == 0)
            {
                Win.wrapLabel(news, "Não consegui ler as notícias do site agora. Clique em Atualizar para tentar de novo.", 13, Btn.TEXT_MUTED, 18, 62, 216, 5);
            }
            else
            {
                for (var ni2:int = 0; ni2 < list.length && ni2 < 4; ni2++)
                {
                    var iy:Number = 50 + ni2 * 86;
                    var row:Sprite = new Sprite();
                    row.x = 12; row.y = iy;
                    row.graphics.lineStyle(1, Win.LINE, 1);
                    if (ni2 > 0) { row.graphics.moveTo(6, -4); row.graphics.lineTo(222, -4); }
                    row.graphics.lineStyle(0, 0, 0);
                    row.graphics.beginFill(Btn.ACCENT, 1); row.graphics.drawCircle(12, 14, 4); row.graphics.endFill();
                    Win.wrapLabel(row, String(list[ni2].title), 13, Btn.TEXT, 26, 4, 196, 3, true);
                    if (String(list[ni2].date) != "") Win.label(row, String(list[ni2].date), 11, Btn.TEXT_MUTED, 26, 62);
                    row.graphics.beginFill(0xFFFFFF, 0); row.graphics.drawRect(0, -4, 228, 82); row.graphics.endFill();
                    row.mouseChildren = false; row.buttonMode = true;
                    var link:String = String(list[ni2].url);
                    row.addEventListener(MouseEvent.CLICK, makeOpener(link));
                    news.addChild(row);
                }
            }

        }

        // Aba Jogo: escolha do servidor na própria tela + botão de entrar.
        private function buildJogo(box:Sprite, pname:String):void
        {
            var lp:Sprite = new Sprite();
            lp.x = 216; lp.y = 86;
            box.addChild(lp);
            Win.card(lp, 0, 0, 400, 398, 18);
            Win.heading(lp, "server", "Escolha o servidor", 18, 14);
            for (var si:int = 0; si < Platforms.LIST.length; si++)
            {
                var sel:Boolean = (si == platformIdx);
                var row:Sprite = new Sprite();
                row.x = 14; row.y = 52 + si * 56;
                Win.card(row, 0, 0, 372, 48, 12, sel ? 0x1C1650 : 0x0B0A1E, sel ? Btn.ACCENT_LIGHT : Win.LINE);
                row.graphics.lineStyle(2, sel ? Btn.ACCENT_LIGHT : Btn.TEXT_MUTED, 1);
                row.graphics.drawCircle(24, 24, 8);
                if (sel) { row.graphics.lineStyle(0, 0, 0); row.graphics.beginFill(Btn.ACCENT_LIGHT, 1); row.graphics.drawCircle(24, 24, 4); row.graphics.endFill(); }
                Win.fitLabel(row, String(Platforms.LIST[si][0]), 14, sel ? 0xFFFFFF : Btn.TEXT, 46, 6, 310, true);
                Win.fitLabel(row, String(Platforms.LIST[si][1]), 11, Btn.TEXT_MUTED, 46, 26, 310);
                row.mouseChildren = false; row.buttonMode = true;
                row.addEventListener(MouseEvent.CLICK, makePicker(si));
                lp.addChild(row);
            }

            var rp:Sprite = new Sprite();
            rp.x = 632; rp.y = 86;
            box.addChild(rp);
            Win.card(rp, 0, 0, 352, 398, 18, 0x120F33, 0x3B2F85);
            Win.heading(rp, "play", "Entrar no jogo", 18, 14);
            Win.label(rp, "SERVIDOR", 11, Btn.ACCENT_LIGHT, 22, 62, true);
            Win.fitLabel(rp, pname, 24, 0xFFFFFF, 22, 80, 308, true);
            Win.wrapLabel(rp, "Clique em Jogar para entrar com a sua conta no site do servidor. Depois do login, o jogo abre sozinho.", 13, Btn.TEXT_SOFT, 22, 126, 308, 4);
            var go:Btn = new Btn(Btn.PRIMARY, 308, 54, "JOGAR", "", playTapped);
            go.x = 22 + 154; go.y = 250;
            rp.addChild(go);
            var lo:Btn = new Btn(Btn.GHOST, 308, 40, "Sair da conta", "", logoutTapped);
            lo.x = 22 + 154; lo.y = 312;
            rp.addChild(lo);
            Win.wrapLabel(rp, "Para trocar de conta, use Sair da conta e entre de novo.", 11, Btn.TEXT_MUTED, 22, 346, 308, 2);
        }

        private function makePicker(i:int):Function
        {
            return function(e:MouseEvent):void { pickServer(i); };
        }

        private function makeOpener(u:String):Function
        {
            return function(e:MouseEvent):void { try { navigateToURL(new URLRequest(u)); } catch (err:Error) { log("Abrir link: " + err.message); } };
        }

        // Carrega o ícone do app (assets/icons/icon512.png) dentro de 'holder', com 'size' px de lado.
        private function loadLogo(holder:Sprite, size:Number):void
        {
            try
            {
                var l:Loader = new Loader();
                l.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void {
                    try
                    {
                        var bm:Bitmap = Bitmap(l.content);
                        bm.smoothing = true;
                        bm.width = size; bm.height = size;
                        holder.addChild(bm);
                    }
                    catch (e2:Error) { log("Logo: " + e2.message); }
                });
                l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(e:IOErrorEvent):void { log("Logo: " + e.text); });
                l.load(new URLRequest("app:/assets/icons/icon512.png"));
            }
            catch (err:Error) { log("Logo: " + err.message); }
        }

        // Mensagens de erro ficam em amarelo; o resto em branco.
        private function paintStatus():void
        {
            if (!status) return;
            status.textColor = /erro|falha|faltam|indispon/i.test(status.text) ? 0xFFE066 : 0xFFFFFF;
        }

        private function setStatus(s:String):void { lastStatus = s; if (status) { status.text = s; paintStatus(); } log(s); }

        // ---------- ações da tela inicial ----------
        private function chooseTapped(e:MouseEvent):void { openPlatformMenu(); }

        private function openPlatformMenu():void
        {
            var names:Array = [];
            for each (var p:Array in Platforms.LIST) names.push(p[0]);
            menuMode = M_PLATFORM;
            bridge.showMenu("Escolha a plataforma", names);
        }

        private function settingsTapped(e:MouseEvent):void { openSettings(); }

        // Entra com a última conta usada (ou cria a primeira).
        private function playTapped(e:MouseEvent):void
        {
            var id:String = Accounts.last;
            if (id == "" || Accounts.find(id) == null) id = Accounts.newId();
            loginAs(id);
        }

        private function loginAs(id:String):void
        {
            curAcc = id;
            var a:Object = Accounts.find(id);
            setStatus("Abrindo o login" + (a != null ? " (" + String(a.name) + ")" : "") + "...");
            bridge.login(Platforms.LIST[platformIdx][1], id);
        }

        // ---------- contas ----------
        private function openAccounts():void
        {
            var names:Array = [];
            accMenuIds = [];
            for each (var a:Object in Accounts.all())
            {
                accMenuIds.push(String(a.id));
                var hasSess:Boolean = a.session != undefined && String(a.session).length > 8;
                names.push(String(a.name) + (hasSess ? "  · rápido" : "") + (String(a.id) == curAcc ? "  ✓" : ""));
            }
            names.push("+ Adicionar outra conta (site)");
            if (accMenuIds.length > 0) names.push("Remover uma conta...");
            menuMode = M_ACC;
            bridge.showMenu("Contas (rápido = sessão salva)", names);
        }

        private function switchAccount(id:String):void
        {
            if (inGame) { curAcc = id; relog(); return; }
            // Login rápido: reusa a sessão guardada sem abrir o site de novo.
            var a:Object = Accounts.find(id);
            if (a != null && a.session != undefined && String(a.session).length > 8)
            {
                try
                {
                    session = JSON.parse(String(a.session));
                    if (session.host == undefined && session.site != undefined) session.host = session.site;
                    curAcc = id;
                    setStatus("Login rápido: " + String(a.name) + " (sessão pode estar vencida)...");
                    enterGameFromSession();
                    return;
                }
                catch (e:Error)
                {
                    log("sessão salva inválida: " + e.message);
                }
            }
            loginAs(id);
        }

        // Continua o fluxo de onGame a partir de uma sessão já montada.
        private function enterGameFromSession():void
        {
            applyResolution();
            port = bridge.startServer(session.host != undefined ? String(session.host) : Platforms.LIST[platformIdx][1]);
            if (port <= 0) { setStatus("Falha ao iniciar servidor local."); return; }
            bridge.keepAlive(true);
            setStatus("Baixando o jogo...");
            fbIndex = 0;
            fetchSwf();
        }

        private function onAccChoice(i:int):void
        {
            var n:int = accMenuIds.length;
            if (i >= 0 && i < n) { switchAccount(accMenuIds[i]); return; }
            if (i == n) { switchAccount(Accounts.newId()); return; }
            if (i == n + 1)
            {
                var names:Array = [];
                for each (var a:Object in Accounts.all()) names.push("Remover: " + String(a.name));
                menuMode = M_ACCDEL;
                bridge.showMenu("Remover conta", names);
            }
        }

        private function onAccDelChoice(i:int):void
        {
            if (i < 0 || i >= accMenuIds.length) return;
            var id:String = accMenuIds[i];
            bridge.clearSession(id);
            Accounts.remove(id);
            if (curAcc == id) curAcc = "";
            setStatus("Conta removida.");
        }

        private function logoutTapped(e:MouseEvent):void { logout(); }

        private function logTapped(e:MouseEvent):void { bridge.showText("Log", logLines.join("\n") + prevLogText()); }

        private function logout():void
        {
            bridge.clearSession(curAcc);
            if (curAcc != "") { Accounts.remove(curAcc); curAcc = ""; }
            setStatus("Conta desconectada.");
        }

        private function onError(e:StatusEvent):void { setStatus("Erro: " + e.level); }

        // ---------- menu nativo (um evento só, roteado por menuMode) ----------
        private function onMenu(e:StatusEvent):void
        {
            var i:int = int(e.level);
            switch (menuMode)
            {
                case M_PLATFORM:
                    if (i >= 0 && i < Platforms.LIST.length)
                    {
                        platformIdx = i; Prefs.platform = i;
                        if (gameLoader) { bridge.restartApp(); } else { showHome(); }
                    }
                    break;
                case M_SETTINGS: onSettingsChoice(i); break;
                case M_ACC: onAccChoice(i); break;
                case M_ACCDEL: onAccDelChoice(i); break;
                case M_QUALITY:
                    Prefs.quality = ["LOW", "MEDIUM", "HIGH"][i];
                    applyDisplayPrefs(); log("Qualidade: " + Prefs.quality);
                    break;
                case M_FPS:
                    if (i >= 0 && i < FPS_OPTIONS.length)
                    {
                        Prefs.fps = FPS_OPTIONS[i];
                        applyDisplayPrefs();
                        setTimeout(function():void { log("FPS: " + Prefs.fps); }, 1200);
                        if (Prefs.fps > 60) bridge.showText("FPS " + Prefs.fps,
                            "O app pede " + Prefs.fps + " FPS.\n\n" +
                            "Só aparece diferença se o monitor suportar essa taxa. " +
                            "Se o jogo for feito para 30 FPS, as animações podem ficar mais rápidas.");
                    }
                    break;
                case M_CACHE:
                    if (i == 0) clearCache();
                    else if (i == 1)
                    {
                        Prefs.fastNeg = !Prefs.fastNeg;
                        SwfFixer.fastNeg = Prefs.fastNeg;
                        log("Atalho para imagens inexistentes: " + (Prefs.fastNeg ? "ligado" : "desligado"));
                    }
                    break;
                case M_RES:
                    if (i >= 0 && i < RES_OPTIONS.length && RES_OPTIONS[i] == RES_CUSTOM) { openSlider(); break; }
                    if (i >= 0 && i < RES_OPTIONS.length)
                    {
                        Prefs.resHeight = RES_OPTIONS[i];
                        applyResolution();
                        if (isVirtual()) setTimeout(function():void { verifyVirtual(true); }, 900);
                        if (!inGame) showHome();
                        else bridge.showText("Resolução", "Para o jogo se reorganizar por completo, reinicie o app (Configurações > Reiniciar o app).");
                    }
                    break;
                case M_EXIT:
                    if (i == 0) { log("Indo para segundo plano"); flushLog(); bridge.toBackground(); }
                    else if (i == 1) { flushLog(); bridge.keepAlive(false); NativeApplication.nativeApplication.exit(); }
                    break;
            }
        }

        private function openSettings():void
        {
            menuMode = M_SETTINGS;
            var lead:String = MirrorBus.isLeaderSlot(windowSlot) ? "LÍDER" : ("seguidor (líder j" + MirrorBus.leaderSlot + ")");
            bridge.showMenu("Configurações", [
                "Nova janela — outra conta (" + instances.length + "/" + MAX_WINDOWS + ")",
                "Espelho: esta janela é " + lead + " → tornar LÍDER",
                "Espelho CLIQUES: " + (MirrorBus.mirrorClicks ? "LIGADO" : "desligado"),
                "Espelho MACROS: " + (MirrorBus.mirrorMacros ? "LIGADO" : "desligado"),
                "Resolução (" + resLabel(Prefs.resHeight) + ")",
                "Qualidade gráfica (" + Prefs.quality + ")",
                "FPS (" + Prefs.fps + ")",
                "Cache do jogo",
                "Mostrar log",
                "Trocar plataforma",
                "Sair da conta",
                "Reiniciar o app",
                "Fechar esta janela",
                "Sair do app (todas as janelas)",
                "Relogar (recarregar o jogo)",
                "Tela cheia (F11)"
            ]);
        }

        private function onSettingsChoice(i:int):void
        {
            switch (i)
            {
                case 0:
                    if (instances.length >= MAX_WINDOWS)
                        bridge.showText("Janelas", "Já há " + MAX_WINDOWS + " janelas abertas (máximo).\nFeche uma para abrir outra conta.");
                    else
                        openExtraWindow();
                    break;
                case 1:
                    MirrorBus.setLeader(windowSlot);
                    log("Esta janela (" + windowSlot + ") é o LÍDER do espelho.");
                    break;
                case 2:
                    MirrorBus.mirrorClicks = !MirrorBus.mirrorClicks;
                    log("Espelho CLIQUES: " + (MirrorBus.mirrorClicks ? "LIGADO" : "desligado"));
                    break;
                case 3:
                    MirrorBus.mirrorMacros = !MirrorBus.mirrorMacros;
                    log("Espelho MACROS: " + (MirrorBus.mirrorMacros ? "LIGADO" : "desligado"));
                    break;
                case 4: openResolutionMenu(); break;
                case 5: menuMode = M_QUALITY; bridge.showMenu("Qualidade gráfica", ["Baixa", "Média", "Alta"]); break;
                case 6: openFpsMenu(); break;
                case 7:
                    menuMode = M_CACHE;
                    bridge.showMenu("Cache do jogo (" + cacheSizeText() + ")", ["Apagar cache",
                        "Atalho p/ imagens inexistentes: " + (Prefs.fastNeg ? "LIGADO" : "desligado"), "Voltar"]);
                    break;
                case 8: bridge.showText("Log", logLines.join("\n") + prevLogText()); break;
                case 9: openPlatformMenu(); break;
                case 10: logout(); break;
                case 11: bridge.restartApp(); break;
                case 12: closeThisWindow(); break;
                case 13: askExit(); break;
                case 14: relog(); break;
                case 15: toggleFullscreen(); break;
            }
        }

        // Relogar: fecha o jogo atual e entra de novo com um login novo (sem reiniciar o app).
        private function relog():void
        {
            if (!inGame || gameLoader == null) { log("Relogar: o jogo não está aberto."); return; }
            log("Relogando...");
            try { if (macroPanel != null) macroPanel.stopAll(); } catch (eM:Error) {}
            try { if (topTimer) topTimer.stop(); } catch (eT:Error) {}
            kickGen++;
            try { SwfFixer.gameDomain = null; } catch (eD:Error) {}
            myGameDomain = null;
            try { gameLoader.unloadAndStop(true); } catch (eU:Error) {}
            try { if (gameLoader.parent != null) gameLoader.parent.removeChild(gameLoader); } catch (eR:Error) {}
            gameLoader = null;
            // o jogo põe janelas direto no palco: tira tudo que não é o próprio app
            try
            {
                for (var ci:int = stage.numChildren - 1; ci >= 0; ci--)
                {
                    var ch:DisplayObject = stage.getChildAt(ci);
                    if (ch != this) { try { stage.removeChild(ch); } catch (eX:Error) {} }
                }
            }
            catch (eS:Error) {}
            try { if (controls != null) stage.addChild(controls); } catch (eC2:Error) {}
            inGame = false;
            drawBg();
            showHome();
            if (controls != null) controls.pinned = false;
            setStatus("Relogando...");
            bridge.login(Platforms.LIST[platformIdx][1], curAcc);
        }

        // ---------- espelho (cliques + macros) ----------
        private function hookMirrorMouse(on:Boolean):void
        {
            if (stage == null) return;
            if (on && !mirrorMouseHooked)
            {
                stage.addEventListener(MouseEvent.MOUSE_DOWN, onMirrorMouse, true, 900);
                stage.addEventListener(MouseEvent.MOUSE_UP, onMirrorMouse, true, 900);
                stage.addEventListener(MouseEvent.CLICK, onMirrorMouse, true, 900);
                mirrorMouseHooked = true;
            }
            else if (!on && mirrorMouseHooked)
            {
                stage.removeEventListener(MouseEvent.MOUSE_DOWN, onMirrorMouse, true);
                stage.removeEventListener(MouseEvent.MOUSE_UP, onMirrorMouse, true);
                stage.removeEventListener(MouseEvent.CLICK, onMirrorMouse, true);
                mirrorMouseHooked = false;
            }
        }

        // Liga SwfFixer a ESTA janela (stage + domínio do jogo). Obrigatório antes de qualquer macro.
        public function bindSwfContext():void
        {
            try
            {
                SwfFixer.rootStage = stage;
                if (myGameDomain != null) SwfFixer.gameDomain = myGameDomain;
                if (macroPanel != null)
                {
                    macroPanel.hostStage = stage;
                    macroPanel.hostDomain = myGameDomain;
                }
            }
            catch (e:Error) {}
        }

        private function onMirrorMouse(e:MouseEvent):void
        {
            if (mirrorInjecting || !inGame) return;
            if (!MirrorBus.mirrorClicks || !MirrorBus.isLeaderSlot(windowSlot)) return;
            // Enquanto um macro roda no líder, NÃO espelha cliques: o próprio macro já gera cliques
            // e a seguidora deve rodar o macro dela (broadcastMacro), não coordenadas soltas.
            try
            {
                if (macroPanel != null && macroPanel.isRunning()) return;
            }
            catch (eR:Error) {}
            var t:DisplayObject = e.target as DisplayObject;
            var walk:DisplayObject = t;
            while (walk != null)
            {
                if (walk is MacroPanel || walk is Sidebar || walk is SliderPanel || walk is Btn) return;
                walk = walk.parent;
            }
            var typ:String = e.type == MouseEvent.MOUSE_DOWN ? "mouseDown"
                : (e.type == MouseEvent.MOUSE_UP ? "mouseUp" : "click");
            MirrorBus.broadcastClick(windowSlot, typ, e.stageX, e.stageY, stage.stageWidth, stage.stageHeight);
        }

        // Chamado pelas seguidoras: injeta evento de mouse no mesmo ponto (escala se o palco for outro tamanho).
        public function injectMirrorClick(type:String, srcX:Number, srcY:Number, srcW:Number, srcH:Number):void
        {
            if (!inGame || stage == null || mirrorInjecting) return;
            var w:Number = stage.stageWidth > 0 ? stage.stageWidth : srcW;
            var h:Number = stage.stageHeight > 0 ? stage.stageHeight : srcH;
            if (srcW < 1) srcW = w;
            if (srcH < 1) srcH = h;
            var x:Number = srcX * w / srcW;
            var y:Number = srcY * h / srcH;
            mirrorInjecting = true;
            try
            {
                var list:Array = stage.getObjectsUnderPoint(new Point(x, y));
                var target:DisplayObject = stage;
                for (var i:int = list.length - 1; i >= 0; i--)
                {
                    var o:DisplayObject = list[i] as DisplayObject;
                    if (o == null) continue;
                    if (o is MacroPanel || o is Sidebar || o is SliderPanel) continue;
                    // sobe até achar um InteractiveObject típico; senão usa o próprio
                    target = o;
                    break;
                }
                var local:Point = target.globalToLocal(new Point(x, y));
                var et:String = type == "mouseDown" ? MouseEvent.MOUSE_DOWN
                    : (type == "mouseUp" ? MouseEvent.MOUSE_UP : MouseEvent.CLICK);
                var ev:MouseEvent = new MouseEvent(et, true, false, local.x, local.y, null, false, false, false, true, 0);
                target.dispatchEvent(ev);
                log("Espelho RX " + type + " @ " + int(x) + "," + int(y) + " → " + (target.name != null ? target.name : "?"));
            }
            catch (err:Error) { log("Espelho inject: " + err.message); }
            mirrorInjecting = false;
        }

        public function injectMirrorMacro(action:String):void
        {
            if (!inGame) { log("Espelho macro '" + action + "': janela sem jogo"); return; }
            ensureMacroPanel();
            bindSwfContext();
            log("Espelho macro RX (janela " + windowSlot + "): " + action);
            try { macroPanel.remoteAction(action); } catch (e:Error) { log("Espelho macro erro: " + e.message); }
        }

        private function ensureMacroPanel():void
        {
            if (macroPanel != null) return;
            macroPanel = new MacroPanel();
            macroPanel.logger = log;
            try { macroPanel.dumpDir = bridge.modsPath(); } catch (eMods:Error) {}
            macroPanel.onText = function(title:String, text:String):void { bridge.showText(title, text); };
            macroPanel.onWake = function():void { if (!macroPanel.isOpen) macroPanel.show(stage, sw(), sh(), uiScale()); };
            macroPanel.onBeforeAction = function():void {
                bindSwfContext();
                macroPanel.hostStage = stage;
                macroPanel.hostDomain = myGameDomain;
            };
            macroPanel.onMirrorMacro = function(action:String):void
            {
                if (MirrorBus.isLeaderSlot(windowSlot)) MirrorBus.broadcastMacro(windowSlot, action);
            };
        }

        // ---------- janela de macros ----------
        // Pop-up por cima do jogo (dentro do app). O botão ▶ ao lado da engrenagem e o item "Macros" do menu abrem/fecham.
        private function openMacros():void
        {
            ensureMacroPanel();
            if (macroPanel.isOpen) { macroPanel.hide(); return; }
            macroPanel.show(stage, sw(), sh(), uiScale());
        }

        private function openFpsMenu():void
        {
            var names:Array = [];
            for each (var f:int in FPS_OPTIONS)
                names.push(f + " FPS" + (f == Prefs.fps ? "  ✓" : "") + (f == 120 ? "  (precisa de tela 120 Hz)" : ""));
            menuMode = M_FPS;
            bridge.showMenu("FPS do jogo (atual: " + Prefs.fps + ")", names);
        }

        // ---------- resolução ----------
        // A troca de resolução NÃO usa mais o Android (setFixedSize não muda o tamanho do palco do AIR).
        // Modo PC = StageScaleMode.SHOW_ALL: o palco passa a ter o tamanho do SWF (1250x650, definido em
        // [SWF(...)] / -default-size) e o AIR amplia tudo para a tela mantendo a proporção (barras pretas
        // nos lados se a tela for mais larga). O jogo vê um palco de 1250x650 e se organiza para ele.
        private function screenSize():Array
        {
            var w:int = stage.fullScreenWidth > 0 ? stage.fullScreenWidth : int(Capabilities.screenResolutionX);
            var h:int = stage.fullScreenHeight > 0 ? stage.fullScreenHeight : int(Capabilities.screenResolutionY);
            if (h > w) { var t:int = w; w = h; h = t; }
            return [w, h];
        }

        // Valor salvo que não existe mais na lista (de versões antigas) volta para o Modo PC.
        private function validRes():int
        {
            var v:int = Prefs.resHeight;
            if (RES_OPTIONS.indexOf(v) < 0) { v = RES_BASE; Prefs.resHeight = RES_BASE; }
            return v;
        }

        private function isPcMode():Boolean { var v:int = validRes(); return v >= RES_BASE && v < RES_VIRT_BASE; }
        private function isVirtual():Boolean { return validRes() >= RES_VIRT_BASE; }

        private function resLabel(v:int):String
        {
            var s:Array = screenSize();
            if (v == RES_CUSTOM) return "Personalizada " + virtW(customH()) + "x" + customH();
            if (v >= RES_VIRT_BASE && v - RES_VIRT_BASE < RES_VIRT.length)
                return RES_VIRT[v - RES_VIRT_BASE][2] + " " + RES_VIRT[v - RES_VIRT_BASE][0] + "x" + RES_VIRT[v - RES_VIRT_BASE][1];
            if (v >= RES_BASE && v < RES_VIRT_BASE && v - RES_BASE < RES_FIXED.length)
                return "Ajustar à janela (" + RES_FIXED[v - RES_BASE][0] + "x" + RES_FIXED[v - RES_BASE][1] + ")";
            return "Tamanho da janela (automático, sem zoom)";
        }

        private function openResolutionMenu():void
        {
            var cur:int = validRes();
            var names:Array = [];
            for each (var v:int in RES_OPTIONS)
            {
                var n:String = resLabel(v);
                if (v == cur) n += "  ✓";
                names.push(n);
            }
            menuMode = M_RES;
            bridge.showMenu("Tela do jogo", names);
        }

        // "Tamanho da janela": o jogo usa a área real da janela (sem zoom). Só se a janela ficar menor
        // que o jogo (1352x650) ele volta a encolher/ajustar, para as janelas do jogo não cortarem.
        private function windowTooSmall():Boolean
        {
            try
            {
                if (stage.displayState != StageDisplayState.NORMAL)
                    return stage.fullScreenWidth < 1340 || stage.fullScreenHeight < 640;
                var nw:Object = stage.nativeWindow;
                return (nw.width - 16) < 1340 || (nw.height - 40) < 640;
            }
            catch (e:Error) {}
            return false;
        }

        private function wantedScaleMode():String
        {
            // Modo PC / virtual: letra box (SHOW_ALL).
            // "Tamanho da janela": NO_SCALE sempre — assim o snap esquerdo/direito do Windows
            // preenche a metade da tela e o jogo recebe RESIZE no tamanho real.
            if (isPcMode() || isVirtual()) return StageScaleMode.SHOW_ALL;
            return StageScaleMode.NO_SCALE;
        }

        private function applyResolution():void
        {
            var want:String = wantedScaleMode();
            if (stage.scaleMode != want) stage.scaleMode = want;
            stage.align = StageAlign.TOP_LEFT;
            applyVirtualStage();
            var rl:String = "Resolução: " + resLabel(validRes());
            if (rl != lastResLog) { lastResLog = rl; log(rl); }
            setTimeout(logStage, 300);
            if (inGame) for each (var d:int in [50, 400, 1200]) setTimeout(notifyResize, d);
        }

        // Resolução virtual (1920x1080 / 2560x1440): o jogo só reorganiza a tela se o PALCO mudar de
        // tamanho. O AIR do Android não deixa o app mudar o tamanho da tela por fora (testado: só
        // encolhe a imagem), então tentamos pelo próprio palco e CONFERIMOS o resultado.
        private function baseRatio():Number { return (loaderInfo && loaderInfo.height > 0) ? loaderInfo.width / loaderInfo.height : 2.08; }
        private function customH():int { var h:int = Prefs.customH; return (h >= CUSTOM_MIN && h <= CUSTOM_MAX) ? h : 800; }
        private function virtW(h:int):int { return Math.round(h * baseRatio()); }
        // [largura, altura, nome] da resolução virtual escolhida (Full HD, 2K ou Personalizada)
        private function virtSize():Array
        {
            var v:int = validRes();
            if (v == RES_CUSTOM) return [virtW(customH()), customH(), "Personalizada"];
            return RES_VIRT[v - RES_VIRT_BASE];
        }
        private function applyVirtualStage():void
        {
            if (!isVirtual()) return;
            var r:Array = virtSize();
            try { stage["stageWidth"] = int(r[0]); stage["stageHeight"] = int(r[1]); }
            catch (err:Error) { log("Palco virtual: " + err.message); }
        }

        // Confere se o palco ficou mesmo com o tamanho pedido. Se o aparelho/AIR não aceitar, volta para
        // o Modo PC (em vez de deixar a tela quebrada) e avisa.
        private function verifyVirtual(announce:Boolean):void
        {
            if (!isVirtual() || !stage) return;
            var r:Array = virtSize();
            if (stage.stageWidth == int(r[0]) && stage.stageHeight == int(r[1]))
            {
                log("Resolução " + r[0] + "x" + r[1] + ": ok (palco " + stage.stageWidth + "x" + stage.stageHeight + ")");
                return;
            }
            log("Resolução " + r[0] + "x" + r[1] + " NÃO aceita pelo AIR (palco ficou " + stage.stageWidth + "x" + stage.stageHeight + "). Voltando ao Padrão.");
            Prefs.resHeight = RES_BASE;
            applyResolution();
            if (!inGame) showHome();
            if (announce) bridge.showText("Resolução",
                "Este aparelho não aceitou mudar o tamanho da tela do jogo para " + r[0] + "x" + r[1] + ". Voltei para o Padrão para não quebrar a tela.\n\n" +
                "Opção mais parecida: \"Nativa\" (usa todos os pixels da tela).");
        }

        private var lastResLog:String = "";
        private var lastStageLog:String = "";
        private function logStage():void
        {
            var sc:Array = screenSize();
            var m:String = "Palco: " + stage.stageWidth + "x" + stage.stageHeight + " | tela " + sc[0] + "x" + sc[1] + " | escala " + stage.scaleMode;
            if (m != lastStageLog) { lastStageLog = m; log(m); }
        }

        // O jogo avisa que o palco mudou de tamanho (útil ao trocar de modo com o jogo aberto).
        // O jogo só posiciona alguns botões (ex.: "Explorar" no mapa dos arredores) quando recebe um RESIZE DEPOIS de montar
        // a interface. Avisar durante a montagem (v3.4/v3.5) estragou o mapa, então os avisos são poucos e espaçados
        // (3, 8, 16 e 30 s depois do jogo carregar ou de ele trocar a escala), que é o que o seu "mudar a resolução" fazia.
        private var kickGen:int = 0;
        private var kickLogN:int = 0;
        private function scheduleKicks():void
        {
            if (!Prefs.fixLayout || !inGame) return;
            var gen:int = ++kickGen;
            for each (var d:int in [3000, 8000, 16000, 30000])
                setTimeout(function():void { if (gen == kickGen) kickResize(); }, d);
        }
        private function kickResize():void
        {
            if (!inGame || !stage) return;
            try { stage.dispatchEvent(new Event(Event.RESIZE)); } catch (err:Error) {}
            if (kickLogN < 12) { kickLogN++; log("Aviso de resize ao jogo (layout) #" + kickLogN); }
        }
        private function notifyResize():void
        {
            if (!inGame || !stage) return;
            try { stage.dispatchEvent(new Event(Event.RESIZE)); } catch (err:Error) { log("aviso de resize: " + err.message); }
            if (controls) controls.layout(sw(), uiScale());
        }

        // O botão da engrenagem fica no palco (stage), por cima de tudo, e é trazido para a
        // frente de tempos em tempos: o jogo adiciona janelas no palco e o cobria.
        private function keepOnTop(e:TimerEvent):void
        {
            if (!controls || !stage) return;
            try
            {
                if (stage.scaleMode != wantedScaleMode())
                {
                    log("Escala foi alterada para " + stage.scaleMode + "; restaurando.");
                    applyResolution();
                    scheduleKicks();
                }
                if (controls.parent != stage) stage.addChild(controls);
                else if (stage.getChildIndex(controls) != stage.numChildren - 1) stage.setChildIndex(controls, stage.numChildren - 1);
                // só reposiciona a engrenagem se o tamanho da tela mudou (antes mexia na lista de exibição a cada tick)
                if (sw() != topW || sh() != topH) { topW = sw(); topH = sh(); controls.layout(topW, uiScale()); }
                if (macroPanel && macroPanel.parent == stage && stage.getChildIndex(macroPanel) != stage.numChildren - 1)
                    stage.setChildIndex(macroPanel, stage.numChildren - 1);
                if (sliderPanel && sliderPanel.parent == stage && stage.getChildIndex(sliderPanel) != stage.numChildren - 1)
                    stage.setChildIndex(sliderPanel, stage.numChildren - 1);
            }
            catch (err:Error) {}
        }

        // ---------- sair do app / segundo plano ----------
        private function onKey(e:KeyboardEvent):void
        {
            if (e.keyCode == Keyboard.F11)
            {
                e.preventDefault();
                e.stopImmediatePropagation();
                toggleFullscreen();
                return;
            }
            if (e.keyCode == Keyboard.F10)
            {
                e.preventDefault();
                e.stopImmediatePropagation();
                if (controls != null) controls.togglePinned();
                return;
            }
            if (e.keyCode != Keyboard.BACK) return;
            e.preventDefault();
            e.stopImmediatePropagation();
            askExit();
        }

        private function toggleFullscreen():void
        {
            try
            {
                stage.displayState = (stage.displayState == StageDisplayState.NORMAL)
                    ? StageDisplayState.FULL_SCREEN_INTERACTIVE : StageDisplayState.NORMAL;
            }
            catch (err:Error) { log("Tela cheia: " + err.message); }
        }

        private function askExit():void
        {
            menuMode = M_EXIT;
            bridge.showMenu("Sair do app", [
                "Minimizar esta janela (o jogo continua)",
                "Fechar TODAS as janelas",
                "Cancelar"
            ]);
        }

        // ---------- zoom ----------
        private function zoomBy(delta:Number):void
        {
            zoomLevel = Math.max(0.5, Math.min(2, zoomLevel + delta));
            Prefs.zoom = zoomLevel;
            applyZoom();
        }
        // ---------- barra de resolução personalizada ----------
        private var sliderPanel:SliderPanel;
        private function openSlider():void
        {
            closeSlider();
            var ratio:Number = baseRatio();
            sliderPanel = new SliderPanel("Resolução personalizada", CUSTOM_MIN, CUSTOM_MAX, 10, customH(),
                function(h:int):String { return Math.round(h * ratio) + " x " + h; },
                "menor = itens maiores | maior = mais área do jogo",
                applySlider, closeSlider);
            sliderPanel.scaleX = sliderPanel.scaleY = uiScale();
            sliderPanel.x = sw() / 2;
            sliderPanel.y = sh() / 2;
            stage.addChild(sliderPanel);
        }
        private function closeSlider():void
        {
            if (sliderPanel && sliderPanel.parent) sliderPanel.parent.removeChild(sliderPanel);
            sliderPanel = null;
        }
        private function applySlider(h:int):void
        {
            closeSlider();
            Prefs.customH = h;
            Prefs.resHeight = RES_CUSTOM;
            log("Resolução personalizada: " + virtW(h) + "x" + h);
            applyResolution();
            setTimeout(function():void { verifyVirtual(true); }, 900);
            if (!inGame) showHome();
        }
        private function applyZoom():void
        {
            if (!gameLoader) return;
            gameLoader.scaleX = gameLoader.scaleY = zoomLevel;
        }

        // ---------- cache do Loading.swf (TTL em disco) ----------
        private function cacheDir():File
        {
            var d:File = File.applicationStorageDirectory.resolvePath("cache");
            if (!d.exists) d.createDirectory();
            return d;
        }
        private function cacheFile():File { return cacheDir().resolvePath("Loading.swf"); }

        private function cacheSizeText():String
        {
            var n:Number = SwfFixer.cacheSize();
            if (n <= 0) return "vazio";
            if (n >= 1048576) return (Math.round(n / 104857.6) / 10) + " MB";
            return Math.round(n / 1024) + " KB";
        }
        private function clearCache():void
        {
            SwfFixer.clearCache();
            log("Cache apagado.");
        }
        private function saveCache(b:ByteArray):void
        {
            try {
                var fs:FileStream = new FileStream();
                fs.open(cacheFile(), FileMode.WRITE);
                fs.writeBytes(b); fs.close();
            } catch (err:Error) { log("Falha ao salvar cache: " + err.message); }
        }
        private function readCacheIfFresh():ByteArray
        {
            var f:File = cacheFile();
            if (!f.exists) return null;
            if (new Date().time - f.modificationDate.time > CACHE_TTL_MS) return null;
            return readFile(f);
        }

        private function readFile(f:File):ByteArray
        {
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.READ);
            var ba:ByteArray = new ByteArray();
            fs.readBytes(ba); fs.close();
            return ba;
        }

        // ---------- sessão recebida do ANE ----------
        private function onGame(e:StatusEvent):void
        {
            try { session = JSON.parse(e.level); }
            catch (err:Error) { setStatus("Resposta de login inválida."); return; }
            if (session.host == undefined && session.site != undefined) session.host = session.site;

            try
            {
                var uname:String = session.user != undefined ? String(session.user) : "Conta";
                if (curAcc == "") curAcc = Accounts.newId();
                Accounts.upsert(curAcc, uname, JSON.stringify(session));
                log("Conta salva para login rápido: " + uname);
            }
            catch (eA:Error) { log("salvar conta: " + eA.message); }
            applyResolution();   // o login pausa/recria a tela do app: reaplica a resolução
            port = bridge.startServer(session.host);
            if (port <= 0) { setStatus("Falha ao iniciar servidor local."); return; }
            bridge.keepAlive(true);
            setStatus("Baixando o jogo...");
            fbIndex = 0;
            fetchSwf();
        }

        // 1) servidor (via proxy local, tentando vários caminhos)  2) cache  3) reservas empacotadas
        private function fetchSwf():void
        {
            swfCandidates = [];
            if (session.swf) swfCandidates.push(String(session.swf));
            swfCandidates.push("/client/Loading.swf");
            swfCandidates.push("/Loading.swf");
            swfIdx = 0;
            log("Sessão: host=" + session.host + " swf=" + (session.swf ? session.swf : "(nenhum)") + " porta=" + port);
            tryServer();
        }

        private function isSwf(b:ByteArray):Boolean
        {
            if (b.length < 3) return false;
            var h:String = String.fromCharCode(b[0], b[1], b[2]);
            return h == "FWS" || h == "CWS" || h == "ZWS";
        }

        private function tryServer():void
        {
            if (swfIdx >= swfCandidates.length)
            {
                log("Servidor não respondeu; usando a cópia do app.");
                launchWith(0);
                return;
            }
            var path:String = String(swfCandidates[swfIdx++]);
            log("Tentando https://" + session.host + path);
            var code:int = 0;
            var l:URLLoader = new URLLoader();
            l.dataFormat = URLLoaderDataFormat.BINARY;
            l.addEventListener(HTTPStatusEvent.HTTP_STATUS, function(ev:HTTPStatusEvent):void { code = ev.status; });
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var b:ByteArray = ByteArray(l.data);
                log("Recebido " + b.length + " bytes (HTTP " + code + ")");
                if (!isSwf(b)) { log("A resposta não é um SWF."); tryServer(); return; }
                okPath = path;
                launchWith(b.length);
            });
            l.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                log("Falhou (HTTP " + code + "): " + ev.text);
                tryServer();
            });
            l.load(new URLRequest(bridge.direct ? "https://" + session.host + path : "http://127.0.0.1:" + port + path));
        }

        // O Loading.swf do servidor NÃO é executado: serve só para saber a versão (pelo tamanho).
        // Quem roda é a cópia modificada que vem no app (assets/game), a mesma versão do servidor.
        private function launchWith(serverLen:int):void
        {
            var name:String = "assets/game/Loading.swf";
            if (serverLen > 0 && serverLen != BRAZIL_LEN)
            {
                var alt:String = "assets/game/Loading_" + serverLen + ".swf";
                if (File.applicationDirectory.resolvePath(alt).exists)
                {
                    name = alt;
                    log("Versão deste servidor: " + serverLen + " bytes (cópia própria no app)");
                }
                else
                {
                    log("AVISO: a versão do Loading.swf deste servidor (" + serverLen + " bytes) não está no app. Usando a do Brasil.");
                }
            }
            else if (serverLen == BRAZIL_LEN)
            {
                log("Versão deste servidor: a mesma do Brasil");
            }
            var f:File = File.applicationDirectory.resolvePath(name);
            if (!f.exists)
            {
                setStatus("Faltam os arquivos do jogo no app (" + name + "). Clique em Ver log.");
                return;
            }
            setStatus("Carregando o jogo...");
            startGame(readFile(f));
        }

        private function startGame(bytes:ByteArray):void
        {
            inGame = true;
            drawBg();
            while (ui.numChildren) ui.removeChildAt(0);
            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;
            var p:String = okPath;
            var qi:int = p.indexOf("?");
            if (qi >= 0) p = p.substring(0, qi);
            var dir:String = "https://" + session.host + p.substring(0, p.lastIndexOf("/") + 1);
            var params:Object = {};
            for each (var pn:String in ["user", "key", "site", "p2", "rid", "logintype"])
            {
                if (session.params && session.params[pn] != undefined) params[pn] = String(session.params[pn]);
            }
            params["http"] = "https:";
            params["config"] = dir + "config.xml";
            params["base"] = dir;
            log("Jogo: " + bytes.length + " bytes | config " + params["config"]);
            applyResolution();
            ctx.parameters = params;
            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                myGameDomain = gameLoader.contentLoaderInfo.applicationDomain;
                bindSwfContext();
                applyResolution();
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, function(ev:Event):void {
                zoomLevel = 1; Prefs.zoom = 1;
                addChild(gameLoader);
                applyZoom();
                if (controls == null) controls = new Sidebar([]);
                controls.pinned = false;
                controls.layout(sw(), uiScale());
                topW = sw(); topH = sh();
                stage.addChild(controls);
                scheduleKicks();
                if (topTimer) topTimer.stop();
                topTimer = new Timer(1000);
                topTimer.addEventListener(TimerEvent.TIMER, keepOnTop);
                topTimer.start();
                log("Jogo carregado.");
            });
            gameLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                inGame = false; gameLoader = null; drawBg(); showHome(); setStatus("Falha ao carregar o jogo.");
            });
            gameLoader.loadBytes(bytes, ctx);
        }
    }
}
