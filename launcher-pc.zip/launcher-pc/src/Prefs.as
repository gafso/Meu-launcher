package
{
    import flash.net.SharedObject;
    import flash.utils.ByteArray;

    // Preferências salvas no aparelho (SharedObject).
    public class Prefs
    {
        private static var so:SharedObject = SharedObject.getLocal("meulauncher");

        public static function get platform():int      { return int(so.data.platform); }
        public static function set platform(v:int):void { so.data.platform = v; so.flush(); }

        // "LOW" | "MEDIUM" | "HIGH"
        public static function get quality():String    { return so.data.quality ? String(so.data.quality) : "MEDIUM"; }
        public static function set quality(v:String):void { so.data.quality = v; so.flush(); }

        public static function get fps():int           { return so.data.fps ? int(so.data.fps) : 30; }
        public static function set fps(v:int):void     { so.data.fps = v; so.flush(); }

        public static function get controls():Boolean  { return so.data.controls === undefined ? true : Boolean(so.data.controls); }
        public static function set controls(v:Boolean):void { so.data.controls = v; so.flush(); }

        // Altura da resolução do jogo em pixels (0 = nativa da tela).
        // Padrão: Modo PC 1250x650 (100000). Valores salvos por versões antigas (< v1.7) são descartados.
        public static function get resHeight():int
        {
            if (so.data.resVer != 3) { so.data.resVer = 3; so.data.resHeight = 0; so.flush(); }
            return so.data.resHeight === undefined ? 0 : int(so.data.resHeight);
        }
        public static function set resHeight(v:int):void { so.data.resVer = 3; so.data.resHeight = v; so.flush(); }

        // Cache negativo de imagens inexistentes (SwfFixer). Ligado por padrão.
        public static function get fastNeg():Boolean   { return so.data.fastNeg === undefined ? true : Boolean(so.data.fastNeg); }
        public static function set fastNeg(v:Boolean):void { so.data.fastNeg = v; so.flush(); }

        // Altura escolhida na barra "Personalizada" (resolução virtual).
        public static function get customH():int       { return so.data.customH ? int(so.data.customH) : 800; }
        public static function set customH(v:int):void { so.data.customH = v; so.flush(); }

        // Avisa o jogo (RESIZE) ao abrir janelas novas no Modo PC, para a interface se posicionar. Ligado por padrão.
        public static function get fixLayout():Boolean { return so.data.fixLayout === undefined ? true : Boolean(so.data.fixLayout); }
        public static function set fixLayout(v:Boolean):void { so.data.fixLayout = v; so.flush(); }

        // Quando foi a última varredura de limpeza do cache (ms).
        public static function get lastPrune():Number  { return so.data.lastPrune ? Number(so.data.lastPrune) : 0; }
        public static function set lastPrune(v:Number):void { so.data.lastPrune = v; so.flush(); }

        public static function get zoom():Number       { return so.data.zoom ? Number(so.data.zoom) : 1; }
        public static function set zoom(v:Number):void { so.data.zoom = v; so.flush(); }

        // Imagens reais dos itens (PNG) capturadas do jogo, guardadas no aparelho.
        public static function iconBytes(key:String):ByteArray
        {
            try { var b:* = so.data["icon2_" + key]; return b is ByteArray ? ByteArray(b) : null; } catch (e:Error) {}
            return null;
        }
        public static function setIconBytes(key:String, b:ByteArray):void { so.data["icon2_" + key] = b; so.flush(); }

        // Salvar as imagens que o jogo baixa (mods/_capturas/), para você escolher ícones.
        public static function get saveImages():Boolean { return so.data.saveImages === true; }
        public static function set saveImages(v:Boolean):void { so.data.saveImages = v; so.flush(); }
    }
}
