package
{
    import flash.display.Sprite;
    import flash.events.MouseEvent;

    // Só a engrenagem (abre o menu de configurações), no canto superior direito.
    // Botão redondo translúcido com o ícone desenhado em vetor (não depende de fonte/emoji).
    public class Controls extends Sprite
    {
        private static const SIZE:Number = 56;
        private static const GEAR_Y:Number = 134;  // distância do topo (era 56): desce para a área livre abaixo dos ícones do jogo
        private var gear:Sprite;
        private var macro:Sprite;

        public function Controls(onGear:Function, onMacro:Function = null)
        {
            gear = new Sprite();
            gear.graphics.lineStyle(1, 0x7C3AED, 0.9);
            gear.graphics.beginFill(0x12112E, 0.85);
            gear.graphics.drawRoundRect(0, 0, SIZE, SIZE, 18, 18);
            gear.graphics.endFill();
            drawGear(gear, SIZE / 2, SIZE / 2);
            gear.mouseChildren = false;
            gear.buttonMode = true;
            gear.y = GEAR_Y;
            gear.addEventListener(MouseEvent.MOUSE_DOWN, function(e:MouseEvent):void { gear.alpha = 0.7; });
            var up:Function = function(e:MouseEvent):void { gear.alpha = 1; };
            gear.addEventListener(MouseEvent.MOUSE_UP, up);
            gear.addEventListener(MouseEvent.ROLL_OUT, up);
            gear.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onGear(); });
            addChild(gear);

            if (onMacro != null)
            {
                macro = new Sprite();
                macro.graphics.lineStyle(1, 0x7C3AED, 0.9);
                macro.graphics.beginFill(0x12112E, 0.85);
                macro.graphics.drawRoundRect(0, 0, SIZE, SIZE, 18, 18);
                macro.graphics.endFill();
                // triangulo de "play" (macros)
                macro.graphics.lineStyle(0, 0, 0);
                macro.graphics.beginFill(0xFFFFFF, 0.95);
                macro.graphics.moveTo(SIZE / 2 - 7, SIZE / 2 - 11);
                macro.graphics.lineTo(SIZE / 2 + 11, SIZE / 2);
                macro.graphics.lineTo(SIZE / 2 - 7, SIZE / 2 + 11);
                macro.graphics.lineTo(SIZE / 2 - 7, SIZE / 2 - 11);
                macro.graphics.endFill();
                macro.mouseChildren = false;
                macro.buttonMode = true;
                macro.y = GEAR_Y;
                macro.addEventListener(MouseEvent.MOUSE_DOWN, function(e:MouseEvent):void { macro.alpha = 0.7; });
                var up2:Function = function(e:MouseEvent):void { macro.alpha = 1; };
                macro.addEventListener(MouseEvent.MOUSE_UP, up2);
                macro.addEventListener(MouseEvent.ROLL_OUT, up2);
                macro.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onMacro(); });
                addChild(macro);
            }
        }

        // Engrenagem de 8 dentes com furo no meio.
        private function drawGear(s:Sprite, cx:Number, cy:Number):void
        {
            var teeth:int = 8;
            var rOut:Number = 13, rIn:Number = 9.5;
            var step:Number = Math.PI * 2 / teeth;
            var half:Number = step * 0.22;       // meia largura do dente (rad)
            var first:Boolean = true;
            s.graphics.lineStyle(0, 0, 0);
            s.graphics.beginFill(0xFFFFFF, 0.95);
            for (var i:int = 0; i < teeth; i++)
            {
                var a:Number = i * step;
                var pts:Array = [
                    [a - half * 1.8, rIn], [a - half, rOut], [a + half, rOut], [a + half * 1.8, rIn]
                ];
                for each (var p:Array in pts)
                {
                    var px:Number = cx + Math.cos(p[0]) * p[1];
                    var py:Number = cy + Math.sin(p[0]) * p[1];
                    if (first) { s.graphics.moveTo(px, py); first = false; }
                    else s.graphics.lineTo(px, py);
                }
            }
            s.graphics.endFill();
            // furo (círculo no mesmo tom do fundo do botão)
            s.graphics.beginFill(0x12112E, 1);
            s.graphics.drawCircle(cx, cy, 4.2);
            s.graphics.endFill();
        }

        // Posiciona a engrenagem no canto superior direito (scale > 1 aumenta o botão em telas grandes).
        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = scale;
            gear.x = stageW / scale - SIZE - 14;
            if (macro != null) macro.x = gear.x - SIZE - 12;
        }
    }
}
