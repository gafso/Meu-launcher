package
{
    // Mapas de referência (pisos completos 8x8 e 10x10, feitos a partir dos prints do jogador; 12x12 ainda falta).
    // Só serve para DESCOBRIR onde o olho está quando o piso ainda está quase todo na névoa:
    // compara as casas já abertas (parede ou não) com cada referência; se só restar uma
    // (ou todas as que restarem tiverem o olho no mesmo lugar), devolve a posição do olho.
    // Coordenadas: x = coluna (0 = esquerda), y = linha (0 = topo).
    public class MapRefs
    {
        private static var DATA:Array = null;

        private static function mk(name:String, n:int, walls:String, unk:String, ex:int, ey:int):Object
        {
            var w:Object = {};
            var u:Object = {};
            var s:String;
            for each (s in walls.split(";")) w[s] = true;
            if (unk != "") for each (s in unk.split(";")) u[s] = true;
            return {name: name, n: n, w: w, u: u, ex: ex, ey: ey};
        }

        private static function init():void
        {
            if (DATA != null) return;
            DATA = [
                mk("Básico água A", 8, "1,0;3,0;4,0;4,1;5,1;7,1;0,3;4,3;5,3;6,3;5,4;6,4;0,5;2,5;3,5;6,5;1,6;6,6;1,7;6,7;7,7", "0,6;0,7", 7, 6),
                mk("Básico água B", 8, "0,0;1,2;4,2;1,3;5,3;4,4;2,5;1,6;0,7;5,7;6,7", "0,3", 1, 7),
                mk("Básico lava A", 8, "0,0;1,0;6,0;5,1;6,1;1,2;4,2;5,2;0,4;1,4;2,4;6,4;4,5;5,5;0,6;3,6;4,6;7,6;1,7;2,7;6,7", "0,7;7,7", 7, 5),
                mk("Básico lava B", 8, "0,0;3,1;4,1;6,1;7,1;0,2;1,2;2,2;7,2;2,3;4,3;6,3;0,4;2,4;2,5;5,5;7,5;4,6;0,7;2,7;6,7;7,7", "", 7, 0),
                mk("Básico lava C", 8, "1,0;2,0;3,0;5,0;1,2;4,2;5,2;7,2;1,3;3,3;5,3;1,4;3,4;4,4;5,4;6,4;0,6;2,6;4,6;0,7;2,7;5,7;6,7;7,7", "4,3", 1, 7),
                mk("Intermediário A", 10, "1,0;4,0;5,0;6,0;0,1;2,1;6,1;8,1;1,2;3,2;5,2;8,2;1,3;2,3;5,3;8,3;9,3;8,4;1,5;2,5;5,5;6,5;8,5;0,6;1,6;2,6;7,6;9,6;5,7;0,8;5,8;6,8;7,8;9,8;3,9;6,9;7,9;9,9", "0,0;1,1;2,2;9,4;9,5", 9, 7),
                mk("Intermediário B", 10, "2,0;4,0;5,0;6,0;8,0;1,1;9,1;0,2;9,2;0,3;2,3;4,3;5,3;9,3;0,4;6,4;9,4;0,5;5,5;8,5;0,6;3,6;9,6;2,7;0,8;1,8;6,8;7,8;2,9;4,9;6,9;8,9;9,9", "0,0;1,0;9,0;0,1;9,5;0,9;1,9;7,9", 2, 8),
                mk("Intermediário C", 10, "0,0;2,0;5,0;0,1;5,1;8,1;9,1;1,2;2,2;3,2;5,2;6,2;8,2;1,3;2,3;3,3;5,3;9,3;0,4;7,4;0,5;2,5;3,5;4,5;5,5;6,5;9,5;3,6;5,6;9,6;3,7;5,7;6,7;0,8;1,8;2,8;3,8;7,8;9,8;1,9;5,9", "0,2;9,2;0,3;0,9", 2, 9),
                mk("Intermediário D", 10, "0,0;2,0;3,0;6,0;9,0;1,2;2,2;3,2;4,2;6,2;7,2;8,2;2,3;7,3;8,3;1,4;2,4;4,4;5,4;8,4;9,4;2,5;4,5;8,5;9,5;1,6;2,6;4,6;5,6;4,7;5,7;8,7;4,8;5,8;7,8;8,8;0,9;1,9;3,9;5,9;7,9;8,9", "4,9", 0, 8),
                mk("Intermediário E", 10, "3,0;6,0;0,1;2,1;5,1;8,1;9,1;3,2;4,2;5,2;6,2;8,2;9,2;1,3;1,4;3,4;4,4;5,4;7,4;8,4;0,5;4,5;7,5;8,5;2,6;4,6;6,6;8,6;1,7;2,7;3,7;4,7;7,7;8,7;9,7;0,8;1,8;3,8;9,8;0,9;5,9;6,9;7,9;9,9", "4,0;5,0;3,1;4,1;7,6", 9, 0)
            ];
        }

        // Referências do tamanho n x n que ainda são compatíveis com as casas JÁ ABERTAS (parede/olho coincidem).
        // Casas na névoa não entram na conta. Se nenhuma referência existe para o tamanho, devolve [].
        public static function candidates(list:Array, cols:int, rows:int, useEye:Boolean = true):Array
        {
            var out:Array = [];
            if (cols != rows) return out;
            init();
            var r:int, i:int;
            var ref:Object, c:Object;
            var k:String;
            var ok:Boolean;
            for (r = 0; r < DATA.length; r++)
            {
                ref = DATA[r];
                if (int(ref.n) != cols) continue;
                ok = true;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if (!c.opened) continue;
                    k = c.x + "," + c.y;
                    if (ref.u[k]) continue;
                    if ((c.type == -1) != (ref.w[k] == true)) { ok = false; break; }
                    if (useEye && c.type == 8 && !(c.x == ref.ex && c.y == ref.ey)) { ok = false; break; }
                    if (useEye && c.x == ref.ex && c.y == ref.ey && c.type != 8) { ok = false; break; }
                }
                if (ok) out.push(ref);
            }
            return out;
        }

        // Só para o log: devolve {name, ex, ey} quando todas as referências compatíveis têm o olho no mesmo lugar.
        public static function match(list:Array, cols:int, rows:int):Object
        {
            var cand:Array = candidates(list, cols, rows);
            if (cand.length == 0) return null;
            var names:Array = [];
            for (var i:int = 0; i < cand.length; i++)
            {
                if (cand[i].ex != cand[0].ex || cand[i].ey != cand[0].ey) return null;
                names.push(cand[i].name);
            }
            return {name: names.join(" ou "), ex: cand[0].ex, ey: cand[0].ey};
        }
    }
}
