package
{
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFormat;

    // Aba discreta no canto esquerdo (estilo edge panel):
    // fechada = filete fino com 3 pontos; clique abre o menu.
    public class Sidebar extends Sprite
    {
        private static const EDGE_W:Number = 10;
        private static const EDGE_H:Number = 72;
        private static const W_OPEN:Number = 188;
        private static const ICON_W:Number = 44;
        private static const ITEM_H:Number = 40;
        private static const PAD:Number = 6;

        private var edge:Sprite = new Sprite();
        private var panel:Sprite = new Sprite();
        private var rows:Array = [];
        private var _pinned:Boolean = false;
        private var hot:int = -1;
        private var nItems:int;

        public function Sidebar(defs:Array)
        {
            addChild(panel);
            addChild(edge);
            nItems = defs.length;
            for (var i:int = 0; i < nItems; i++) addRow(i, defs[i]);
            edge.buttonMode = true;
            edge.mouseChildren = false;
            edge.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                e.stopPropagation();
                togglePinned();
            });
            redraw();
        }

        public function get pinned():Boolean { return _pinned; }
        public function set pinned(v:Boolean):void { _pinned = v; hot = -1; redraw(); }
        public function togglePinned():void { pinned = !_pinned; }

        private function addRow(i:int, def:Array):void
        {
            var sp:Sprite = new Sprite();
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 12, 0xE8E8E8, false);
            tf.selectable = false;
            tf.mouseEnabled = false;
            tf.text = String(def[1]);
            tf.width = W_OPEN - ICON_W - 8;
            tf.height = 20;
            tf.x = ICON_W - 4;
            tf.y = (ITEM_H - 4 - 20) / 2;
            sp.addChild(tf);
            sp.mouseChildren = false;
            sp.buttonMode = true;
            var fn:Function = def[2] as Function;
            var idx:int = i;
            sp.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { hot = idx; redraw(); });
            sp.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { if (hot == idx) hot = -1; redraw(); });
            sp.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                e.stopPropagation();
                if (fn != null) fn();
                pinned = false;
            });
            panel.addChild(sp);
            rows.push({sp: sp, lbl: tf, glyph: String(def[0])});
        }

        private function redraw():void
        {
            var open:Boolean = _pinned;
            var g:Graphics;

            // filete edge
            g = edge.graphics;
            g.clear();
            g.beginFill(0x1A1A1A, 0.92);
            g.lineStyle(1, 0xF5C542, 0.55);
            g.drawRoundRect(0, 0, EDGE_W, EDGE_H, 8, 8);
            g.endFill();
            g.lineStyle(0, 0, 0);
            g.beginFill(0xF5C542, 0.95);
            var cx:Number = EDGE_W / 2 - 1.5;
            var cy:Number = EDGE_H / 2;
            for (var k:int = -1; k <= 1; k++)
                g.drawCircle(EDGE_W / 2, cy + k * 10, 2.2);
            g.endFill();
            edge.x = 0;
            edge.y = 0;

            panel.visible = open;
            if (open)
            {
                var ph:Number = nItems * ITEM_H + PAD * 2;
                g = panel.graphics;
                g.clear();
                g.lineStyle(1, 0x2A2A2A, 1);
                g.beginFill(0x121212, 0.97);
                g.drawRoundRect(EDGE_W + 4, 0, W_OPEN, ph, 12, 12);
                g.endFill();
            }
            else
            {
                panel.graphics.clear();
            }

            for (var i:int = 0; i < rows.length; i++)
            {
                var sp:Sprite = rows[i].sp;
                sp.visible = open;
                TextField(rows[i].lbl).visible = open;
                sp.x = EDGE_W + 4 + PAD;
                sp.y = PAD + i * ITEM_H;
                var gg:Graphics = sp.graphics;
                gg.clear();
                if (!open) continue;
                gg.beginFill(0x2A2A2A, hot == i ? 1 : 0);
                gg.drawRoundRect(0, 0, W_OPEN - PAD * 2, ITEM_H - 4, 10, 10);
                gg.endFill();
                Win.glyph(gg, String(rows[i].glyph), (ICON_W - PAD * 2) / 2, (ITEM_H - 4) / 2, 18, hot == i ? 0xFFFFFF : 0xBBBBBB);
            }
        }

        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = Math.min(scale, 1.2);
            x = 0;
            var h:Number = (stage != null && stage.stageHeight > 0) ? stage.stageHeight : 650;
            y = Math.max(20, (h / scaleY - EDGE_H) / 2);
        }
    }
}
