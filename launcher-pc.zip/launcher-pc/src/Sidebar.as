package
{
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFormat;

    // Barra lateral do launcher (PC): faixa fina de ícones na borda esquerda; passando o mouse ela abre
    // mostrando os nomes. F10 esconde/mostra. Fica por cima do jogo e da tela de entrada.
    public class Sidebar extends Sprite
    {
        private static const W_MIN:Number = 54;
        private static const W_MAX:Number = 210;
        private static const ITEM_H:Number = 48;
        private static const PAD:Number = 8;

        private var bg:Sprite = new Sprite();
        private var rows:Array = [];     // {sp, lbl, glyph, fn}
        private var expanded:Boolean = false;
        private var hot:int = -1;
        private var totalH:Number;

        // defs: [[glifo, texto, função], ...]
        public function Sidebar(defs:Array)
        {
            addChild(bg);
            totalH = defs.length * ITEM_H + PAD * 2;
            for (var i:int = 0; i < defs.length; i++) addRow(i, defs[i]);
            addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { setExpanded(true); });
            addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { setExpanded(false); });
            redraw();
        }

        private function addRow(i:int, def:Array):void
        {
            var sp:Sprite = new Sprite();
            sp.x = PAD; sp.y = PAD + i * ITEM_H;
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 14, 0xF4F1FF, true);
            tf.selectable = false;
            tf.mouseEnabled = false;
            tf.text = String(def[1]);
            tf.width = W_MAX - W_MIN - 12;
            tf.height = 22;
            tf.x = W_MIN - PAD + 2;
            tf.y = (ITEM_H - 22) / 2 + 2;
            tf.visible = false;
            sp.addChild(tf);
            sp.mouseChildren = false;
            sp.buttonMode = true;
            var fn:Function = def[2] as Function;
            sp.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { hot = i; redraw(); });
            sp.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { if (hot == i) hot = -1; redraw(); });
            sp.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { if (fn != null) fn(); });
            addChild(sp);
            rows.push({sp: sp, lbl: tf, glyph: String(def[0])});
        }

        private function setExpanded(v:Boolean):void
        {
            if (expanded == v) return;
            expanded = v;
            redraw();
        }

        private function redraw():void
        {
            var w:Number = expanded ? W_MAX : W_MIN;
            var g:Graphics = bg.graphics;
            g.clear();
            g.lineStyle(1, 0x7C3AED, 0.9);
            g.beginFill(0x12112E, expanded ? 0.96 : 0.86);
            g.drawRoundRect(-20, 0, w + 20, totalH, 22, 22);
            g.endFill();
            for (var i:int = 0; i < rows.length; i++)
            {
                var sp:Sprite = rows[i].sp;
                var gg:Graphics = sp.graphics;
                gg.clear();
                gg.lineStyle(0, 0, 0);
                gg.beginFill(hot == i ? 0x3A2A8C : 0x000000, hot == i ? 1 : 0);
                gg.drawRoundRect(0, 0, w - PAD * 2, ITEM_H - 4, 14, 14);
                gg.endFill();
                Win.glyph(gg, String(rows[i].glyph), (W_MIN - PAD * 2) / 2, (ITEM_H - 4) / 2, 22, hot == i ? 0xFFFFFF : 0xC9C4EE);
                TextField(rows[i].lbl).visible = expanded;
            }
        }

        // Posiciona na borda esquerda, centralizada na altura (scale > 1 aumenta em telas grandes).
        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = scale;
            x = 0;
            var h:Number = (stage != null && stage.stageHeight > 0) ? stage.stageHeight : 650;
            y = Math.max(8, (h / scale - totalH) / 2);
        }
    }
}
