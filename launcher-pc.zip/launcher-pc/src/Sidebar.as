package
{
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Barra lateral do launcher (PC).
    //   fixada (pinned)  : aberta, com ícones e nomes.
    //   solta            : some e deixa só uma aba fina na borda; passe o mouse na aba para a barra voltar.
    // F10 alterna entre fixada e solta. Dentro do jogo ela fica solta (não atrapalha a tela).
    public class Sidebar extends Sprite
    {
        private static const HANDLE_W:Number = 14;
        private static const W_OPEN:Number = 214;
        private static const ICON_W:Number = 54;
        private static const ITEM_H:Number = 48;
        private static const PAD:Number = 8;

        private var bg:Sprite = new Sprite();
        private var rows:Array = [];     // {sp, lbl, glyph}
        private var _pinned:Boolean = true;
        private var hoverOpen:Boolean = false;
        private var hot:int = -1;
        private var totalH:Number;
        private var closeTimer:Timer = new Timer(450, 1);

        // defs: [[glifo, texto, função], ...]
        public function Sidebar(defs:Array)
        {
            addChild(bg);
            totalH = defs.length * ITEM_H + PAD * 2;
            for (var i:int = 0; i < defs.length; i++) addRow(i, defs[i]);
            addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { closeTimer.stop(); setHover(true); });
            addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { closeTimer.reset(); closeTimer.start(); });
            closeTimer.addEventListener(TimerEvent.TIMER_COMPLETE, function(e:TimerEvent):void { setHover(false); });
            redraw();
        }

        public function get pinned():Boolean { return _pinned; }
        public function set pinned(v:Boolean):void { _pinned = v; hoverOpen = false; redraw(); }
        public function togglePinned():void { pinned = !_pinned; }

        private function isOpen():Boolean { return _pinned || hoverOpen; }

        private function setHover(v:Boolean):void
        {
            if (hoverOpen == v) return;
            hoverOpen = v;
            if (!v) hot = -1;
            redraw();
        }

        private function addRow(i:int, def:Array):void
        {
            var sp:Sprite = new Sprite();
            sp.x = PAD; sp.y = PAD + i * ITEM_H;
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 14, 0xF4F1FF, true);
            tf.selectable = false;
            tf.mouseEnabled = false;
            tf.text = String(def[1]);
            tf.width = W_OPEN - ICON_W - 14;
            tf.height = 22;
            tf.x = ICON_W - PAD + 2;
            tf.y = (ITEM_H - 4 - 22) / 2 + 1;
            sp.addChild(tf);
            sp.mouseChildren = false;
            sp.buttonMode = true;
            var fn:Function = def[2] as Function;
            sp.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { hot = i; redraw(); });
            sp.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { if (hot == i) hot = -1; redraw(); });
            sp.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { if (fn != null) fn(); });
            addChild(sp);
            rows.push({sp: sp, lbl: tf, glyph: String(def[0])});
        }

        private function redraw():void
        {
            var open:Boolean = isOpen();
            var g:Graphics = bg.graphics;
            g.clear();
            if (open)
            {
                g.lineStyle(1, 0x7C3AED, 0.9);
                g.beginFill(0x12112E, 0.96);
                g.drawRoundRect(-20, 0, W_OPEN + 20, totalH, 22, 22);
                g.endFill();
            }
            else
            {
                // aba fina na borda (com 3 tracinhos) que chama a barra de volta
                g.lineStyle(1, 0x7C3AED, 0.9);
                g.beginFill(0x12112E, 0.72);
                g.drawRoundRect(-20, 0, HANDLE_W + 20, totalH, 14, 14);
                g.endFill();
                g.lineStyle(0, 0, 0);
                g.beginFill(0xC9C4EE, 0.9);
                var cy:Number = totalH / 2;
                for (var k:int = -1; k <= 1; k++) g.drawRoundRect(HANDLE_W / 2 - 1.5, cy + k * 9 - 3, 3, 6, 2, 2);
                g.endFill();
            }
            for (var i:int = 0; i < rows.length; i++)
            {
                var sp:Sprite = rows[i].sp;
                sp.visible = open;
                TextField(rows[i].lbl).visible = open;
                var gg:Graphics = sp.graphics;
                gg.clear();
                if (!open) continue;
                gg.lineStyle(0, 0, 0);
                gg.beginFill(0x3A2A8C, hot == i ? 1 : 0);
                gg.drawRoundRect(0, 0, W_OPEN - PAD * 2, ITEM_H - 4, 14, 14);
                gg.endFill();
                Win.glyph(gg, String(rows[i].glyph), (ICON_W - PAD * 2) / 2, (ITEM_H - 4) / 2, 22, hot == i ? 0xFFFFFF : 0xC9C4EE);
            }
        }

        // Posiciona na borda esquerda, centralizada na altura (scale > 1 aumenta em telas grandes).
        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = scale;
            x = 0;
            var h:Number = (stage != null && stage.stageHeight > 0) ? stage.stageHeight : 650;
            y = Math.max(8, (h / scale - totalH) / 2);
        }
    }
}
