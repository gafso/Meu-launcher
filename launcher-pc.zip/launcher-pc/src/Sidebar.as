package
{
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Matrix;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Barra lateral do launcher (PC), no estilo de "painel de aplicativo".
    //   docked  (antes do jogo): painel fixo de 250 px, altura toda: conta, botão ENTRAR e menus por seção.
    //   overlay (dentro do jogo): faixa fina que some e volta ao passar o mouse na borda; F10 fixa/solta.
    public class Sidebar extends Sprite
    {
        public static const DOCK_W:Number = 250;
        private static const BG:uint = 0x0E1022;
        private static const LINE:uint = 0x1E2142;
        private static const CARD:uint = 0x15183A;
        private static const HOTBG:uint = 0x23275A;
        private static const ORANGE:uint = 0xF7931E;
        private static const ORANGE_D:uint = 0xD9730D;
        private static const TXT:uint = 0xE8E9F7;
        private static const MUTED:uint = 0x7C80A6;
        private static const HANDLE_W:Number = 14;
        private static const W_OPEN:Number = 236;
        private static const ICON_W:Number = 54;
        private static const ITEM_H:Number = 46;
        private static const D_ITEM_H:Number = 38;
        private static const PAD:Number = 8;

        public var onEnter:Function;

        private var bg:Sprite = new Sprite();
        private var entries:Array = [];     // {sec:Boolean, sp:Sprite, tf:TextField, glyph:String, fn:Function}
        private var enterBtn:Sprite = new Sprite();
        private var headG:Sprite = new Sprite();
        private var nameTf:TextField;
        private var subTf:TextField;
        private var titleTf:TextField;
        private var _docked:Boolean = false;
        private var _pinned:Boolean = true;
        private var hoverOpen:Boolean = false;
        private var hot:int = -1;
        private var totalH:Number = 100;
        private var dockH:Number = 700;
        private var closeTimer:Timer = new Timer(450, 1);

        // defs: [["#", "SEÇÃO"], [glifo, texto, função], ...]
        public function Sidebar(defs:Array)
        {
            addChild(bg);
            addChild(headG);
            titleTf = mk(16, 0xFFFFFF, true, 0, 0, 180);
            titleTf.text = "LEGEND PC";
            headG.addChild(titleTf);
            nameTf = mk(14, TXT, true, 0, 0, 150);
            nameTf.text = "Sem conta";
            headG.addChild(nameTf);
            subTf = mk(12, MUTED, false, 0, 0, 150);
            headG.addChild(subTf);
            var lab:TextField = mk(14, 0x1A1204, true, 0, 0, 222);
            lab.defaultTextFormat = new TextFormat("_sans", 14, 0x1A1204, true, null, null, null, null, "center");
            lab.text = "ENTRAR NA CONTA";
            enterBtn.addChild(lab);
            enterBtn.mouseChildren = false;
            enterBtn.buttonMode = true;
            enterBtn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { if (onEnter != null) onEnter(); });
            addChild(enterBtn);
            for (var i:int = 0; i < defs.length; i++) addEntry(i, defs[i]);
            addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { closeTimer.stop(); setHover(true); });
            addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { closeTimer.reset(); closeTimer.start(); });
            closeTimer.addEventListener(TimerEvent.TIMER_COMPLETE, function(e:TimerEvent):void { setHover(false); });
            redraw();
        }

        private function mk(size:int, color:uint, bold:Boolean, x:Number, y:Number, w:Number):TextField
        {
            var t:TextField = new TextField();
            t.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            t.selectable = false;
            t.mouseEnabled = false;
            t.x = x; t.y = y; t.width = w; t.height = size + 8;
            return t;
        }

        private function addEntry(i:int, def:Array):void
        {
            if (String(def[0]) == "#")
            {
                var st:TextField = mk(11, MUTED, true, 0, 0, 220);
                st.text = String(def[1]);
                addChild(st);
                entries.push({sec: true, sp: null, tf: st, glyph: "", fn: null});
                return;
            }
            var idx:int = entries.length;
            var sp:Sprite = new Sprite();
            var tf:TextField = mk(14, TXT, true, 0, 0, 180);
            tf.text = String(def[1]);
            sp.addChild(tf);
            sp.mouseChildren = false;
            sp.buttonMode = true;
            var fn:Function = def[2] as Function;
            sp.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { hot = idx; redraw(); });
            sp.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { if (hot == idx) hot = -1; redraw(); });
            sp.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { if (fn != null) fn(); });
            addChild(sp);
            entries.push({sec: false, sp: sp, tf: tf, glyph: String(def[0]), fn: fn});
        }

        public function get docked():Boolean { return _docked; }
        public function set docked(v:Boolean):void { _docked = v; hoverOpen = false; hot = -1; redraw(); }
        public function get pinned():Boolean { return _pinned; }
        public function set pinned(v:Boolean):void { _pinned = v; hoverOpen = false; redraw(); }
        public function togglePinned():void { if (!_docked) pinned = !_pinned; }
        public function dockPixelW():Number { return DOCK_W * scaleX; }

        public function setAccount(name:String, sub:String):void
        {
            nameTf.text = name;
            subTf.text = sub;
            fit(nameTf, 150);
        }

        private function fit(t:TextField, maxW:Number):void
        {
            var s:int = 14;
            var f:TextFormat = t.getTextFormat();
            f.size = s;
            t.setTextFormat(f);
            while (t.textWidth > maxW && s > 9) { s--; f.size = s; t.setTextFormat(f); }
        }

        private function isOpen():Boolean { return _docked || _pinned || hoverOpen; }

        private function setHover(v:Boolean):void
        {
            if (_docked || hoverOpen == v) return;
            hoverOpen = v;
            if (!v) hot = -1;
            redraw();
        }

        private function redraw():void
        {
            if (_docked) drawDocked(); else drawOverlay();
        }

        // ---------- painel fixo ----------
        private function drawDocked():void
        {
            var g:Graphics = bg.graphics;
            g.clear();
            g.beginFill(BG, 1);
            g.drawRect(0, 0, DOCK_W, dockH);
            g.endFill();
            g.lineStyle(1, LINE, 1);
            g.moveTo(DOCK_W, 0); g.lineTo(DOCK_W, dockH);
            headG.visible = true;
            var hg:Graphics = headG.graphics;
            hg.clear();
            hg.lineStyle(0, 0, 0);
            hg.beginFill(ORANGE, 1);
            hg.drawRoundRect(16, 18, 38, 38, 12, 12);
            hg.endFill();
            Win.glyph(hg, "play", 36, 37, 20, 0x1A1204);
            titleTf.x = 64; titleTf.y = 22;
            hg.lineStyle(1, LINE, 1);
            hg.beginFill(CARD, 1);
            hg.drawRoundRect(14, 74, 222, 58, 14, 14);
            hg.endFill();
            hg.lineStyle(0, 0, 0);
            hg.beginFill(0x2A2E63, 1);
            hg.drawCircle(44, 103, 18);
            hg.endFill();
            Win.glyph(hg, "user", 44, 103, 22, 0xE8E9F7);
            nameTf.x = 70; nameTf.y = 84;
            subTf.x = 70; subTf.y = 106;
            enterBtn.x = 14; enterBtn.y = 146;
            var eg:Graphics = enterBtn.graphics;
            eg.clear();
            var m:Matrix = new Matrix();
            m.createGradientBox(222, 44, Math.PI / 2, 0, 0);
            eg.lineStyle(0, 0, 0);
            eg.beginGradientFill(GradientType.LINEAR, [ORANGE, ORANGE_D], [1, 1], [0, 255], m);
            eg.drawRoundRect(0, 0, 222, 44, 14, 14);
            eg.endFill();
            TextField(enterBtn.getChildAt(0)).y = 12;
            enterBtn.visible = true;
            var y:Number = 206;
            for (var i:int = 0; i < entries.length; i++)
            {
                var en:Object = entries[i];
                if (en.sec)
                {
                    var st:TextField = en.tf;
                    st.visible = true;
                    st.x = 22; st.y = y + 4;
                    y += 28;
                    continue;
                }
                var sp:Sprite = en.sp;
                sp.visible = true;
                sp.x = 10; sp.y = y;
                var gg:Graphics = sp.graphics;
                gg.clear();
                gg.lineStyle(0, 0, 0);
                gg.beginFill(HOTBG, hot == i ? 1 : 0);
                gg.drawRoundRect(0, 0, DOCK_W - 20, D_ITEM_H, 12, 12);
                gg.endFill();
                Win.glyph(gg, String(en.glyph), 24, D_ITEM_H / 2, 18, hot == i ? 0xFFFFFF : 0xB9BCE0);
                var tf:TextField = en.tf;
                tf.visible = true;
                tf.x = 46; tf.y = (D_ITEM_H - 22) / 2;
                tf.width = DOCK_W - 20 - 54;
                y += D_ITEM_H + 2;
            }
        }

        // ---------- faixa sobre o jogo ----------
        private function drawOverlay():void
        {
            headG.visible = false;
            enterBtn.visible = false;
            var open:Boolean = isOpen();
            var cnt:int = 0;
            for each (var e0:Object in entries) if (!e0.sec) cnt++;
            totalH = cnt * ITEM_H + PAD * 2;
            var g:Graphics = bg.graphics;
            g.clear();
            if (open)
            {
                g.lineStyle(1, ORANGE, 0.9);
                g.beginFill(BG, 0.96);
                g.drawRoundRect(-20, 0, W_OPEN + 20, totalH, 22, 22);
                g.endFill();
            }
            else
            {
                g.lineStyle(1, ORANGE, 0.9);
                g.beginFill(BG, 0.72);
                g.drawRoundRect(-20, 0, HANDLE_W + 20, totalH, 14, 14);
                g.endFill();
                g.lineStyle(0, 0, 0);
                g.beginFill(0xC9C4EE, 0.9);
                var cy:Number = totalH / 2;
                for (var k:int = -1; k <= 1; k++) g.drawRoundRect(HANDLE_W / 2 - 1.5, cy + k * 9 - 3, 3, 6, 2, 2);
                g.endFill();
            }
            var n:int = 0;
            for (var i:int = 0; i < entries.length; i++)
            {
                var en:Object = entries[i];
                if (en.sec) { TextField(en.tf).visible = false; continue; }
                var sp:Sprite = en.sp;
                sp.visible = open;
                sp.x = PAD; sp.y = PAD + n * ITEM_H;
                n++;
                var gg:Graphics = sp.graphics;
                gg.clear();
                if (!open) continue;
                gg.lineStyle(0, 0, 0);
                gg.beginFill(HOTBG, hot == i ? 1 : 0);
                gg.drawRoundRect(0, 0, W_OPEN - PAD * 2, ITEM_H - 4, 14, 14);
                gg.endFill();
                Win.glyph(gg, String(en.glyph), (ICON_W - PAD * 2) / 2, (ITEM_H - 4) / 2, 22, hot == i ? 0xFFFFFF : 0xB9BCE0);
                var tf:TextField = en.tf;
                tf.visible = true;
                tf.x = ICON_W - PAD + 2; tf.y = (ITEM_H - 4 - 22) / 2;
                tf.width = W_OPEN - ICON_W - 12;
            }
        }

        // Painel fixo: altura toda. Faixa: centralizada na altura da janela.
        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = scale;
            x = 0;
            var h:Number = (stage != null && stage.stageHeight > 0) ? stage.stageHeight : 650;
            if (_docked)
            {
                y = 0;
                dockH = h / scale;
                redraw();
                return;
            }
            y = Math.max(8, (h / scale - totalH) / 2);
        }
    }
}
