package
{
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFormat;

    // Barra lateral compacta:
    //   fechada = só um botão pequeno com 3 traços (hambúrguer)
    //   aberta  = painel com ícones + nomes (só ao CLICAR no hambúrguer; F10 também)
    public class Sidebar extends Sprite
    {
        private static const BTN:Number = 36;       // tamanho do hambúrguer
        private static const W_OPEN:Number = 200;
        private static const ICON_W:Number = 48;
        private static const ITEM_H:Number = 44;
        private static const PAD:Number = 8;

        private var bg:Sprite = new Sprite();
        private var handle:Sprite = new Sprite();
        private var panel:Sprite = new Sprite();
        private var rows:Array = [];
        private var _pinned:Boolean = false;
        private var hot:int = -1;
        private var totalH:Number;
        private var nItems:int;

        public function Sidebar(defs:Array)
        {
            addChild(bg);
            addChild(panel);
            addChild(handle);
            nItems = defs.length;
            totalH = nItems * ITEM_H + PAD * 2 + 8;
            for (var i:int = 0; i < nItems; i++) addRow(i, defs[i]);

            handle.buttonMode = true;
            handle.mouseChildren = false;
            handle.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                e.stopPropagation();
                togglePinned();
            });
            redraw();
        }

        public function get pinned():Boolean { return _pinned; }
        public function set pinned(v:Boolean):void { _pinned = v; hot = -1; redraw(); }
        public function togglePinned():void { pinned = !_pinned; }

        private function addRow(i:int, def:Array):void
        {
            var sp:Sprite = new Sprite();
            sp.x = PAD;
            sp.y = PAD + i * ITEM_H;
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 13, 0xEDE9FE, false);
            tf.selectable = false;
            tf.mouseEnabled = false;
            tf.text = String(def[1]);
            tf.width = W_OPEN - ICON_W - 10;
            tf.height = 22;
            tf.x = ICON_W - PAD + 2;
            tf.y = (ITEM_H - 4 - 22) / 2 + 1;
            sp.addChild(tf);
            sp.mouseChildren = false;
            sp.buttonMode = true;
            var fn:Function = def[2] as Function;
            var idx:int = i;
            sp.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { hot = idx; redraw(); });
            sp.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { if (hot == idx) hot = -1; redraw(); });
            sp.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                e.stopPropagation();
                if (fn != null) fn();
                // após escolher um item, fecha a barra
                pinned = false;
            });
            panel.addChild(sp);
            rows.push({sp: sp, lbl: tf, glyph: String(def[0])});
        }

        private function redraw():void
        {
            var open:Boolean = _pinned;
            var g:Graphics;

            // fundo do painel (só aberto)
            g = bg.graphics;
            g.clear();
            if (open)
            {
                g.lineStyle(1, 0x8B5CF6, 0.9);
                g.beginFill(0x0F0E1A, 0.96);
                g.drawRoundRect(0, 0, W_OPEN, totalH, 16, 16);
                g.endFill();
            }

            panel.visible = open;

            // hambúrguer sempre visível, pequeno
            g = handle.graphics;
            g.clear();
            g.lineStyle(1, 0x8B5CF6, 0.95);
            g.beginFill(0x0F0E1A, open ? 0.98 : 0.9);
            g.drawRoundRect(0, 0, BTN, BTN, 10, 10);
            g.endFill();
            g.lineStyle(0, 0, 0);
            g.beginFill(0xEDE9FE, 1);
            var bx:Number = BTN / 2 - 8;
            var cy:Number = BTN / 2;
            for (var k:int = -1; k <= 1; k++)
                g.drawRoundRect(bx, cy + k * 6 - 1.2, 16, 2.4, 1.5, 1.5);
            g.endFill();
            handle.x = open ? 6 : 4;
            handle.y = open ? 6 : 4;

            for (var i:int = 0; i < rows.length; i++)
            {
                var sp:Sprite = rows[i].sp;
                sp.visible = open;
                TextField(rows[i].lbl).visible = open;
                var gg:Graphics = sp.graphics;
                gg.clear();
                if (!open) continue;
                // empurra itens para baixo do hambúrguer
                sp.y = PAD + 40 + i * ITEM_H;
                gg.lineStyle(0, 0, 0);
                gg.beginFill(0x3A2A8C, hot == i ? 1 : 0);
                gg.drawRoundRect(0, 0, W_OPEN - PAD * 2, ITEM_H - 4, 12, 12);
                gg.endFill();
                Win.glyph(gg, String(rows[i].glyph), (ICON_W - PAD * 2) / 2, (ITEM_H - 4) / 2, 20, hot == i ? 0xFFFFFF : 0xC9C4EE);
            }
            if (open)
            {
                // altura inclui o botão
                totalH = nItems * ITEM_H + PAD * 2 + 48;
                g = bg.graphics;
                g.clear();
                g.lineStyle(1, 0x8B5CF6, 0.9);
                g.beginFill(0x0F0E1A, 0.96);
                g.drawRoundRect(0, 0, W_OPEN, totalH, 16, 16);
                g.endFill();
            }
        }

        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = scale;
            x = 6;
            y = 10;
        }
    }
}
