package
{
    public class Platforms
    {
        // [nome exibido, host do site de login]
        public static const LIST:Array = [
            ["Legend Online Brasil", "lobr.creaction-network.com"]
        ];
    }
}
