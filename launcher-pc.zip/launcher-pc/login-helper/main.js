'use strict';
// Janela de login com Chromium atual. Abre o site, você entra normalmente e este programa captura
// user/key (e o caminho do Loading.swf) e grava num arquivo JSON para o launcher. Nenhuma senha é lida.
const { app, BrowserWindow, session } = require('electron');
const fs = require('fs');

const args = {};
for (const a of process.argv.slice(1)) {
  if (!a.startsWith('--')) continue;
  const i = a.indexOf('=');
  if (i < 0) args[a.slice(2)] = true; else args[a.slice(2, i)] = a.slice(i + 1);
}
const HOST = String(args.host || 'lobr.creaction-network.com');
const OUT = args.out ? String(args.out) : null;
const ACC = String(args.account || 'legend').replace(/[^\w-]/g, '') || 'legend';
const PARTITION = 'persist:legend';
// Cada conta tem a própria pasta de dados (cookies separados) e pode rodar ao mesmo tempo que outra.
const path = require('path');
app.setPath('userData', path.join(app.getPath('appData'), 'LegendLogin', ACC));
const KEYS = ['user', 'key', 'site', 'p2', 'rid', 'logintype'];
const RE_SWF_LOADING = /([\w.\/:\-%]*Loading[\w\-]*\.swf[\w?=&.%\-]*)/;
const RE_SWF_ANY = /([\w.\/:\-%]+\.swf)/;
const ASSET_EXT = ['.png', '.jpg', '.jpeg', '.gif', '.css', '.js', '.ico', '.woff', '.woff2', '.svg', '.webp'];

let win = null;
let done = false;
let scans = 0;
let seenSwf = null;
let timer = null;

function dec(s) { try { return decodeURIComponent(s.replace(/\+/g, ' ')); } catch (e) { return s; } }
function pathOf(url) {
  const qi = url.indexOf('?');
  const p = qi >= 0 ? url.substring(0, qi) : url;
  return p.replace(/^[a-zA-Z]+:\/\/[^\/]*/, '');
}
function isAsset(lp) { return ASSET_EXT.some((e) => lp.endsWith(e)); }
function plausible(v) {
  if (!v) return false;
  return !['function', 'null', 'undefined', 'true', 'false', 'this', 'document', 'window', 'var'].includes(v.toLowerCase());
}

function note(url) {
  if (!url) return;
  const p = pathOf(url).toLowerCase();
  if (p.indexOf('loading') >= 0 && p.endsWith('.swf')) {
    const qi = url.indexOf('?');
    const raw = pathOf(url);
    seenSwf = qi >= 0 ? raw + url.substring(qi) : raw;
  }
}

// Qualquer URL (que não seja imagem/css/js) com user= e key= vira a sessão.
function check(url) {
  if (done || !url) return false;
  const qi = url.indexOf('?');
  if (qi < 0) return false;
  const hi = url.indexOf('#', qi);
  const q = url.substring(qi + 1, hi >= 0 ? hi : url.length);
  const lp = pathOf(url).toLowerCase();
  if (q.indexOf('user=') < 0 || q.indexOf('key=') < 0 || isAsset(lp)) return false;
  const params = {};
  for (const kv of q.split('&')) {
    const i = kv.indexOf('=');
    if (i > 0) params[kv.substring(0, i)] = dec(kv.substring(i + 1));
  }
  if (!params.key || String(params.key).length < 4) return false;
  const m = url.match(/^[a-zA-Z]+:\/\/([^\/?#]+)/);
  finishWith(m ? m[1] : HOST, params, seenSwf);
  return true;
}

function scanHtml(t, force) {
  if (done || !t) return false;
  let swf = null;
  let m = t.match(RE_SWF_LOADING);
  if (m) swf = m[1];
  else { m = t.match(RE_SWF_ANY); if (m) swf = m[1]; }
  if (!swf) swf = seenSwf;
  const params = {};
  for (const k of KEYS) {
    const re = new RegExp('\\b' + k + '["\']?\\s*[:=]\\s*["\']?([^"\'&<>\\s,;]+)', 'gi');
    let mm;
    while ((mm = re.exec(t)) !== null) {
      if (plausible(String(mm[1]))) { params[k] = String(mm[1]); break; }
    }
  }
  if (!params.user || !params.key || String(params.key).length < 8) return false;
  if (!swf && scans < 10 && !force) return false;   // espera mais um pouco pelo caminho do swf
  finishWith(HOST, params, swf);
  return true;
}

function scanUrls(t) {
  const urls = t.match(/https?:\/\/[^\s"'<>]+/g);
  if (!urls) return false;
  for (const u of urls) note(u.replace(/&amp;/g, '&'));
  for (const u of urls) { if (check(u.replace(/&amp;/g, '&'))) return true; }
  return false;
}

function finishWith(gameHost, params, swf) {
  if (done) return;
  done = true;
  let outHost = gameHost;
  let swfPath = null;
  if (swf) {
    let u = swf;
    if (u.indexOf('//') === 0) u = 'https:' + u;
    const m = u.match(/^https?:\/\/([^\/?#]+)(.*)$/i);
    if (m) {
      outHost = m[1];
      swfPath = String(m[2]).replace(/#.*$/, '');
      if (swfPath === '') swfPath = '/Loading.swf';
    } else {
      swfPath = '/' + u.replace(/^\/+/, '').replace(/#.*$/, '');
    }
  }
  const out = { host: outHost, params: params, user: params.user, key: params.key };
  if (swfPath) out.swf = swfPath;
  try { if (OUT) fs.writeFileSync(OUT, JSON.stringify(out), 'utf8'); } catch (e) {}
  if (timer) clearInterval(timer);
  try { if (win) win.destroy(); } catch (e) {}
  app.exit(0);
}

async function collectHtml() {
  const out = [];
  try {
    for (const f of win.webContents.mainFrame.framesInSubtree) {
      try { out.push(String(await f.executeJavaScript('document.documentElement ? document.documentElement.outerHTML : ""'))); } catch (e) {}
    }
  } catch (e) {}
  return out.join('\n');
}

function start() {
  const ses = session.fromPartition(PARTITION);
  // Chromium "limpo": sem Electron/nome do app no User-Agent.
  ses.setUserAgent(ses.getUserAgent().replace(/\s?Electron\/\S+/i, '').replace(/\s?legend-login\/\S+/i, ''));

  ses.webRequest.onBeforeRequest({ urls: ['<all_urls>'] }, (details, cb) => {
    try { note(details.url); check(details.url); } catch (e) {}
    cb({});
  });

  win = new BrowserWindow({
    width: 1100, height: 800, show: true, autoHideMenuBar: true,
    title: 'Login - ' + HOST,
    backgroundColor: '#0B0A1E',
    webPreferences: { partition: PARTITION, contextIsolation: true, sandbox: true, nodeIntegration: false }
  });
  win.setMenuBarVisibility(false);
  win.on('closed', () => { if (!done) app.exit(1); });
  win.webContents.on('did-navigate', (e, url) => { note(url); check(url); });
  win.webContents.on('did-navigate-in-page', (e, url) => { note(url); check(url); });
  win.webContents.on('did-redirect-navigation', (e, url) => { note(url); check(url); });
  win.webContents.on('did-finish-load', () => { scans = 0; });
  win.webContents.on('page-title-updated', (e, t) => { try { win.setTitle('Login - ' + t); } catch (x) {} });

  timer = setInterval(async () => {
    if (done || !win) return;
    scans++;
    const t = await collectHtml();
    if (!t) return;
    if (scanUrls(t)) return;
    scanHtml(t, false);
  }, 2000);

  win.loadURL('https://' + HOST + '/').catch(() => {});
}

app.on('window-all-closed', () => { app.exit(done ? 0 : 1); });

app.whenReady().then(async () => {
  if (args.logout) {
    try {
      const ses = session.fromPartition(PARTITION);
      await ses.clearStorageData();
      await ses.clearCache();
    } catch (e) {}
    app.exit(0);
    return;
  }
  start();
});
