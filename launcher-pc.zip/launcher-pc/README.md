# Legend PC (AIR desktop, Windows)

Versão para PC do launcher do Legend Mobile. Mesmo código do app de celular (macros, cache, exportar imagens),
com a "ponte" do Android trocada por ActionScript puro (`src/Bridge.as`, `src/LoginWindow.as`).

## v5.1 PC
- Visual de aplicativo de PC: painel lateral fixo (conta, ENTRAR NA CONTA, menus por seção) e barra de status.
- Login do site **dentro da janela** (StageWebView/WebView2, exige o WebView2 do Windows). Se não funcionar, botão
  "Usar Chromium" abre o login em janela (login/LegendLogin.exe).
- Várias contas ao mesmo tempo: 3 janelas (Legend1, Legend2, Legend3), cada uma com login e macros próprios.
  Mantenha as pastas Legend1, Legend2, Legend3 e login lado a lado.
- Telas Full HD / 2K / 4K em Configurações > Tela do jogo (resolução virtual; o log diz se o AIR aceitou).

## v5.0 PC
- Ao abrir, o app já abre o **login do site num Chromium atual** (`login/LegendLogin.exe`, feito com Electron a partir de
  `login-helper/`). Você entra, ele captura user/key e o jogo carrega dentro do app. O login fica salvo no Chromium.
- **Barra lateral** na borda esquerda (passe o mouse para ver os nomes): Entrar/Relogar, Macros, Configurações, Log,
  Tela cheia, Sair da conta. **F10** esconde/mostra a barra.
- Se o `login/` não existir, usa a janela antiga (navegador embutido do AIR + Colar link / código).

## O que mudou em relação ao celular
- Sem ANE/Java: login numa janela com navegador embutido (HTMLLoader). Se o site não funcionar nele, use
  **Colar link / código** (cole o código-fonte da página do jogo, Ctrl+U no navegador normal, ou a URL com user= e key=).
- Menus e textos (log) abrem dentro do app, no mesmo tema. Esc fecha.
- Janela redimensionável. **F11** = tela cheia. Configurações > "Tela do jogo": *Ajustar à janela* (1352x650 com barras)
  ou *Tamanho da janela* (o jogo se reorganiza para o tamanho da janela; experimental).
- Jogo e Loading.swf são baixados direto do servidor (sem servidor local).
- Pasta de mods/capturas: `Documentos\LegendPC\mods\_capturas`.
- Relogar: Configurações > Relogar (fecha o jogo e entra de novo sem reiniciar).
- "Sair da conta" só apaga os cookies que o navegador embutido deixa ver.

## Compilar (GitHub Actions, runner Windows)
1. Suba `launcher-pc.zip` na raiz de um repositório PRIVADO (o projeto tem os arquivos do jogo).
2. Crie `.github/workflows/build-pc.yml` com o conteúdo do arquivo `build-pc.yml`.
3. Tenha o **AIR SDK 51 para Windows** (airsdk.harman.com) como arquivo numa *release* de um repositório seu.
4. Actions > Build PC (Windows) > Run workflow (cole o link da release do SDK).
5. Baixe o artefato `LegendPC-Windows`, extraia e abra `LegendPC.exe`.

Nada disto foi compilado nem testado no jogo ainda. Se o Actions acusar erro, mande o log.
