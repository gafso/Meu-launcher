# Legend PC (AIR desktop, Windows)

Versão para PC do launcher do Legend Mobile. Mesmo código do app de celular (macros, cache, exportar imagens),
com a "ponte" do Android trocada por ActionScript puro (`src/Bridge.as`, `src/LoginWindow.as`).

## v5.5.1 PC (estabilidade) — correções de crash/lag
- Erros não tratados agora são engolidos com mais força (evita o runtime AIR fechar o app do nada).
- Limpeza mais completa no Relogar e no fechamento da janela (timers, domains, unloadAndStop + System.gc).
- GC periódico (~20s) enquanto o jogo está aberto para aliviar pressão de memória no AIR 32-bit.
- `SwfFixer`: harvest menos frequente + limite no número de ApplicationDomains guardados (evita vazamento de memória).
- Timer do MissionMacro reduzido de agressividade (60ms → 180ms).
- Proteção extra no final do carregamento do jogo.

## v5.0 PC
- Ao abrir, o app já abre o **login do site num Chromium atual** (`login/LegendLogin.exe`, feito com Electron a partir de
  `login-helper/`). Você entra, ele captura user/key e o jogo carrega dentro do app. O login fica salvo no Chromium.
- **Barra lateral** na borda esquerda (passe o mouse para ver os nomes): Entrar/Relogar, Macros, Configurações, Log,
  Tela cheia, Sair da conta. **F10** esconde/mostra a barra.
- Se o `login/` não existir, usa a janela antiga (navegador embutido do AIR + Colar link / código).

## O que mudou em relação ao celular
- Sem ANE/Java: login numa janela com navegador embutido (HTMLLoader). Se o site não funcionar nele, use
  **Colar link / código** (cole o código-fonte da página do jogo, Ctrl+U no navegador normal, ou a URL com user= e key=).
- Menus e textos (log) abrem dentro do app, no mesmo tema. Esc fecha.
- Janela redimensionável. **F11** = tela cheia. Configurações > "Tela do jogo": *Ajustar à janela* (1352x650 com barras)
  ou *Tamanho da janela* (o jogo se reorganiza para o tamanho da janela; experimental).
- Jogo e Loading.swf são baixados direto do servidor (sem servidor local).
- Pasta de mods/capturas: `Documentos\LegendPC\mods\_capturas`.
- Relogar: Configurações > Relogar (fecha o jogo e entra de novo sem reiniciar).
- "Sair da conta" só apaga os cookies que o navegador embutido deixa ver.

## Compilar (GitHub Actions, runner Windows)
1. Suba `launcher-pc.zip` na raiz de um repositório PRIVADO (o projeto tem os arquivos do jogo).
2. Crie `.github/workflows/build-pc.yml` com o conteúdo do arquivo `build-pc.yml`.
3. Tenha o **AIR SDK 51 para Windows** (airsdk.harman.com) como arquivo numa *release* de um repositório seu.
4. Actions > Build PC (Windows) > Run workflow (cole o link da release do SDK).
5. Baixe o artefato `LegendPC-Windows`, extraia e abra `LegendPC.exe`.

Nada disto foi compilado nem testado no jogo ainda. Se o Actions acusar erro, mande o log.
