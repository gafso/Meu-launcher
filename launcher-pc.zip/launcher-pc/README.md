# Legend PC (AIR desktop, Windows)

Versão para PC do launcher do Legend Mobile. Mesmo código do app de celular (macros, cache, exportar imagens),
com a "ponte" do Android trocada por ActionScript puro (`src/Bridge.as`, `src/LoginWindow.as`).

## v5.0 PC
- Ao abrir, o app já abre o **login do site num Chromium atual** (`login/LegendLogin.exe`, feito com Electron a partir de
  `login-helper/`). Você entra, ele captura user/key e o jogo carrega dentro do app. O login fica salvo no Chromium.
- **Barra lateral** na borda esquerda (passe o mouse para ver os nomes): Entrar/Relogar, Macros, Configurações, Log,
  Tela cheia, Sair da conta. **F10** esconde/mostra a barra.
- Se o `login/` não existir, usa a janela antiga (navegador embutido do AIR + Colar link / código).

## v5.1 PC
- **Macro de Planos**: depois de pegar a mina, a saída do plano e a espera pelo castelo agora aguentam lag (até 90 s) e o ciclo
  tenta de novo sozinho (até 4 vezes) em vez de parar o macro com "o castelo não carregou". A saída alterna botão da tela / op 19
  e também fecha avisos extras que segurem a saída.
- **Lag / cache**: o cache do jogo ficou numa pasta fixa, `%LOCALAPPDATA%\LegendPC\gamecache` (o cache antigo é movido para lá sozinho);
  arquivos já vistos ficam na RAM, as gravações em disco são feitas aos poucos (não travam o jogo) e a busca de botões/janelas ficou
  bem mais leve. O log mostra "Cache do jogo em: ..." e "Cache ao abrir: N arquivos" para conferir se ele está sendo guardado.
- **Instalador + várias janelas**: o workflow agora gera `LegendPC-Setup.exe` (artefato `LegendPC-Instalador`). Ele instala
  "Legend PC", "Legend PC 2", "Legend PC 3"... (campo `instancias` do workflow, 1 a 6). O AIR só deixa uma janela por app, por isso
  cada instância é um app com id próprio; o cache, a lista de contas e o navegador do login são compartilhados.
  O artefato `LegendPC-Windows` (pasta solta, só a primeira instância) continua existindo.

## O que mudou em relação ao celular
- Sem ANE/Java: login numa janela com navegador embutido (HTMLLoader). Se o site não funcionar nele, use
  **Colar link / código** (cole o código-fonte da página do jogo, Ctrl+U no navegador normal, ou a URL com user= e key=).
- Menus e textos (log) abrem dentro do app, no mesmo tema. Esc fecha.
- Janela redimensionável. **F11** = tela cheia. Configurações > "Tela do jogo": *Ajustar à janela* (1352x650 com barras)
  ou *Tamanho da janela* (o jogo se reorganiza para o tamanho da janela; experimental).
- Jogo e Loading.swf são baixados direto do servidor (sem servidor local).
- Pasta de mods/capturas: `Documentos\LegendPC\mods\_capturas`.
- Relogar: Configurações > Relogar (fecha o jogo e entra de novo sem reiniciar).
- "Sair da conta" só apaga os cookies que o navegador embutido deixa ver.

## Compilar (GitHub Actions, runner Windows)
1. Suba `launcher-pc.zip` na raiz de um repositório PRIVADO (o projeto tem os arquivos do jogo).
2. Crie `.github/workflows/build-pc.yml` com o conteúdo do arquivo `build-pc.yml`.
3. Tenha o **AIR SDK 51 para Windows** (airsdk.harman.com) como arquivo numa *release* de um repositório seu.
4. Actions > Build PC (Windows) > Run workflow (cole o link da release do SDK e, se quiser, o número de instâncias).
5. Baixe o artefato `LegendPC-Instalador`, extraia o `LegendPC-Setup.exe` e instale (ou use `LegendPC-Windows`: pasta solta, abre `LegendPC.exe`).

Nada disto foi compilado nem testado no jogo ainda. Se o Actions acusar erro, mande o log.
