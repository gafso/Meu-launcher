# Nexus Launcher (Novo do zero)

Launcher completamente novo, feito do zero, para o Legend Online.

## Características
- Interface limpa em preto e laranja: tela inicial só com a escolha entre Legend Online e Legend Remake
- Salva as contas utilizadas automaticamente
- Acesso ao jogo via login nativo + proxy local
- **Macro VIP** (Moeda VIP → Pedra secreta / Ordem)
- **Macro de Minas** (modo Planos com portal = 3)
- Modo **60 FPS** disponível (botão e configurações)
- Leve por padrão: sem KeepAlive automático, sem WifiLock, qualidade LOW

## Legend Remake
Na tela inicial, escolha **Legend Remake**, depois **+ Adicionar conta**: entra com usuário e senha (ou cria conta) direto no servidor do Remake.
Contas do Remake ficam salvas como `[Remake] nome` (só usuário + ticket, nunca a senha) e entram com um toque.
O jogo é baixado de `http://45.157.16.32/client/Loading.swf` com os mesmos parâmetros do app oficial do Remake.
Se o IP do servidor mudar, troque a constante `REMAKE` no `src/Main.as`.

## Como funciona
1. Na tela inicial: lista de contas salvas ou "+ Nova conta"
2. Após login, o jogo carrega
3. No jogo aparecem botões flutuantes: **VIP**, **MINAS** e **60 FPS**
4. Contas são salvas em `accounts.json` no armazenamento do app

## Compilar
Mesmo processo do anterior (GitHub Actions + AIR SDK 51).
O keystore é o mesmo, então pode atualizar por cima.

## Observações
- Os macros usam as classes originais (VipMacro e PlanesBot) porque dependem da estrutura interna do jogo.
- O app em si (UI, fluxo, contas, overlay) é 100% novo.
- Para economizar bateria: não deixe em segundo plano e use FPS 30 ou menos quando não precisar de 60.
