package
{
    import flash.display.Sprite;

    // Painel de macros (marcador). GamePlanesAdapter usa só "ch is MacroPanel" para ignorar
    // este painel ao varrer a tela do jogo; o launcher atual não tem painel desse tipo.
    public class MacroPanel extends Sprite
    {
        public function MacroPanel() { super(); }
    }
}
