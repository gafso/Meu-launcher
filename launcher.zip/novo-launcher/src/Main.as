package
{
    import com.meulauncher.air.Bridge;
    import flash.desktop.NativeApplication;
    import flash.desktop.SystemIdleMode;
    import flash.display.Loader;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageQuality;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.SecurityErrorEvent;
    import flash.events.StatusEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.net.URLLoader;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.net.URLRequestHeader;
    import flash.net.URLRequestMethod;
    import flash.system.ApplicationDomain;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.utils.ByteArray;

    [SWF(width="1280", height="720", frameRate="30", backgroundColor="#0D1117")]
    public class Main extends Sprite
    {
        private static const VERSION:String = "Nexus 1.0";
        private static const HOST:String = "lobr.creaction-network.com";
        // Legend Remake: servidor próprio (HTTP), login por API JSON em /launcher/api/<acao>
        private static const REMAKE:String = "http://45.157.16.32";

        // Tema preto + laranja
        private static const BG:uint     = 0x0A0A0A;
        private static const CARD:uint   = 0x161616;
        private static const LINE:uint   = 0x2B2B2B;
        private static const ORANGE:uint = 0xFF7A00;
        private static const TEXT:uint   = 0xFFFFFF;
        private static const MUTED:uint  = 0x8C8C8C;
        private static const ERR:uint    = 0xFF5A4D;

        private var bridge:Bridge;
        private var session:Object;
        private var accounts:Array = [];
        private var ui:Sprite = new Sprite();
        private var gameLoader:Loader;
        private var inGame:Boolean = false;
        private var port:int = 0;
        private var apiBusy:Boolean = false;
        private var statusTf:TextField;
        private var userTf:TextField;
        private var passTf:TextField;

        // Macros
        private var vipMacro:VipMacro;
        private var planesBot:PlanesBot;
        private var macroOverlay:Sprite;

        public function Main()
        {
            stage.align = StageAlign.TOP_LEFT;
            stage.scaleMode = StageScaleMode.NO_SCALE;
            stage.quality = StageQuality.LOW;
            stage.frameRate = 30;

            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.NORMAL; } catch (e:Error) {}

            bridge = new Bridge();
            bridge.addEventListener("game", onGameSession);
            bridge.addEventListener("error", onError);

            loadAccounts();
            SwfFixer.install();

            addChild(ui);
            showHome();
        }

        // ---------- telas ----------
        private function showHome():void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            drawBackground();
            var cx:Number = stage.stageWidth / 2;

            var title:TextField = makeText("LEGEND", 46, ORANGE, true);
            title.x = cx - title.width / 2; title.y = 60;
            ui.addChild(title);

            var sub:TextField = makeText("Escolha onde jogar", 16, MUTED);
            sub.x = cx - sub.width / 2; sub.y = 128;
            ui.addChild(sub);

            var online:Sprite = makeCard("Legend Online", "Servidor original", 340, 170);
            online.x = cx - 340 - 20; online.y = 200;
            online.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { showServer("online"); });
            ui.addChild(online);

            var remake:Sprite = makeCard("Legend Remake", "Servidor Remake", 340, 170);
            remake.x = cx + 20; remake.y = 200;
            remake.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { showServer("remake"); });
            ui.addChild(remake);

            var cfg:TextField = makeText("Configurações", 15, MUTED);
            cfg.x = cx - cfg.width / 2; cfg.y = stage.stageHeight - 70;
            cfg.selectable = false; cfg.mouseEnabled = true;
            cfg.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { showSettings(); });
            ui.addChild(cfg);
        }

        // Contas salvas de um servidor + adicionar conta
        private function showServer(kind:String):void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            drawBackground();
            var isRemake:Boolean = (kind == "remake");
            var cx:Number = stage.stageWidth / 2;

            var title:TextField = makeText(isRemake ? "LEGEND REMAKE" : "LEGEND ONLINE", 30, ORANGE, true);
            title.x = cx - title.width / 2; title.y = 36;
            ui.addChild(title);

            // contas deste servidor, as mais recentes primeiro (cabem 5 na tela)
            var list:Array = [];
            for (var i:int = 0; i < accounts.length; i++)
                if (Boolean(accounts[i].remake) == isRemake) list.push(accounts[i]);
            list.sortOn("saved", Array.NUMERIC | Array.DESCENDING);

            var y:Number = 110;
            if (list.length == 0)
            {
                var empty:TextField = makeText("Nenhuma conta salva.", 16, MUTED);
                empty.x = cx - empty.width / 2; empty.y = y + 10;
                ui.addChild(empty);
            }
            else
            {
                for (var j:int = 0; j < list.length && j < 5; j++)
                {
                    var acc:Object = list[j];
                    var row:Sprite = makeButton(String(acc.name || "Conta"), CARD, TEXT, 360);
                    row.x = cx - 180; row.y = y;
                    row.addEventListener(MouseEvent.CLICK, makeAccountClick(acc));
                    ui.addChild(row);
                    y += 58;
                }
            }

            var addY:Number = stage.stageHeight - 150;
            var add:Sprite = makeButton("+ Adicionar conta", ORANGE, BG, 360);
            add.x = cx - 180; add.y = addY;
            add.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                if (isRemake) showRemakeLogin(); else bridge.login(HOST);
            });
            ui.addChild(add);

            var back:Sprite = makeButton("Voltar", CARD, MUTED, 360);
            back.x = cx - 180; back.y = addY + 58;
            back.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { showHome(); });
            ui.addChild(back);
        }

        // Tela simples de mensagem central (carregando...)
        private function showLoading(msg:String):void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            drawBackground();
            statusTf = makeText(msg, 18, MUTED);
            statusTf.x = stage.stageWidth / 2 - statusTf.width / 2;
            statusTf.y = stage.stageHeight / 2 - 12;
            ui.addChild(statusTf);
        }

        // =====================================================================
        //  LEGEND REMAKE
        //  Fluxo (igual ao do app oficial do Remake):
        //   1) POST {REMAKE}/launcher/api/login|register  {username,password,target:"web"} -> {ok,username,ticket}
        //      (contas salvas usam /launcher/api/resume {username,ticket}; a senha NUNCA é salva)
        //   2) GET  {REMAKE}/client/Loading.swf  e carrega com os parâmetros user/key/site/config...
        // =====================================================================
        private function showRemakeLogin(prefill:String = "", msg:String = ""):void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            drawBackground();
            var cx:Number = stage.stageWidth / 2;
            var fx:Number = cx - 140;

            var title:TextField = makeText("LEGEND REMAKE", 30, ORANGE, true);
            title.x = cx - title.width / 2; title.y = 36;
            ui.addChild(title);

            var l1:TextField = makeText("Usuário ou email", 14, MUTED);
            l1.x = fx; l1.y = 110;
            ui.addChild(l1);
            userTf = makeInput(false);
            userTf.x = fx; userTf.y = 134;
            userTf.text = prefill;
            ui.addChild(userTf);

            var l2:TextField = makeText("Senha", 14, MUTED);
            l2.x = fx; l2.y = 190;
            ui.addChild(l2);
            passTf = makeInput(true);
            passTf.x = fx; passTf.y = 214;
            ui.addChild(passTf);

            statusTf = makeText(msg, 14, ERR);
            statusTf.x = fx; statusTf.y = 264;
            ui.addChild(statusTf);

            var go:Sprite = makeButton("Entrar", ORANGE, BG);
            go.x = fx; go.y = 300;
            go.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { remakeSubmit("login"); });
            ui.addChild(go);

            var reg:Sprite = makeButton("Criar conta", CARD, TEXT);
            reg.x = fx; reg.y = 358;
            reg.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { remakeSubmit("register"); });
            ui.addChild(reg);

            var back:Sprite = makeButton("Voltar", CARD, MUTED);
            back.x = fx; back.y = 416;
            back.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { showServer("remake"); });
            ui.addChild(back);
        }

        private function makeInput(password:Boolean):TextField
        {
            var tf:TextField = new TextField();
            tf.type = TextFieldType.INPUT;
            tf.defaultTextFormat = new TextFormat("_sans", 18, TEXT);
            tf.background = true; tf.backgroundColor = CARD;
            tf.border = true; tf.borderColor = LINE;
            tf.width = 280; tf.height = 40;
            tf.maxChars = 60;
            tf.displayAsPassword = password;
            tf.needsSoftKeyboard = true;
            tf.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                stage.focus = tf;
                tf.requestSoftKeyboard();
            });
            return tf;
        }

        private function setRemakeStatus(msg:String, error:Boolean = false):void
        {
            if (!statusTf) return;
            statusTf.textColor = error ? ERR : MUTED;
            statusTf.text = msg;
        }

        private function remakeSubmit(action:String):void
        {
            if (apiBusy) return;
            var user:String = userTf.text.replace(/^\s+|\s+$/g, "");
            var pass:String = passTf.text;
            if (user.length == 0 || pass.length == 0) { setRemakeStatus("Preencha usuário e senha.", true); return; }
            if (action == "register" && !/^[A-Za-z0-9_]{3,20}$/.test(user))
            {
                setRemakeStatus("O usuário deve ter de 3 a 20 letras, números ou _.", true);
                return;
            }
            setRemakeStatus(action == "register" ? "Criando a conta..." : "Entrando...");
            remakeApi(action, {username: user, password: pass, target: "web"},
                function(r:Object):void {
                    var u:String = r.username ? String(r.username) : user;
                    saveRemakeAccount(u, String(r.ticket));
                    remakeStart(u, String(r.ticket));
                },
                function(err:String):void { setRemakeStatus(err, true); });
        }

        private function remakeResume(acc:Object):void
        {
            var user:String = String(acc.user || acc.name);
            showLoading("Entrando como " + user + "...");
            remakeApi("resume", {username: user, ticket: String(acc.ticket)},
                function(r:Object):void {
                    var u:String = r.username ? String(r.username) : user;
                    saveRemakeAccount(u, String(r.ticket));
                    remakeStart(u, String(r.ticket));
                },
                function(err:String):void { showRemakeLogin(user, err); });
        }

        private function remakeApi(action:String, body:Object, onOk:Function, onFail:Function):void
        {
            if (apiBusy) return;
            apiBusy = true;
            var req:URLRequest = new URLRequest(REMAKE + "/launcher/api/" + action);
            req.method = URLRequestMethod.POST;
            req.contentType = "application/json";
            req.requestHeaders = [new URLRequestHeader("Accept", "application/json")];
            req.data = JSON.stringify(body);

            var l:URLLoader = new URLLoader();
            var parse:Function = function():Object {
                try { return JSON.parse(String(l.data)); } catch (err:Error) {}
                return null;
            };
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                apiBusy = false;
                var r:Object = parse();
                if (r && r.ok && r.ticket) onOk(r);
                else onFail(r && r.error ? String(r.error) : "Resposta inválida do servidor.");
            });
            var netFail:Function = function(ev:Event):void {
                apiBusy = false;
                var r:Object = parse();   // o servidor pode devolver o motivo junto com um erro HTTP
                onFail(r && r.error ? String(r.error) : "Sem conexão com o servidor. Confira a internet e tente de novo.");
            };
            l.addEventListener(IOErrorEvent.IO_ERROR, netFail);
            l.addEventListener(SecurityErrorEvent.SECURITY_ERROR, netFail);
            l.load(req);
        }

        private function remakeStart(user:String, ticket:String):void
        {
            showLoading("Baixando o jogo...");

            var params:Object = {
                user: user,
                key: ticket,
                site: "broas_0905",
                logintype: "4",
                p2: "",
                rid: "",
                config: REMAKE + "/client/config.xml?user=" + encodeURIComponent(user),
                scaleMode: "showAll",
                align: "TL"
            };

            var loader:URLLoader = new URLLoader();
            loader.dataFormat = URLLoaderDataFormat.BINARY;
            loader.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var bytes:ByteArray = ByteArray(loader.data);
                if (bytes.length > 1000 && (bytes[0] == 0x46 || bytes[0] == 0x43 || bytes[0] == 0x5A)) // FWS/CWS/ZWS
                    startGame(bytes, params);
                else
                    showRemakeLogin(user, "O servidor não devolveu o jogo.");
            });
            loader.addEventListener(IOErrorEvent.IO_ERROR, function(ev:Event):void {
                showRemakeLogin(user, "Não deu para baixar o jogo. Confira a internet e tente de novo.");
            });
            loader.load(new URLRequest(REMAKE + "/client/Loading.swf?v=" + new Date().time));
        }

        // Guarda só usuário + ticket (nunca a senha), separado das contas do servidor antigo.
        private function saveRemakeAccount(user:String, ticket:String):void
        {
            var entry:Object = { name: user, user: user, ticket: ticket, remake: true, host: REMAKE, saved: new Date().time };
            var found:Boolean = false;
            for (var i:int = 0; i < accounts.length; i++)
            {
                if (accounts[i].remake && accounts[i].name == user) { accounts[i] = entry; found = true; break; }
            }
            if (!found) accounts.push(entry);
            saveAccounts();
        }

        private function onNewLogin(e:MouseEvent):void
        {
            bridge.login(HOST);
        }

        private function makeAccountClick(acc:Object):Function
        {
            return function(e:MouseEvent):void
            {
                if (acc.remake) { remakeResume(acc); return; }
                try {
                    session = JSON.parse(String(acc.session));
                    enterGame();
                } catch (err:Error) {
                    trace("Conta inválida");
                }
            };
        }

        private function onGameSession(e:StatusEvent):void
        {
            try {
                session = JSON.parse(e.level);
                saveCurrentAccount();
                enterGame();
            } catch (err:Error) {
                trace("Erro sessão: " + err.message);
            }
        }

        private function enterGame():void
        {
            if (!session || !session.host) return;
            port = bridge.startServer(session.host);
            if (port <= 0) return;

            // Não inicia KeepAlive automaticamente (economia de bateria)
            fetchAndLoadSwf();
        }

        private function fetchAndLoadSwf():void
        {
            // Tenta via proxy local; se falhar, usa o SWF empacotado
            var loader:URLLoader = new URLLoader();
            loader.dataFormat = URLLoaderDataFormat.BINARY;
            loader.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var bytes:ByteArray = ByteArray(loader.data);
                if (bytes.length > 1000 && (bytes[0] == 0x46 || bytes[0] == 0x43 || bytes[0] == 0x5A)) // FWS/CWS/ZWS
                    startGame(bytes);
                else
                    loadFallbackSwf();
            });
            loader.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void { loadFallbackSwf(); });
            loader.load(new URLRequest("http://127.0.0.1:" + port + "/client/Loading.swf"));
        }

        private function loadFallbackSwf():void
        {
            var f:File = File.applicationDirectory.resolvePath("assets/game/Loading.swf");
            if (f.exists) {
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.READ);
                var b:ByteArray = new ByteArray();
                fs.readBytes(b);
                fs.close();
                startGame(b);
            }
        }

        private function startGame(bytes:ByteArray, gameParams:Object = null):void
        {
            inGame = true;
            while (ui.numChildren) ui.removeChildAt(0);

            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;

            var params:Object = {};
            if (gameParams)
            {
                // Legend Remake: parâmetros prontos (user, key, site, config...)
                for (var gk:String in gameParams) params[gk] = String(gameParams[gk]);
            }
            else
            {
                if (session.params) {
                    for (var k:String in session.params) params[k] = String(session.params[k]);
                }
                params["http"] = "https:";
                params["config"] = "https://" + session.host + "/client/config.xml";
                params["base"] = "https://" + session.host + "/client/";
            }
            ctx.parameters = params;

            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                SwfFixer.gameDomain = gameLoader.contentLoaderInfo.applicationDomain;
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, onGameLoaded);
            gameLoader.loadBytes(bytes, ctx);
            addChild(gameLoader);

            createMacroOverlay();
        }

        private function onGameLoaded(e:Event):void
        {
            // Macros disponíveis
            vipMacro = new VipMacro();
            vipMacro.logger = function(s:String):void { trace("[VIP] " + s); };

            var ad:GamePlanesAdapter = new GamePlanesAdapter();
            planesBot = new PlanesBot(ad, "Minas");
            planesBot.logger = function(s:String):void { trace("[MINAS] " + s); };
            planesBot.opts.portal = 3;
        }

        private function createMacroOverlay():void
        {
            macroOverlay = new Sprite();
            macroOverlay.x = 20;
            macroOverlay.y = 20;

            var vipBtn:Sprite = makeButton("VIP", ORANGE, BG, 100);
            vipBtn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                if (vipMacro && !vipMacro.running) vipMacro.start();
            });
            macroOverlay.addChild(vipBtn);

            var mineBtn:Sprite = makeButton("MINAS", ORANGE, BG, 100);
            mineBtn.x = 110;
            mineBtn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                if (planesBot && !planesBot.running) {
                    // Modo minas (portal = 3)
                    try {
                        planesBot.opts = planesBot.opts || {};
                        planesBot.opts.portal = 3;
                        planesBot.start();
                    } catch (err:Error) { trace("Erro minas: " + err.message); }
                }
            });
            macroOverlay.addChild(mineBtn);

            var fpsBtn:Sprite = makeButton("60 FPS", BG, ORANGE, 100);
            fpsBtn.x = 220;
            fpsBtn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                stage.frameRate = 60;
            });
            macroOverlay.addChild(fpsBtn);

            stage.addChild(macroOverlay);
        }

        private function showSettings():void
        {
            var cx:Number = stage.stageWidth / 2;
            var panel:Sprite = new Sprite();
            panel.graphics.beginFill(CARD, 1);
            panel.graphics.lineStyle(2, ORANGE);
            panel.graphics.drawRoundRect(cx - 220, 150, 440, 250, 20);
            panel.graphics.endFill();

            var t:TextField = makeText("Configurações", 22, ORANGE, true);
            t.x = cx - t.width / 2; t.y = 170;
            panel.addChild(t);

            var fps30:Sprite = makeButton("FPS 30", BG, TEXT, 190);
            fps30.x = cx - 200; fps30.y = 230;
            fps30.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { stage.frameRate = 30; });
            panel.addChild(fps30);

            var fps60:Sprite = makeButton("FPS 60", ORANGE, BG, 190);
            fps60.x = cx + 10; fps60.y = 230;
            fps60.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { stage.frameRate = 60; });
            panel.addChild(fps60);

            var close:Sprite = makeButton("Fechar", BG, MUTED, 400);
            close.x = cx - 200; close.y = 320;
            close.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { ui.removeChild(panel); });
            panel.addChild(close);

            ui.addChild(panel);
        }

        // ---------- helpers ----------
        private function drawBackground():void
        {
            var bg:Shape = new Shape();
            bg.graphics.beginFill(BG);
            bg.graphics.drawRect(0, 0, stage.stageWidth, stage.stageHeight);
            bg.graphics.endFill();
            ui.addChild(bg);
        }

        private function makeText(txt:String, size:int, color:uint, bold:Boolean = false):TextField
        {
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            tf.text = txt;
            tf.selectable = false;
            tf.autoSize = "left";
            return tf;
        }

        private function makeButton(label:String, bg:uint, fg:uint, w:Number = 280):Sprite
        {
            var s:Sprite = new Sprite();
            s.graphics.beginFill(bg);
            s.graphics.lineStyle(1, bg == BG || bg == CARD ? LINE : bg);
            s.graphics.drawRoundRect(0, 0, w, 48, 12);
            s.graphics.endFill();
            var t:TextField = makeText(label, 16, fg, true);
            t.x = (w - t.width) / 2; t.y = 12;
            s.addChild(t);
            s.mouseChildren = false;
            s.buttonMode = true;
            return s;
        }

        private function makeCard(name:String, sub:String, w:Number, h:Number):Sprite
        {
            var s:Sprite = new Sprite();
            s.graphics.beginFill(CARD);
            s.graphics.lineStyle(2, ORANGE);
            s.graphics.drawRoundRect(0, 0, w, h, 20);
            s.graphics.endFill();
            var t:TextField = makeText(name, 26, TEXT, true);
            t.x = (w - t.width) / 2; t.y = h / 2 - 34;
            s.addChild(t);
            var u:TextField = makeText(sub, 14, MUTED);
            u.x = (w - u.width) / 2; u.y = h / 2 + 8;
            s.addChild(u);
            s.mouseChildren = false;
            s.buttonMode = true;
            return s;
        }

        private function loadAccounts():void
        {
            var f:File = File.applicationStorageDirectory.resolvePath("accounts.json");
            if (!f.exists) return;
            try {
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.READ);
                accounts = JSON.parse(fs.readUTFBytes(fs.bytesAvailable)) as Array;
                fs.close();
            } catch (e:Error) { accounts = []; }
        }

        private function saveCurrentAccount():void
        {
            if (!session) return;
            var user:String = session.user || (session.params && session.params.user) || "Conta";
            var entry:Object = {
                name: user,
                host: session.host,
                session: JSON.stringify(session),
                saved: new Date().time
            };
            // Update or add
            var found:Boolean = false;
            for (var i:int = 0; i < accounts.length; i++) {
                if (!accounts[i].remake && accounts[i].name == user) { accounts[i] = entry; found = true; break; }
            }
            if (!found) accounts.push(entry);
            saveAccounts();
        }

        private function saveAccounts():void
        {
            var f:File = File.applicationStorageDirectory.resolvePath("accounts.json");
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.WRITE);
            fs.writeUTFBytes(JSON.stringify(accounts));
            fs.close();
        }

        private function onError(e:StatusEvent):void
        {
            trace("Erro nativo: " + e.level);
        }
    }
}
