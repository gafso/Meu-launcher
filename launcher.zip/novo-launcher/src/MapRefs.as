package
{
    // Mapas de referência para achar o "olho" nos planos.
    // A base original de mapas não veio no projeto, então aqui ela está vazia:
    // nenhum mapa é reconhecido e o PlanesBot cai na exploração geral da névoa (caminho "mapa desconhecido").
    public class MapRefs
    {
        // Lugares candidatos onde o olho estaria (vazio = nenhum mapa conhecido).
        public static function candidates(list:Array, cols:int, rows:int, onlyUnseen:Boolean = true):Array
        {
            return [];
        }

        // Mapa reconhecido: {name, ex, ey} ou null se desconhecido.
        public static function match(list:Array, cols:int, rows:int):Object
        {
            return null;
        }
    }
}
