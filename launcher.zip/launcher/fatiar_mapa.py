#!/usr/bin/env python3
"""Fatia uma imagem grande nos tiles do mapa 10000 (tile_X_Y.jpg) para a pasta mods.

Uso:  python3 fatiar_mapa.py minha_imagem.png LARGURA_TILE ALTURA_TILE [colunas] [linhas]
Ex.:  python3 fatiar_mapa.py minha_imagem.png 256 256 30 20

Descubra o tamanho de UM tile abrindo no navegador, por exemplo:
https://res1011oas.creaction-network.com/mapmaterial/land/10000/tile_5_3_803a702d.jpg
(Colunas/linhas vistas na lista: X de 0 a 29, Y de 0 a 19 => 30 x 20.)
Depois copie a pasta 'saida' inteira para  Android/data/<pacote>/files/mods/
Requer: pip install pillow
"""
import os, sys
from PIL import Image

if len(sys.argv) < 4:
    print(__doc__); sys.exit(1)
src, tw, th = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
cols = int(sys.argv[4]) if len(sys.argv) > 4 else 30
rows = int(sys.argv[5]) if len(sys.argv) > 5 else 20
img = Image.open(src).convert("RGB").resize((cols * tw, rows * th), Image.LANCZOS)
os.makedirs("saida", exist_ok=True)
for x in range(cols):
    for y in range(rows):
        img.crop((x * tw, y * th, (x + 1) * tw, (y + 1) * th)).save(f"saida/tile_{x}_{y}.jpg", quality=90)
print(f"{cols*rows} tiles gravados em ./saida")
