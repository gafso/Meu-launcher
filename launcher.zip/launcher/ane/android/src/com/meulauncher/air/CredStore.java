package com.meulauncher.air;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import org.json.JSONObject;

import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

// Guarda usuário e senha CRIPTOGRAFADOS (AES-256-GCM) com uma chave do Android Keystore.
// A chave nunca sai do aparelho e o app não consegue exportá-la. Uma entrada por servidor (host).
// Só funciona no Android 6+ (API 23); abaixo disso nada é salvo.
final class CredStore {
    private static final String ALIAS = "meulauncher_cred";
    private static final String PREFS = "meulauncher_cred";

    static boolean supported() { return Build.VERSION.SDK_INT >= 23; }

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            kg.init(new KeyGenParameterSpec.Builder(ALIAS,
                    KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
            return kg.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    static boolean save(Context c, String host, String user, String pass) {
        if (!supported()) return false;
        try {
            JSONObject o = new JSONObject();
            o.put("user", user);
            o.put("pass", pass);
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.ENCRYPT_MODE, key());
            byte[] ct = ci.doFinal(o.toString().getBytes("UTF-8"));
            String v = Base64.encodeToString(ci.getIV(), Base64.NO_WRAP) + ":" + Base64.encodeToString(ct, Base64.NO_WRAP);
            c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("c:" + host, v).apply();
            return true;
        } catch (Throwable t) { return false; }
    }

    // Devolve {"user":"...","pass":"..."} ou "" se não houver nada salvo.
    static String load(Context c, String host) {
        if (!supported()) return "";
        try {
            String v = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("c:" + host, null);
            if (v == null) return "";
            int i = v.indexOf(':');
            if (i < 0) return "";
            byte[] iv = Base64.decode(v.substring(0, i), Base64.NO_WRAP);
            byte[] ct = Base64.decode(v.substring(i + 1), Base64.NO_WRAP);
            Cipher ci = Cipher.getInstance("AES/GCM/NoPadding");
            ci.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));
            return new String(ci.doFinal(ct), "UTF-8");
        } catch (Throwable t) { return ""; }
    }

    static void forget(Context c, String host) {
        try {
            SharedPreferences.Editor e = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
            if (host == null || host.length() == 0) e.clear(); else e.remove("c:" + host);
            e.apply();
        } catch (Throwable t) {}
    }
}
