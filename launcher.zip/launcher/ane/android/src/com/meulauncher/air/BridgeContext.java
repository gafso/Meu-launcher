package com.meulauncher.air;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Matrix;
import android.os.Build;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

import java.util.HashMap;
import java.util.Map;

public class BridgeContext extends FREContext {
    private LocalServer server;

    @Override public Map<String, FREFunction> getFunctions() {
        Map<String, FREFunction> m = new HashMap<String, FREFunction>();
        m.put("login", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                Intent i = new Intent(getActivity(), LoginActivity.class);
                i.putExtra("host", a[0].getAsString());
                getActivity().startActivity(i);
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("setStageSize", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try { applyStage(getActivity(), a[0].getAsInt(), a[1].getAsInt()); } catch (Exception e) {}
            return null; } });
        m.put("setRefreshRate", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try { applyRefresh(getActivity(), a[0].getAsInt()); } catch (Exception e) {}
            return null; } });
        m.put("displayHz", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                android.view.Display d = getActivity().getWindowManager().getDefaultDisplay();
                return FREObject.newObject((double) d.getRefreshRate());
            } catch (Exception e) { return null; } } });
        m.put("modsPath", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                java.io.File d = getActivity().getExternalFilesDir(null);
                java.io.File mods = new java.io.File(d != null ? d : getActivity().getFilesDir(), "mods");
                mods.mkdirs();
                return FREObject.newObject(mods.getAbsolutePath());
            } catch (Exception e) { return null; } } });
        m.put("startServer", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                if (server != null) server.stop();
                java.io.File mods = getActivity().getExternalFilesDir(null);
                mods = new java.io.File(mods != null ? mods : getActivity().getFilesDir(), "mods");
                server = new LocalServer(a[0].getAsString(), mods);
                return FREObject.newObject(server.start());
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            try { return FREObject.newObject(0); } catch (Exception e) { return null; } } });
        m.put("showMenu", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                final String title = a[0].getAsString();
                final String[] items = a[1].getAsString().split("\\|");
                getActivity().runOnUiThread(new Runnable() { public void run() {
                    AlertDialog dlg = themedBuilder(getActivity()).setTitle(title)
                        .setItems(items, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int which) {
                                dispatchStatusEventAsync("menu", String.valueOf(which)); } })
                        .create();
                    styleDialog(dlg);
                    dlg.show();
                    tintButtons(dlg); } });
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("toBackground", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            // Manda o app para segundo plano (como o botão Início) sem fechá-lo.
            try { getActivity().moveTaskToBack(true); }
            catch (Exception e) { dispatchStatusEventAsync("error", "toBackground: " + e); }
            return null; } });
        m.put("keepAlive", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                Intent i = new Intent(getActivity(), KeepAliveService.class);
                if (a[0].getAsBool()) {
                    // Android 13+: sem esta permissão a notificação do serviço não aparece.
                    if (Build.VERSION.SDK_INT >= 33
                        && getActivity().checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                           != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        getActivity().requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7071);
                    }
                    if (Build.VERSION.SDK_INT >= 26) getActivity().startForegroundService(i);
                    else getActivity().startService(i);
                } else getActivity().stopService(i);
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("restartApp", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            Activity act = getActivity();
            // RestartActivity roda em outro processo e reabre o app depois que este morrer.
            Intent i = new Intent(act, RestartActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
            android.os.Process.killProcess(android.os.Process.myPid());
            return null; } });
        m.put("clearSession", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookies(null); cm.flush();
            return null; } });
        m.put("setSurfaceSize", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            // Troca a resolução em que o jogo é desenhado (w <= 0 volta ao tamanho nativo).
            // O Android estica essa superfície menor até preencher a tela, então tudo fica maior.
            try {
                final int w = a[0].getAsInt();
                final int h = a[1].getAsInt();
                final Activity act = getActivity();
                act.runOnUiThread(new Runnable() { public void run() {
                    try { applySurface(act, w, h); }
                    catch (Throwable t) { dispatchStatusEventAsync("error", "setSurfaceSize: " + t); }
                } });
            } catch (Exception e) { dispatchStatusEventAsync("error", "setSurfaceSize: " + e); }
            return null; } });
        m.put("showText", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                final String title = a[0].getAsString();
                final String text = a[1].getAsString();
                getActivity().runOnUiThread(new Runnable() { public void run() {
                    AlertDialog dlg = themedBuilder(getActivity()).setTitle(title).setMessage(text)
                        .setPositiveButton("Copiar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                ClipboardManager cb = (ClipboardManager)
                                    getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
                                cb.setPrimaryClip(ClipData.newPlainText("log", text)); } })
                        .setNegativeButton("Fechar", null).create();
                    styleDialog(dlg);
                    dlg.show();
                    tintButtons(dlg); } });
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        return m;
    }

    // ---------- visual dos diálogos ----------
    // Tema escuro do sistema + fundo azul-marinho com cantos arredondados (combina com o launcher).
    static AlertDialog.Builder themedBuilder(Activity act) {
        return new AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    // Botões do diálogo (Copiar / Fechar) em vermelho; só existem depois de show().
    static void tintButtons(AlertDialog d) {
        try {
            int[] ids = { DialogInterface.BUTTON_POSITIVE, DialogInterface.BUTTON_NEGATIVE, DialogInterface.BUTTON_NEUTRAL };
            for (int id : ids) {
                android.widget.Button b = d.getButton(id);
                if (b != null) b.setTextColor(0xFFFF5A63);
            }
        } catch (Throwable t) {}
    }

    static void styleDialog(AlertDialog d) {
        try {
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setColor(0xFF140A0C);
            g.setCornerRadius(28f);
            g.setStroke(2, 0xFF5A1B22);
            d.getWindow().setBackgroundDrawable(g);
        } catch (Throwable t) {}
    }

    // ---------- resolução virtual (escala) ----------
    // O AIR usa o tamanho da própria SurfaceView como tamanho do palco. Então damos a ela w x h
    // pixels e a REDUZIMOS/AMPLIAMOS com escala (e centralizamos) para caber na tela, mantendo a
    // proporção. O toque é convertido pelo Android de volta para as coordenadas do palco.
    // (w, h) = (0, 0) restaura o modo normal (tela cheia).
    private static void applyStage(final Activity act, final int w, final int h) {
        act.runOnUiThread(new Runnable() { public void run() {
            try {
                final SurfaceView sv = findSurface(act.getWindow().getDecorView());
                if (sv == null) return;
                if (w <= 0 || h <= 0) { resetView(act, sv); return; }
                try { act.getWindow().getDecorView().setBackgroundColor(0xFF000000); } catch (Throwable t) {}
                ViewGroup parent = (ViewGroup) sv.getParent();
                int pw = parent != null ? parent.getWidth() : 0;
                int ph = parent != null ? parent.getHeight() : 0;
                if (pw <= 0 || ph <= 0) {
                    android.util.DisplayMetrics dm = act.getResources().getDisplayMetrics();
                    pw = Math.max(dm.widthPixels, dm.heightPixels);
                    ph = Math.min(dm.widthPixels, dm.heightPixels);
                }
                float s = Math.min((float) pw / w, (float) ph / h);
                ViewGroup.LayoutParams lp = sv.getLayoutParams();
                if (lp == null) return;
                lp.width = w;
                lp.height = h;
                if (lp instanceof android.widget.FrameLayout.LayoutParams)
                    ((android.widget.FrameLayout.LayoutParams) lp).gravity = android.view.Gravity.TOP | android.view.Gravity.LEFT;
                if (lp instanceof ViewGroup.MarginLayoutParams) {
                    ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
                    m.leftMargin = 0; m.topMargin = 0; m.rightMargin = 0; m.bottomMargin = 0;
                }
                sv.setPivotX(0f); sv.setPivotY(0f);
                sv.setScaleX(s); sv.setScaleY(s);
                sv.setTranslationX((pw - w * s) / 2f);
                sv.setTranslationY((ph - h * s) / 2f);
                sv.setLayoutParams(lp);
                sv.requestLayout();
            } catch (Throwable t) {}
        } });
    }

    // ---------- taxa de atualização da tela (ex.: 120 Hz) ----------
    private static void applyRefresh(final Activity act, final int fps) {
        act.runOnUiThread(new Runnable() { public void run() {
            try {
                android.view.Window w = act.getWindow();
                android.view.WindowManager.LayoutParams p = w.getAttributes();
                p.preferredRefreshRate = fps;
                if (android.os.Build.VERSION.SDK_INT >= 23) {
                    android.view.Display d = w.getWindowManager().getDefaultDisplay();
                    android.view.Display.Mode cur = d.getMode();
                    android.view.Display.Mode best = null;
                    for (android.view.Display.Mode m : d.getSupportedModes()) {
                        if (m.getPhysicalWidth() != cur.getPhysicalWidth() || m.getPhysicalHeight() != cur.getPhysicalHeight()) continue;
                        if (best == null || Math.abs(m.getRefreshRate() - fps) < Math.abs(best.getRefreshRate() - fps)) best = m;
                    }
                    if (best != null) p.preferredDisplayModeId = best.getModeId();
                }
                w.setAttributes(p);
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    SurfaceView sv = findSurface(w.getDecorView());
                    if (sv != null) {
                        // Surface.setFrameRate(float, int) existe só a partir do Android 11: via reflexão.
                        android.view.Surface.class.getMethod("setFrameRate", float.class, int.class)
                            .invoke(sv.getHolder().getSurface(), (float) fps, 0);
                    }
                }
            } catch (Throwable t) {}
        } });
    }

    // ---------- resolução (SurfaceView) ----------
    private static SurfaceView findSurface(View v) {
        if (v instanceof SurfaceView) return (SurfaceView) v;
        SurfaceView best = null;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                SurfaceView f = findSurface(g.getChildAt(i));
                if (f != null && (best == null || f.getWidth() * f.getHeight() > best.getWidth() * best.getHeight())) best = f;
            }
        }
        return best;
    }

    // A SurfaceView SEMPRE continua ocupando a tela inteira (MATCH_PARENT). Só o tamanho do buffer
    // de desenho muda (setFixedSize) e o Android estica esse buffer até preencher a tela.
    // O Main.as já pede um tamanho com a MESMA proporção da tela, então não há distorção nem barras.
    // (Antes o tamanho da própria View era alterado: isso deslocava e cortava o jogo e escondia a engrenagem.)
    private static void resetView(Activity act, SurfaceView sv) {
        try { act.getWindow().getDecorView().setBackgroundColor(0xFF000000); } catch (Throwable t) {}
        ViewGroup.LayoutParams lp = sv.getLayoutParams();
        if (lp == null) return;
        lp.width = ViewGroup.LayoutParams.MATCH_PARENT;
        lp.height = ViewGroup.LayoutParams.MATCH_PARENT;
        if (lp instanceof android.widget.FrameLayout.LayoutParams)
            ((android.widget.FrameLayout.LayoutParams) lp).gravity = 0;
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            ViewGroup.MarginLayoutParams m = (ViewGroup.MarginLayoutParams) lp;
            m.leftMargin = 0; m.topMargin = 0; m.rightMargin = 0; m.bottomMargin = 0;
        }
        sv.setTranslationX(0); sv.setTranslationY(0);
        sv.setScaleX(1f); sv.setScaleY(1f);
        sv.setLayoutParams(lp);
        sv.requestLayout();
    }

    // Quando o Android recria a superfície (ex.: ao voltar do login), reaplica o tamanho escolhido.
    private static int wantW = 0, wantH = 0;
    private static SurfaceView cbView = null;
    private static void ensureCallback(final SurfaceView sv) {
        if (cbView == sv) return;
        cbView = sv;
        sv.getHolder().addCallback(new android.view.SurfaceHolder.Callback() {
            public void surfaceCreated(android.view.SurfaceHolder h) {
                try { if (wantW > 0 && wantH > 0) h.setFixedSize(wantW, wantH); } catch (Throwable t) {}
            }
            public void surfaceChanged(android.view.SurfaceHolder h, int f, int w, int hh) {}
            public void surfaceDestroyed(android.view.SurfaceHolder h) {}
        });
    }

    private void applySurface(Activity act, final int w, final int h) {
        final SurfaceView sv = findSurface(act.getWindow().getDecorView());
        if (sv == null) { dispatchStatusEventAsync("error", "setSurfaceSize: sem SurfaceView"); return; }
        final boolean fixed = w > 0 && h > 0;
        wantW = fixed ? w : 0; wantH = fixed ? h : 0;
        ensureCallback(sv);
        resetView(act, sv);
        sv.setVisibility(View.INVISIBLE);
        if (fixed) sv.getHolder().setFixedSize(w, h); else sv.getHolder().setSizeFromLayout();
        sv.postDelayed(new Runnable() { public void run() {
            sv.setVisibility(View.VISIBLE);
            sv.postDelayed(new Runnable() { public void run() {
                if (fixed) {
                    sv.getHolder().setFixedSize(w, h);
                    installTouchScaler(sv, w, h);
                } else {
                    sv.getHolder().setSizeFromLayout();
                    sv.setOnTouchListener(null);
                    sv.setOnGenericMotionListener(null);
                }
                dispatchStatusEventAsync("surf", fixed ? (w + "x" + h) : "native");
            } }, 150);
        } }, 150);
    }

    // Com a superfície menor que a tela, os toques chegam em pixels da tela. Aqui eles são
    // convertidos para pixels da superfície antes de ir para o AIR.
    private static void installTouchScaler(SurfaceView sv, final int w, final int h) {
        final boolean[] busy = new boolean[1];
        sv.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (busy[0] || v.getWidth() == 0 || v.getHeight() == 0) return false;
                MotionEvent o = MotionEvent.obtain(e);
                Matrix mx = new Matrix();
                mx.setScale((float) w / v.getWidth(), (float) h / v.getHeight());
                o.transform(mx);
                busy[0] = true;
                try { v.onTouchEvent(o); return true; }
                finally { busy[0] = false; o.recycle(); }
            } });
        sv.setOnGenericMotionListener(new View.OnGenericMotionListener() {
            @Override public boolean onGenericMotion(View v, MotionEvent e) {
                if (busy[0] || v.getWidth() == 0 || v.getHeight() == 0) return false;
                MotionEvent o = MotionEvent.obtain(e);
                Matrix mx = new Matrix();
                mx.setScale((float) w / v.getWidth(), (float) h / v.getHeight());
                o.transform(mx);
                busy[0] = true;
                try { v.onGenericMotionEvent(o); return true; }
                finally { busy[0] = false; o.recycle(); }
            } });
    }

    @Override public void dispose() {
        if (server != null) server.stop();
    }
}
