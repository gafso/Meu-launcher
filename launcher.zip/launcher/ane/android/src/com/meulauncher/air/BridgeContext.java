package com.meulauncher.air;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.webkit.CookieManager;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

import java.util.HashMap;
import java.util.Map;

public class BridgeContext extends FREContext {
    private LocalServer server;

    @Override public Map<String, FREFunction> getFunctions() {
        Map<String, FREFunction> m = new HashMap<String, FREFunction>();
        m.put("login", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                Intent i = new Intent(getActivity(), LoginActivity.class);
                i.putExtra("host", a[0].getAsString());
                getActivity().startActivity(i);
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("startServer", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                if (server != null) server.stop();
                server = new LocalServer(a[0].getAsString());
                return FREObject.newObject(server.start());
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            try { return FREObject.newObject(0); } catch (Exception e) { return null; } } });
        m.put("showMenu", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                final String title = a[0].getAsString();
                final String[] items = a[1].getAsString().split("\\|");
                getActivity().runOnUiThread(new Runnable() { public void run() {
                    new AlertDialog.Builder(getActivity()).setTitle(title)
                        .setItems(items, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int which) {
                                dispatchStatusEventAsync("menu", String.valueOf(which)); } })
                        .show(); } });
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("keepAlive", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                Intent i = new Intent(getActivity(), KeepAliveService.class);
                if (a[0].getAsBool()) {
                    if (Build.VERSION.SDK_INT >= 26) getActivity().startForegroundService(i);
                    else getActivity().startService(i);
                } else getActivity().stopService(i);
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("restartApp", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            Activity act = getActivity();
            // RestartActivity roda em outro processo e reabre o app depois que este morrer.
            Intent i = new Intent(act, RestartActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
            android.os.Process.killProcess(android.os.Process.myPid());
            return null; } });
        m.put("clearSession", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookies(null); cm.flush();
            return null; } });
        m.put("setSurfaceSize", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            // Reservado: ajuste de superfície depende do runtime AIR; implemente aqui se precisar.
            return null; } });
        m.put("showText", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                final String title = a[0].getAsString();
                final String text = a[1].getAsString();
                getActivity().runOnUiThread(new Runnable() { public void run() {
                    new AlertDialog.Builder(getActivity()).setTitle(title).setMessage(text)
                        .setPositiveButton("Copiar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                ClipboardManager cb = (ClipboardManager)
                                    getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
                                cb.setPrimaryClip(ClipData.newPlainText("log", text)); } })
                        .setNegativeButton("Fechar", null).show(); } });
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        return m;
    }

    @Override public void dispose() {
        if (server != null) server.stop();
    }
}
