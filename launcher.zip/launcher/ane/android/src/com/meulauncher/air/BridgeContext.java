package com.meulauncher.air;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Matrix;
import android.os.Build;
import android.view.MotionEvent;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

import java.util.HashMap;
import java.util.Map;

public class BridgeContext extends FREContext {
    private LocalServer server;

    @Override public Map<String, FREFunction> getFunctions() {
        Map<String, FREFunction> m = new HashMap<String, FREFunction>();
        m.put("login", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                Intent i = new Intent(getActivity(), LoginActivity.class);
                i.putExtra("host", a[0].getAsString());
                getActivity().startActivity(i);
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("startServer", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                if (server != null) server.stop();
                server = new LocalServer(a[0].getAsString());
                return FREObject.newObject(server.start());
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            try { return FREObject.newObject(0); } catch (Exception e) { return null; } } });
        m.put("showMenu", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                final String title = a[0].getAsString();
                final String[] items = a[1].getAsString().split("\\|");
                getActivity().runOnUiThread(new Runnable() { public void run() {
                    new AlertDialog.Builder(getActivity()).setTitle(title)
                        .setItems(items, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int which) {
                                dispatchStatusEventAsync("menu", String.valueOf(which)); } })
                        .show(); } });
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("toBackground", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            // Manda o app para segundo plano (como o botão Início) sem fechá-lo.
            try { getActivity().moveTaskToBack(true); }
            catch (Exception e) { dispatchStatusEventAsync("error", "toBackground: " + e); }
            return null; } });
        m.put("keepAlive", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                Intent i = new Intent(getActivity(), KeepAliveService.class);
                if (a[0].getAsBool()) {
                    // Android 13+: sem esta permissão a notificação do serviço não aparece.
                    if (Build.VERSION.SDK_INT >= 33
                        && getActivity().checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                           != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                        getActivity().requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 7071);
                    }
                    if (Build.VERSION.SDK_INT >= 26) getActivity().startForegroundService(i);
                    else getActivity().startService(i);
                } else getActivity().stopService(i);
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        m.put("restartApp", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            Activity act = getActivity();
            // RestartActivity roda em outro processo e reabre o app depois que este morrer.
            Intent i = new Intent(act, RestartActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            act.startActivity(i);
            android.os.Process.killProcess(android.os.Process.myPid());
            return null; } });
        m.put("clearSession", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookies(null); cm.flush();
            return null; } });
        m.put("setSurfaceSize", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            // Troca a resolução em que o jogo é desenhado (w <= 0 volta ao tamanho nativo).
            // O Android estica essa superfície menor até preencher a tela, então tudo fica maior.
            try {
                final int w = a[0].getAsInt();
                final int h = a[1].getAsInt();
                final Activity act = getActivity();
                act.runOnUiThread(new Runnable() { public void run() {
                    try { applySurface(act, w, h); }
                    catch (Throwable t) { dispatchStatusEventAsync("error", "setSurfaceSize: " + t); }
                } });
            } catch (Exception e) { dispatchStatusEventAsync("error", "setSurfaceSize: " + e); }
            return null; } });
        m.put("showText", new FREFunction() { public FREObject call(FREContext c, FREObject[] a) {
            try {
                final String title = a[0].getAsString();
                final String text = a[1].getAsString();
                getActivity().runOnUiThread(new Runnable() { public void run() {
                    new AlertDialog.Builder(getActivity()).setTitle(title).setMessage(text)
                        .setPositiveButton("Copiar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                ClipboardManager cb = (ClipboardManager)
                                    getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
                                cb.setPrimaryClip(ClipData.newPlainText("log", text)); } })
                        .setNegativeButton("Fechar", null).show(); } });
            } catch (Exception e) { dispatchStatusEventAsync("error", String.valueOf(e)); }
            return null; } });
        return m;
    }

    // ---------- resolução (SurfaceView) ----------
    private static SurfaceView findSurface(View v) {
        if (v instanceof SurfaceView) return (SurfaceView) v;
        SurfaceView best = null;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                SurfaceView f = findSurface(g.getChildAt(i));
                if (f != null && (best == null || f.getWidth() * f.getHeight() > best.getWidth() * best.getHeight())) best = f;
            }
        }
        return best;
    }

    private static int origW = Integer.MIN_VALUE, origH = Integer.MIN_VALUE;

    // Se a proporção pedida for mais "quadrada" que a tela, a área do jogo fica centralizada
    // com barras pretas dos lados (sem esticar). Com w<=0 volta a ocupar a tela toda.
    private static void fitView(Activity act, SurfaceView sv, int w, int h) {
        View parent = (View) sv.getParent();
        if (parent == null) return;
        ViewGroup.LayoutParams lp = sv.getLayoutParams();
        if (origW == Integer.MIN_VALUE) { origW = lp.width; origH = lp.height; }
        int pw = parent.getWidth(), ph = parent.getHeight();
        int want = -1;
        if (w > 0 && h > 0 && pw > 0 && ph > 0) {
            want = Math.round((float) ph * w / h);
            if (want >= pw - 8) want = -1;
        }
        try { act.getWindow().getDecorView().setBackgroundColor(0xFF000000); } catch (Throwable t) {}
        try { parent.setBackgroundColor(0xFF000000); } catch (Throwable t) {}
        if (want > 0) {
            lp.width = want;
            lp.height = ViewGroup.LayoutParams.MATCH_PARENT;
            if (lp instanceof android.widget.FrameLayout.LayoutParams)
                ((android.widget.FrameLayout.LayoutParams) lp).gravity = android.view.Gravity.CENTER;
            else if (lp instanceof ViewGroup.MarginLayoutParams)
                ((ViewGroup.MarginLayoutParams) lp).leftMargin = (pw - want) / 2;
        } else {
            lp.width = origW;
            lp.height = origH;
            if (lp instanceof android.widget.FrameLayout.LayoutParams)
                ((android.widget.FrameLayout.LayoutParams) lp).gravity = 0;
            else if (lp instanceof ViewGroup.MarginLayoutParams)
                ((ViewGroup.MarginLayoutParams) lp).leftMargin = 0;
        }
        sv.setLayoutParams(lp);
        sv.requestLayout();
    }

    private void applySurface(Activity act, final int w, final int h) {
        final SurfaceView sv = findSurface(act.getWindow().getDecorView());
        if (sv == null) { dispatchStatusEventAsync("error", "setSurfaceSize: sem SurfaceView"); return; }
        final boolean fixed = w > 0 && h > 0;
        fitView(act, sv, w, h);
        sv.setVisibility(View.INVISIBLE);
        if (fixed) sv.getHolder().setFixedSize(w, h); else sv.getHolder().setSizeFromLayout();
        sv.postDelayed(new Runnable() { public void run() {
            sv.setVisibility(View.VISIBLE);
            sv.postDelayed(new Runnable() { public void run() {
                if (fixed) {
                    sv.getHolder().setFixedSize(w, h);
                    installTouchScaler(sv, w, h);
                } else {
                    sv.getHolder().setSizeFromLayout();
                    sv.setOnTouchListener(null);
                    sv.setOnGenericMotionListener(null);
                }
                dispatchStatusEventAsync("surf", fixed ? (w + "x" + h) : "native");
            } }, 150);
        } }, 150);
    }

    // Com a superfície menor que a tela, os toques chegam em pixels da tela. Aqui eles são
    // convertidos para pixels da superfície antes de ir para o AIR.
    private static void installTouchScaler(SurfaceView sv, final int w, final int h) {
        final boolean[] busy = new boolean[1];
        sv.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (busy[0] || v.getWidth() == 0 || v.getHeight() == 0) return false;
                MotionEvent o = MotionEvent.obtain(e);
                Matrix mx = new Matrix();
                mx.setScale((float) w / v.getWidth(), (float) h / v.getHeight());
                o.transform(mx);
                busy[0] = true;
                try { v.onTouchEvent(o); return true; }
                finally { busy[0] = false; o.recycle(); }
            } });
        sv.setOnGenericMotionListener(new View.OnGenericMotionListener() {
            @Override public boolean onGenericMotion(View v, MotionEvent e) {
                if (busy[0] || v.getWidth() == 0 || v.getHeight() == 0) return false;
                MotionEvent o = MotionEvent.obtain(e);
                Matrix mx = new Matrix();
                mx.setScale((float) w / v.getWidth(), (float) h / v.getHeight());
                o.transform(mx);
                busy[0] = true;
                try { v.onGenericMotionEvent(o); return true; }
                finally { busy[0] = false; o.recycle(); }
            } });
    }

    @Override public void dispose() {
        if (server != null) server.stop();
    }
}
