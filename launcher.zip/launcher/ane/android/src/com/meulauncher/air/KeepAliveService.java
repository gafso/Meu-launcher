package com.meulauncher.air;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

// Serviço em primeiro plano para manter o app conectado em segundo plano.
public class KeepAliveService extends Service {
    private static final String CH = "keepalive";

    @Override public int onStartCommand(Intent i, int flags, int id) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Sessão ativa", NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, CH);
        } else nb = new Notification.Builder(this);
        nb.setContentTitle("Meu Launcher").setContentText("Sessão ativa")
          .setSmallIcon(android.R.drawable.ic_media_play);
        if (Build.VERSION.SDK_INT >= 34) {
            // 0x40000000 = FOREGROUND_SERVICE_TYPE_SPECIAL_USE (constante literal: o android.jar
            // usado no build pode ser mais antigo que a API 34).
            startForeground(1, nb.build(), 0x40000000);
        } else {
            startForeground(1, nb.build());
        }
        return START_STICKY;
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
