package com.meulauncher.air;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

// Serviço em primeiro plano que mantém o app vivo e conectado em segundo plano.
// Além da notificação, segura o processador (WakeLock) e o Wi-Fi (WifiLock) acordados:
// sem isso o Android corta a conexão do jogo pouco depois de você sair do app.
public class KeepAliveService extends Service {
    private static final String CH = "keepalive";
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    @Override public int onStartCommand(Intent i, int flags, int id) {
        try {
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                // 0x40000000 = FOREGROUND_SERVICE_TYPE_SPECIAL_USE (constante literal: o android.jar
                // usado no build pode ser mais antigo que a API 34).
                startForeground(1, n, 0x40000000);
            } else {
                startForeground(1, n);
            }
        } catch (Throwable t) {
            // Sem notificação o Android pode matar o serviço; segue mesmo assim.
        }
        acquireLocks();
        return START_STICKY;
    }

    private Notification buildNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Jogo em segundo plano", NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, CH);
        } else {
            nb = new Notification.Builder(this);
        }
        nb.setContentTitle("Legend Mobile").setContentText("Jogo conectado. Toque para voltar.")
          .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true);
        Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            int pf = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
            nb.setContentIntent(PendingIntent.getActivity(this, 0, launch, pf));
        }
        return nb.build();
    }

    private void acquireLocks() {
        try {
            if (wake == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "meulauncher:keepalive");
                wake.setReferenceCounted(false);
            }
            if (!wake.isHeld()) wake.acquire();
        } catch (Throwable t) {}
        try {
            if (wifi == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "meulauncher:wifi");
                wifi.setReferenceCounted(false);
            }
            if (!wifi.isHeld()) wifi.acquire();
        } catch (Throwable t) {}
    }

    // O usuário removeu o app da lista de recentes: encerra o serviço.
    @Override public void onTaskRemoved(Intent rootIntent) {
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Throwable t) {}
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Throwable t) {}
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
