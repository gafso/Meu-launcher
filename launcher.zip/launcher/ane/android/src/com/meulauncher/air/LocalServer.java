package com.meulauncher.air;

import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.net.ssl.HttpsURLConnection;

// Servidor HTTP em 127.0.0.1 (porta aleatória). Responde crossdomain.xml
// liberando tudo e repassa o restante para https://<host>/...
public class LocalServer {
    private static final String CROSSDOMAIN =
        "<?xml version=\"1.0\"?><cross-domain-policy>"
      + "<site-control permitted-cross-domain-policies=\"all\"/>"
      + "<allow-access-from domain=\"*\" secure=\"false\"/>"
      + "<allow-http-request-headers-from domain=\"*\" headers=\"*\" secure=\"false\"/>"
      + "</cross-domain-policy>";

    private final String host;
    private final File modsDir;   // pasta de arquivos substitutos (mods locais); pode ser null
    private final java.util.Set<String> seen = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
    private ServerSocket ss;
    private volatile boolean running;
    private final ExecutorService pool = Executors.newCachedThreadPool();

    public LocalServer(String host, File modsDir) {
        this.host = host;
        this.modsDir = modsDir;
        if (modsDir != null) { try { modsDir.mkdirs(); } catch (Exception ignored) {} }
    }

    // ---- mods locais: se existir mods/<caminho> (ou mods/<nome do arquivo>), serve ele no lugar do servidor ----
    private File findMod(String path) {
        if (modsDir == null) return null;
        String clean = path;
        int q = clean.indexOf('?'); if (q >= 0) clean = clean.substring(0, q);
        int h = clean.indexOf('#'); if (h >= 0) clean = clean.substring(0, h);
        try { clean = URLDecoder.decode(clean, "UTF-8"); } catch (Exception ignored) {}
        if (clean.contains("..") || clean.endsWith("/")) return null;
        while (clean.startsWith("/")) clean = clean.substring(1);
        if (clean.length() == 0) return null;
        File f = new File(modsDir, clean);
        if (f.isFile()) return f;
        File g = new File(modsDir, clean.substring(clean.lastIndexOf('/') + 1));  // só pelo nome
        return g.isFile() ? g : null;
    }

    // Anota em mods/_pedidos.txt os caminhos de imagens/swf pedidos, para você saber o que substituir.
    private void noteRequest(String path) {
        if (modsDir == null) return;
        String clean = path.indexOf('?') >= 0 ? path.substring(0, path.indexOf('?')) : path;
        String l = clean.toLowerCase();
        if (!(l.endsWith(".png") || l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".swf")
              || l.endsWith(".gif") || l.endsWith(".jpe") || l.endsWith(".webp"))) return;
        if (!seen.add(clean) || seen.size() > 5000) return;
        try {
            FileWriter w = new FileWriter(new File(modsDir, "_pedidos.txt"), true);
            w.write(clean + "\n"); w.close();
        } catch (Exception ignored) {}
    }

    private static String mime(String name) {
        String l = name.toLowerCase();
        if (l.endsWith(".png")) return "image/png";
        if (l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".jpe")) return "image/jpeg";
        if (l.endsWith(".gif")) return "image/gif";
        if (l.endsWith(".webp")) return "image/webp";
        if (l.endsWith(".swf")) return "application/x-shockwave-flash";
        if (l.endsWith(".xml")) return "text/xml";
        return "application/octet-stream";
    }

    public int start() throws IOException {
        ss = new ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"));
        running = true;
        pool.execute(new Runnable() { public void run() {
            while (running) {
                try {
                    final Socket s = ss.accept();
                    pool.execute(new Runnable() { public void run() { handle(s); } });
                } catch (IOException e) { break; }
            }
        } });
        return ss.getLocalPort();
    }

    public void stop() {
        running = false;
        try { if (ss != null) ss.close(); } catch (IOException ignored) {}
        pool.shutdownNow();
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(30000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = new BufferedOutputStream(s.getOutputStream());
            String reqLine = readLine(in);
            if (reqLine == null) { s.close(); return; }
            String[] p = reqLine.split(" ");
            String method = p[0], path = p.length > 1 ? p[1] : "/";
            int contentLength = 0;
            String contentType = null, line;
            while ((line = readLine(in)) != null && line.length() > 0) {
                String l = line.toLowerCase();
                if (l.startsWith("content-length:")) contentLength = Integer.parseInt(line.substring(15).trim());
                else if (l.startsWith("content-type:")) contentType = line.substring(13).trim();
            }
            byte[] body = new byte[0];
            if (contentLength > 0) {
                body = new byte[contentLength];
                int off = 0, n;
                while (off < contentLength && (n = in.read(body, off, contentLength - off)) > 0) off += n;
            }

            if (path.startsWith("/crossdomain.xml")) {
                byte[] x = CROSSDOMAIN.getBytes("UTF-8");
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/x-cross-domain-policy\r\nContent-Length: "
                    + x.length + "\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
                out.write(x); out.flush(); s.close(); return;
            }

            noteRequest(path);
            File mod = "GET".equals(method) ? findMod(path) : null;
            if (mod != null) {
                byte[] data = new byte[(int) mod.length()];
                DataInputStream di = new DataInputStream(new FileInputStream(mod));
                di.readFully(data); di.close();
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: " + mime(mod.getName()) + "\r\nContent-Length: "
                    + data.length + "\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
                out.write(data); out.flush(); s.close(); return;
            }

            HttpsURLConnection c = (HttpsURLConnection) new URL("https://" + host + path).openConnection();
            c.setRequestMethod(method);
            c.setConnectTimeout(15000); c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "Mozilla/5.0");
            if (body.length > 0) {
                c.setDoOutput(true);
                if (contentType != null) c.setRequestProperty("Content-Type", contentType);
                c.getOutputStream().write(body);
            }
            int code = c.getResponseCode();
            InputStream r = code >= 400 ? c.getErrorStream() : c.getInputStream();
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            if (r != null) { byte[] b = new byte[8192]; int n; while ((n = r.read(b)) > 0) buf.write(b, 0, n); }
            String ct = c.getContentType() != null ? c.getContentType() : "application/octet-stream";
            out.write(("HTTP/1.1 " + code + " OK\r\nContent-Type: " + ct + "\r\nContent-Length: "
                + buf.size() + "\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
            buf.writeTo(out); out.flush(); s.close();
        } catch (Exception e) {
            // Avisa o app com 502 (em vez de fechar mudo) para o log mostrar que foi o proxy.
            try {
                byte[] m = ("proxy: " + e).getBytes("UTF-8");
                OutputStream o = s.getOutputStream();
                o.write(("HTTP/1.1 502 Bad Gateway\r\nContent-Type: text/plain\r\nContent-Length: "
                    + m.length + "\r\nConnection: close\r\n\r\n").getBytes("UTF-8"));
                o.write(m); o.flush();
            } catch (Exception ignored) {}
            try { s.close(); } catch (IOException ignored) {}
        }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
        }
        return (c == -1 && sb.length() == 0) ? null : sb.toString();
    }
}
