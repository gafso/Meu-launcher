package com.meulauncher.air;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

// Roda em outro processo (:restart). Espera o processo principal morrer e
// reabre o app, fechando o jogo atual por completo.
public class RestartActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        final String pkg = getPackageName();
        new Handler().postDelayed(new Runnable() { public void run() {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
            finish();
            android.os.Process.killProcess(android.os.Process.myPid());
        } }, 600);
    }
}
