package com.meulauncher.air;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREExtension;

public class BridgeExtension implements FREExtension {
    public static BridgeContext ctx;

    @Override public FREContext createContext(String type) {
        ctx = new BridgeContext();
        return ctx;
    }
    @Override public void initialize() {}
    @Override public void dispose() { ctx = null; }
}
