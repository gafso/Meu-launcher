package com.meulauncher.air;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.net.URI;
import java.net.URLDecoder;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// WebView em modo desktop. O usuário faz o login normal no site; capturamos os parâmetros
// (user/key e o Loading.swf) de três jeitos: URL de qualquer requisição, HTML da página e
// HTML dos iframes (lido de tempos em tempos). Nenhuma senha é lida nem guardada.
// O botão "Diagnóstico" mostra o que a página tem (valores de user/key são mascarados).
public class LoginActivity extends Activity {
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    private static final Pattern SWF_LOADING = Pattern.compile("([\\w./:\\-%]*Loading[\\w\\-]*\\.swf[\\w?=&.%\\-]*)");
    private static final Pattern SWF_ANY = Pattern.compile("([\\w./:\\-%]+\\.swf)");
    private static final Pattern MASK = Pattern.compile(
        "(?i)(user|key|pass\\w*|token|sid|sign|auth\\w*|session\\w*|cookie)([\"']?\\s*[:=]\\s*[\"']?)[^\"'&<>\\s,;]+");
    private static final String[] KEYS = {"user", "key", "site", "p2", "rid", "logintype"};

    // HTML da página + dos iframes do mesmo domínio.
    private static final String JS_ALL =
        "(function(){var o=[];function a(d){try{o.push(d.documentElement.outerHTML);}catch(e){}}"
      + "a(document);var f=document.querySelectorAll('iframe,frame');"
      + "for(var i=0;i<f.length;i++){try{a(f[i].contentDocument);}catch(e){}}"
      + "return o.join(String.fromCharCode(10));})()";

    // Resumo para diagnóstico: iframes e trechos em volta de ".swf", swfobject, flashvars, object, embed.
    private static final String JS_DIAG =
        "(function(){var r=[];var nl=String.fromCharCode(10);"
      + "function c(t,k){var o=[],p=0,n=0,i,l=t.toLowerCase();"
      + "while(n<4&&(i=l.indexOf(k,p))>=0){o.push(t.substr(Math.max(0,i-120),300).split(nl).join(' '));p=i+k.length;n++;}return o;}"
      + "var docs=[document];var f=document.querySelectorAll('iframe,frame');r.push('iframes='+f.length);"
      + "for(var i=0;i<f.length;i++){r.push(' iframe src='+f[i].src);"
      + "try{if(f[i].contentDocument)docs.push(f[i].contentDocument);else r.push(' (sem acesso)');}catch(e){r.push(' (sem acesso)');}}"
      + "for(var d=0;d<docs.length;d++){var h='';try{h=docs[d].documentElement.outerHTML;}catch(e){}"
      + "r.push('DOC'+d+' len='+h.length);"
      + "var ks=['.swf','swfobject','flashvars','embedswf','<object','<embed'];"
      + "for(var j=0;j<ks.length;j++){var cs=c(h,ks[j]);for(var m=0;m<cs.length;m++){r.push(' ['+ks[j]+'] '+cs[m]);}}}"
      + "return r.join(nl);})()";

    private static final String JS_FILL =
        "(function(U,P){\n"
          + "function vis(e){try{return !!(e.offsetWidth||e.offsetHeight||(e.getClientRects&&e.getClientRects().length));}catch(x){return false;}}\n"
          + "function setv(e,v){try{var d=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');d.set.call(e,v);}catch(x){e.value=v;}\n"
          + "e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}\n"
          + "function find(doc){var pw=doc.querySelectorAll('input[type=password]');\n"
          + "for(var i=0;i<pw.length;i++){if(!vis(pw[i]))continue;var root=pw[i].form||doc;var ins=root.querySelectorAll('input');var user=null;\n"
          + "for(var j=0;j<ins.length;j++){if(ins[j]===pw[i])break;var t=(ins[j].type||'text').toLowerCase();\n"
          + "if((t==='text'||t==='email'||t==='tel')&&vis(ins[j]))user=ins[j];}\n"
          + "if(user)return {u:user,p:pw[i],doc:doc};}\n"
          + "return null;}\n"
          + "function go(r){var root=r.p.form||r.doc;var c=root.querySelectorAll('button,input[type=submit],input[type=button],a');var b=null;var i,t;\n"
          + "for(i=0;i<c.length;i++){if(c[i].type==='submit'&&vis(c[i])){b=c[i];break;}}\n"
          + "if(!b){for(i=0;i<c.length;i++){t=((c[i].innerText||c[i].value||'')+' '+(c[i].id||'')).toLowerCase();\n"
          + "if(/login|log in|entrar|logar|sign in|acessar/.test(t)&&vis(c[i])){b=c[i];break;}}}\n"
          + "if(b){b.click();return;}\n"
          + "if(r.p.form){if(r.p.form.requestSubmit)r.p.form.requestSubmit();else r.p.form.submit();}}\n"
          + "var docs=[document];var fr=document.querySelectorAll('iframe,frame');\n"
          + "for(var k=0;k<fr.length;k++){try{if(fr[k].contentDocument)docs.push(fr[k].contentDocument);}catch(x){}}\n"
          + "for(var d=0;d<docs.length;d++){var r=find(docs[d]);\n"
          + "if(r){r.u.focus();setv(r.u,U);setv(r.p,P);setTimeout(function(){go(r);},400);return 'filled';}}\n"
          + "return 'noform';})(";

    private String host;
    private boolean done = false;
    private WebView web;
    private ProgressBar bar;
    // login automático (usuário/senha vindos da tela inicial)
    private String autoUser, autoPass;
    private boolean autoMode = false, filled = false, revealed = false;
    private int fillTries = 0;
    private View overlay;
    private final Runnable revealTimeout = new Runnable() {
        @Override public void run() {
            reveal(filled ? "Não consegui entrar sozinho. Confira usuário e senha ou entre pelo site."
                          : "Não consegui entrar sozinho. Faça o login no site.");
        }
    };
    private final Runnable fillTick = new Runnable() {
        @Override public void run() {
            if (done || isFinishing() || filled || revealed || !autoMode) return;
            String js = JS_FILL + JSONObject.quote(autoUser) + "," + JSONObject.quote(autoPass) + ")";
            web.evaluateJavascript(js, new ValueCallback<String>() {
                @Override public void onReceiveValue(String v) {
                    if (done || filled || revealed) return;
                    if ("filled".equals(decode(v))) {
                        filled = true;
                        handler.removeCallbacks(revealTimeout);
                        handler.postDelayed(revealTimeout, 20000);
                    } else if (++fillTries < 10) {
                        handler.postDelayed(fillTick, 1000);
                    } else {
                        reveal("Não achei o formulário de login. Entre pelo site.");
                    }
                }
            });
        }
    };
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LinkedList<String> reqLog = new LinkedList<String>();
    private volatile String seenSwf;
    private int scans = 0;

    private final Runnable scanTick = new Runnable() {
        @Override public void run() {
            if (done || isFinishing()) return;
            web.evaluateJavascript(JS_ALL, new ValueCallback<String>() {
                @Override public void onReceiveValue(String v) { scanHtml(decode(v)); } });
            scans++;
            if (scans < 40) handler.postDelayed(this, 2000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getStringExtra("host");
        autoUser = getIntent().getStringExtra("user");
        autoPass = getIntent().getStringExtra("pass");
        autoMode = autoUser != null && autoUser.length() > 0 && autoPass != null && autoPass.length() > 0;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0F131A);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // barra fina de progresso no topo (some quando a página termina de carregar)
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgressTintList(ColorStateList.valueOf(0xFF4C8DFF));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(0x22FFFFFF));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(3));
        bp.gravity = Gravity.TOP;
        root.addView(bar, bp);

        // botão "Diagnóstico" discreto, em forma de pílula
        Button diag = new Button(this);
        diag.setText("Diagnóstico");
        diag.setAllCaps(false);
        diag.setTextSize(12);
        diag.setTextColor(0xFFC9D3E6);
        diag.setMinHeight(0); diag.setMinimumHeight(0);
        diag.setMinWidth(0);  diag.setMinimumWidth(0);
        diag.setPadding(dp(16), dp(8), dp(16), dp(8));
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0xCC1A2130);
        pill.setCornerRadius(dp(20));
        pill.setStroke(dp(1), 0xFF34425A);
        diag.setBackground(pill);
        diag.setAlpha(0.85f);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.gravity = Gravity.BOTTOM | Gravity.END;
        lp.setMargins(0, 0, dp(16), dp(16));
        root.addView(diag, lp);

        if (autoMode) {
            // Tela "Entrando..." por cima do site enquanto o formulário é preenchido sozinho.
            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER);
            box.setBackgroundColor(0xFF0F131A);
            box.setClickable(true);
            ProgressBar sp = new ProgressBar(this);
            sp.setIndeterminateTintList(ColorStateList.valueOf(0xFF4C8DFF));
            box.addView(sp, new LinearLayout.LayoutParams(dp(48), dp(48)));
            TextView tv = new TextView(this);
            tv.setText("Entrando...");
            tv.setTextColor(0xFFC9D3E6);
            tv.setTextSize(16);
            tv.setPadding(0, dp(16), 0, dp(20));
            box.addView(tv);
            Button show = new Button(this);
            show.setText("Mostrar o site");
            show.setAllCaps(false);
            show.setTextSize(12);
            show.setTextColor(0xFFC9D3E6);
            show.setMinHeight(0); show.setMinimumHeight(0);
            show.setPadding(dp(18), dp(8), dp(18), dp(8));
            GradientDrawable sp2 = new GradientDrawable();
            sp2.setColor(0x331A2130);
            sp2.setCornerRadius(dp(20));
            sp2.setStroke(dp(1), 0xFF34425A);
            show.setBackground(sp2);
            show.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { revealed = true; overlay.setVisibility(View.GONE); } });
            box.addView(show);
            overlay = box;
            root.addView(box, new FrameLayout.LayoutParams(-1, -1));
            handler.postDelayed(revealTimeout, 30000);
        }
        diag.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showDiag(); } });
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setBackgroundColor(0xFF0F131A);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                bar.setProgress(p);
                bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                note(u);
                return check(u);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                note(r.getUrl().toString());
                return null;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) { check(url); }
            @Override public void onPageFinished(WebView v, String url) {
                if (done) return;
                if (autoMode && !filled && !revealed) {
                    handler.removeCallbacks(fillTick);
                    handler.postDelayed(fillTick, 700);
                }
                scans = 0;
                handler.removeCallbacks(scanTick);
                handler.postDelayed(scanTick, 600);
            }
        });
        web.loadUrl("https://" + host + "/");
    }

    // ---------- captura por URL ----------
    private static boolean isAsset(String lowerPath) {
        String[] ext = {".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".woff2", ".svg", ".webp"};
        for (String e : ext) if (lowerPath.endsWith(e)) return true;
        return false;
    }

    // Registra a requisição (só host, caminho e NOMES dos parâmetros) e guarda o Loading.swf visto.
    private void note(String url) {
        try {
            URI u = new URI(url);
            String path = u.getPath() == null ? "" : u.getPath();
            String q = u.getRawQuery();
            StringBuilder names = new StringBuilder();
            if (q != null) {
                for (String kv : q.split("&")) {
                    int i = kv.indexOf('=');
                    names.append(i > 0 ? kv.substring(0, i) : kv).append(',');
                }
            }
            synchronized (reqLog) {
                reqLog.add(u.getHost() + path + (names.length() > 0 ? "?" + names : ""));
                if (reqLog.size() > 80) reqLog.removeFirst();
            }
            if (path.toLowerCase().endsWith(".swf") && path.contains("Loading")) {
                seenSwf = u.getRawPath() + (q != null ? "?" + q : "");
            }
            check(url);
        } catch (Exception ignored) {}
    }

    // Qualquer URL (que não seja imagem/css/js) com user= e key= vira a sessão.
    private boolean check(String url) {
        if (done) return false;
        try {
            URI u = new URI(url);
            String q = u.getRawQuery();
            String lp = u.getPath() == null ? "" : u.getPath().toLowerCase();
            if (q == null || !q.contains("user=") || !q.contains("key=") || isAsset(lp)) return false;
            JSONObject params = new JSONObject();
            for (String kv : q.split("&")) {
                int i = kv.indexOf('=');
                if (i > 0) params.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), "UTF-8"));
            }
            if (params.optString("key").length() < 4) return false;
            finishWith(u.getHost() != null ? u.getHost() : host, params, seenSwf);
            return true;
        } catch (Exception e) { return false; }
    }

    // ---------- captura pelo HTML ----------
    private static boolean plausible(String v) {
        if (v == null) return false;
        String l = v.toLowerCase();
        return !(l.equals("function") || l.equals("null") || l.equals("undefined") || l.equals("true")
            || l.equals("false") || l.equals("this") || l.equals("document") || l.equals("window") || l.equals("var"));
    }

    private void scanHtml(String html) {
        if (done || html == null || html.length() == 0) return;
        try {
            Matcher m = SWF_LOADING.matcher(html);
            String swf = m.find() ? m.group(1) : null;
            if (swf == null) {
                m = SWF_ANY.matcher(html);
                if (m.find()) swf = m.group(1);
            }
            if (swf == null) swf = seenSwf;
            JSONObject params = new JSONObject();
            for (String k : KEYS) {
                Matcher mm = Pattern.compile("(?i)\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)").matcher(html);
                while (mm.find()) {
                    String val = mm.group(1);
                    if (plausible(val)) { params.put(k, val); break; }
                }
            }
            if (!params.has("user") || !params.has("key") || params.optString("key").length() < 8) return;
            if (swf == null && scans < 10) return;   // espera mais um pouco pelo caminho do swf
            finishWith(host, params, swf);
        } catch (Exception ignored) {}
    }

    private static String decode(String raw) {
        if (raw == null || raw.equals("null")) return "";
        try {
            Object o = new JSONTokener(raw).nextValue();
            if (o instanceof String) return (String) o;
        } catch (Exception ignored) {}
        return raw;
    }

    // ---------- entrega ao AS3 ----------
    private void finishWith(final String gameHost, final JSONObject params, final String swf) {
        synchronized (this) {
            if (done) return;
            done = true;
        }
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    String outHost = gameHost;
                    String swfPath = null;
                    if (swf != null) {
                        try {
                            URI su = new URI(swf.startsWith("http") ? swf : "https://" + gameHost + "/" + swf.replaceFirst("^/", ""));
                            if (su.getHost() != null) outHost = su.getHost();
                            swfPath = su.getRawPath() + (su.getRawQuery() != null ? "?" + su.getRawQuery() : "");
                        } catch (Exception e) { swfPath = "/Loading.swf"; }
                    }
                    JSONObject out = new JSONObject();
                    out.put("host", outHost);
                    out.put("params", params);
                    out.put("user", params.optString("user"));
                    out.put("key", params.optString("key"));
                    if (swfPath != null) out.put("swf", swfPath);
                    if (BridgeExtension.ctx != null) BridgeExtension.ctx.dispatchStatusEventAsync("game", out.toString());
                } catch (Exception e) {
                    if (BridgeExtension.ctx != null) BridgeExtension.ctx.dispatchStatusEventAsync("error", String.valueOf(e));
                }
                finish();
            }
        });
    }

    // ---------- diagnóstico ----------
    private static String mask(String s) {
        return MASK.matcher(s).replaceAll("$1$2***");
    }

    private void showDiag() {
        final StringBuilder sb = new StringBuilder();
        sb.append("URL: ").append(String.valueOf(web.getUrl())).append("\n");
        sb.append("capturado=").append(done).append(" swfVisto=").append(seenSwf).append("\n");
        sb.append("-- ultimas requisicoes (so nomes de parametros) --\n");
        synchronized (reqLog) {
            int skip = Math.max(0, reqLog.size() - 40);
            int n = 0;
            for (String r : reqLog) { if (n++ >= skip) sb.append(r).append("\n"); }
        }
        web.evaluateJavascript(JS_DIAG, new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
                sb.append("-- pagina --\n").append(decode(v));
                showText("Diagnóstico", mask(sb.toString()));
            }
        });
    }

    private void reveal(String msg) {
        if (revealed || done) return;
        revealed = true;
        handler.removeCallbacks(revealTimeout);
        if (overlay != null) overlay.setVisibility(View.GONE);
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showText(String title, String text) {
        final String t = text.length() > 9000 ? text.substring(0, 9000) : text;
        AlertDialog dlg = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(title).setMessage(t)
            .setPositiveButton("Copiar", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cb.setPrimaryClip(ClipData.newPlainText("diag", t));
                    Toast.makeText(LoginActivity.this, "Copiado", Toast.LENGTH_SHORT).show();
                } })
            .setNegativeButton("Fechar", null).create();
        BridgeContext.styleDialog(dlg);
        dlg.show();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
