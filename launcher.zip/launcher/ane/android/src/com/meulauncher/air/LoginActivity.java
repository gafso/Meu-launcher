package com.meulauncher.air;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.net.URI;
import java.net.URLDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// WebView em modo desktop. O usuário faz o login normal no site; quando a
// navegação chega numa URL "*.jsp?...user=...&key=..." capturamos os
// parâmetros e devolvemos ao AS3. Nenhuma senha é lida nem guardada.
public class LoginActivity extends Activity {
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    private static final Pattern SWF = Pattern.compile("([\\w./:\\-]*Loading[\\w\\-]*\\.swf)");

    private String host;
    private boolean done = false;
    private WebView web;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getStringExtra("host");
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return check(r.getUrl().toString());
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) { check(url); }
            @Override public void onPageFinished(WebView v, String url) {
                if (done) return;
                // Procura o Loading.swf e as variáveis no HTML da página de jogo.
                v.evaluateJavascript("(function(){return document.documentElement.outerHTML;})()",
                    new android.webkit.ValueCallback<String>() {
                        public void onReceiveValue(String html) { scanHtml(html); } });
            }
        });
        web.loadUrl("https://" + host + "/");
    }

    private boolean check(String url) {
        if (done || !url.contains(".jsp")) return false;
        try {
            URI u = new URI(url);
            String q = u.getRawQuery();
            if (q == null || !q.contains("user=") || !q.contains("key=")) return false;
            JSONObject params = new JSONObject();
            for (String kv : q.split("&")) {
                int i = kv.indexOf('=');
                if (i > 0) params.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), "UTF-8"));
            }
            finishWith(u.getHost() != null ? u.getHost() : host, params, null);
            return true;
        } catch (Exception e) { return false; }
    }

    private void scanHtml(String html) {
        if (done || html == null) return;
        try {
            html = html.replace("\\u003C", "<").replace("\\\"", "\"").replace("\\/", "/");
            Matcher m = SWF.matcher(html);
            if (!m.find()) return;
            String swf = m.group(1);
            JSONObject params = new JSONObject();
            for (String k : new String[]{"user", "key", "site", "p2", "rid", "logintype"}) {
                Matcher mm = Pattern.compile(k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)").matcher(html);
                if (mm.find()) params.put(k, mm.group(1));
            }
            if (params.has("user") && params.has("key")) finishWith(host, params, swf);
        } catch (Exception ignored) {}
    }

    private void finishWith(String gameHost, JSONObject params, String swf) {
        if (done) return;
        done = true;
        try {
            JSONObject out = new JSONObject();
            out.put("host", gameHost);
            out.put("params", params);
            out.put("user", params.optString("user"));
            out.put("key", params.optString("key"));
            if (swf != null) {
                try { out.put("swf", new URI(swf.startsWith("http") ? swf : "https://" + gameHost + "/" + swf.replaceFirst("^/", "")).getPath()); }
                catch (Exception e) { out.put("swf", "/Loading.swf"); }
            }
            if (BridgeExtension.ctx != null) BridgeExtension.ctx.dispatchStatusEventAsync("game", out.toString());
        } catch (Exception e) {
            if (BridgeExtension.ctx != null) BridgeExtension.ctx.dispatchStatusEventAsync("error", String.valueOf(e));
        }
        finish();
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
