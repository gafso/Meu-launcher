package com.meulauncher.air;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.net.URI;
import java.net.URLDecoder;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// WebView em modo desktop. O usuário faz o login normal no site; capturamos os parâmetros
// (user/key e o Loading.swf) de três jeitos: URL de qualquer requisição, HTML da página e
// HTML dos iframes (lido de tempos em tempos). Nenhuma senha é lida nem guardada.
// O botão "Diagnóstico" mostra o que a página tem (valores de user/key são mascarados).
public class LoginActivity extends Activity {
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    private static final Pattern SWF_LOADING = Pattern.compile("([\\w./:\\-%]*Loading[\\w\\-]*\\.swf[\\w?=&.%\\-]*)");
    private static final Pattern SWF_ANY = Pattern.compile("([\\w./:\\-%]+\\.swf)");
    private static final Pattern MASK = Pattern.compile(
        "(?i)(user|key|pass\\w*|token|sid|sign|auth\\w*|session\\w*|cookie)([\"']?\\s*[:=]\\s*[\"']?)[^\"'&<>\\s,;]+");
    private static final String[] KEYS = {"user", "key", "site", "p2", "rid", "logintype"};

    // HTML da página + dos iframes do mesmo domínio.
    private static final String JS_ALL =
        "(function(){var o=[];function a(d){try{o.push(d.documentElement.outerHTML);}catch(e){}}"
      + "a(document);var f=document.querySelectorAll('iframe,frame');"
      + "for(var i=0;i<f.length;i++){try{a(f[i].contentDocument);}catch(e){}}"
      + "return o.join(String.fromCharCode(10));})()";

    // Resumo para diagnóstico: iframes e trechos em volta de ".swf", swfobject, flashvars, object, embed.
    private static final String JS_DIAG =
        "(function(){var r=[];var nl=String.fromCharCode(10);"
      + "function c(t,k){var o=[],p=0,n=0,i,l=t.toLowerCase();"
      + "while(n<4&&(i=l.indexOf(k,p))>=0){o.push(t.substr(Math.max(0,i-120),300).split(nl).join(' '));p=i+k.length;n++;}return o;}"
      + "var docs=[document];var f=document.querySelectorAll('iframe,frame');r.push('iframes='+f.length);"
      + "for(var i=0;i<f.length;i++){r.push(' iframe src='+f[i].src);"
      + "try{if(f[i].contentDocument)docs.push(f[i].contentDocument);else r.push(' (sem acesso)');}catch(e){r.push(' (sem acesso)');}}"
      + "var as=document.querySelectorAll('a,button,input[type=button],input[type=submit]');r.push('clicaveis='+as.length);"
      + "for(var q=0;q<as.length&&q<40;q++){var e=as[q];var b=e.getBoundingClientRect();"
      + "r.push(' <'+e.tagName+'> '+((e.innerText||e.value||'')+'').trim().substr(0,24)+' | '+(e.getAttribute('href')||'').substr(0,60)+' | cls='+(e.className||'')+' | '+Math.round(b.width)+'x'+Math.round(b.height)+'@'+Math.round(b.top));}"
      + "for(var d=0;d<docs.length;d++){var h='';try{h=docs[d].documentElement.outerHTML;}catch(e){}"
      + "r.push('DOC'+d+' len='+h.length);"
      + "var ks=['.swf','swfobject','flashvars','embedswf','<object','<embed'];"
      + "for(var j=0;j<ks.length;j++){var cs=c(h,ks[j]);for(var m=0;m<cs.length;m++){r.push(' ['+ks[j]+'] '+cs[m]);}}}"
      + "return r.join(nl);})()";

    // Conta salva: depois de abrir o site já logado, entra no servidor do TOPO de "Meus Servidores" (o mais recente);
    // se não achar a lista, tenta o botão JOGAR grande.
    private static final String JS_AUTO =
        "(function(){ function vis(e){var r=e.getBoundingClientRect();return r.width>40&&r.height>10&&r.bottom>0;} func"
      + "tion txt(e){return ((e.innerText||e.textContent||'')+' '+(e.title||'')+' '+(e.alt||'')+' '+(e.value||'')).trim"
      + "();} function fire(t){ try{t.click();}catch(x){} ['mousedown','mouseup','click'].forEach(function(n){try{t.dis"
      + "patchEvent(new MouseEvent(n,{bubbles:true,cancelable:true,view:window}));}catch(x){}}); } var reOne=/^\\s*[A-Z"
      + "a-z]{2,6}\\d{2,6}\\s*[:\\uFF1A]/; var reAll=/[A-Za-z]{2,6}\\d{2,6}\\s*[:\\uFF1A]/g; var all=[].slice.call(docu"
      + "ment.querySelectorAll('a,li,div,span,p,button,td')); var c=[]; for(var i=0;i<all.length;i++){ var e=all[i];var"
      + " t=(e.innerText||'').trim(); if(!reOne.test(t))continue; if(((t.match(reAll))||[]).length>1)continue; if(!vis("
      + "e))continue; c.push(e); } if(c.length>0){ c.sort(function(a,b){ var ra=a.getBoundingClientRect(),rb=b.getBound"
      + "ingClientRect(); if(Math.abs(ra.top-rb.top)>3)return ra.top-rb.top; return ra.width*ra.height-rb.width*rb.heig"
      + "ht; }); var best=c[0]; var tg=(best.closest&&best.closest('a'))||(best.querySelector&&best.querySelector('a'))"
      + "||best; fire(tg); return 'clicou servidor: '+txt(best).substr(0,34); } var bad=/recarga|sair|logout|exit|usu.r"
      + "io|centro|baixar|sac|pacote|mais/i; var bs=document.querySelectorAll('a,button,input[type=button],input[type=s"
      + "ubmit],area'); var pb=null,ps=-1; for(var k=0;k<bs.length;k++){ var b=bs[k];var r=b.getBoundingClientRect(); i"
      + "f(r.width<60||r.height<25||r.top>window.innerHeight*0.6||r.bottom<0)continue; var tt=txt(b);var im=b.querySele"
      + "ctor?b.querySelector('img'):null;if(im)tt+=' '+(im.alt||'')+' '+(im.title||'')+' '+(im.src||''); var h=(b.getA"
      + "ttribute('href')||'')+' '+(b.className||'')+' '+(b.id||''); if(bad.test(txt(b))&&!/jogar/i.test(txt(b)))contin"
      + "ue; if(/logout|sair|recharge|pay/i.test(h))continue; var sc=0;if(/^\\s*jogar\\s*$/i.test(txt(b)))sc+=10;else i"
      + "f(/jogar/i.test(tt))sc+=6; if(/play|jogar|start|game/i.test(h+' '+tt))sc+=3;sc+=Math.min(r.width*r.height/4000"
      + "0,3); if(sc>ps&&sc>=5){ps=sc;pb=b;} } if(pb){fire(pb);return 'clicou jogar: '+txt(pb).substr(0,24);} return 'n"
      + "enhum candidato'; })()";

    private String host;
    private boolean autoplay = false;
    private boolean autoClicked = false;
    private int autoTries = 0;
    private final Runnable autoTick = new Runnable() {
        @Override public void run() {
            if (done || isFinishing() || autoClicked) return;
            autoTries++;
            web.evaluateJavascript(JS_AUTO, new ValueCallback<String>() {
                @Override public void onReceiveValue(String v) {
                    String r = decode(v);
                    if (r.startsWith("clicou")) {
                        autoClicked = true;
                        Toast.makeText(LoginActivity.this, "Auto: " + r, Toast.LENGTH_SHORT).show();
                    } else if (autoTries < 8 && !done && !isFinishing()) {
                        handler.postDelayed(autoTick, 1500);   // a lista pode carregar depois da página
                    } else {
                        Toast.makeText(LoginActivity.this, "Auto: " + r, Toast.LENGTH_SHORT).show();
                    }
                } });
        }
    };
    private boolean done = false;
    private WebView web;
    private ProgressBar bar;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LinkedList<String> reqLog = new LinkedList<String>();
    private volatile String seenSwf;
    private int scans = 0;

    private final Runnable scanTick = new Runnable() {
        @Override public void run() {
            if (done || isFinishing()) return;
            web.evaluateJavascript(JS_ALL, new ValueCallback<String>() {
                @Override public void onReceiveValue(String v) { scanHtml(decode(v)); } });
            scans++;
            if (scans < 40) handler.postDelayed(this, 2000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getStringExtra("host");

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF07061A);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // barra fina de progresso no topo (some quando a página termina de carregar)
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgressTintList(ColorStateList.valueOf(0xFF7C3AED));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(0x22FFFFFF));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(3));
        bp.gravity = Gravity.TOP;
        root.addView(bar, bp);

        // botão "Diagnóstico" discreto, em forma de pílula
        Button diag = new Button(this);
        diag.setText("Diagnóstico");
        diag.setAllCaps(false);
        diag.setTextSize(12);
        diag.setTextColor(0xFFE9DDFF);
        diag.setMinHeight(0); diag.setMinimumHeight(0);
        diag.setMinWidth(0);  diag.setMinimumWidth(0);
        diag.setPadding(dp(16), dp(8), dp(16), dp(8));
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0xCC12112E);
        pill.setCornerRadius(dp(20));
        pill.setStroke(dp(1), 0xFF4B3AA8);
        diag.setBackground(pill);
        diag.setAlpha(0.85f);
        diag.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showDiag(); } });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.gravity = Gravity.BOTTOM | Gravity.END;
        lp.setMargins(0, 0, dp(16), dp(16));
        root.addView(diag, lp);

        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setBackgroundColor(0xFF07061A);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                bar.setProgress(p);
                bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                note(u);
                return check(u);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                note(r.getUrl().toString());
                return null;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) { check(url); }
            @Override public void onPageFinished(WebView v, String url) {
                if (done) return;
                scans = 0;
                handler.removeCallbacks(scanTick);
                handler.postDelayed(scanTick, 600);
                if (autoplay && !autoClicked) {
                    autoTries = 0;
                    handler.removeCallbacks(autoTick);
                    handler.postDelayed(autoTick, 1500);
                }
            }
        });
        // Conta salva: restaura os cookies dessa conta (limpando os da anterior) e abre o site já logado.
        final String saved = getIntent().getStringExtra("cookies");
        autoplay = saved != null && saved.length() > 2;
        if (saved != null && saved.length() > 2) restoreAndLoad(saved);
        else web.loadUrl("https://" + host + "/");
    }

    private void restoreAndLoad(final String saved) {
        final CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.removeAllCookies(new ValueCallback<Boolean>() {
            @Override public void onReceiveValue(Boolean ok) {
                try {
                    JSONObject o = new JSONObject(saved);
                    java.util.Iterator<String> it = o.keys();
                    while (it.hasNext()) {
                        String h = it.next();
                        String hdr = o.optString(h);
                        if (hdr == null || hdr.length() == 0) continue;
                        for (String kv : hdr.split(";\\s*")) {
                            if (kv.indexOf('=') > 0) cm.setCookie("https://" + h + "/", kv + "; Path=/");
                        }
                    }
                    cm.flush();
                } catch (Exception ignored) {}
                web.loadUrl("https://" + host + "/");
            }
        });
    }

    // Cookies atuais dos hosts (para guardar junto da conta e reabrir o site já logado depois).
    private JSONObject snapshotCookies(String gameHost) {
        JSONObject c = new JSONObject();
        try {
            CookieManager cm = CookieManager.getInstance();
            for (String h : new String[]{host, gameHost}) {
                if (h == null || c.has(h)) continue;
                String v = cm.getCookie("https://" + h + "/");
                if (v != null && v.length() > 0) c.put(h, v);
            }
        } catch (Exception ignored) {}
        return c;
    }

    // ---------- captura por URL ----------
    private static boolean isAsset(String lowerPath) {
        String[] ext = {".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".woff2", ".svg", ".webp"};
        for (String e : ext) if (lowerPath.endsWith(e)) return true;
        return false;
    }

    // Registra a requisição (só host, caminho e NOMES dos parâmetros) e guarda o Loading.swf visto.
    private void note(String url) {
        try {
            URI u = new URI(url);
            String path = u.getPath() == null ? "" : u.getPath();
            String q = u.getRawQuery();
            StringBuilder names = new StringBuilder();
            if (q != null) {
                for (String kv : q.split("&")) {
                    int i = kv.indexOf('=');
                    names.append(i > 0 ? kv.substring(0, i) : kv).append(',');
                }
            }
            synchronized (reqLog) {
                reqLog.add(u.getHost() + path + (names.length() > 0 ? "?" + names : ""));
                if (reqLog.size() > 80) reqLog.removeFirst();
            }
            if (path.toLowerCase().endsWith(".swf") && path.contains("Loading")) {
                seenSwf = u.getRawPath() + (q != null ? "?" + q : "");
            }
            check(url);
        } catch (Exception ignored) {}
    }

    // Qualquer URL (que não seja imagem/css/js) com user= e key= vira a sessão.
    private boolean check(String url) {
        if (done) return false;
        try {
            URI u = new URI(url);
            String q = u.getRawQuery();
            String lp = u.getPath() == null ? "" : u.getPath().toLowerCase();
            if (q == null || !q.contains("user=") || !q.contains("key=") || isAsset(lp)) return false;
            JSONObject params = new JSONObject();
            for (String kv : q.split("&")) {
                int i = kv.indexOf('=');
                if (i > 0) params.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), "UTF-8"));
            }
            if (params.optString("key").length() < 4) return false;
            finishWith(u.getHost() != null ? u.getHost() : host, params, seenSwf);
            return true;
        } catch (Exception e) { return false; }
    }

    // ---------- captura pelo HTML ----------
    private static boolean plausible(String v) {
        if (v == null) return false;
        String l = v.toLowerCase();
        return !(l.equals("function") || l.equals("null") || l.equals("undefined") || l.equals("true")
            || l.equals("false") || l.equals("this") || l.equals("document") || l.equals("window") || l.equals("var"));
    }

    private void scanHtml(String html) {
        if (done || html == null || html.length() == 0) return;
        try {
            Matcher m = SWF_LOADING.matcher(html);
            String swf = m.find() ? m.group(1) : null;
            if (swf == null) {
                m = SWF_ANY.matcher(html);
                if (m.find()) swf = m.group(1);
            }
            if (swf == null) swf = seenSwf;
            JSONObject params = new JSONObject();
            for (String k : KEYS) {
                Matcher mm = Pattern.compile("(?i)\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)").matcher(html);
                while (mm.find()) {
                    String val = mm.group(1);
                    if (plausible(val)) { params.put(k, val); break; }
                }
            }
            if (!params.has("user") || !params.has("key") || params.optString("key").length() < 8) return;
            if (swf == null && scans < 10) return;   // espera mais um pouco pelo caminho do swf
            finishWith(host, params, swf);
        } catch (Exception ignored) {}
    }

    private static String decode(String raw) {
        if (raw == null || raw.equals("null")) return "";
        try {
            Object o = new JSONTokener(raw).nextValue();
            if (o instanceof String) return (String) o;
        } catch (Exception ignored) {}
        return raw;
    }

    // ---------- entrega ao AS3 ----------
    private void finishWith(final String gameHost, final JSONObject params, final String swf) {
        synchronized (this) {
            if (done) return;
            done = true;
        }
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    String outHost = gameHost;
                    String swfPath = null;
                    if (swf != null) {
                        try {
                            URI su = new URI(swf.startsWith("http") ? swf : "https://" + gameHost + "/" + swf.replaceFirst("^/", ""));
                            if (su.getHost() != null) outHost = su.getHost();
                            swfPath = su.getRawPath() + (su.getRawQuery() != null ? "?" + su.getRawQuery() : "");
                        } catch (Exception e) { swfPath = "/Loading.swf"; }
                    }
                    JSONObject out = new JSONObject();
                    out.put("host", outHost);
                    out.put("params", params);
                    out.put("user", params.optString("user"));
                    out.put("key", params.optString("key"));
                    if (swfPath != null) out.put("swf", swfPath);
                    out.put("cookies", snapshotCookies(outHost));
                    if (BridgeExtension.ctx != null) BridgeExtension.ctx.dispatchStatusEventAsync("game", out.toString());
                } catch (Exception e) {
                    if (BridgeExtension.ctx != null) BridgeExtension.ctx.dispatchStatusEventAsync("error", String.valueOf(e));
                }
                finish();
            }
        });
    }

    // ---------- diagnóstico ----------
    private static String mask(String s) {
        return MASK.matcher(s).replaceAll("$1$2***");
    }

    private void showDiag() {
        final StringBuilder sb = new StringBuilder();
        sb.append("URL: ").append(String.valueOf(web.getUrl())).append("\n");
        sb.append("capturado=").append(done).append(" swfVisto=").append(seenSwf).append("\n");
        sb.append("-- ultimas requisicoes (so nomes de parametros) --\n");
        synchronized (reqLog) {
            int skip = Math.max(0, reqLog.size() - 40);
            int n = 0;
            for (String r : reqLog) { if (n++ >= skip) sb.append(r).append("\n"); }
        }
        web.evaluateJavascript(JS_DIAG, new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
                sb.append("-- pagina --\n").append(decode(v));
                showText("Diagnóstico", mask(sb.toString()));
            }
        });
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showText(String title, String text) {
        final String t = text.length() > 9000 ? text.substring(0, 9000) : text;
        AlertDialog dlg = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(title).setMessage(t)
            .setPositiveButton("Copiar", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cb.setPrimaryClip(ClipData.newPlainText("diag", t));
                    Toast.makeText(LoginActivity.this, "Copiado", Toast.LENGTH_SHORT).show();
                } })
            .setNegativeButton("Fechar", null).create();
        BridgeContext.styleDialog(dlg);
        dlg.show();
        BridgeContext.tintButtons(dlg);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
