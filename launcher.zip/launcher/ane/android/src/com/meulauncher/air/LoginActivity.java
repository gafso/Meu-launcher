package com.meulauncher.air;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONObject;
import org.json.JSONTokener;

import java.net.URI;
import java.net.URLDecoder;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

// WebView em modo desktop. O usuário faz o login normal no site; capturamos os parâmetros
// (user/key e o Loading.swf) de três jeitos: URL de qualquer requisição, HTML da página e
// HTML dos iframes (lido de tempos em tempos). Nenhuma senha é lida nem guardada.
// O botão "Diagnóstico" mostra o que a página tem (valores de user/key são mascarados).
public class LoginActivity extends Activity {
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        + "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    private static final Pattern SWF_LOADING = Pattern.compile("([\\w./:\\-%]*Loading[\\w\\-]*\\.swf[\\w?=&.%\\-]*)");
    private static final Pattern SWF_ANY = Pattern.compile("([\\w./:\\-%]+\\.swf)");
    private static final Pattern MASK = Pattern.compile(
        "(?i)(user|key|pass\\w*|token|sid|sign|auth\\w*|session\\w*|cookie)([\"']?\\s*[:=]\\s*[\"']?)[^\"'&<>\\s,;]+");
    private static final String[] KEYS = {"user", "key", "site", "p2", "rid", "logintype"};

    // HTML da página + dos iframes do mesmo domínio.
    private static final String JS_ALL =
        "(function(){var o=[];function a(d){try{o.push(d.documentElement.outerHTML);}catch(e){}}"
      + "a(document);var f=document.querySelectorAll('iframe,frame');"
      + "for(var i=0;i<f.length;i++){try{a(f[i].contentDocument);}catch(e){}}"
      + "return o.join(String.fromCharCode(10));})()";

    // Resumo para diagnóstico: iframes e trechos em volta de ".swf", swfobject, flashvars, object, embed.
    private static final String JS_DIAG =
        "(function(){var r=[];var nl=String.fromCharCode(10);"
      + "function c(t,k){var o=[],p=0,n=0,i,l=t.toLowerCase();"
      + "while(n<4&&(i=l.indexOf(k,p))>=0){o.push(t.substr(Math.max(0,i-120),300).split(nl).join(' '));p=i+k.length;n++;}return o;}"
      + "var docs=[document];var f=document.querySelectorAll('iframe,frame');r.push('iframes='+f.length);"
      + "for(var i=0;i<f.length;i++){r.push(' iframe src='+f[i].src);"
      + "try{if(f[i].contentDocument)docs.push(f[i].contentDocument);else r.push(' (sem acesso)');}catch(e){r.push(' (sem acesso)');}}"
      + "for(var d=0;d<docs.length;d++){var h='';try{h=docs[d].documentElement.outerHTML;}catch(e){}"
      + "r.push('DOC'+d+' len='+h.length);"
      + "var ks=['.swf','swfobject','flashvars','embedswf','<object','<embed'];"
      + "for(var j=0;j<ks.length;j++){var cs=c(h,ks[j]);for(var m=0;m<cs.length;m++){r.push(' ['+ks[j]+'] '+cs[m]);}}}"
      + "return r.join(nl);})()";

    private String host;
    private boolean done = false;
    private WebView web;
    private ProgressBar bar;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final LinkedList<String> reqLog = new LinkedList<String>();
    private volatile String seenSwf;
    private int scans = 0;

    private final Runnable scanTick = new Runnable() {
        @Override public void run() {
            if (done || isFinishing()) return;
            web.evaluateJavascript(JS_ALL, new ValueCallback<String>() {
                @Override public void onReceiveValue(String v) { scanHtml(decode(v)); } });
            scans++;
            if (scans < 40) handler.postDelayed(this, 2000);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        host = getIntent().getStringExtra("host");

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0F131A);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // barra fina de progresso no topo (some quando a página termina de carregar)
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgressTintList(ColorStateList.valueOf(0xFF4C8DFF));
        bar.setProgressBackgroundTintList(ColorStateList.valueOf(0x22FFFFFF));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(-1, dp(3));
        bp.gravity = Gravity.TOP;
        root.addView(bar, bp);

        // botão "Diagnóstico" discreto, em forma de pílula
        Button diag = new Button(this);
        diag.setText("Diagnóstico");
        diag.setAllCaps(false);
        diag.setTextSize(12);
        diag.setTextColor(0xFFC9D3E6);
        diag.setMinHeight(0); diag.setMinimumHeight(0);
        diag.setMinWidth(0);  diag.setMinimumWidth(0);
        diag.setPadding(dp(16), dp(8), dp(16), dp(8));
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(0xCC1A2130);
        pill.setCornerRadius(dp(20));
        pill.setStroke(dp(1), 0xFF34425A);
        diag.setBackground(pill);
        diag.setAlpha(0.85f);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, -2);
        lp.gravity = Gravity.BOTTOM | Gravity.END;
        lp.setMargins(0, 0, dp(16), dp(16));
        root.addView(diag, lp);
        diag.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showDiag(); } });
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(UA);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        web.setBackgroundColor(0xFF0F131A);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView v, int p) {
                bar.setProgress(p);
                bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                note(u);
                return check(u);
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                note(r.getUrl().toString());
                return null;
            }
            @Override public void onPageStarted(WebView v, String url, Bitmap f) { check(url); }
            @Override public void onPageFinished(WebView v, String url) {
                if (done) return;
                scans = 0;
                handler.removeCallbacks(scanTick);
                handler.postDelayed(scanTick, 600);
            }
        });
        web.loadUrl("https://" + host + "/");
    }

    // ---------- captura por URL ----------
    private static boolean isAsset(String lowerPath) {
        String[] ext = {".png", ".jpg", ".jpeg", ".gif", ".css", ".js", ".ico", ".woff", ".woff2", ".svg", ".webp"};
        for (String e : ext) if (lowerPath.endsWith(e)) return true;
        return false;
    }

    // Registra a requisição (só host, caminho e NOMES dos parâmetros) e guarda o Loading.swf visto.
    private void note(String url) {
        try {
            URI u = new URI(url);
            String path = u.getPath() == null ? "" : u.getPath();
            String q = u.getRawQuery();
            StringBuilder names = new StringBuilder();
            if (q != null) {
                for (String kv : q.split("&")) {
                    int i = kv.indexOf('=');
                    names.append(i > 0 ? kv.substring(0, i) : kv).append(',');
                }
            }
            synchronized (reqLog) {
                reqLog.add(u.getHost() + path + (names.length() > 0 ? "?" + names : ""));
                if (reqLog.size() > 80) reqLog.removeFirst();
            }
            if (path.toLowerCase().endsWith(".swf") && path.contains("Loading")) {
                seenSwf = u.getRawPath() + (q != null ? "?" + q : "");
            }
            check(url);
        } catch (Exception ignored) {}
    }

    // Qualquer URL (que não seja imagem/css/js) com user= e key= vira a sessão.
    private boolean check(String url) {
        if (done) return false;
        try {
            URI u = new URI(url);
            String q = u.getRawQuery();
            String lp = u.getPath() == null ? "" : u.getPath().toLowerCase();
            if (q == null || !q.contains("user=") || !q.contains("key=") || isAsset(lp)) return false;
            JSONObject params = new JSONObject();
            for (String kv : q.split("&")) {
                int i = kv.indexOf('=');
                if (i > 0) params.put(kv.substring(0, i), URLDecoder.decode(kv.substring(i + 1), "UTF-8"));
            }
            if (params.optString("key").length() < 4) return false;
            finishWith(u.getHost() != null ? u.getHost() : host, params, seenSwf);
            return true;
        } catch (Exception e) { return false; }
    }

    // ---------- captura pelo HTML ----------
    private static boolean plausible(String v) {
        if (v == null) return false;
        String l = v.toLowerCase();
        return !(l.equals("function") || l.equals("null") || l.equals("undefined") || l.equals("true")
            || l.equals("false") || l.equals("this") || l.equals("document") || l.equals("window") || l.equals("var"));
    }

    private void scanHtml(String html) {
        if (done || html == null || html.length() == 0) return;
        try {
            Matcher m = SWF_LOADING.matcher(html);
            String swf = m.find() ? m.group(1) : null;
            if (swf == null) {
                m = SWF_ANY.matcher(html);
                if (m.find()) swf = m.group(1);
            }
            if (swf == null) swf = seenSwf;
            JSONObject params = new JSONObject();
            for (String k : KEYS) {
                Matcher mm = Pattern.compile("(?i)\\b" + k + "[\"']?\\s*[:=]\\s*[\"']?([^\"'&<>\\s,;]+)").matcher(html);
                while (mm.find()) {
                    String val = mm.group(1);
                    if (plausible(val)) { params.put(k, val); break; }
                }
            }
            if (!params.has("user") || !params.has("key") || params.optString("key").length() < 8) return;
            if (swf == null && scans < 10) return;   // espera mais um pouco pelo caminho do swf
            finishWith(host, params, swf);
        } catch (Exception ignored) {}
    }

    private static String decode(String raw) {
        if (raw == null || raw.equals("null")) return "";
        try {
            Object o = new JSONTokener(raw).nextValue();
            if (o instanceof String) return (String) o;
        } catch (Exception ignored) {}
        return raw;
    }

    // ---------- entrega ao AS3 ----------
    private void finishWith(final String gameHost, final JSONObject params, final String swf) {
        synchronized (this) {
            if (done) return;
            done = true;
        }
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try {
                    String outHost = gameHost;
                    String swfPath = null;
                    if (swf != null) {
                        try {
                            URI su = new URI(swf.startsWith("http") ? swf : "https://" + gameHost + "/" + swf.replaceFirst("^/", ""));
                            if (su.getHost() != null) outHost = su.getHost();
                            swfPath = su.getRawPath() + (su.getRawQuery() != null ? "?" + su.getRawQuery() : "");
                        } catch (Exception e) { swfPath = "/Loading.swf"; }
                    }
                    JSONObject out = new JSONObject();
                    out.put("host", outHost);
                    out.put("params", params);
                    out.put("user", params.optString("user"));
                    out.put("key", params.optString("key"));
                    if (swfPath != null) out.put("swf", swfPath);
                    if (BridgeExtension.ctx != null) BridgeExtension.ctx.dispatchStatusEventAsync("game", out.toString());
                } catch (Exception e) {
                    if (BridgeExtension.ctx != null) BridgeExtension.ctx.dispatchStatusEventAsync("error", String.valueOf(e));
                }
                finish();
            }
        });
    }

    // ---------- diagnóstico ----------
    private static String mask(String s) {
        return MASK.matcher(s).replaceAll("$1$2***");
    }

    private void showDiag() {
        final StringBuilder sb = new StringBuilder();
        sb.append("URL: ").append(String.valueOf(web.getUrl())).append("\n");
        sb.append("capturado=").append(done).append(" swfVisto=").append(seenSwf).append("\n");
        sb.append("-- ultimas requisicoes (so nomes de parametros) --\n");
        synchronized (reqLog) {
            int skip = Math.max(0, reqLog.size() - 40);
            int n = 0;
            for (String r : reqLog) { if (n++ >= skip) sb.append(r).append("\n"); }
        }
        web.evaluateJavascript(JS_DIAG, new ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
                sb.append("-- pagina --\n").append(decode(v));
                showText("Diagnóstico", mask(sb.toString()));
            }
        });
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void showText(String title, String text) {
        final String t = text.length() > 9000 ? text.substring(0, 9000) : text;
        AlertDialog dlg = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(title).setMessage(t)
            .setPositiveButton("Copiar", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) {
                    ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    cb.setPrimaryClip(ClipData.newPlainText("diag", t));
                    Toast.makeText(LoginActivity.this, "Copiado", Toast.LENGTH_SHORT).show();
                } })
            .setNegativeButton("Fechar", null).create();
        BridgeContext.styleDialog(dlg);
        dlg.show();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
