# Meu Launcher (AIR + ANE Android, arm64)

Launcher que faz login no site oficial do servidor escolhido (WebView),
captura `user`/`key`, sobe um proxy local e carrega o `Loading.swf` do jogo.

## O que tem
- Seleção de plataforma (menu nativo) e botão JOGAR
- Menu de configurações (engrenagem): qualidade gráfica, FPS, controles na tela,
  cache do jogo (ver tamanho / apagar), mostrar log (com copiar), trocar plataforma,
  sair da conta, reiniciar e sair do app
- Atalhos na tela: Mochila (B), Missão (L), Mapa (M) e zoom + / −  (edite em `src/Controls.as`)
- Manter a sessão em segundo plano (serviço em primeiro plano)
- Cache do `Loading.swf` em disco (6 h) e reservas em `assets/game/`

Não implementado (o original fazia): resolução/superfície (`setSurfaceSize` é stub),
mapa do mundo em 2D e lista de e-mails salvos.

## Compilar pelo celular (GitHub Actions)
1. Crie um repositório e suba **todo** o conteúdo desta pasta (inclusive `.github/workflows/build.yml`).
2. Suba o zip do **AIR SDK 51** como *release* de um repositório seu (o nome do arquivo tanto faz).
   (O SDK 32 não serve: não gera APK de 64 bits.)
3. Aba **Actions → Build APK → Run workflow**. O campo já vem com `https://github.com/gafso/sdk/releases/tag/Sdk`;
   pode colar a página de outra release ou o link direto do arquivo. O workflow acha o SDK sozinho.
4. Ao terminar, baixe `MeuLauncher-apk` na própria execução e instale o `MeuLauncher.apk`.

Sem os secrets `KEYSTORE_B64` / `KEYSTORE_PASS` cada build usa uma chave nova; para
atualizar o app por cima sem desinstalar, crie uma keystore e salve-a nos secrets.

## Reservas do carregador
Coloque seus `Loading*.swf` em `assets/game/` (nomes em `assets/game/LEIA-ME.txt`).
Não são fornecidos aqui.

## Compilar num PC
    AIR_SDK=/caminho/AIRSDK ANDROID_JAR=/caminho/android.jar STOREPASS=senha ./build.sh

## Estado dos testes
- A classe `Bridge` fica dentro do ANE (`ane/as`): o AIR só entrega o ExtensionContext a código que veio da library.swf da extensão (senão dá Error #2113).
- Java do ANE e o APK final **não foram compilados aqui** (sem `android.jar` nem SDK 51 neste
  ambiente). Se o Actions apontar erro, mande-me o log.
- Pontos que dependem do jogo real: regex de captura do `Loading.swf` em `LoginActivity`,
  hosts de `Platforms.as` (loes/lotr/lortr/lorpt são suposição pelo padrão do lobr).
