# Legend Mobile (AIR + ANE Android, arm64)

Launcher que faz login no site oficial do servidor escolhido (WebView),
captura `user`/`key`, sobe um proxy local e carrega o `Loading.swf` do jogo.

## O que tem
- Seleção de plataforma (menu nativo) e botão JOGAR
- Menu de configurações (engrenagem): qualidade gráfica, FPS, controles na tela,
  cache do jogo (ver tamanho / apagar), mostrar log (com copiar), trocar plataforma,
  sair da conta, reiniciar e sair do app
- Atalhos na tela: Mochila (B), Missão (L), Mapa (M) e zoom + / −  (edite em `src/Controls.as`)
- Manter a sessão em segundo plano (serviço em primeiro plano)
- Cache em disco dos arquivos que o jogo baixa (`SwfFixer`, pasta `gamecache`)

Não implementado (o original fazia): resolução/superfície (`setSurfaceSize` é stub),
mapa do mundo em 2D e lista de e-mails salvos.

## Compilar pelo celular (GitHub Actions)
1. Crie um repositório e suba **todo** o conteúdo desta pasta (inclusive `.github/workflows/build.yml`).
2. Suba o zip do **AIR SDK 51** como *release* de um repositório seu (o nome do arquivo tanto faz).
   (O SDK 32 não serve: não gera APK de 64 bits.)
3. Aba **Actions → Build APK → Run workflow**. O campo já vem com `https://github.com/gafso/sdk/releases/tag/Sdk`;
   pode colar a página de outra release ou o link direto do arquivo. O workflow acha o SDK sozinho.
4. Ao terminar, baixe `MeuLauncher-apk` na própria execução e instale o `MeuLauncher.apk`.

Sem os secrets `KEYSTORE_B64` / `KEYSTORE_PASS` cada build usa uma chave nova; para
atualizar o app por cima sem desinstalar, crie uma keystore e salve-a nos secrets.

## Como o jogo é aberto (importante)
O `Loading.swf` do servidor **não é executado**: o launcher baixa só para medir o tamanho (versão) e abre a cópia
modificada de `assets/game/` (`Loading.swf` = Brasil, 244783 bytes; `Loading_<tamanho>.swf` = outras versões).
Essas cópias usam funções (`__lofix`, `loadByteZ`, `__cacheGet`...) que o `src/SwfFixer.as` instala no `Loader`.
Sem as cópias em `assets/game/` o jogo não abre. São arquivos do jogo: mantenha o repositório **privado**.

## Compilar num PC
    AIR_SDK=/caminho/AIRSDK ANDROID_JAR=/caminho/android.jar STOREPASS=senha ./build.sh

## Estado dos testes
- A classe `Bridge` fica dentro do ANE (`ane/as`): o AIR só entrega o ExtensionContext a código que veio da library.swf da extensão (senão dá Error #2113).
- Java do ANE e o APK final **não foram compilados aqui** (sem `android.jar` nem SDK 51 neste
  ambiente). Se o Actions apontar erro, mande-me o log.
- Pontos que dependem do jogo real: regex de captura do `Loading.swf` em `LoginActivity`,
  hosts de `Platforms.as` (loes/lotr/lortr/lorpt são suposição pelo padrão do lobr).

## v4.0
- Macro > Moeda VIP: o botão agora é **Exportar imagens do jogo**. Copia para `mods/_capturas/` todas as imagens (PNG/JPG/GIF) que o jogo já guardou no cache do app (a pasta é criada na hora). Abra a mochila e a Roleta antes, para os ícones estarem no cache.
- Configurações: removidas as opções de reorganizar a interface e o item Macros (use o botão ▶). Novo **Relogar (recarregar o jogo)**: fecha o jogo, para os macros e faz um login novo sem reiniciar o app.

## v3.9 (energia automática nos Planos)
- Janela de Macros: botão **Energia auto** (OFF → 1x → 3x → 5x → 10x compras por rodada). Quando a energia cai abaixo de 40 (ou o caminho do olho/mina precisa de mais), o macro compra energia com a **op 8**, a mesma da barra de energia do jogo (`PlanesTopView`): param `[2]` = diamante vinculado primeiro (caixa marcada), `[1]` = não.
- Travas: não envia nada se não conseguir ler custo, limite diário, compras feitas ou diamantes; para ao atingir o limite diário do jogo, ao faltar diamantes, ao bater o limite da rodada, ou se a energia não subir em 8 s (nunca repete sozinho). Cada compra vai para o log com energia/diamantes antes e depois.
- "Diagnóstico (só lê)" mostra a linha ENERGIA (energia/máx, compras hoje/limite, custo, seus diamantes): confira antes de ligar.
- Código do Transmissor (módulo `4.png`, `PlanesListView`): recarga fora do plano = op 20 `[1|2]`; entrar no plano = op 15 `[planesId]`; desistir = op 18 `[planesId]`; vida = op 17 `[planesId, item]`. Ainda NÃO usados pelo macro.

## v2.3 / v2.2 (resolução, 120 FPS, ícone e fonte)
- Resolução: opções **Full HD 1920x1080** e **2K 2560x1440** (experimentais). O AIR do Android não aceita que o app mude o tamanho da tela por fora (a tentativa por escala da SurfaceView só encolheu a imagem e escondeu a engrenagem; foi removida). Agora o app tenta mudar o tamanho do palco do AIR e CONFERE ("Palco: WxH" no log); se não aceitar, volta sozinho ao Modo PC e avisa.
- FPS: nova opção **120**. Além de `stage.frameRate`, o app pede à tela do aparelho o modo de atualização mais próximo (`BridgeContext.applyRefresh`). O menu de FPS mostra a taxa real da tela.
- Ícone do app: `assets/icons/` (36 a 144 px, registrados em `app.xml`). Fonte original 512 px em `assets/icons/icon512.png`.
- Fonte do jogo: Configurações > Fonte do jogo (também disponível no menu inicial, antes de entrar). Usa fontes do sistema Android; o PALCO inteiro (o jogo põe janelas direto nele) é varrido a cada 1,5 s trocando a fonte dos textos. Conferir em Mostrar log: "Fonte 'X': N textos vistos, M alterados, K bloqueados".
- Menu inicial ganhou o botão "Configurações".

## v2.1 (visual profissional)
- Sem emblema; título "LEGEND MOBILE" em duas cores, painel translúcido com borda discreta, cantos dos botões mais sóbrios, marca vermelha no cartão do servidor, rodapé com versão e entrada suave do painel.

## v2.0 (tema preto e vermelho)
- Nome do app: **Legend Mobile** (o pacote `com.meulauncher.air` e a keystore não mudaram, então instala por cima do app antigo).
- Imagem de fundo do menu em `assets/fundo.jpg` (1870x841). Para trocar, substitua o arquivo mantendo o nome. Menu numa coluna à esquerda, com sombra para o texto ficar legível.
- Tema preto com vermelho em toda a interface (tela inicial, engrenagem, diálogos e tela de login); botões ~10% menores.
- Login volta a ser só pelo site (a tentativa de login dentro do app foi removida).

## v1.9 (visual)
- Tela inicial redesenhada: fundo em degradê com brilhos suaves, emblema, cartão "SERVIDOR" (toque para trocar), botão JOGAR em destaque e ações secundárias (Sair da conta / Ver log) discretas. Tudo escala com o tamanho da tela.
- Botões com feedback ao toque (`src/Btn.as`); mensagens de erro ficam em vermelho claro.
- Engrenagem redonda com ícone desenhado em vetor (não depende de fonte/emoji).
- Diálogos nativos (menus, log, diagnóstico) em tema escuro com cantos arredondados.
- Tela de login: barra de progresso no topo, fundo escuro e botão "Diagnóstico" em pílula.
- Nenhuma lógica foi alterada (login, proxy, cache, mods, resolução continuam iguais).

## v3.6
- Corrige o mapa preto / botão Explorar: os avisos de resize da v3.4/v3.5 (no instante em que o jogo monta o mundo) estragavam o mapa. Voltou ao comportamento da v3.3 (restaura a escala até 1 s depois) e os avisos agora são poucos e espaçados (3, 8, 16 e 30 s após o jogo carregar ou trocar a escala). Menu: "Reorganizar interface sozinho" (liga/desliga) e "Reorganizar a interface agora" (aviso manual).
- Padrão sem barras: o palco passou de 1250x650 para 1352x650 (mesma proporção da tela 2246x1080 deste aparelho). Para outro aparelho: `STAGE_W=<largura> ./build.sh` (e `width` em `[SWF(...)]` no Main.as), com STAGE_W = 650 x (largura da área do app / altura).
- Resolução > "Personalizada": barra deslizante (altura 650 a 1080; largura pela proporção do palco). Usa a mesma técnica das resoluções Full HD/2K (pede ao AIR um palco virtual WxH e CONFERE; se o aparelho não aceitar, volta ao Padrão e avisa). Experimental.
- Alinhamento voltou a TOP_LEFT (a centralização da v3.5 foi removida).
- Log: "imagem inexistente respondida na hora: <arquivo>" (primeiras 15) para saber quais imagens o cache negativo está trocando por PNG transparente.

## v3.5
- Fundo do menu (imagem + degradê) é escondido quando o jogo abre: o mapa do jogo é desenhado atrás do app e a imagem o cobria (mapa dos arredores "não carregava").
- Quando o jogo troca a escala do palco para noScale (acontece ao carregar e ao entrar no mundo), o app restaura NA HORA e reenvia o resize (antes até 1 s depois, e a interface, ex. botão Explorar, ficava fora da área visível).
- Padrão (ex-"Modo PC"): alinhado ao centro na horizontal (barras dos dois lados em vez de só à direita). O alinhamento também é conferido a cada 1 s.
- Engrenagem 12 unidades mais baixa (`GEAR_Y` em `Controls.as`).
- "Modo PC" renomeado para "Padrão" nos textos.

## v3.4
- Modo PC: o app agora manda um aviso de resize ao jogo (no máximo 1 a cada 1,5 s) quando o jogo põe algo novo no palco ou na raiz dele, para a interface do mapa (ex.: "arredores") se posicionar sem precisar mudar o tamanho da tela. Liga/desliga: Configurações > "Corrigir layout do Modo PC".
- Menos ruído no log: "Resolução"/"Palco" só quando mudam; a linha CACHE só quando algo mudou (a cada 60 s).

## v3.3
- Cache negativo também para HTTP 403 em PNG (o servidor responde 403, e não 404, para arquivos inexistentes; confirmado pelo log da v3.2).

## v3.2 (desempenho dentro do jogo)
- Cache negativo de imagens: quando um PNG falha, o app confirma se foi HTTP 404/410 e lembra por 12 h (arquivo `gamecache/neg.json`). Nas próximas vezes o `__cacheGet` devolve na hora um PNG transparente 1x1, sem esperar ~2 s por imagem (ícones `skillname/*.png` do PvP). Só vale para `.png` e só para 404/410; falha de rede não é lembrada. Liga/desliga em Configurações > Cache do jogo.
- O log de falhas agora mostra o código HTTP e o tempo (`FALHOU download (HTTP 404, 1800 ms ...)`), para separar 404 de timeout. A linha `CACHE:` mostra quantos pedidos foram respondidos na hora.
- Log gravado em arquivo (`launcher.log`; a sessão anterior fica em `launcher_prev.log`). "Mostrar log" mostra a sessão atual + a anterior, então dá para enviar o log depois de reabrir o app.
- Limpeza do cache (varredura da pasta inteira) roda no máximo 1x por dia, e não a cada abertura.
- Dentro do jogo, o temporizador da engrenagem passou de 400 ms para 1 s e só reposiciona a engrenagem quando o tamanho da tela muda.

## v3.1
- Log: linha "CACHE:" a cada 30 s (arquivos lidos do disco x baixados da rede). Gravação do cache sempre imediata e conferida.

## v3.8 (listar classes do jogo)
- Janela de Macros: botão **Listar classes**. Lê da memória do jogo (só leitura) os nomes de classes ligadas a Planos/Transmissor/portal/crise/energia e, das principais, métodos, variáveis e constantes. Abra o Transmissor e a Bolsa do Plano no jogo ANTES de usar. O relatório aparece numa caixa (com copiar) e é gravado em `mods/classes_planes.txt` (pasta `Android/data/com.meulauncher.air/files/mods`).
- Serve para descobrir em que arquivo do jogo está a tela do Transmissor (ops 15/18/20) sem adivinhar pelo log.

## v3.0
- Cache: diagnóstico no log (cache MISS / EXPIRADO / falha ao gravar), gravação imediata de arquivos pequenos, validade dos arquivos sem identificador de versão de 3 para 7 dias. Engrenagem mais abaixo.

## v2.9
- SwfFixer: swf que não precisa de correção passa a ser lembrado (antes era descompactado e varrido a cada carregamento). O log passa a mostrar "cache lento" e "fix levou N ms" quando algo demora.

## v2.8
- Removidos: mods locais (pasta `mods`, troca de tiles/SWF, `ferramentas/`) e a troca de fonte do jogo. A troca de fonte varria todos os textos do jogo a cada 1,5 s, o que deixava o jogo lento (batalhas).

## v1.8
- Resolução refeita sem depender do Android: Modo PC usa StageScaleMode.SHOW_ALL com palco de 1250x650 (SWF compilado com -default-size). A SurfaceView não é mais mexida (o setFixedSize não alterava o palco do AIR).

## v1.7
- Modo PC é a resolução padrão (aplicada já na abertura do app e de novo ao voltar do login); as outras ficam no menu.

## v1.6
- Corrige a resolução / Modo PC: a SurfaceView não é mais redimensionada (isso deslocava e cortava o jogo e escondia a engrenagem). Agora só o buffer muda (setFixedSize) com a mesma proporção da tela.

## v1.5
- Resolução como no app original: Nativa ou "Modo PC" (1250x650, 1440x750, 1100x572) centralizado.
  Resoluções abaixo de ~600 de altura cortam as janelas do jogo, por isso não são oferecidas.
- Segundo plano: `executeInBackground` + serviço com WakeLock/WifiLock. Botão Voltar abre a janela
  "Sair do app" (segundo plano / fechar / cancelar).
- Só a engrenagem fica na tela (atalhos Mochila/Missão/Mapa e zoom removidos).
- `keystore.p12` NÃO pode mudar entre versões: é ela que permite instalar por cima do app antigo.
