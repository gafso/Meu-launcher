# Legend Mobile (AIR + ANE Android, arm64)

Launcher que faz login no site oficial do servidor escolhido (WebView),
captura `user`/`key`, sobe um proxy local e carrega o `Loading.swf` do jogo.

## O que tem
- Seleção de plataforma (menu nativo) e botão JOGAR
- Menu de configurações (engrenagem): qualidade gráfica, FPS, controles na tela,
  cache do jogo (ver tamanho / apagar), mostrar log (com copiar), trocar plataforma,
  sair da conta, reiniciar e sair do app
- Atalhos na tela: Mochila (B), Missão (L), Mapa (M) e zoom + / −  (edite em `src/Controls.as`)
- Manter a sessão em segundo plano (serviço em primeiro plano)
- Cache em disco dos arquivos que o jogo baixa (`SwfFixer`, pasta `gamecache`)

Não implementado (o original fazia): resolução/superfície (`setSurfaceSize` é stub),
mapa do mundo em 2D e lista de e-mails salvos.

## Compilar pelo celular (GitHub Actions)
1. Crie um repositório e suba **todo** o conteúdo desta pasta (inclusive `.github/workflows/build.yml`).
2. Suba o zip do **AIR SDK 51** como *release* de um repositório seu (o nome do arquivo tanto faz).
   (O SDK 32 não serve: não gera APK de 64 bits.)
3. Aba **Actions → Build APK → Run workflow**. O campo já vem com `https://github.com/gafso/sdk/releases/tag/Sdk`;
   pode colar a página de outra release ou o link direto do arquivo. O workflow acha o SDK sozinho.
4. Ao terminar, baixe `MeuLauncher-apk` na própria execução e instale o `MeuLauncher.apk`.

Sem os secrets `KEYSTORE_B64` / `KEYSTORE_PASS` cada build usa uma chave nova; para
atualizar o app por cima sem desinstalar, crie uma keystore e salve-a nos secrets.

## Como o jogo é aberto (importante)
O `Loading.swf` do servidor **não é executado**: o launcher baixa só para medir o tamanho (versão) e abre a cópia
modificada de `assets/game/` (`Loading.swf` = Brasil, 244783 bytes; `Loading_<tamanho>.swf` = outras versões).
Essas cópias usam funções (`__lofix`, `loadByteZ`, `__cacheGet`...) que o `src/SwfFixer.as` instala no `Loader`.
Sem as cópias em `assets/game/` o jogo não abre. São arquivos do jogo: mantenha o repositório **privado**.

## Compilar num PC
    AIR_SDK=/caminho/AIRSDK ANDROID_JAR=/caminho/android.jar STOREPASS=senha ./build.sh

## Estado dos testes
- A classe `Bridge` fica dentro do ANE (`ane/as`): o AIR só entrega o ExtensionContext a código que veio da library.swf da extensão (senão dá Error #2113).
- Java do ANE e o APK final **não foram compilados aqui** (sem `android.jar` nem SDK 51 neste
  ambiente). Se o Actions apontar erro, mande-me o log.
- Pontos que dependem do jogo real: regex de captura do `Loading.swf` em `LoginActivity`,
  hosts de `Platforms.as` (loes/lotr/lortr/lorpt são suposição pelo padrão do lobr).

## v2.3 / v2.2 (resolução, 120 FPS, ícone e fonte)
- Resolução: opções **Full HD 1920x1080** e **2K 2560x1440** (experimentais). O AIR do Android não aceita que o app mude o tamanho da tela por fora (a tentativa por escala da SurfaceView só encolheu a imagem e escondeu a engrenagem; foi removida). Agora o app tenta mudar o tamanho do palco do AIR e CONFERE ("Palco: WxH" no log); se não aceitar, volta sozinho ao Modo PC e avisa.
- FPS: nova opção **120**. Além de `stage.frameRate`, o app pede à tela do aparelho o modo de atualização mais próximo (`BridgeContext.applyRefresh`). O menu de FPS mostra a taxa real da tela.
- Ícone do app: `assets/icons/` (36 a 144 px, registrados em `app.xml`). Fonte original 512 px em `assets/icons/icon512.png`.
- Fonte do jogo: Configurações > Fonte do jogo (também disponível no menu inicial, antes de entrar). Usa fontes do sistema Android; o PALCO inteiro (o jogo põe janelas direto nele) é varrido a cada 1,5 s trocando a fonte dos textos. Conferir em Mostrar log: "Fonte 'X': N textos vistos, M alterados, K bloqueados".
- Menu inicial ganhou o botão "Configurações".

## v2.1 (visual profissional)
- Sem emblema; título "LEGEND MOBILE" em duas cores, painel translúcido com borda discreta, cantos dos botões mais sóbrios, marca vermelha no cartão do servidor, rodapé com versão e entrada suave do painel.

## v2.0 (tema preto e vermelho)
- Nome do app: **Legend Mobile** (o pacote `com.meulauncher.air` e a keystore não mudaram, então instala por cima do app antigo).
- Imagem de fundo do menu em `assets/fundo.jpg` (1870x841). Para trocar, substitua o arquivo mantendo o nome. Menu numa coluna à esquerda, com sombra para o texto ficar legível.
- Tema preto com vermelho em toda a interface (tela inicial, engrenagem, diálogos e tela de login); botões ~10% menores.
- Login volta a ser só pelo site (a tentativa de login dentro do app foi removida).

## v1.9 (visual)
- Tela inicial redesenhada: fundo em degradê com brilhos suaves, emblema, cartão "SERVIDOR" (toque para trocar), botão JOGAR em destaque e ações secundárias (Sair da conta / Ver log) discretas. Tudo escala com o tamanho da tela.
- Botões com feedback ao toque (`src/Btn.as`); mensagens de erro ficam em vermelho claro.
- Engrenagem redonda com ícone desenhado em vetor (não depende de fonte/emoji).
- Diálogos nativos (menus, log, diagnóstico) em tema escuro com cantos arredondados.
- Tela de login: barra de progresso no topo, fundo escuro e botão "Diagnóstico" em pílula.
- Nenhuma lógica foi alterada (login, proxy, cache, mods, resolução continuam iguais).

## v3.2 (desempenho dentro do jogo)
- Cache negativo de imagens: quando um PNG falha, o app confirma se foi HTTP 404/410 e lembra por 12 h (arquivo `gamecache/neg.json`). Nas próximas vezes o `__cacheGet` devolve na hora um PNG transparente 1x1, sem esperar ~2 s por imagem (ícones `skillname/*.png` do PvP). Só vale para `.png` e só para 404/410; falha de rede não é lembrada. Liga/desliga em Configurações > Cache do jogo.
- O log de falhas agora mostra o código HTTP e o tempo (`FALHOU download (HTTP 404, 1800 ms ...)`), para separar 404 de timeout. A linha `CACHE:` mostra quantos pedidos foram respondidos na hora.
- Log gravado em arquivo (`launcher.log`; a sessão anterior fica em `launcher_prev.log`). "Mostrar log" mostra a sessão atual + a anterior, então dá para enviar o log depois de reabrir o app.
- Limpeza do cache (varredura da pasta inteira) roda no máximo 1x por dia, e não a cada abertura.
- Dentro do jogo, o temporizador da engrenagem passou de 400 ms para 1 s e só reposiciona a engrenagem quando o tamanho da tela muda.

## v3.1
- Log: linha "CACHE:" a cada 30 s (arquivos lidos do disco x baixados da rede). Gravação do cache sempre imediata e conferida.

## v3.0
- Cache: diagnóstico no log (cache MISS / EXPIRADO / falha ao gravar), gravação imediata de arquivos pequenos, validade dos arquivos sem identificador de versão de 3 para 7 dias. Engrenagem mais abaixo.

## v2.9
- SwfFixer: swf que não precisa de correção passa a ser lembrado (antes era descompactado e varrido a cada carregamento). O log passa a mostrar "cache lento" e "fix levou N ms" quando algo demora.

## v2.8
- Removidos: mods locais (pasta `mods`, troca de tiles/SWF, `ferramentas/`) e a troca de fonte do jogo. A troca de fonte varria todos os textos do jogo a cada 1,5 s, o que deixava o jogo lento (batalhas).

## v1.8
- Resolução refeita sem depender do Android: Modo PC usa StageScaleMode.SHOW_ALL com palco de 1250x650 (SWF compilado com -default-size). A SurfaceView não é mais mexida (o setFixedSize não alterava o palco do AIR).

## v1.7
- Modo PC é a resolução padrão (aplicada já na abertura do app e de novo ao voltar do login); as outras ficam no menu.

## v1.6
- Corrige a resolução / Modo PC: a SurfaceView não é mais redimensionada (isso deslocava e cortava o jogo e escondia a engrenagem). Agora só o buffer muda (setFixedSize) com a mesma proporção da tela.

## v1.5
- Resolução como no app original: Nativa ou "Modo PC" (1250x650, 1440x750, 1100x572) centralizado.
  Resoluções abaixo de ~600 de altura cortam as janelas do jogo, por isso não são oferecidas.
- Segundo plano: `executeInBackground` + serviço com WakeLock/WifiLock. Botão Voltar abre a janela
  "Sair do app" (segundo plano / fechar / cancelar).
- Só a engrenagem fica na tela (atalhos Mochila/Missão/Mapa e zoom removidos).
- `keystore.p12` NÃO pode mudar entre versões: é ela que permite instalar por cima do app antigo.
