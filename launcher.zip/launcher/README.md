# Legend Mobile (AIR + ANE Android, arm64)

Launcher que faz login no site oficial do servidor escolhido (WebView),
captura `user`/`key`, sobe um proxy local e carrega o `Loading.swf` do jogo.

## O que tem
- Seleção de plataforma (menu nativo) e botão JOGAR
- Menu de configurações (engrenagem): qualidade gráfica, FPS, controles na tela,
  cache do jogo (ver tamanho / apagar), mostrar log (com copiar), trocar plataforma,
  sair da conta, reiniciar e sair do app
- Atalhos na tela: Mochila (B), Missão (L), Mapa (M) e zoom + / −  (edite em `src/Controls.as`)
- Manter a sessão em segundo plano (serviço em primeiro plano)
- Cache em disco dos arquivos que o jogo baixa (`SwfFixer`, pasta `gamecache`)

Não implementado (o original fazia): resolução/superfície (`setSurfaceSize` é stub),
mapa do mundo em 2D e lista de e-mails salvos.

## Compilar pelo celular (GitHub Actions)
1. Crie um repositório e suba **todo** o conteúdo desta pasta (inclusive `.github/workflows/build.yml`).
2. Suba o zip do **AIR SDK 51** como *release* de um repositório seu (o nome do arquivo tanto faz).
   (O SDK 32 não serve: não gera APK de 64 bits.)
3. Aba **Actions → Build APK → Run workflow**. O campo já vem com `https://github.com/gafso/sdk/releases/tag/Sdk`;
   pode colar a página de outra release ou o link direto do arquivo. O workflow acha o SDK sozinho.
4. Ao terminar, baixe `MeuLauncher-apk` na própria execução e instale o `MeuLauncher.apk`.

Sem os secrets `KEYSTORE_B64` / `KEYSTORE_PASS` cada build usa uma chave nova; para
atualizar o app por cima sem desinstalar, crie uma keystore e salve-a nos secrets.

## Como o jogo é aberto (importante)
O `Loading.swf` do servidor **não é executado**: o launcher baixa só para medir o tamanho (versão) e abre a cópia
modificada de `assets/game/` (`Loading.swf` = Brasil, 244783 bytes; `Loading_<tamanho>.swf` = outras versões).
Essas cópias usam funções (`__lofix`, `loadByteZ`, `__cacheGet`...) que o `src/SwfFixer.as` instala no `Loader`.
Sem as cópias em `assets/game/` o jogo não abre. São arquivos do jogo: mantenha o repositório **privado**.

## Compilar num PC
    AIR_SDK=/caminho/AIRSDK ANDROID_JAR=/caminho/android.jar STOREPASS=senha ./build.sh

## Estado dos testes
- A classe `Bridge` fica dentro do ANE (`ane/as`): o AIR só entrega o ExtensionContext a código que veio da library.swf da extensão (senão dá Error #2113).
- Java do ANE e o APK final **não foram compilados aqui** (sem `android.jar` nem SDK 51 neste
  ambiente). Se o Actions apontar erro, mande-me o log.
- Pontos que dependem do jogo real: regex de captura do `Loading.swf` em `LoginActivity`,
  hosts de `Platforms.as` (loes/lotr/lortr/lorpt são suposição pelo padrão do lobr).

## v2.3 / v2.2 (resolução, 120 FPS, ícone e fonte)
- Resolução: opções **Full HD 1920x1080** e **2K 2560x1440** (experimentais). O AIR do Android não aceita que o app mude o tamanho da tela por fora (a tentativa por escala da SurfaceView só encolheu a imagem e escondeu a engrenagem; foi removida). Agora o app tenta mudar o tamanho do palco do AIR e CONFERE ("Palco: WxH" no log); se não aceitar, volta sozinho ao Modo PC e avisa.
- FPS: nova opção **120**. Além de `stage.frameRate`, o app pede à tela do aparelho o modo de atualização mais próximo (`BridgeContext.applyRefresh`). O menu de FPS mostra a taxa real da tela.
- Ícone do app: `assets/icons/` (36 a 144 px, registrados em `app.xml`). Fonte original 512 px em `assets/icons/icon512.png`.
- Fonte do jogo: Configurações > Fonte do jogo (também disponível no menu inicial, antes de entrar). Usa fontes do sistema Android; o PALCO inteiro (o jogo põe janelas direto nele) é varrido a cada 1,5 s trocando a fonte dos textos. Conferir em Mostrar log: "Fonte 'X': N textos vistos, M alterados, K bloqueados".
- Menu inicial ganhou o botão "Configurações".

## v2.1 (visual profissional)
- Sem emblema; título "LEGEND MOBILE" em duas cores, painel translúcido com borda discreta, cantos dos botões mais sóbrios, marca vermelha no cartão do servidor, rodapé com versão e entrada suave do painel.

## v2.0 (tema preto e vermelho)
- Nome do app: **Legend Mobile** (o pacote `com.meulauncher.air` e a keystore não mudaram, então instala por cima do app antigo).
- Imagem de fundo do menu em `assets/fundo.jpg` (1870x841). Para trocar, substitua o arquivo mantendo o nome. Menu numa coluna à esquerda, com sombra para o texto ficar legível.
- Tema preto com vermelho em toda a interface (tela inicial, engrenagem, diálogos e tela de login); botões ~10% menores.
- Login volta a ser só pelo site (a tentativa de login dentro do app foi removida).

## v1.9 (visual)
- Tela inicial redesenhada: fundo em degradê com brilhos suaves, emblema, cartão "SERVIDOR" (toque para trocar), botão JOGAR em destaque e ações secundárias (Sair da conta / Ver log) discretas. Tudo escala com o tamanho da tela.
- Botões com feedback ao toque (`src/Btn.as`); mensagens de erro ficam em vermelho claro.
- Engrenagem redonda com ícone desenhado em vetor (não depende de fonte/emoji).
- Diálogos nativos (menus, log, diagnóstico) em tema escuro com cantos arredondados.
- Tela de login: barra de progresso no topo, fundo escuro e botão "Diagnóstico" em pílula.
- Nenhuma lógica foi alterada (login, proxy, cache, mods, resolução continuam iguais).

## v1.8
- Resolução refeita sem depender do Android: Modo PC usa StageScaleMode.SHOW_ALL com palco de 1250x650 (SWF compilado com -default-size). A SurfaceView não é mais mexida (o setFixedSize não alterava o palco do AIR).

## v1.7
- Modo PC é a resolução padrão (aplicada já na abertura do app e de novo ao voltar do login); as outras ficam no menu.

## v1.6
- Corrige a resolução / Modo PC: a SurfaceView não é mais redimensionada (isso deslocava e cortava o jogo e escondia a engrenagem). Agora só o buffer muda (setFixedSize) com a mesma proporção da tela.

## v1.5
- Resolução como no app original: Nativa ou "Modo PC" (1250x650, 1440x750, 1100x572) centralizado.
  Resoluções abaixo de ~600 de altura cortam as janelas do jogo, por isso não são oferecidas.
- Segundo plano: `executeInBackground` + serviço com WakeLock/WifiLock. Botão Voltar abre a janela
  "Sair do app" (segundo plano / fechar / cancelar).
- Só a engrenagem fica na tela (atalhos Mochila/Missão/Mapa e zoom removidos).
- `keystore.p12` NÃO pode mudar entre versões: é ela que permite instalar por cima do app antigo.

## Mods locais (mapa / fundo)
O proxy local serve, no lugar do servidor, qualquer arquivo que esteja em
`Android/data/<pacote do app>/files/mods/` (só no seu aparelho; nada muda para os outros).
- Coloque o arquivo com o MESMO caminho do pedido (ex.: `mods/client/res/xxx/fundo.jpg`) ou só com o mesmo NOME (`mods/fundo.jpg`).
- Abra o jogo uma vez: o proxy anota em `mods/_pedidos.txt` todas as imagens/swf pedidas, para você descobrir o nome do mapa/fundo.
- Depois de colocar um mod: Configurações > Cache do jogo > Apagar cache, e reinicie o app.
- Para desativar, apague o arquivo da pasta `mods`.

### Atualização: mods pelo cache do jogo
O jogo só pede o `/client/Loading.swf` ao proxy; o resto passa por `__cacheGet` (SwfFixer). Agora o `SwfFixer.cacheGet`
também olha em `mods/` pelo NOME do arquivo da URL e anota todas as URLs em `mods/_pedidos.txt`.

### Mapa (tiles)
O mapa 10000 vem em `mapmaterial/land/10000/tile_X_Y_<hash>.jpg` (X 0..29, Y 0..19). O mod aceita `tile_X_Y.jpg` (sem hash).
`fatiar_mapa.py` gera esses arquivos a partir de uma imagem. NÃO substitua `*.maps` / `*.titles` (dados de colisão do mapa).

### Mapa estilizado (ferramentas/estilizar.py)
Estiliza o mapa inteiro de uma vez (clareza, curva em S, vibração, brilho suave, graduação de cor) e fatia de volta nos
tiles originais (mesmo tamanho). Workflow: `mapa_completo.yml` (precisa do `_pedidos.txt` na raiz do repositório).

### Mods por mapa (importante)
Tiles do mapa só são trocados a partir de `mods/<id do mapa>/tile_X_Y.jpg` (ex.: `mods/10000/tile_5_3.jpg`).
O log mostra "Mapa de tiles id=... (COM mod / sem mod)" na 1ª vez que cada mapa é aberto. Mapas/andares sem pasta ficam originais.
Arquivos soltos `tile_X_Y.jpg` na raiz de `mods/` deixaram de valer para tiles de mapa.

### Mods por mapa (atualização)
Tiles de mapa agora só valem dentro da pasta do mapa: `mods/10000/tile_X_Y.jpg`. Tiles soltos em `mods/` são ignorados
(isso evita trocar outro mapa, como o "2º Piso", que tem tiles com os mesmos nomes). Veja o id do mapa nas URLs do `_pedidos.txt`
(`.../mapmaterial/land/<id>/tile_X_Y_hash.jpg`).

### Diagnóstico de tiles (log)
O log mostra `TILE pedido SEM mod: <pasta>/<arquivo>` (tile pedido para o qual não há arquivo em mods),
`TILE veio do servidor` e `TILE salvo no cache`. Use para descobrir tiles que o jogo carrega de outro caminho/extensão.

## Mods de imagem SEM faltar tile (v2) — `ferramentas/mods.py` + workflow `mods.yml`
Por que faltava tile: o jogo só pede um tile quando você passa por perto, então `_pedidos.txt` só lista o que você já viu.
A ferramenta gera a GRADE INTEIRA (todos os X,Y) a partir da sua imagem do mapa e confere tudo no fim.
No app: o mod de tile vale por X,Y (ignora hash e extensão) e os tiles que ficaram sem mod são anotados em `mods/_faltando.txt`.

1. Jogue um pouco; suba `mods/_pedidos.txt` (e `_faltando.txt`, se existir) para a raiz do repositório.
2. Actions > **Gerar mods** > `analisar`: mostra mapas (grade) e as outras imagens (fundo, carregamento, castelo).
3. `baixar`: baixa os originais e monta `editar/mapa_<ID>_original.png` (mapa inteiro, para você editar).
4. Coloque em `personalizados/`:  `mapa_<ID>.png` (mapa inteiro, qualquer tamanho)  e/ou  `<nome da imagem>.png`
   (ex.: `loading_bg.png`; se o nome se repete, use `<pasta>__<nome>.png`).
5. `gerar`: cria `saida_mods/mods/...` com TODOS os tiles + imagens no formato/tamanho originais e confere (`verificacao.txt`).
6. Copie o conteúdo de `mods/` do artefato para `Android/data/<pacote>/files/mods/`, apague o cache do jogo e reinicie o app.
Se o mapa for maior que o detectado, informe a grade no campo do workflow (ex.: `10000=30x20`).
