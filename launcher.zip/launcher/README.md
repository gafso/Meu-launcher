# Meu Launcher (AIR + ANE Android, arm64)

Launcher que faz login no site oficial do servidor escolhido (WebView),
captura `user`/`key`, sobe um proxy local e carrega o `Loading.swf` do jogo.

## O que tem
- Seleção de plataforma (menu nativo) e botão JOGAR
- Menu de configurações (engrenagem): qualidade gráfica, FPS, controles na tela,
  cache do jogo (ver tamanho / apagar), mostrar log (com copiar), trocar plataforma,
  sair da conta, reiniciar e sair do app
- Atalhos na tela: Mochila (B), Missão (L), Mapa (M) e zoom + / −  (edite em `src/Controls.as`)
- Manter a sessão em segundo plano (serviço em primeiro plano)
- Cache em disco dos arquivos que o jogo baixa (`SwfFixer`, pasta `gamecache`)

Não implementado (o original fazia): resolução/superfície (`setSurfaceSize` é stub),
mapa do mundo em 2D e lista de e-mails salvos.

## Compilar pelo celular (GitHub Actions)
1. Crie um repositório e suba **todo** o conteúdo desta pasta (inclusive `.github/workflows/build.yml`).
2. Suba o zip do **AIR SDK 51** como *release* de um repositório seu (o nome do arquivo tanto faz).
   (O SDK 32 não serve: não gera APK de 64 bits.)
3. Aba **Actions → Build APK → Run workflow**. O campo já vem com `https://github.com/gafso/sdk/releases/tag/Sdk`;
   pode colar a página de outra release ou o link direto do arquivo. O workflow acha o SDK sozinho.
4. Ao terminar, baixe `MeuLauncher-apk` na própria execução e instale o `MeuLauncher.apk`.

Sem os secrets `KEYSTORE_B64` / `KEYSTORE_PASS` cada build usa uma chave nova; para
atualizar o app por cima sem desinstalar, crie uma keystore e salve-a nos secrets.

## Como o jogo é aberto (importante)
O `Loading.swf` do servidor **não é executado**: o launcher baixa só para medir o tamanho (versão) e abre a cópia
modificada de `assets/game/` (`Loading.swf` = Brasil, 244783 bytes; `Loading_<tamanho>.swf` = outras versões).
Essas cópias usam funções (`__lofix`, `loadByteZ`, `__cacheGet`...) que o `src/SwfFixer.as` instala no `Loader`.
Sem as cópias em `assets/game/` o jogo não abre. São arquivos do jogo: mantenha o repositório **privado**.

## Compilar num PC
    AIR_SDK=/caminho/AIRSDK ANDROID_JAR=/caminho/android.jar STOREPASS=senha ./build.sh

## Estado dos testes
- A classe `Bridge` fica dentro do ANE (`ane/as`): o AIR só entrega o ExtensionContext a código que veio da library.swf da extensão (senão dá Error #2113).
- Java do ANE e o APK final **não foram compilados aqui** (sem `android.jar` nem SDK 51 neste
  ambiente). Se o Actions apontar erro, mande-me o log.
- Pontos que dependem do jogo real: regex de captura do `Loading.swf` em `LoginActivity`,
  hosts de `Platforms.as` (loes/lotr/lortr/lorpt são suposição pelo padrão do lobr).

## v1.8
- Resolução refeita sem depender do Android: Modo PC usa StageScaleMode.SHOW_ALL com palco de 1250x650 (SWF compilado com -default-size). A SurfaceView não é mais mexida (o setFixedSize não alterava o palco do AIR).

## v1.7
- Modo PC é a resolução padrão (aplicada já na abertura do app e de novo ao voltar do login); as outras ficam no menu.

## v1.6
- Corrige a resolução / Modo PC: a SurfaceView não é mais redimensionada (isso deslocava e cortava o jogo e escondia a engrenagem). Agora só o buffer muda (setFixedSize) com a mesma proporção da tela.

## v1.5
- Resolução como no app original: Nativa ou "Modo PC" (1250x650, 1440x750, 1100x572) centralizado.
  Resoluções abaixo de ~600 de altura cortam as janelas do jogo, por isso não são oferecidas.
- Segundo plano: `executeInBackground` + serviço com WakeLock/WifiLock. Botão Voltar abre a janela
  "Sair do app" (segundo plano / fechar / cancelar).
- Só a engrenagem fica na tela (atalhos Mochila/Missão/Mapa e zoom removidos).
- `keystore.p12` NÃO pode mudar entre versões: é ela que permite instalar por cima do app antigo.
