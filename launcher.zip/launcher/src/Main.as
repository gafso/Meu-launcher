package
{
    import com.meulauncher.air.Bridge;
    import flash.desktop.NativeApplication;
    import flash.display.Loader;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.HTTPStatusEvent;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.events.TimerEvent;
    import flash.events.UncaughtErrorEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.net.URLLoader;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.system.ApplicationDomain;
    import flash.system.Capabilities;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.utils.ByteArray;
    import flash.utils.Timer;
    import flash.utils.setTimeout;

    public class Main extends Sprite
    {
        // Reservas empacotadas (você coloca os SEUS arquivos em assets/game/).
        private static const FALLBACKS:Array = [
            "assets/game/Loading.swf",
            "assets/game/Loading_270767.swf",
            "assets/game/Loading_245292.swf",
            "assets/game/Loading_243852.swf",
            "assets/game/Loading_234741.swf"
        ];
        private static const CACHE_TTL_MS:Number = 6 * 60 * 60 * 1000;   // 6 h

        // Modos do menu nativo (o evento "menu" é compartilhado).
        private static const M_PLATFORM:String = "platform";
        private static const M_SETTINGS:String = "settings";
        private static const M_QUALITY:String  = "quality";
        private static const M_FPS:String      = "fps";
        private static const M_CACHE:String    = "cache";
        private static const M_RES:String      = "res";
        // Alturas (px) oferecidas; 0 = nativa. A largura acompanha a proporção da tela.
        private static const RES_HEIGHTS:Array = [0, 1080, 900, 720, 600, 540, 480];

        private var bridge:Bridge;
        private var lastStatus:String = "";
        private var inGame:Boolean = false;
        private var platformIdx:int = 0;
        private var ui:Sprite = new Sprite();
        private var status:TextField;
        private var session:Object;
        private var port:int;
        private var fbIndex:int = 0;
        private var swfCandidates:Array = [];
        private var swfIdx:int = 0;
        private var okPath:String = "/client/Loading.swf";
        private static const BRAZIL_LEN:int = 244783;   // tamanho do Loading.swf do servidor do Brasil
        private var gameLoader:Loader;
        private var controls:Controls;
        private var menuMode:String = M_PLATFORM;
        private var logLines:Array = [];
        private var zoomLevel:Number = 1;
        private var topTimer:Timer;
        private var reqW:int = 0;
        private var reqH:int = 0;
        private var resTries:int = 0;
        private var resSerial:int = 0;

        public function Main()
        {
            try { init(); }
            catch (err:Error) { fatal(String(err.message) + stackOf(err)); }
        }

        private function init():void
        {
            if (loaderInfo && loaderInfo.uncaughtErrorEvents)
                loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR, onUncaught);
            stage.align = StageAlign.TOP_LEFT;
            stage.scaleMode = StageScaleMode.NO_SCALE;
            drawBg();
            bridge = new Bridge();
            SwfFixer.logger = log;
            SwfFixer.install();
            SwfFixer.pruneOld();
            platformIdx = Math.min(Prefs.platform, Platforms.LIST.length - 1);
            applyDisplayPrefs();
            addChild(ui);
            bridge.addEventListener("game", onGame);
            bridge.addEventListener("menu", onMenu);
            bridge.addEventListener("error", onError);
            log("Launcher iniciado. ANE: " + (bridge.available ? "ok" : "ausente (" + bridge.initError + ")"));
            stage.addEventListener(Event.RESIZE, onResize);
            showHome();
        }

        // Em alguns aparelhos o stage começa com tamanho 0; usa o tamanho real da tela nesse caso.
        private function sw():Number { return stage.stageWidth > 0 ? stage.stageWidth : stage.fullScreenWidth; }
        // Botões maiores em telas de muitos pixels (e menores se a resolução do jogo for reduzida).
        private function uiScale():Number { return Math.max(1, Math.min(2.5, sh() / 650)); }
        private function sh():Number { return stage.stageHeight > 0 ? stage.stageHeight : stage.fullScreenHeight; }

        private function drawBg():void
        {
            graphics.clear();
            graphics.beginFill(0x14181F);
            graphics.drawRect(0, 0, Math.max(sw(), 4096), Math.max(sh(), 4096));
            graphics.endFill();
        }

        private function onResize(e:Event):void
        {
            drawBg();
            if (!inGame) showHome();
            else if (controls) controls.layout(sw(), uiScale());
        }

        private function stackOf(err:Error):String
        {
            var st:String = err.getStackTrace();
            return st ? "\n" + st : "";
        }

        private function onUncaught(e:UncaughtErrorEvent):void
        {
            var m:String = (e.error is Error) ? (Error(e.error).message + stackOf(Error(e.error))) : String(e.error);
            log("ERRO: " + m);
            if (!inGame) { e.preventDefault(); fatal(m); }
        }

        // Mostra o erro na tela (fundo amarelo) em vez de ficar branco sem explicação.
        private function fatal(msg:String):void
        {
            try
            {
                var tf:TextField = new TextField();
                tf.defaultTextFormat = new TextFormat("_sans", 22, 0x000000);
                tf.background = true; tf.backgroundColor = 0xFFEE00;
                tf.multiline = true; tf.wordWrap = true;
                tf.x = 20; tf.y = 20;
                tf.width = Math.max(300, sw() - 40);
                tf.text = "ERRO NO LAUNCHER:\n" + msg;
                addChild(tf);
            }
            catch (e2:Error) {}
        }

        // ---------- log ----------
        public function log(s:String):void
        {
            var d:Date = new Date();
            logLines.push(pad(d.hours) + ":" + pad(d.minutes) + ":" + pad(d.seconds) + "  " + s);
            if (logLines.length > 200) logLines.shift();
        }
        private function pad(n:int):String { return n < 10 ? "0" + n : String(n); }

        // ---------- preferências de exibição ----------
        private function applyDisplayPrefs():void
        {
            stage.quality = Prefs.quality;     // StageQuality.LOW / MEDIUM / HIGH
            stage.frameRate = Prefs.fps;
        }

        // ---------- UI inicial ----------
        private function showHome():void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            stage.scaleMode = StageScaleMode.NO_SCALE;
            var cx:Number = sw() / 2;
            addLabel("Meu Launcher", cx, 80, 36);
            addButton("Plataforma: " + Platforms.LIST[platformIdx][0], cx, 200, chooseTapped);
            addButton("JOGAR", cx, 300, playTapped);
            addButton("Sair da conta", cx, 400, logoutTapped);
            addButton("Ver log", cx, 500, logTapped);
            status = addLabel(lastStatus != "" ? lastStatus : (bridge.available ? "" : "ANE indisponível: " + bridge.initError), cx, 600, 18);
            addLabel("v1.4", cx, 690, 14);
        }

        private function addLabel(t:String, x:Number, y:Number, size:int):TextField
        {
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", size, 0xFFFFFF, true, null, null, null, null, "center");
            tf.width = 600; tf.x = x - 300; tf.y = y; tf.text = t;
            tf.selectable = false; tf.autoSize = "center"; tf.x = x - tf.width / 2;
            ui.addChild(tf);
            return tf;
        }

        private function addButton(t:String, x:Number, y:Number, fn:Function):void
        {
            var b:Sprite = new Sprite();
            b.graphics.beginFill(0x2D6CDF); b.graphics.drawRoundRect(-220, 0, 440, 70, 16); b.graphics.endFill();
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 22, 0xFFFFFF, true, null, null, null, null, "center");
            tf.width = 440; tf.x = -220; tf.y = 18; tf.text = t; tf.mouseEnabled = false;
            b.addChild(tf); b.x = x; b.y = y; b.addEventListener(MouseEvent.CLICK, fn);
            ui.addChild(b);
        }

        private function setStatus(s:String):void { lastStatus = s; if (status) status.text = s; log(s); }

        // ---------- ações da tela inicial ----------
        private function chooseTapped(e:MouseEvent):void { openPlatformMenu(); }

        private function openPlatformMenu():void
        {
            var names:Array = [];
            for each (var p:Array in Platforms.LIST) names.push(p[0]);
            menuMode = M_PLATFORM;
            bridge.showMenu("Escolha a plataforma", names);
        }

        private function playTapped(e:MouseEvent):void
        {
            setStatus("Abrindo login...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        private function logoutTapped(e:MouseEvent):void { logout(); }

        private function logTapped(e:MouseEvent):void { bridge.showText("Log", logLines.join("\n")); }

        private function logout():void
        {
            bridge.clearSession();
            setStatus("Sessão apagada.");
        }

        private function onError(e:StatusEvent):void { setStatus("Erro: " + e.level); }

        // ---------- menu nativo (um evento só, roteado por menuMode) ----------
        private function onMenu(e:StatusEvent):void
        {
            var i:int = int(e.level);
            switch (menuMode)
            {
                case M_PLATFORM:
                    if (i >= 0 && i < Platforms.LIST.length)
                    {
                        platformIdx = i; Prefs.platform = i;
                        if (gameLoader) { bridge.restartApp(); } else { showHome(); }
                    }
                    break;
                case M_SETTINGS: onSettingsChoice(i); break;
                case M_QUALITY:
                    Prefs.quality = ["LOW", "MEDIUM", "HIGH"][i];
                    applyDisplayPrefs(); log("Qualidade: " + Prefs.quality);
                    break;
                case M_FPS:
                    Prefs.fps = [15, 24, 30, 60][i];
                    applyDisplayPrefs(); log("FPS: " + Prefs.fps);
                    break;
                case M_CACHE:
                    if (i == 0) clearCache();
                    break;
                case M_RES:
                    if (i >= 0 && i < RES_HEIGHTS.length)
                    {
                        Prefs.resHeight = RES_HEIGHTS[i];
                        if (inGame) applyResolution();
                    }
                    break;
            }
        }

        private function openSettings():void
        {
            menuMode = M_SETTINGS;
            bridge.showMenu("Configurações", [
                "Resolução (" + resLabel(Prefs.resHeight) + ")",
                "Qualidade gráfica (" + Prefs.quality + ")",
                "FPS (" + Prefs.fps + ")",
                "Controles na tela: " + (Prefs.controls ? "ligados" : "desligados"),
                "Cache do jogo",
                "Mostrar log",
                "Trocar plataforma",
                "Sair da conta",
                "Reiniciar o app",
                "Sair do app"
            ]);
        }

        private function onSettingsChoice(i:int):void
        {
            switch (i)
            {
                case 0: openResolutionMenu(); break;
                case 1: menuMode = M_QUALITY; bridge.showMenu("Qualidade gráfica", ["Baixa", "Média", "Alta"]); break;
                case 2: menuMode = M_FPS;     bridge.showMenu("FPS", ["15", "24", "30", "60"]); break;
                case 3:
                    Prefs.controls = !Prefs.controls;
                    if (controls) controls.visibleBar = Prefs.controls;
                    break;
                case 4:
                    menuMode = M_CACHE;
                    bridge.showMenu("Cache do jogo (" + cacheSizeText() + ")", ["Apagar cache", "Voltar"]);
                    break;
                case 5: bridge.showText("Log", logLines.join("\n")); break;
                case 6: openPlatformMenu(); break;
                case 7: logout(); break;
                case 8: bridge.restartApp(); break;
                case 9: bridge.keepAlive(false); NativeApplication.nativeApplication.exit(); break;
            }
        }

        // ---------- resolução ----------
        private function screenSize():Array
        {
            var w:int = int(Capabilities.screenResolutionX);
            var h:int = int(Capabilities.screenResolutionY);
            if (h > w) { var t:int = w; w = h; h = t; }
            return [w, h];
        }

        private function resLabel(h:int):String
        {
            var s:Array = screenSize();
            if (h <= 0 || h >= s[1]) return "Nativa " + s[0] + "x" + s[1];
            return Math.round(h * s[0] / s[1]) + "x" + h;
        }

        private function openResolutionMenu():void
        {
            var names:Array = [];
            for each (var h:int in RES_HEIGHTS)
                names.push(resLabel(h) + (h == Prefs.resHeight ? "  ✓" : "") + (h > 0 && h <= 540 ? "  (maior e mais leve)" : ""));
            menuMode = M_RES;
            bridge.showMenu("Resolução (menor = tudo maior na tela)", names);
        }

        private function applyResolution():void
        {
            var s:Array = screenSize();
            var h:int = Prefs.resHeight;
            if (h <= 0 || h >= s[1]) { reqW = 0; reqH = 0; }
            else { reqW = Math.round(h * s[0] / s[1]); reqH = h; }
            resTries = 0;
            resSerial++;
            log("Resolução: " + resLabel(h));
            sendSurface();
        }

        private function sendSurface():void
        {
            try { bridge.setSurfaceSize(reqW, reqH); }
            catch (err:Error) { log("Falha ao mudar a resolução: " + err.message); }
            checkSurface();
        }

        // Confere se o palco ficou do tamanho pedido; o Android às vezes demora ou ignora.
        private function checkSurface():void
        {
            var serial:int = resSerial;
            setTimeout(function():void
            {
                if (serial != resSerial || !inGame) return;
                var now:String = stage.stageWidth + "x" + stage.stageHeight;
                if (reqW <= 0) { log("Palco: " + now); return; }
                var exp:String = reqW + "x" + reqH;
                if (now == exp) { log("Palco: " + now); return; }
                if (resTries < 3)
                {
                    resTries++;
                    log("Palco " + now + " (esperado " + exp + "), tentando de novo...");
                    sendSurface();
                }
                else
                {
                    log("Palco " + now + " (esperado " + exp + "); desisti.");
                    bridge.showText("Resolução", "O Android não trocou a resolução agora. A sua escolha foi salva: feche o app e abra de novo (Configurações > Sair do app) que ela é aplicada ao entrar no jogo.");
                }
            }, 1500);
        }

        // Os botões e a engrenagem ficam no palco (stage), por cima de tudo, e são trazidos
        // para a frente de tempos em tempos: o jogo adiciona janelas no palco e as cobria.
        private function keepOnTop(e:TimerEvent):void
        {
            if (!controls || !stage) return;
            try
            {
                if (controls.parent != stage) stage.addChild(controls);
                else if (stage.getChildIndex(controls) != stage.numChildren - 1) stage.setChildIndex(controls, stage.numChildren - 1);
                controls.layout(sw(), uiScale());
            }
            catch (err:Error) {}
        }

        // ---------- zoom ----------
        private function zoomBy(delta:Number):void
        {
            zoomLevel = Math.max(0.5, Math.min(2, zoomLevel + delta));
            Prefs.zoom = zoomLevel;
            applyZoom();
        }
        private function applyZoom():void
        {
            if (!gameLoader) return;
            gameLoader.scaleX = gameLoader.scaleY = zoomLevel;
        }

        // ---------- cache do Loading.swf (TTL em disco) ----------
        private function cacheDir():File
        {
            var d:File = File.applicationStorageDirectory.resolvePath("cache");
            if (!d.exists) d.createDirectory();
            return d;
        }
        private function cacheFile():File { return cacheDir().resolvePath("Loading.swf"); }

        private function cacheSizeText():String
        {
            var n:Number = SwfFixer.cacheSize();
            if (n <= 0) return "vazio";
            return Math.round(n / 1024) + " KB";
        }
        private function clearCache():void
        {
            SwfFixer.clearCache();
            log("Cache apagado.");
        }
        private function saveCache(b:ByteArray):void
        {
            try {
                var fs:FileStream = new FileStream();
                fs.open(cacheFile(), FileMode.WRITE);
                fs.writeBytes(b); fs.close();
            } catch (err:Error) { log("Falha ao salvar cache: " + err.message); }
        }
        private function readCacheIfFresh():ByteArray
        {
            var f:File = cacheFile();
            if (!f.exists) return null;
            if (new Date().time - f.modificationDate.time > CACHE_TTL_MS) return null;
            return readFile(f);
        }

        private function readFile(f:File):ByteArray
        {
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.READ);
            var ba:ByteArray = new ByteArray();
            fs.readBytes(ba); fs.close();
            return ba;
        }

        // ---------- sessão recebida do ANE ----------
        private function onGame(e:StatusEvent):void
        {
            try { session = JSON.parse(e.level); }
            catch (err:Error) { setStatus("Resposta de login inválida."); return; }

            port = bridge.startServer(session.host);
            if (port <= 0) { setStatus("Falha ao iniciar servidor local."); return; }
            bridge.keepAlive(true);
            setStatus("Baixando o jogo...");
            fbIndex = 0;
            fetchSwf();
        }

        // 1) servidor (via proxy local, tentando vários caminhos)  2) cache  3) reservas empacotadas
        private function fetchSwf():void
        {
            swfCandidates = [];
            if (session.swf) swfCandidates.push(String(session.swf));
            swfCandidates.push("/client/Loading.swf");
            swfCandidates.push("/Loading.swf");
            swfIdx = 0;
            log("Sessão: host=" + session.host + " swf=" + (session.swf ? session.swf : "(nenhum)") + " porta=" + port);
            tryServer();
        }

        private function isSwf(b:ByteArray):Boolean
        {
            if (b.length < 3) return false;
            var h:String = String.fromCharCode(b[0], b[1], b[2]);
            return h == "FWS" || h == "CWS" || h == "ZWS";
        }

        private function tryServer():void
        {
            if (swfIdx >= swfCandidates.length)
            {
                log("Servidor não respondeu; usando a cópia do app.");
                launchWith(0);
                return;
            }
            var path:String = String(swfCandidates[swfIdx++]);
            log("Tentando https://" + session.host + path);
            var code:int = 0;
            var l:URLLoader = new URLLoader();
            l.dataFormat = URLLoaderDataFormat.BINARY;
            l.addEventListener(HTTPStatusEvent.HTTP_STATUS, function(ev:HTTPStatusEvent):void { code = ev.status; });
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var b:ByteArray = ByteArray(l.data);
                log("Recebido " + b.length + " bytes (HTTP " + code + ")");
                if (!isSwf(b)) { log("A resposta não é um SWF."); tryServer(); return; }
                okPath = path;
                launchWith(b.length);
            });
            l.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                log("Falhou (HTTP " + code + "): " + ev.text);
                tryServer();
            });
            l.load(new URLRequest("http://127.0.0.1:" + port + path));
        }

        // O Loading.swf do servidor NÃO é executado: serve só para saber a versão (pelo tamanho).
        // Quem roda é a cópia modificada que vem no app (assets/game), a mesma versão do servidor.
        private function launchWith(serverLen:int):void
        {
            var name:String = "assets/game/Loading.swf";
            if (serverLen > 0 && serverLen != BRAZIL_LEN)
            {
                var alt:String = "assets/game/Loading_" + serverLen + ".swf";
                if (File.applicationDirectory.resolvePath(alt).exists)
                {
                    name = alt;
                    log("Versão deste servidor: " + serverLen + " bytes (cópia própria no app)");
                }
                else
                {
                    log("AVISO: a versão do Loading.swf deste servidor (" + serverLen + " bytes) não está no app. Usando a do Brasil.");
                }
            }
            else if (serverLen == BRAZIL_LEN)
            {
                log("Versão deste servidor: a mesma do Brasil");
            }
            var f:File = File.applicationDirectory.resolvePath(name);
            if (!f.exists)
            {
                setStatus("Faltam os arquivos do jogo no app (" + name + "). Toque em Ver log.");
                return;
            }
            setStatus("Carregando o jogo...");
            startGame(readFile(f));
        }

        private function startGame(bytes:ByteArray):void
        {
            inGame = true;
            while (ui.numChildren) ui.removeChildAt(0);
            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;
            var p:String = okPath;
            var qi:int = p.indexOf("?");
            if (qi >= 0) p = p.substring(0, qi);
            var dir:String = "https://" + session.host + p.substring(0, p.lastIndexOf("/") + 1);
            var params:Object = {};
            for each (var pn:String in ["user", "key", "site", "p2", "rid", "logintype"])
            {
                if (session.params && session.params[pn] != undefined) params[pn] = String(session.params[pn]);
            }
            params["http"] = "https:";
            params["config"] = dir + "config.xml";
            params["base"] = dir;
            log("Jogo: " + bytes.length + " bytes | config " + params["config"]);
            stage.scaleMode = StageScaleMode.NO_SCALE;
            ctx.parameters = params;
            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                SwfFixer.gameDomain = gameLoader.contentLoaderInfo.applicationDomain;
                applyResolution();
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, function(ev:Event):void {
                zoomLevel = Prefs.zoom;
                addChild(gameLoader);
                applyZoom();
                controls = new Controls(openSettings, zoomBy);
                controls.visibleBar = Prefs.controls;
                controls.layout(sw(), uiScale());
                stage.addChild(controls);
                if (topTimer) topTimer.stop();
                topTimer = new Timer(400);
                topTimer.addEventListener(TimerEvent.TIMER, keepOnTop);
                topTimer.start();
                log("Jogo carregado.");
            });
            gameLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                inGame = false; gameLoader = null; showHome(); setStatus("Falha ao carregar o jogo.");
            });
            gameLoader.loadBytes(bytes, ctx);
        }
    }
}
