package
{
    import com.meulauncher.air.Bridge;
    import flash.desktop.NativeApplication;
    import flash.desktop.SystemIdleMode;
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Loader;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.HTTPStatusEvent;
    import flash.events.IOErrorEvent;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.events.TimerEvent;
    import flash.events.UncaughtErrorEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.filters.DropShadowFilter;
    import flash.geom.Matrix;
    import flash.net.URLLoader;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.system.ApplicationDomain;
    import flash.system.Capabilities;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.ui.Keyboard;
    import flash.utils.ByteArray;
    import flash.utils.Timer;
    import flash.utils.setTimeout;

    [SWF(width="1250", height="650", frameRate="30", backgroundColor="#14181F")]
    public class Main extends Sprite
    {
        // Reservas empacotadas (você coloca os SEUS arquivos em assets/game/).
        private static const FALLBACKS:Array = [
            "assets/game/Loading.swf",
            "assets/game/Loading_270767.swf",
            "assets/game/Loading_245292.swf",
            "assets/game/Loading_243852.swf",
            "assets/game/Loading_234741.swf"
        ];
        private static const CACHE_TTL_MS:Number = 6 * 60 * 60 * 1000;   // 6 h
        private static const BG_TOP:uint = 0x0F131A;      // fundo: topo do degradê
        private static const BG_BOTTOM:uint = 0x182131;   // fundo: base do degradê
        private static const VERSION:String = "v1.9";

        // Modos do menu nativo (o evento "menu" é compartilhado).
        private static const M_PLATFORM:String = "platform";
        private static const M_SETTINGS:String = "settings";
        private static const M_QUALITY:String  = "quality";
        private static const M_FPS:String      = "fps";
        private static const M_CACHE:String    = "cache";
        private static const M_RES:String      = "res";
        private static const M_EXIT:String     = "exit";
        // Resolução do jogo. 0 = nativa da tela; 100000+n = tamanho fixo "Modo PC" (RES_FIXED[n]),
        // centralizado com barras pretas se a proporção da tela for diferente.
        // O jogo foi feito para ~1250x650: abaixo disso as janelas dele ficam cortadas.
        private static const RES_BASE:int = 100000;
        private static const RES_OPTIONS:Array = [100000, 0];
        private static const RES_FIXED:Array = [[1250, 650]];

        private var bridge:Bridge;
        private var lastStatus:String = "";
        private var inGame:Boolean = false;
        private var platformIdx:int = 0;
        private var ui:Sprite = new Sprite();
        private var status:TextField;
        private var session:Object;
        private var port:int;
        private var fbIndex:int = 0;
        private var swfCandidates:Array = [];
        private var swfIdx:int = 0;
        private var okPath:String = "/client/Loading.swf";
        private static const BRAZIL_LEN:int = 244783;   // tamanho do Loading.swf do servidor do Brasil
        private var gameLoader:Loader;
        private var controls:Controls;
        private var menuMode:String = M_PLATFORM;
        private var logLines:Array = [];
        private var zoomLevel:Number = 1;
        private var topTimer:Timer;
        private var curUser:String = "";
        private var curPass:String = "";
        private var lastW:Number = -1;
        private var lastH:Number = -1;

        public function Main()
        {
            try { init(); }
            catch (err:Error) { fatal(String(err.message) + stackOf(err)); }
        }

        private function init():void
        {
            if (loaderInfo && loaderInfo.uncaughtErrorEvents)
                loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR, onUncaught);
            applyResolution();
            drawBg();
            bridge = new Bridge();
            SwfFixer.logger = log;
            SwfFixer.install();
            try { SwfFixer.modsPath = bridge.modsPath(); } catch (eMods:Error) {}
            try
            {
                var mdir:File = new File(SwfFixer.modsPath);
                var mn:int = 0;
                var sub:String = "";
                if (SwfFixer.modsPath != "" && mdir.exists)
                    for each (var mf0:File in mdir.getDirectoryListing())
                    {
                        if (mf0.isDirectory)
                            sub += " | " + mf0.name + "/: " + mf0.getDirectoryListing().length + " arquivo(s)";
                        else if (mf0.name.indexOf("_pedidos") != 0) mn++;
                    }
                log("Mods: pasta=" + (SwfFixer.modsPath != "" ? SwfFixer.modsPath : "(indisponível)") + " | raiz: " + mn + " arquivo(s)" + sub);
            }
            catch (eMods2:Error) { log("Mods: erro ao ler a pasta (" + eMods2.message + ")"); }
            SwfFixer.pruneOld();
            // Sem isto o AIR congela o jogo quando você sai do app (jogo desconecta).
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE; } catch (eIdle:Error) {}
            try { NativeApplication.nativeApplication["executeInBackground"] = true; } catch (eBg:Error) { log("segundo plano: " + eBg.message); }
            stage.addEventListener(KeyboardEvent.KEY_DOWN, onKey, false, 100);
            platformIdx = Math.min(Prefs.platform, Platforms.LIST.length - 1);
            loadSaved();
            applyDisplayPrefs();
            addChild(ui);
            bridge.addEventListener("game", onGame);
            bridge.addEventListener("menu", onMenu);
            bridge.addEventListener("error", onError);
            log("Launcher iniciado. ANE: " + (bridge.available ? "ok" : "ausente (" + bridge.initError + ")"));
            stage.addEventListener(Event.RESIZE, onResize);
            showHome();
        }

        // Em alguns aparelhos o stage começa com tamanho 0; usa o tamanho real da tela nesse caso.
        private function sw():Number { return stage.stageWidth > 0 ? stage.stageWidth : stage.fullScreenWidth; }
        // Botões maiores em telas de muitos pixels (e menores se a resolução do jogo for reduzida).
        private function uiScale():Number { return Math.max(1, Math.min(2.5, sh() / 650)); }
        private function sh():Number { return stage.stageHeight > 0 ? stage.stageHeight : stage.fullScreenHeight; }

        // Fundo em degradê com dois brilhos suaves. Fora do palco (barras do Modo PC) as cores
        // continuam iguais às pontas do degradê, então não aparece emenda.
        private function drawBg():void
        {
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            var g:Graphics = graphics;
            g.clear();
            g.beginFill(BG_TOP);    g.drawRect(-4096, -4096, w + 8192, 4096); g.endFill();
            g.beginFill(BG_BOTTOM); g.drawRect(-4096, h, w + 8192, 4096);     g.endFill();
            var m:Matrix = new Matrix();
            m.createGradientBox(w + 8192, h, Math.PI / 2, -4096, 0);
            g.beginGradientFill(GradientType.LINEAR, [BG_TOP, BG_BOTTOM], [1, 1], [0, 255], m);
            g.drawRect(-4096, 0, w + 8192, h); g.endFill();
            // brilho azul atrás do conteúdo
            m = new Matrix();
            m.createGradientBox(w * 1.1, h * 1.3, 0, w / 2 - w * 0.55, h * 0.38 - h * 0.65);
            g.beginGradientFill(GradientType.RADIAL, [0x2D6CDF, 0x2D6CDF], [0.24, 0], [0, 255], m);
            g.drawRect(0, 0, w, h); g.endFill();
            // brilho violeta no canto inferior direito
            m = new Matrix();
            m.createGradientBox(w * 0.8, h * 1.0, 0, w * 0.6, h * 0.5);
            g.beginGradientFill(GradientType.RADIAL, [0x7A4DFF, 0x7A4DFF], [0.13, 0], [0, 255], m);
            g.drawRect(0, 0, w, h); g.endFill();
        }

        private function onResize(e:Event):void
        {
            if (sw() == lastW && sh() == lastH) return;
            lastW = sw(); lastH = sh();
            drawBg();
            if (!inGame) showHome();
            else if (controls) controls.layout(sw(), uiScale());
        }

        private function stackOf(err:Error):String
        {
            var st:String = err.getStackTrace();
            return st ? "\n" + st : "";
        }

        private function onUncaught(e:UncaughtErrorEvent):void
        {
            var m:String = (e.error is Error) ? (Error(e.error).message + stackOf(Error(e.error))) : String(e.error);
            log("ERRO: " + m);
            if (!inGame) { e.preventDefault(); fatal(m); }
        }

        // Mostra o erro na tela (fundo amarelo) em vez de ficar branco sem explicação.
        private function fatal(msg:String):void
        {
            try
            {
                var tf:TextField = new TextField();
                tf.defaultTextFormat = new TextFormat("_sans", 22, 0x000000);
                tf.background = true; tf.backgroundColor = 0xFFEE00;
                tf.multiline = true; tf.wordWrap = true;
                tf.x = 20; tf.y = 20;
                tf.width = Math.max(300, sw() - 40);
                tf.text = "ERRO NO LAUNCHER:\n" + msg;
                addChild(tf);
            }
            catch (e2:Error) {}
        }

        // ---------- log ----------
        public function log(s:String):void
        {
            var d:Date = new Date();
            logLines.push(pad(d.hours) + ":" + pad(d.minutes) + ":" + pad(d.seconds) + "  " + s);
            if (logLines.length > 200) logLines.shift();
        }
        private function pad(n:int):String { return n < 10 ? "0" + n : String(n); }

        // ---------- preferências de exibição ----------
        private function applyDisplayPrefs():void
        {
            stage.quality = Prefs.quality;     // StageQuality.LOW / MEDIUM / HIGH
            stage.frameRate = Prefs.fps;
        }

        // ---------- UI inicial ----------
        // Layout desenhado numa área de ~900x620 e escalado para caber em qualquer tela.
        private function showHome():void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            var s:Number = Math.max(0.55, Math.min(sw() / 900, sh() / 620, 2.5));
            var box:Sprite = new Sprite();
            box.scaleX = box.scaleY = s;
            box.x = sw() / 2; box.y = sh() / 2;
            ui.addChild(box);

            // emblema (quadrado arredondado com "portal")
            var em:Sprite = new Sprite();
            var m:Matrix = new Matrix();
            m.createGradientBox(72, 72, Math.PI / 4, -36, -36);
            em.graphics.beginGradientFill(GradientType.LINEAR, [0x6BA2FF, 0x2559C9], [1, 1], [0, 255], m);
            em.graphics.drawRoundRect(-36, -36, 72, 72, 26, 26);
            em.graphics.endFill();
            em.graphics.lineStyle(5, 0xFFFFFF, 0.95);
            em.graphics.drawCircle(0, 0, 17);
            em.graphics.lineStyle(0, 0, 0);
            em.graphics.beginFill(0xFFFFFF, 1);
            em.graphics.drawCircle(0, 0, 6);
            em.graphics.endFill();
            em.filters = [new DropShadowFilter(0, 90, 0x4C8DFF, 0.5, 24, 24, 1, 3)];
            em.y = -262;
            box.addChild(em);

            homeText(box, "Meu Launcher", 34, 0xFFFFFF, -216, 1);
            homeText(box, "Escolha o servidor e entre no jogo", 15, Btn.TEXT_MUTED, -170, 0);

            var card:Btn = new Btn(Btn.CARD, 440, 60, String(Platforms.LIST[platformIdx][0]), "SERVIDOR", chooseTapped);
            card.y = -104;
            box.addChild(card);

            var fUser:Field = new Field(440, 52, "Usuário ou e-mail");
            fUser.text = curUser;
            fUser.onChange = function():void { curUser = fUser.text; };
            fUser.y = -38;
            box.addChild(fUser);

            var fPass:Field = new Field(440, 52, "Senha", true);
            fPass.text = curPass;
            fPass.onChange = function():void { curPass = fPass.text; };
            fPass.onEnter = function():void { playTapped(null); };
            fPass.y = 24;
            box.addChild(fPass);

            var rem:Toggle = new Toggle("Lembrar usuário e senha", Prefs.remember);
            rem.onToggle = function(c:Boolean):void { Prefs.remember = c; };
            rem.y = 76;
            box.addChild(rem);

            var play:Btn = new Btn(Btn.PRIMARY, 440, 72, "JOGAR", "", playTapped);
            play.y = 134;
            box.addChild(play);

            var out:Btn = new Btn(Btn.GHOST, 212, 46, "Sair da conta", "", logoutTapped);
            out.x = -114; out.y = 204;
            box.addChild(out);
            var lg:Btn = new Btn(Btn.GHOST, 212, 46, "Ver log", "", logTapped);
            lg.x = 114; lg.y = 204;
            box.addChild(lg);

            status = new TextField();
            status.defaultTextFormat = new TextFormat("_sans", 15, 0x9FB3D1, true, null, null, null, null, "center");
            status.width = 560; status.height = 48; status.x = -280; status.y = 238;
            status.multiline = true; status.wordWrap = true;
            status.selectable = false; status.mouseEnabled = false;
            status.text = lastStatus != "" ? lastStatus : (bridge.available ? "" : "ANE indisponível: " + bridge.initError);
            paintStatus();
            box.addChild(status);

            homeText(box, VERSION, 12, 0x4F5B70, 292, 1);
        }

        // Carrega usuário/senha salvos (criptografados) do servidor escolhido.
        private function loadSaved():void
        {
            curUser = ""; curPass = "";
            try
            {
                var raw:String = bridge.loadCreds(String(Platforms.LIST[platformIdx][1]));
                if (raw != "")
                {
                    var o:Object = JSON.parse(raw);
                    curUser = String(o.user); curPass = String(o.pass);
                }
            }
            catch (err:Error) {}
        }

        private function homeText(box:Sprite, t:String, size:int, color:uint, y:Number, spacing:Number):TextField
        {
            var tf:TextField = new TextField();
            var f:TextFormat = new TextFormat("_sans", size, color, true, null, null, null, null, "center");
            f.letterSpacing = spacing;
            tf.defaultTextFormat = f;
            tf.autoSize = "left";
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            tf.x = -tf.width / 2; tf.y = y;
            box.addChild(tf);
            return tf;
        }

        // Mensagens de erro ficam em vermelho claro; o resto em azul acinzentado.
        private function paintStatus():void
        {
            if (!status) return;
            status.textColor = /erro|falha|faltam|indispon/i.test(status.text) ? 0xFF8A8A : 0x9FB3D1;
        }

        private function setStatus(s:String):void { lastStatus = s; if (status) { status.text = s; paintStatus(); } log(s); }

        // ---------- ações da tela inicial ----------
        private function chooseTapped(e:MouseEvent):void { openPlatformMenu(); }

        private function openPlatformMenu():void
        {
            var names:Array = [];
            for each (var p:Array in Platforms.LIST) names.push(p[0]);
            menuMode = M_PLATFORM;
            bridge.showMenu("Escolha a plataforma", names);
        }

        private function playTapped(e:MouseEvent):void
        {
            var host:String = String(Platforms.LIST[platformIdx][1]);
            var u:String = curUser.replace(/^\s+|\s+$/g, "");
            if (u != "" && curPass != "")
            {
                setStatus("Entrando...");
                bridge.login(host, u, curPass);
            }
            else
            {
                // campos vazios: abre o site para você entrar manualmente (como antes)
                setStatus("Abrindo login...");
                bridge.login(host);
            }
        }

        private function logoutTapped(e:MouseEvent):void { logout(); }

        private function logTapped(e:MouseEvent):void { bridge.showText("Log", logLines.join("\n")); }

        private function logout():void
        {
            bridge.clearSession();
            bridge.forgetCreds(String(Platforms.LIST[platformIdx][1]));
            curUser = ""; curPass = "";
            if (!inGame) showHome();
            setStatus("Sessão e senha salva apagadas.");
        }

        private function onError(e:StatusEvent):void { setStatus("Erro: " + e.level); }

        // ---------- menu nativo (um evento só, roteado por menuMode) ----------
        private function onMenu(e:StatusEvent):void
        {
            var i:int = int(e.level);
            switch (menuMode)
            {
                case M_PLATFORM:
                    if (i >= 0 && i < Platforms.LIST.length)
                    {
                        platformIdx = i; Prefs.platform = i;
                        loadSaved();
                        if (gameLoader) { bridge.restartApp(); } else { showHome(); }
                    }
                    break;
                case M_SETTINGS: onSettingsChoice(i); break;
                case M_QUALITY:
                    Prefs.quality = ["LOW", "MEDIUM", "HIGH"][i];
                    applyDisplayPrefs(); log("Qualidade: " + Prefs.quality);
                    break;
                case M_FPS:
                    Prefs.fps = [15, 24, 30, 60][i];
                    applyDisplayPrefs(); log("FPS: " + Prefs.fps);
                    break;
                case M_CACHE:
                    if (i == 0) clearCache();
                    break;
                case M_RES:
                    if (i >= 0 && i < RES_OPTIONS.length)
                    {
                        Prefs.resHeight = RES_OPTIONS[i];
                        applyResolution();
                        if (inGame) bridge.showText("Resolução", "Para o jogo se reorganizar por completo, reinicie o app (Configurações > Reiniciar o app).");
                    }
                    break;
                case M_EXIT:
                    if (i == 0) { log("Indo para segundo plano"); bridge.toBackground(); }
                    else if (i == 1) { bridge.keepAlive(false); NativeApplication.nativeApplication.exit(); }
                    break;
            }
        }

        private function openSettings():void
        {
            menuMode = M_SETTINGS;
            bridge.showMenu("Configurações", [
                "Resolução (" + resLabel(Prefs.resHeight) + ")",
                "Qualidade gráfica (" + Prefs.quality + ")",
                "FPS (" + Prefs.fps + ")",
                "Cache do jogo",
                "Mostrar log",
                "Trocar plataforma",
                "Sair da conta",
                "Reiniciar o app",
                "Sair do app"
            ]);
        }

        private function onSettingsChoice(i:int):void
        {
            switch (i)
            {
                case 0: openResolutionMenu(); break;
                case 1: menuMode = M_QUALITY; bridge.showMenu("Qualidade gráfica", ["Baixa", "Média", "Alta"]); break;
                case 2: menuMode = M_FPS;     bridge.showMenu("FPS", ["15", "24", "30", "60"]); break;
                case 3:
                    menuMode = M_CACHE;
                    bridge.showMenu("Cache do jogo (" + cacheSizeText() + ")", ["Apagar cache", "Voltar"]);
                    break;
                case 4: bridge.showText("Log", logLines.join("\n")); break;
                case 5: openPlatformMenu(); break;
                case 6: logout(); break;
                case 7: bridge.restartApp(); break;
                case 8: askExit(); break;
            }
        }

        // ---------- resolução ----------
        // A troca de resolução NÃO usa mais o Android (setFixedSize não muda o tamanho do palco do AIR).
        // Modo PC = StageScaleMode.SHOW_ALL: o palco passa a ter o tamanho do SWF (1250x650, definido em
        // [SWF(...)] / -default-size) e o AIR amplia tudo para a tela mantendo a proporção (barras pretas
        // nos lados se a tela for mais larga). O jogo vê um palco de 1250x650 e se organiza para ele.
        private function screenSize():Array
        {
            var w:int = stage.fullScreenWidth > 0 ? stage.fullScreenWidth : int(Capabilities.screenResolutionX);
            var h:int = stage.fullScreenHeight > 0 ? stage.fullScreenHeight : int(Capabilities.screenResolutionY);
            if (h > w) { var t:int = w; w = h; h = t; }
            return [w, h];
        }

        // Valor salvo que não existe mais na lista (de versões antigas) volta para o Modo PC.
        private function validRes():int
        {
            var v:int = Prefs.resHeight;
            if (RES_OPTIONS.indexOf(v) < 0) { v = RES_BASE; Prefs.resHeight = RES_BASE; }
            return v;
        }

        private function isPcMode():Boolean { return validRes() >= RES_BASE; }

        private function resLabel(v:int):String
        {
            var s:Array = screenSize();
            if (v >= RES_BASE && v - RES_BASE < RES_FIXED.length)
                return "Modo PC " + RES_FIXED[v - RES_BASE][0] + "x" + RES_FIXED[v - RES_BASE][1];
            return "Nativa " + s[0] + "x" + s[1];
        }

        private function openResolutionMenu():void
        {
            var cur:int = validRes();
            var names:Array = [];
            for each (var v:int in RES_OPTIONS)
            {
                var n:String = resLabel(v);
                if (v == RES_BASE) n += " (padrão)";
                if (v == cur) n += "  ✓";
                names.push(n);
            }
            menuMode = M_RES;
            bridge.showMenu("Resolução (Modo PC deixa tudo maior)", names);
        }

        private function wantedScaleMode():String
        {
            return isPcMode() ? StageScaleMode.SHOW_ALL : StageScaleMode.NO_SCALE;
        }

        private function applyResolution():void
        {
            var want:String = wantedScaleMode();
            if (stage.scaleMode != want) stage.scaleMode = want;
            stage.align = StageAlign.TOP_LEFT;
            log("Resolução: " + resLabel(validRes()));
            setTimeout(logStage, 300);
            if (inGame) for each (var d:int in [50, 400, 1200]) setTimeout(notifyResize, d);
        }

        private function logStage():void
        {
            var sc:Array = screenSize();
            log("Palco: " + stage.stageWidth + "x" + stage.stageHeight + " | tela " + sc[0] + "x" + sc[1] + " | escala " + stage.scaleMode);
        }

        // O jogo avisa que o palco mudou de tamanho (útil ao trocar de modo com o jogo aberto).
        private function notifyResize():void
        {
            if (!inGame || !stage) return;
            try { stage.dispatchEvent(new Event(Event.RESIZE)); } catch (err:Error) { log("aviso de resize: " + err.message); }
            if (controls) controls.layout(sw(), uiScale());
        }

        // O botão da engrenagem fica no palco (stage), por cima de tudo, e é trazido para a
        // frente de tempos em tempos: o jogo adiciona janelas no palco e o cobria.
        private function keepOnTop(e:TimerEvent):void
        {
            if (!controls || !stage) return;
            try
            {
                if (stage.scaleMode != wantedScaleMode()) { log("Escala foi alterada para " + stage.scaleMode + "; restaurando."); applyResolution(); }
                if (controls.parent != stage) stage.addChild(controls);
                else if (stage.getChildIndex(controls) != stage.numChildren - 1) stage.setChildIndex(controls, stage.numChildren - 1);
                controls.layout(sw(), uiScale());
            }
            catch (err:Error) {}
        }

        // ---------- sair do app / segundo plano ----------
        private function onKey(e:KeyboardEvent):void
        {
            if (e.keyCode != Keyboard.BACK) return;
            e.preventDefault();
            e.stopImmediatePropagation();
            askExit();
        }

        private function askExit():void
        {
            menuMode = M_EXIT;
            bridge.showMenu("Sair do app", ["Deixar o jogo aberto em segundo plano", "Fechar o app de vez", "Cancelar"]);
        }

        // ---------- zoom ----------
        private function zoomBy(delta:Number):void
        {
            zoomLevel = Math.max(0.5, Math.min(2, zoomLevel + delta));
            Prefs.zoom = zoomLevel;
            applyZoom();
        }
        private function applyZoom():void
        {
            if (!gameLoader) return;
            gameLoader.scaleX = gameLoader.scaleY = zoomLevel;
        }

        // ---------- cache do Loading.swf (TTL em disco) ----------
        private function cacheDir():File
        {
            var d:File = File.applicationStorageDirectory.resolvePath("cache");
            if (!d.exists) d.createDirectory();
            return d;
        }
        private function cacheFile():File { return cacheDir().resolvePath("Loading.swf"); }

        private function cacheSizeText():String
        {
            var n:Number = SwfFixer.cacheSize();
            if (n <= 0) return "vazio";
            return Math.round(n / 1024) + " KB";
        }
        private function clearCache():void
        {
            SwfFixer.clearCache();
            log("Cache apagado.");
        }
        private function saveCache(b:ByteArray):void
        {
            try {
                var fs:FileStream = new FileStream();
                fs.open(cacheFile(), FileMode.WRITE);
                fs.writeBytes(b); fs.close();
            } catch (err:Error) { log("Falha ao salvar cache: " + err.message); }
        }
        private function readCacheIfFresh():ByteArray
        {
            var f:File = cacheFile();
            if (!f.exists) return null;
            if (new Date().time - f.modificationDate.time > CACHE_TTL_MS) return null;
            return readFile(f);
        }

        private function readFile(f:File):ByteArray
        {
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.READ);
            var ba:ByteArray = new ByteArray();
            fs.readBytes(ba); fs.close();
            return ba;
        }

        // ---------- sessão recebida do ANE ----------
        private function onGame(e:StatusEvent):void
        {
            try { session = JSON.parse(e.level); }
            catch (err:Error) { setStatus("Resposta de login inválida."); return; }

            applyResolution();   // o login pausa/recria a tela do app: reaplica a resolução
            // Só guarda a senha depois que o login deu certo.
            try
            {
                var h:String = String(Platforms.LIST[platformIdx][1]);
                if (curUser != "" && curPass != "")
                {
                    if (Prefs.remember) bridge.saveCreds(h, curUser, curPass);
                    else bridge.forgetCreds(h);
                }
            }
            catch (eSave:Error) {}
            port = bridge.startServer(session.host);
            if (port <= 0) { setStatus("Falha ao iniciar servidor local."); return; }
            bridge.keepAlive(true);
            setStatus("Baixando o jogo...");
            fbIndex = 0;
            fetchSwf();
        }

        // 1) servidor (via proxy local, tentando vários caminhos)  2) cache  3) reservas empacotadas
        private function fetchSwf():void
        {
            swfCandidates = [];
            if (session.swf) swfCandidates.push(String(session.swf));
            swfCandidates.push("/client/Loading.swf");
            swfCandidates.push("/Loading.swf");
            swfIdx = 0;
            log("Sessão: host=" + session.host + " swf=" + (session.swf ? session.swf : "(nenhum)") + " porta=" + port);
            tryServer();
        }

        private function isSwf(b:ByteArray):Boolean
        {
            if (b.length < 3) return false;
            var h:String = String.fromCharCode(b[0], b[1], b[2]);
            return h == "FWS" || h == "CWS" || h == "ZWS";
        }

        private function tryServer():void
        {
            if (swfIdx >= swfCandidates.length)
            {
                log("Servidor não respondeu; usando a cópia do app.");
                launchWith(0);
                return;
            }
            var path:String = String(swfCandidates[swfIdx++]);
            log("Tentando https://" + session.host + path);
            var code:int = 0;
            var l:URLLoader = new URLLoader();
            l.dataFormat = URLLoaderDataFormat.BINARY;
            l.addEventListener(HTTPStatusEvent.HTTP_STATUS, function(ev:HTTPStatusEvent):void { code = ev.status; });
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var b:ByteArray = ByteArray(l.data);
                log("Recebido " + b.length + " bytes (HTTP " + code + ")");
                if (!isSwf(b)) { log("A resposta não é um SWF."); tryServer(); return; }
                okPath = path;
                launchWith(b.length);
            });
            l.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                log("Falhou (HTTP " + code + "): " + ev.text);
                tryServer();
            });
            l.load(new URLRequest("http://127.0.0.1:" + port + path));
        }

        // O Loading.swf do servidor NÃO é executado: serve só para saber a versão (pelo tamanho).
        // Quem roda é a cópia modificada que vem no app (assets/game), a mesma versão do servidor.
        private function launchWith(serverLen:int):void
        {
            var name:String = "assets/game/Loading.swf";
            if (serverLen > 0 && serverLen != BRAZIL_LEN)
            {
                var alt:String = "assets/game/Loading_" + serverLen + ".swf";
                if (File.applicationDirectory.resolvePath(alt).exists)
                {
                    name = alt;
                    log("Versão deste servidor: " + serverLen + " bytes (cópia própria no app)");
                }
                else
                {
                    log("AVISO: a versão do Loading.swf deste servidor (" + serverLen + " bytes) não está no app. Usando a do Brasil.");
                }
            }
            else if (serverLen == BRAZIL_LEN)
            {
                log("Versão deste servidor: a mesma do Brasil");
            }
            var f:File = File.applicationDirectory.resolvePath(name);
            if (!f.exists)
            {
                setStatus("Faltam os arquivos do jogo no app (" + name + "). Toque em Ver log.");
                return;
            }
            setStatus("Carregando o jogo...");
            startGame(readFile(f));
        }

        private function startGame(bytes:ByteArray):void
        {
            inGame = true;
            while (ui.numChildren) ui.removeChildAt(0);
            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;
            var p:String = okPath;
            var qi:int = p.indexOf("?");
            if (qi >= 0) p = p.substring(0, qi);
            var dir:String = "https://" + session.host + p.substring(0, p.lastIndexOf("/") + 1);
            var params:Object = {};
            for each (var pn:String in ["user", "key", "site", "p2", "rid", "logintype"])
            {
                if (session.params && session.params[pn] != undefined) params[pn] = String(session.params[pn]);
            }
            params["http"] = "https:";
            params["config"] = dir + "config.xml";
            params["base"] = dir;
            log("Jogo: " + bytes.length + " bytes | config " + params["config"]);
            applyResolution();
            ctx.parameters = params;
            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                SwfFixer.gameDomain = gameLoader.contentLoaderInfo.applicationDomain;
                applyResolution();
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, function(ev:Event):void {
                zoomLevel = 1; Prefs.zoom = 1;
                addChild(gameLoader);
                applyZoom();
                controls = new Controls(openSettings);
                controls.layout(sw(), uiScale());
                stage.addChild(controls);
                if (topTimer) topTimer.stop();
                topTimer = new Timer(400);
                topTimer.addEventListener(TimerEvent.TIMER, keepOnTop);
                topTimer.start();
                log("Jogo carregado.");
            });
            gameLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                inGame = false; gameLoader = null; showHome(); setStatus("Falha ao carregar o jogo.");
            });
            gameLoader.loadBytes(bytes, ctx);
        }
    }
}
