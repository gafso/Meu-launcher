package
{
    import com.meulauncher.air.Bridge;
    import flash.desktop.NativeApplication;
    import flash.desktop.SystemIdleMode;
    import flash.display.Bitmap;
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Loader;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.HTTPStatusEvent;
    import flash.events.IOErrorEvent;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.events.TimerEvent;
    import flash.events.UncaughtErrorEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.filters.DropShadowFilter;
    import flash.filters.GlowFilter;
    import flash.geom.Matrix;
    import flash.geom.Rectangle;
    import flash.net.URLLoader;
    import flash.net.navigateToURL;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.system.ApplicationDomain;
    import flash.system.Capabilities;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.ui.Keyboard;
    import flash.utils.ByteArray;
    import flash.utils.Timer;
    import flash.utils.clearTimeout;
    import flash.utils.getTimer;
    import flash.utils.setTimeout;

    [SWF(width="1352", height="650", frameRate="30", backgroundColor="#07061A")]
    public class Main extends Sprite
    {
        // Reservas empacotadas (você coloca os SEUS arquivos em assets/game/).
        private static const FALLBACKS:Array = [
            "assets/game/Loading.swf",
            "assets/game/Loading_270767.swf",
            "assets/game/Loading_245292.swf",
            "assets/game/Loading_243852.swf",
            "assets/game/Loading_234741.swf"
        ];
        private static const CACHE_TTL_MS:Number = 6 * 60 * 60 * 1000;   // 6 h
        private static const BG_TOP:uint = 0x0B0A1E;      // fundo: topo do degradê
        private static const BG_BOTTOM:uint = 0x07061A;   // fundo: base do degradê
        private static const VERSION:String = "v4.6";

        // Modos do menu nativo (o evento "menu" é compartilhado).
        private static const M_PLATFORM:String = "platform";
        private static const M_SETTINGS:String = "settings";
        private static const M_QUALITY:String  = "quality";
        private static const M_FPS:String      = "fps";
        private static const M_CACHE:String    = "cache";
        private static const M_RES:String      = "res";
        private static const M_EXIT:String     = "exit";
        // Resolução do jogo. 0 = nativa da tela; 100000+n = tamanho fixo "Modo PC" (RES_FIXED[n]),
        // centralizado com barras pretas se a proporção da tela for diferente.
        // O jogo foi feito para ~1250x650: abaixo disso as janelas dele ficam cortadas.
        private static const RES_BASE:int = 100000;
        // 200000+n = resolução "virtual" (RES_VIRT[n]): tenta dar ao palco exatamente esse tamanho
        // (SHOW_ALL) e confere o resultado; se o AIR não aceitar, volta ao Modo PC (ver verifyVirtual).
        private static const RES_VIRT_BASE:int = 200000;
        private static const RES_CUSTOM:int = 300000;     // "Personalizada": altura escolhida na barra (Prefs.customH)
        private static const CUSTOM_MIN:int = 650;
        private static const CUSTOM_MAX:int = 1080;
        private static const RES_OPTIONS:Array = [100000, 0];
        private static const RES_FIXED:Array = [[1352, 650]];
        private static const RES_VIRT:Array = [[1920, 1080, "Full HD"], [2560, 1440, "2K"]];
        private static const FPS_OPTIONS:Array = [15, 24, 30, 60, 120];
        private var bridge:Bridge;
        private var lastStatus:String = "";
        private var inGame:Boolean = false;
        private var platformIdx:int = 0;
        private var ui:Sprite = new Sprite();
        private var status:TextField;
        private var session:Object;
        private var port:int;
        private var fbIndex:int = 0;
        private var swfCandidates:Array = [];
        private var swfIdx:int = 0;
        private var okPath:String = "/client/Loading.swf";
        private static const BRAZIL_LEN:int = 244783;   // tamanho do Loading.swf do servidor do Brasil
        private var gameLoader:Loader;
        private var controls:Controls;
        private var macroPanel:MacroPanel;
        private var menuMode:String = M_PLATFORM;
        private var logLines:Array = [];
        private var zoomLevel:Number = 1;
        private var topTimer:Timer;
        private var bgLayer:Sprite = new Sprite();   // imagem de fundo + sombra (abaixo da UI)
        private var bgBmp:Bitmap;
        private var shade:Shape = new Shape();
        private var topW:Number = -1;
        private var topH:Number = -1;
        private var lastW:Number = -1;
        private var lastH:Number = -1;

        public function Main()
        {
            try { init(); }
            catch (err:Error) { fatal(String(err.message) + stackOf(err)); }
        }

        private function init():void
        {
            if (loaderInfo && loaderInfo.uncaughtErrorEvents)
                loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR, onUncaught);
            applyResolution();
            drawBg();
            bridge = new Bridge();
            initLogFile();
            SwfFixer.logger = log;
            SwfFixer.rootStage = stage;
            SwfFixer.fastNeg = Prefs.fastNeg;
            SwfFixer.install();
            SwfFixer.pruneOld();
            // Sem isto o AIR congela o jogo quando você sai do app (jogo desconecta).
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE; } catch (eIdle:Error) {}
            try { NativeApplication.nativeApplication["executeInBackground"] = true; } catch (eBg:Error) { log("segundo plano: " + eBg.message); }
            stage.addEventListener(KeyboardEvent.KEY_DOWN, onKey, false, 100);
            // Em segundo plano o AIR derruba o frameRate (~4 fps) e o macro fica lento/parado.
            // Reaplica a taxa normal ao sair do app e de novo ao voltar.
            stage.addEventListener(Event.DEACTIVATE, onBgChange);
            stage.addEventListener(Event.ACTIVATE, onBgChange);
            platformIdx = Math.min(Prefs.platform, Platforms.LIST.length - 1);
            applyDisplayPrefs();
            bgLayer.addChild(shade);
            addChild(bgLayer);
            drawBg();
            addChild(ui);
            bridge.addEventListener("game", onGame);
            bridge.addEventListener("menu", onMenu);
            bridge.addEventListener("error", onError);
            log("Launcher iniciado. ANE: " + (bridge.available ? "ok" : "ausente (" + bridge.initError + ")"));
            stage.addEventListener(Event.RESIZE, onResize);
            applyResolution();
            applyDisplayPrefs();
            if (isVirtual()) setTimeout(function():void { verifyVirtual(false); }, 1500);
            showHome();
        }

        // Em alguns aparelhos o stage começa com tamanho 0; usa o tamanho real da tela nesse caso.
        private function sw():Number { return stage.stageWidth > 0 ? stage.stageWidth : stage.fullScreenWidth; }
        // Botões maiores em telas de muitos pixels (e menores se a resolução do jogo for reduzida).
        private function uiScale():Number { return Math.max(1, Math.min(2.5, sh() / 650)); }
        private function sh():Number { return stage.stageHeight > 0 ? stage.stageHeight : stage.fullScreenHeight; }

        // Fundo base (degradê preto/vinho). Fora do palco (barras do Modo PC) as cores
        // continuam iguais às pontas do degradê, então não aparece emenda.
        private function drawBg():void
        {
            // Dentro do jogo o fundo do menu sai de cena: o mapa do jogo é desenhado ATRÁS do app e a imagem o cobria.
            if (inGame) { bgLayer.visible = false; graphics.clear(); return; }
            bgLayer.visible = true;
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            var g:Graphics = graphics;
            g.clear();
            g.beginFill(BG_TOP);    g.drawRect(-4096, -4096, w + 8192, 4096); g.endFill();
            g.beginFill(BG_BOTTOM); g.drawRect(-4096, h, w + 8192, 4096);     g.endFill();
            var m:Matrix = new Matrix();
            m.createGradientBox(w + 8192, h, Math.PI / 2, -4096, 0);
            g.beginGradientFill(GradientType.LINEAR, [BG_TOP, BG_BOTTOM], [1, 1], [0, 255], m);
            g.drawRect(-4096, 0, w + 8192, h); g.endFill();
            m = new Matrix();
            m.createGradientBox(w * 1.1, h * 1.3, 0, w * 0.3 - w * 0.55, h * 0.45 - h * 0.65);
            g.beginGradientFill(GradientType.RADIAL, [0x7C3AED, 0x7C3AED], [0.22, 0], [0, 255], m);
            g.drawRect(0, 0, w, h); g.endFill();
            layoutBg();
        }

        // Carrega a imagem de fundo empacotada no app (assets/fundo.jpg).
        private function loadBgImage():void
        {
            try
            {
                var l:Loader = new Loader();
                l.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void {
                    try
                    {
                        bgBmp = Bitmap(l.content);
                        bgBmp.smoothing = true;
                        bgLayer.addChildAt(bgBmp, 0);
                        layoutBg();
                    }
                    catch (e2:Error) { log("Fundo: " + e2.message); }
                });
                l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(e:IOErrorEvent):void { log("Fundo: " + e.text); });
                l.load(new URLRequest("app:/assets/fundo.jpg"));
            }
            catch (err:Error) { log("Fundo: " + err.message); }
        }

        // A imagem preenche a tela toda (sem distorcer, cortando o excesso) e recebe uma sombra
        // mais escura à esquerda, onde ficam os botões, para o texto ficar legível.
        private function layoutBg():void
        {
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            bgLayer.scrollRect = new Rectangle(0, 0, w, h);   // não vaza para as barras do Modo PC
            if (bgBmp && bgBmp.bitmapData)
            {
                var sc:Number = Math.max(w / bgBmp.bitmapData.width, h / bgBmp.bitmapData.height);
                bgBmp.scaleX = bgBmp.scaleY = sc;
                bgBmp.x = (w - bgBmp.bitmapData.width * sc) / 2;
                bgBmp.y = (h - bgBmp.bitmapData.height * sc) / 2;
            }
            shade.graphics.clear();   // área de trabalho lisa (sem sombra sobre imagem)
        }

        private function onResize(e:Event):void
        {
            if (sw() == lastW && sh() == lastH) return;
            lastW = sw(); lastH = sh();
            drawBg();
            if (!inGame) showHome();
            else if (controls) controls.layout(sw(), uiScale(), sh());
        }

        private function stackOf(err:Error):String
        {
            var st:String = err.getStackTrace();
            return st ? "\n" + st : "";
        }

        private function onUncaught(e:UncaughtErrorEvent):void
        {
            var m:String = (e.error is Error) ? (Error(e.error).message + stackOf(Error(e.error))) : String(e.error);
            log("ERRO: " + m);
            if (!inGame) { e.preventDefault(); fatal(m); }
        }

        // Mostra o erro na tela (fundo amarelo) em vez de ficar branco sem explicação.
        private function fatal(msg:String):void
        {
            try
            {
                var tf:TextField = new TextField();
                tf.defaultTextFormat = new TextFormat("_sans", 22, 0x000000);
                tf.background = true; tf.backgroundColor = 0xFFEE00;
                tf.multiline = true; tf.wordWrap = true;
                tf.x = 20; tf.y = 20;
                tf.width = Math.max(300, sw() - 40);
                tf.text = "ERRO NO LAUNCHER:\n" + msg;
                addChild(tf);
            }
            catch (e2:Error) {}
        }

        // ---------- log ----------
        public function log(s:String):void
        {
            var d:Date = new Date();
            var line:String = pad(d.hours) + ":" + pad(d.minutes) + ":" + pad(d.seconds) + "  " + s;
            logLines.push(line);
            if (logLines.length > 400) logLines.shift();
            logBuf.push(line);
        }

        // Log em arquivo: sobrevive ao fechar/reabrir o app. launcher.log = sessão atual, launcher_prev.log = a anterior.
        private var logBuf:Array = [];
        private var logTimer:Timer;
        private var prevLog:String = "";
        private function logDir():File { return File.applicationStorageDirectory; }
        private function initLogFile():void
        {
            try
            {
                var cur:File = logDir().resolvePath("launcher.log");
                var prev:File = logDir().resolvePath("launcher_prev.log");
                if (cur.exists && cur.size > 0)
                {
                    var b:ByteArray = readFile(cur);
                    var t:String = b.readUTFBytes(b.length);
                    if (t.length > 60000) t = t.substring(t.length - 60000);   // só o final
                    prevLog = t;
                    cur.moveTo(prev, true);
                }
            }
            catch (e:Error) {}
            logTimer = new Timer(2000);
            logTimer.addEventListener(TimerEvent.TIMER, flushLog);
            logTimer.start();
        }
        private function flushLog(e:TimerEvent = null):void
        {
            if (logBuf.length == 0) return;
            var txt:String = logBuf.join("\n") + "\n";
            logBuf = [];
            try
            {
                var f:File = logDir().resolvePath("launcher.log");
                if (f.exists && f.size > 400000) f.deleteFile();           // limite de tamanho
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.APPEND);
                fs.writeUTFBytes(txt);
                fs.close();
            }
            catch (err:Error) {}
        }
        private function prevLogText():String
        {
            return prevLog.length ? "\n\n----- SESSÃO ANTERIOR (antes de reabrir o app) -----\n" + prevLog : "";
        }
        private function pad(n:int):String { return n < 10 ? "0" + n : String(n); }

        private function onBgChange(e:Event):void
        {
            try { stage.frameRate = Math.max(Prefs.fps, 24); } catch (err:Error) {}
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE; } catch (err2:Error) {}
            try { NativeApplication.nativeApplication["executeInBackground"] = true; } catch (err3:Error) {}
        }

        // ---------- preferências de exibição ----------
        private function applyDisplayPrefs():void
        {
            stage.quality = Prefs.quality;     // StageQuality.LOW / MEDIUM / HIGH
            stage.frameRate = Prefs.fps;
            // Pede à tela do aparelho a taxa mais próxima (60 / 90 / 120 Hz...).
            try { if (bridge && bridge.available) bridge.setRefreshRate(Prefs.fps); } catch (err:Error) {}
        }

        // Texto com a taxa de atualização real da tela (ex.: "120 Hz"), para o menu e o log.
        private function hzText():String
        {
            try
            {
                var hz:Number = (bridge && bridge.available) ? bridge.displayHz() : 0;
                if (hz > 0) return Math.round(hz) + " Hz";
            }
            catch (err:Error) {}
            return "? Hz";
        }

        // ---------- UI inicial ----------
        // Layout desenhado numa área de 1000x560 (cabeçalho, barra lateral, destaque, acesso rápido,
        // informações e barra de status) e escalado para caber em qualquer tela.
        private function showHome():void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            var s:Number = Math.max(0.5, Math.min(sh() / 560, sw() / 1000, 2.5));
            var box:Sprite = new Sprite();
            box.scaleX = box.scaleY = s;
            box.x = (sw() - 1000 * s) / 2;
            box.y = (sh() - 560 * s) / 2;
            ui.addChild(box);

            var base:Sprite = new Sprite();
            box.addChild(base);
            var pname:String = String(Platforms.LIST[platformIdx][0]);

            // ----- cabeçalho -----
            var logo:Sprite = new Sprite();
            logo.x = 22; logo.y = 12;
            box.addChild(logo);
            loadLogo(logo, 48);
            Win.label(box, "LEGEND", 26, 0xFFFFFF, 80, 8, true);
            var sub:TextField = Win.label(box, "M O B I L E", 11, Btn.ACCENT_LIGHT, 82, 40, true);
            base.graphics.lineStyle(1, Win.LINE, 1);
            base.graphics.moveTo(250, 18); base.graphics.lineTo(250, 54);
            Win.label(box, "Sua aventura", 14, Btn.TEXT_SOFT, 266, 14);
            Win.label(box, "começa aqui!", 15, Btn.ACCENT_LIGHT, 266, 33, true);
            Win.card(base, 790, 10, 194, 54, 14);
            var av:Shape = new Shape();
            av.graphics.beginFill(0x2A1F66, 1); av.graphics.drawCircle(820, 37, 18); av.graphics.endFill();
            Win.glyph(av.graphics, "user", 820, 37, 22, 0xE9DDFF);
            box.addChild(av);
            Win.label(box, "Launcher", 12, Btn.TEXT_MUTED, 848, 16);
            var okTxt:TextField = Win.label(box, bridge.available ? "Pronto" : "ANE ausente", 14, bridge.available ? Btn.GREEN : 0xFFE066, 848, 34, true);
            base.graphics.lineStyle(1, Win.LINE, 1);
            base.graphics.moveTo(0, 74); base.graphics.lineTo(1000, 74);

            // ----- barra lateral -----
            Win.card(base, 16, 86, 188, 458, 18, 0x0F0E28);
            var navs:Array = [
                ["home", "Início", function(e:MouseEvent):void { setTab("inicio"); }, homeTab == "inicio"],
                ["play", "Jogo", function(e:MouseEvent):void { setTab("jogo"); }, homeTab == "jogo"],
                ["gear", "Configurações", settingsTapped, false],
                ["doc", "Ver log", logTapped, false]
            ];
            for (var ni:int = 0; ni < navs.length; ni++)
            {
                var nv:Sprite = Win.navItem(String(navs[ni][0]), String(navs[ni][1]), 170, 48, Boolean(navs[ni][3]), navs[ni][2]);
                nv.x = 25; nv.y = 98 + ni * 56;
                box.addChild(nv);
            }
            // cartão do servidor (toque para trocar)
            var srv:Sprite = new Sprite();
            Win.card(srv, 0, 0, 170, 70, 14, 0x0B0A1E);
            srv.graphics.lineStyle(0, 0, 0);
            srv.graphics.beginFill(Btn.GREEN, 0.25); srv.graphics.drawCircle(26, 35, 11); srv.graphics.endFill();
            srv.graphics.beginFill(Btn.GREEN, 1); srv.graphics.drawCircle(26, 35, 6); srv.graphics.endFill();
            Win.label(srv, "Servidor", 11, Btn.TEXT_MUTED, 48, 14);
            Win.fitLabel(srv, pname, 14, Btn.GREEN, 48, 32, 112, true);
            srv.mouseChildren = false; srv.buttonMode = true;
            srv.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { setTab("jogo"); });
            srv.x = 25; srv.y = 464;
            box.addChild(srv);

            if (homeTab == "jogo") buildJogo(box, pname); else buildInicio(box, pname);

            // ----- barra de status -----
            Win.card(base, 216, 498, 768, 46, 14);
            base.graphics.lineStyle(0, 0, 0);
            base.graphics.beginFill(Btn.ACCENT, 1); base.graphics.drawCircle(240, 521, 5); base.graphics.endFill();
            status = new TextField();
            status.defaultTextFormat = new TextFormat("_sans", 13, 0xFFFFFF, false);
            status.width = 640; status.height = 22; status.x = 256; status.y = 510;
            status.multiline = false; status.wordWrap = false;
            status.selectable = false; status.mouseEnabled = false;
            status.text = lastStatus != "" ? lastStatus : (bridge.available ? "Pronto" : "ANE indisponível: " + bridge.initError);
            paintStatus();
            box.addChild(status);
            var ver:TextField = Win.label(box, VERSION, 12, Btn.TEXT_MUTED, 0, 512);
            ver.x = 970 - ver.width;

            // entrada suave
            box.alpha = 0;
            var f:int = 0;
            var tick:Function = function(ev:Event):void
            {
                f++;
                var t:Number = Math.min(f / 12, 1);
                box.alpha = 1 - Math.pow(1 - t, 3);
                if (t >= 1) box.removeEventListener(Event.ENTER_FRAME, tick);
            };
            box.addEventListener(Event.ENTER_FRAME, tick);
        }

        // ---------- abas da tela inicial ----------
        private var homeTab:String = "inicio";
        private function setTab(t:String):void { homeTab = t; showHome(); }
        private function pickServer(i:int):void
        {
            if (i < 0 || i >= Platforms.LIST.length) return;
            platformIdx = i; Prefs.platform = i;
            showHome();
        }

        // Aba Início: destaque, informações e notícias.
        private function buildInicio(box:Sprite, pname:String):void
        {
            // ----- destaque -----
            var hero:Sprite = new Sprite();
            hero.x = 216; hero.y = 86;
            box.addChild(hero);
            var hm:Matrix = new Matrix();
            hm.createGradientBox(500, 190, 0, 0, 0);
            hero.graphics.lineStyle(1, 0x3B2F85, 1);
            hero.graphics.beginGradientFill(GradientType.LINEAR, [0x2E1A6E, 0x120F33], [1, 1], [0, 255], hm);
            hero.graphics.drawRoundRect(0, 0, 500, 190, 32, 32);
            hero.graphics.endFill();
            Win.label(hero, "SERVIDOR SELECIONADO", 12, Btn.ACCENT_LIGHT, 28, 22, true);
            Win.fitLabel(hero, pname, 34, 0xFFFFFF, 28, 42, 290, true);
            Win.wrapLabel(hero, "Entre com a conta que você logou no site e continue sua aventura.", 13, Btn.TEXT_SOFT, 28, 92, 280, 2);
            var play:Btn = new Btn(Btn.PRIMARY, 150, 46, "JOGAR", "", playTapped);
            play.x = 28 + 75; play.y = 152;
            hero.addChild(play);
            var art:Sprite = new Sprite();
            art.x = 330; art.y = 10;
            art.filters = [new GlowFilter(0xFF2D55, 0.45, 24, 24, 1.5, 2)];
            hero.addChild(art);
            loadLogo(art, 170);

            // ----- informações (sob o destaque) -----
            var info:Sprite = new Sprite();
            info.x = 216; info.y = 288;
            box.addChild(info);
            Win.card(info, 0, 0, 500, 196, 18);
            buildAccounts(info);

            // ----- notícias da página de login (direita) -----
            var host:String = String(Platforms.LIST[platformIdx][1]);
            var news:Sprite = new Sprite();
            news.x = 732; news.y = 86;
            box.addChild(news);
            Win.card(news, 0, 0, 252, 398, 18);
            Win.heading(news, "doc", "Últimas Notícias", 18, 14);
            var reload:Sprite = new Sprite();
            var rl:TextField = Win.label(reload, "Atualizar", 11, Btn.ACCENT_LIGHT, 0, 0, true);
            reload.x = 234 - rl.width; reload.y = 18;
            reload.mouseChildren = false; reload.buttonMode = true;
            reload.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { NewsFeed.reset(host); showHome(); });
            news.addChild(reload);
            var list:Array = NewsFeed.items(host);
            if (list == null)
            {
                Win.label(news, "Carregando notícias...", 13, Btn.TEXT_MUTED, 18, 62);
                NewsFeed.logger = log;
                NewsFeed.load(host, function():void { if (!inGame) showHome(); });
            }
            else if (list.length == 0)
            {
                Win.wrapLabel(news, "Não consegui ler as notícias do site agora. Toque em Atualizar para tentar de novo.", 13, Btn.TEXT_MUTED, 18, 62, 216, 5);
            }
            else
            {
                for (var ni2:int = 0; ni2 < list.length && ni2 < 4; ni2++)
                {
                    var iy:Number = 50 + ni2 * 86;
                    var row:Sprite = new Sprite();
                    row.x = 12; row.y = iy;
                    row.graphics.lineStyle(1, Win.LINE, 1);
                    if (ni2 > 0) { row.graphics.moveTo(6, -4); row.graphics.lineTo(222, -4); }
                    row.graphics.lineStyle(0, 0, 0);
                    row.graphics.beginFill(Btn.ACCENT, 1); row.graphics.drawCircle(12, 14, 4); row.graphics.endFill();
                    Win.wrapLabel(row, String(list[ni2].title), 13, Btn.TEXT, 26, 4, 196, 3, true);
                    if (String(list[ni2].date) != "") Win.label(row, String(list[ni2].date), 11, Btn.TEXT_MUTED, 26, 62);
                    row.graphics.beginFill(0xFFFFFF, 0); row.graphics.drawRect(0, -4, 228, 82); row.graphics.endFill();
                    row.mouseChildren = false; row.buttonMode = true;
                    var link:String = String(list[ni2].url);
                    row.addEventListener(MouseEvent.CLICK, makeOpener(link));
                    news.addChild(row);
                }
            }

        }

        // Aba Jogo: escolha do servidor na própria tela + botão de entrar.
        private function buildJogo(box:Sprite, pname:String):void
        {
            var lp:Sprite = new Sprite();
            lp.x = 216; lp.y = 86;
            box.addChild(lp);
            Win.card(lp, 0, 0, 400, 398, 18);
            Win.heading(lp, "server", "Escolha o servidor", 18, 14);
            for (var si:int = 0; si < Platforms.LIST.length; si++)
            {
                var sel:Boolean = (si == platformIdx);
                var row:Sprite = new Sprite();
                row.x = 14; row.y = 52 + si * 56;
                Win.card(row, 0, 0, 372, 48, 12, sel ? 0x1C1650 : 0x0B0A1E, sel ? Btn.ACCENT_LIGHT : Win.LINE);
                row.graphics.lineStyle(2, sel ? Btn.ACCENT_LIGHT : Btn.TEXT_MUTED, 1);
                row.graphics.drawCircle(24, 24, 8);
                if (sel) { row.graphics.lineStyle(0, 0, 0); row.graphics.beginFill(Btn.ACCENT_LIGHT, 1); row.graphics.drawCircle(24, 24, 4); row.graphics.endFill(); }
                Win.fitLabel(row, String(Platforms.LIST[si][0]), 14, sel ? 0xFFFFFF : Btn.TEXT, 46, 6, 310, true);
                Win.fitLabel(row, String(Platforms.LIST[si][1]), 11, Btn.TEXT_MUTED, 46, 26, 310);
                row.mouseChildren = false; row.buttonMode = true;
                row.addEventListener(MouseEvent.CLICK, makePicker(si));
                lp.addChild(row);
            }

            var rp:Sprite = new Sprite();
            rp.x = 632; rp.y = 86;
            box.addChild(rp);
            Win.card(rp, 0, 0, 352, 398, 18, 0x120F33, 0x3B2F85);
            Win.heading(rp, "play", "Entrar no jogo", 18, 14);
            Win.label(rp, "SERVIDOR", 11, Btn.ACCENT_LIGHT, 22, 62, true);
            Win.fitLabel(rp, pname, 24, 0xFFFFFF, 22, 80, 308, true);
            Win.wrapLabel(rp, "Toque em Jogar para entrar com a sua conta no site do servidor. Depois do login, o jogo abre sozinho.", 13, Btn.TEXT_SOFT, 22, 126, 308, 4);
            var go:Btn = new Btn(Btn.PRIMARY, 308, 54, "JOGAR", "", playTapped);
            go.x = 22 + 154; go.y = 250;
            rp.addChild(go);
        }

        private function makePicker(i:int):Function
        {
            return function(e:MouseEvent):void { pickServer(i); };
        }

        private function makeOpener(u:String):Function
        {
            return function(e:MouseEvent):void { try { navigateToURL(new URLRequest(u)); } catch (err:Error) { log("Abrir link: " + err.message); } };
        }

        // Carrega o ícone do app (assets/icons/icon512.png) dentro de 'holder', com 'size' px de lado.
        private function loadLogo(holder:Sprite, size:Number):void
        {
            try
            {
                var l:Loader = new Loader();
                l.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void {
                    try
                    {
                        var bm:Bitmap = Bitmap(l.content);
                        bm.smoothing = true;
                        bm.width = size; bm.height = size;
                        holder.addChild(bm);
                    }
                    catch (e2:Error) { log("Logo: " + e2.message); }
                });
                l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(e:IOErrorEvent):void { log("Logo: " + e.text); });
                l.load(new URLRequest("app:/assets/icons/icon512.png"));
            }
            catch (err:Error) { log("Logo: " + err.message); }
        }

        // Mensagens de erro ficam em amarelo; o resto em branco.
        private function paintStatus():void
        {
            if (!status) return;
            status.textColor = /erro|falha|faltam|indispon/i.test(status.text) ? 0xFFE066 : 0xFFFFFF;
        }

        private function setStatus(s:String):void { lastStatus = s; if (status) { status.text = s; paintStatus(); } log(s); }

        // ---------- contas salvas ----------
        private var accOffset:int = 0;
        private var delPending:String = "";
        private var delTimer:Timer;

        private function accName(acc:Object):String
        {
            var l:String = acc.label != undefined ? String(acc.label) : "";
            return l != "" ? l : String(acc.name);
        }

        // Cartão "Contas salvas" (no lugar do antigo cartão de Informações): 3 contas por página.
        private function buildAccounts(info:Sprite):void
        {
            Win.heading(info, "user", "Contas salvas", 18, 12);
            var list:Array = Prefs.accounts();
            var per:int = 3;
            if (accOffset >= list.length) accOffset = 0;
            var nb:Sprite = new Sprite();
            nb.x = 500 - 18 - 108; nb.y = 10;
            Win.card(nb, 0, 0, 108, 28, 9, 0x1C1650, Btn.ACCENT_LIGHT);
            Win.label(nb, "+ Nova conta", 11, 0xFFFFFF, 12, 6, true);
            nb.mouseChildren = false; nb.buttonMode = true;
            nb.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { newAccount(); });
            info.addChild(nb);
            if (list.length > per)
            {
                var pages:int = int(Math.ceil(list.length / per));
                var pg:Sprite = new Sprite();
                pg.x = nb.x - 6 - 60; pg.y = 10;
                Win.card(pg, 0, 0, 60, 28, 9, 0x0B0A1E, Win.LINE);
                Win.label(pg, (int(accOffset / per) + 1) + "/" + pages + " >", 11, 0xFFFFFF, 10, 6, true);
                pg.mouseChildren = false; pg.buttonMode = true;
                pg.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { accOffset = (accOffset + per < list.length) ? accOffset + per : 0; showHome(); });
                info.addChild(pg);
            }
            if (list.length == 0)
                Win.wrapLabel(info, "Nenhuma conta salva ainda. Toque em + Nova conta, faça o login no site e ela fica guardada aqui. Depois use Nome para dar um apelido.", 12, Btn.TEXT_MUTED, 18, 56, 464, 4);
            for (var i:int = accOffset; i < list.length && i < accOffset + per; i++)
            {
                var acc:Object = list[i];
                var id:String = String(acc.id);
                var row:Sprite = new Sprite();
                row.x = 18; row.y = 46 + (i - accOffset) * 48;
                var arm:Boolean = (delPending == id);
                Win.card(row, 0, 0, 464, 42, 11, 0x0B0A1E, arm ? 0xFF5A5A : Win.LINE);
                var main:Sprite = new Sprite();
                main.graphics.beginFill(0xFFFFFF, 0); main.graphics.drawRect(0, 0, 296, 42); main.graphics.endFill();
                Win.fitLabel(main, accName(acc), 14, 0xFFFFFF, 14, 3, 276, true);
                Win.fitLabel(main, "ID " + acc.name + "  -  " + serverName(int(acc.platform)), 10, Btn.TEXT_MUTED, 14, 24, 276);
                main.mouseChildren = false; main.buttonMode = true;
                main.addEventListener(MouseEvent.CLICK, makeAccSite(id));
                row.addChild(main);
                row.addChild(accButton("Nome", 330, 70, Btn.ACCENT_LIGHT, makeAccRename(id)));
                row.addChild(accButton(arm ? "?" : "x", 408, 44, arm ? 0xFF5A5A : Btn.TEXT_MUTED, makeAccDel(id)));
                info.addChild(row);
            }
        }

        private function accButton(t:String, x:Number, w:Number, color:uint, fn:Function):Sprite
        {
            var b:Sprite = new Sprite();
            b.x = x; b.y = 7;
            Win.card(b, 0, 0, w, 28, 8, 0x14123A, Win.LINE);
            var tf:TextField = Win.label(b, t, 11, color, 0, 6, true);
            tf.x = (w - tf.width) / 2;
            b.mouseChildren = false; b.buttonMode = true;
            b.addEventListener(MouseEvent.CLICK, fn);
            return b;
        }

        private function makeAccRename(id:String):Function { return function(e:MouseEvent):void { openRename(id); }; }

        // Janela para dar um nome (apelido) à conta.
        private var renamePanel:Sprite;
        private var renameInput:TextField;
        private function openRename(id:String):void
        {
            var acc:Object = findAccount(id);
            if (acc == null) return;
            closeRename();
            renamePanel = new Sprite();
            renamePanel.graphics.beginFill(0x000000, 0.72);
            renamePanel.graphics.drawRect(0, 0, sw(), sh());
            renamePanel.graphics.endFill();
            var card:Sprite = new Sprite();
            card.scaleX = card.scaleY = uiScale();
            card.x = sw() / 2; card.y = sh() * 0.32;
            Win.card(card, -190, -80, 380, 190, 18, 0x120F33, 0x3B2F85);
            Win.label(card, "Nome da conta", 16, 0xFFFFFF, -170, -68, true);
            Win.fitLabel(card, "ID: " + acc.name, 11, Btn.TEXT_MUTED, -170, -44, 340);
            Win.card(card, -172, -20, 344, 38, 10, 0x0B0A1E, Btn.ACCENT_LIGHT);
            renameInput = new TextField();
            renameInput.type = TextFieldType.INPUT;
            renameInput.defaultTextFormat = new TextFormat("_sans", 16, 0xFFFFFF, true);
            renameInput.width = 324; renameInput.height = 26; renameInput.x = -162; renameInput.y = -14;
            renameInput.maxChars = 24;
            renameInput.text = acc.label != undefined ? String(acc.label) : "";
            card.addChild(renameInput);
            var cancel:Btn = new Btn(Btn.GHOST, 150, 40, "Cancelar", "", function(e:MouseEvent):void { closeRename(); });
            cancel.x = -90; cancel.y = 70;
            card.addChild(cancel);
            var save:Btn = new Btn(Btn.PRIMARY, 150, 40, "Salvar", "", function(e:MouseEvent):void { saveRename(id); });
            save.x = 90; save.y = 70;
            card.addChild(save);
            renamePanel.addChild(card);
            stage.addChild(renamePanel);
            try { stage.focus = renameInput; renameInput.requestSoftKeyboard(); } catch (eK:Error) {}
        }
        private function closeRename():void
        {
            try { if (renamePanel != null && renamePanel.parent != null) renamePanel.parent.removeChild(renamePanel); } catch (e:Error) {}
            renamePanel = null; renameInput = null;
        }
        private function saveRename(id:String):void
        {
            var acc:Object = findAccount(id);
            var t:String = renameInput != null ? renameInput.text.replace(/^\s+|\s+$/g, "") : "";
            closeRename();
            if (acc == null) return;
            acc.label = t;
            Prefs.saveAccount(acc);
            setStatus(t != "" ? "Conta renomeada: " + t : "Nome removido (volta a mostrar o ID).");
            if (!inGame) showHome();
        }

        private function serverName(i:int):String
        {
            try { return String(Platforms.LIST[i][0]); } catch (e:Error) {}
            return "";
        }

        private function makeAccEnter(id:String):Function { return function(e:MouseEvent):void { enterAccount(id); }; }
        private function makeAccSite(id:String):Function { return function(e:MouseEvent):void { openAccountSite(id); }; }
        private function makeAccDel(id:String):Function
        {
            return function(e:MouseEvent):void
            {
                if (delPending == id)
                {
                    Prefs.removeAccount(id); delPending = "";
                    setStatus("Conta removida.");
                    showHome();
                    return;
                }
                delPending = id;
                if (delTimer != null) delTimer.stop();
                delTimer = new Timer(3000, 1);
                delTimer.addEventListener(TimerEvent.TIMER_COMPLETE, function(ev:TimerEvent):void { delPending = ""; if (!inGame) showHome(); });
                delTimer.start();
                setStatus("Toque em ? de novo para remover a conta.");
                showHome();
            };
        }

        private function findAccount(id:String):Object
        {
            var list:Array = Prefs.accounts();
            for (var i:int = 0; i < list.length; i++) if (String(list[i].id) == id) return list[i];
            return null;
        }

        // Toque na conta: entra direto no jogo com a sessão guardada (sem abrir o site).
        private function enterAccount(id:String):void
        {
            var acc:Object = findAccount(id);
            if (acc == null) return;
            try
            {
                platformIdx = int(acc.platform); Prefs.platform = platformIdx;
                session = JSON.parse(String(acc.session));
            }
            catch (err:Error) { setStatus("Conta salva inválida: entre pelo botão site."); return; }
            setStatus("Entrando com " + accName(acc) + " (sessão guardada, pode estar vencida)...");
            enterGame();
        }

        // Botão "site": abre o site do servidor já logado com os cookies dessa conta (renova a sessão guardada).
        private function openAccountSite(id:String):void
        {
            var acc:Object = findAccount(id);
            if (acc == null) return;
            platformIdx = int(acc.platform); Prefs.platform = platformIdx;
            setStatus("Entrando com " + accName(acc) + " (renovando a sessão no site)...");
            bridge.login(String(acc.host), acc.cookies ? String(acc.cookies) : "");
        }

        // + Nova conta: apaga a sessão atual do site e abre o login limpo (a conta fica salva ao entrar).
        private function newAccount():void
        {
            bridge.clearSession();
            setStatus("Abrindo login de uma nova conta...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        // ---------- ações da tela inicial ----------
        private function chooseTapped(e:MouseEvent):void { openPlatformMenu(); }

        private function openPlatformMenu():void
        {
            var names:Array = [];
            for each (var p:Array in Platforms.LIST) names.push(p[0]);
            menuMode = M_PLATFORM;
            bridge.showMenu("Escolha a plataforma", names);
        }

        private function settingsTapped(e:MouseEvent):void { openSettings(); }

        private function playTapped(e:MouseEvent):void
        {
            setStatus("Abrindo login...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        private function logoutTapped(e:MouseEvent):void { logout(); }

        private function logTapped(e:MouseEvent):void { bridge.showText("Log", logLines.join("\n") + prevLogText()); }

        private function logout():void
        {
            bridge.clearSession();
            setStatus("Sessão apagada.");
        }

        private function onError(e:StatusEvent):void { setStatus("Erro: " + e.level); }

        // ---------- menu nativo (um evento só, roteado por menuMode) ----------
        private function onMenu(e:StatusEvent):void
        {
            var i:int = int(e.level);
            switch (menuMode)
            {
                case M_PLATFORM:
                    if (i >= 0 && i < Platforms.LIST.length)
                    {
                        platformIdx = i; Prefs.platform = i;
                        if (gameLoader) { bridge.restartApp(); } else { showHome(); }
                    }
                    break;
                case M_SETTINGS: onSettingsChoice(i); break;
                case M_QUALITY:
                    Prefs.quality = ["LOW", "MEDIUM", "HIGH"][i];
                    applyDisplayPrefs(); log("Qualidade: " + Prefs.quality);
                    break;
                case M_FPS:
                    if (i >= 0 && i < FPS_OPTIONS.length)
                    {
                        Prefs.fps = FPS_OPTIONS[i];
                        applyDisplayPrefs();
                        setTimeout(function():void { log("FPS: " + Prefs.fps + " | tela do aparelho: " + hzText()); }, 1200);
                        if (Prefs.fps > 60) bridge.showText("FPS " + Prefs.fps,
                            "O app pede " + Prefs.fps + " FPS e a tela do aparelho em " + hzText() + ".\n\n" +
                            "Só aparece diferença se a tela do aparelho suportar essa taxa (ative o modo de 120 Hz nas configurações de tela do Android). " +
                            "Se o jogo for feito para 30 FPS, as animações podem ficar mais rápidas.");
                    }
                    break;
                case M_CACHE:
                    if (i == 0) clearCache();
                    else if (i == 1)
                    {
                        Prefs.fastNeg = !Prefs.fastNeg;
                        SwfFixer.fastNeg = Prefs.fastNeg;
                        log("Atalho para imagens inexistentes: " + (Prefs.fastNeg ? "ligado" : "desligado"));
                    }
                    break;
                case M_RES:
                    if (i >= 0 && i < RES_OPTIONS.length && RES_OPTIONS[i] == RES_CUSTOM) { openSlider(); break; }
                    if (i >= 0 && i < RES_OPTIONS.length)
                    {
                        Prefs.resHeight = RES_OPTIONS[i];
                        applyResolution();
                        if (isVirtual()) setTimeout(function():void { verifyVirtual(true); }, 900);
                        if (!inGame) showHome();
                        else bridge.showText("Resolução", "Para o jogo se reorganizar por completo, use Configurações > Voltar à tela inicial e entre de novo.");
                    }
                    break;
                case M_EXIT:
                    if (i == 0) { log("Indo para segundo plano"); flushLog(); bridge.toBackground(); }
                    else if (i == 1) { flushLog(); bridge.keepAlive(false); NativeApplication.nativeApplication.exit(); }
                    break;
            }
        }

        private function openSettings():void
        {
            menuMode = M_SETTINGS;
            bridge.showMenu("Configurações", [
                "Resolução (" + resLabel(Prefs.resHeight) + ")",
                "Qualidade gráfica (" + Prefs.quality + ")",
                "FPS (" + Prefs.fps + ")",
                "Cache do jogo",
                "Mostrar log",
                "Voltar à tela inicial",
                "Sair do app",
                "Relogar (recarregar o jogo)"
            ]);
        }

        private function onSettingsChoice(i:int):void
        {
            switch (i)
            {
                case 0: openResolutionMenu(); break;
                case 1: menuMode = M_QUALITY; bridge.showMenu("Qualidade gráfica", ["Baixa", "Média", "Alta"]); break;
                case 2: openFpsMenu(); break;
                case 3:
                    menuMode = M_CACHE;
                    bridge.showMenu("Cache do jogo (" + cacheSizeText() + ")", ["Apagar cache",
                        "Atalho p/ imagens inexistentes: " + (Prefs.fastNeg ? "LIGADO" : "desligado"), "Voltar"]);
                    break;
                case 4: bridge.showText("Log", logLines.join("\n") + prevLogText()); break;
                case 5: backToHome(); break;
                case 6: askExit(); break;
                case 7: relog(); break;
            }
        }

        // Relogar: fecha o jogo atual e entra de novo com um login novo (sem reiniciar o app).
        private function relog():void
        {
            if (!inGame || gameLoader == null) { log("Relogar: o jogo não está aberto."); return; }
            log("Relogando...");
            closeGame();
            setStatus("Relogando...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        // Voltar à tela inicial: fecha o jogo (sem reiniciar o app) e mostra a tela inicial com as contas salvas.
        private function backToHome():void
        {
            closeRename();
            if (!inGame || gameLoader == null) { showHome(); return; }
            log("Voltando à tela inicial...");
            closeGame();
            try { bridge.keepAlive(false); } catch (eK:Error) {}
            setStatus("Pronto");
            showHome();
        }

        // Fecha o jogo atual e limpa o palco (usado por Relogar e por Voltar à tela inicial).
        private function closeGame():void
        {
            try { if (macroPanel != null) macroPanel.stopAll(); } catch (eM:Error) {}
            try { if (topTimer) topTimer.stop(); } catch (eT:Error) {}
            kickGen++;
            try { if (controls != null && controls.parent != null) controls.parent.removeChild(controls); } catch (eC:Error) {}
            controls = null;
            try { SwfFixer.gameDomain = null; } catch (eD:Error) {}
            try { gameLoader.unloadAndStop(true); } catch (eU:Error) {}
            try { if (gameLoader.parent != null) gameLoader.parent.removeChild(gameLoader); } catch (eR:Error) {}
            gameLoader = null;
            // o jogo põe janelas direto no palco: tira tudo que não é o próprio app
            try
            {
                for (var ci:int = stage.numChildren - 1; ci >= 0; ci--)
                {
                    var ch:DisplayObject = stage.getChildAt(ci);
                    if (ch != this) { try { stage.removeChild(ch); } catch (eX:Error) {} }
                }
            }
            catch (eS:Error) {}
            inGame = false;
            drawBg();
        }

        // ---------- janela de macros ----------
        // Pop-up por cima do jogo (dentro do app). O botão ▶ ao lado da engrenagem e o item "Macros" do menu abrem/fecham.
        private function openMacros():void
        {
            if (macroPanel == null)
            {
                macroPanel = new MacroPanel();
                macroPanel.logger = log;
                try { macroPanel.dumpDir = bridge.modsPath(); } catch (eMods:Error) {}
                macroPanel.onText = function(title:String, text:String):void { bridge.showText(title, text); };
                macroPanel.onWake = function():void { if (!macroPanel.isOpen) macroPanel.show(stage, sw(), sh(), uiScale()); };
            }
            if (macroPanel.isOpen) { macroPanel.hide(); return; }
            macroPanel.show(stage, sw(), sh(), uiScale());
        }

        private function openFpsMenu():void
        {
            var names:Array = [];
            for each (var f:int in FPS_OPTIONS)
                names.push(f + " FPS" + (f == Prefs.fps ? "  ✓" : "") + (f == 120 ? "  (precisa de tela 120 Hz)" : ""));
            menuMode = M_FPS;
            bridge.showMenu("FPS (tela do aparelho: " + hzText() + ")", names);
        }

        // ---------- resolução ----------
        // A troca de resolução NÃO usa mais o Android (setFixedSize não muda o tamanho do palco do AIR).
        // Modo PC = StageScaleMode.SHOW_ALL: o palco passa a ter o tamanho do SWF (1250x650, definido em
        // [SWF(...)] / -default-size) e o AIR amplia tudo para a tela mantendo a proporção (barras pretas
        // nos lados se a tela for mais larga). O jogo vê um palco de 1250x650 e se organiza para ele.
        private function screenSize():Array
        {
            var w:int = stage.fullScreenWidth > 0 ? stage.fullScreenWidth : int(Capabilities.screenResolutionX);
            var h:int = stage.fullScreenHeight > 0 ? stage.fullScreenHeight : int(Capabilities.screenResolutionY);
            if (h > w) { var t:int = w; w = h; h = t; }
            return [w, h];
        }

        // Valor salvo que não existe mais na lista (de versões antigas) volta para o Modo PC.
        private function validRes():int
        {
            var v:int = Prefs.resHeight;
            if (RES_OPTIONS.indexOf(v) < 0) { v = RES_BASE; Prefs.resHeight = RES_BASE; }
            return v;
        }

        private function isPcMode():Boolean { var v:int = validRes(); return v >= RES_BASE && v < RES_VIRT_BASE; }
        private function isVirtual():Boolean { return validRes() >= RES_VIRT_BASE; }

        private function resLabel(v:int):String
        {
            var s:Array = screenSize();
            if (v == RES_CUSTOM) return "Personalizada " + virtW(customH()) + "x" + customH();
            if (v >= RES_VIRT_BASE && v - RES_VIRT_BASE < RES_VIRT.length)
                return RES_VIRT[v - RES_VIRT_BASE][2] + " " + RES_VIRT[v - RES_VIRT_BASE][0] + "x" + RES_VIRT[v - RES_VIRT_BASE][1];
            if (v >= RES_BASE && v < RES_VIRT_BASE && v - RES_BASE < RES_FIXED.length)
                return "Padrão " + RES_FIXED[v - RES_BASE][0] + "x" + RES_FIXED[v - RES_BASE][1];
            return "Nativa " + s[0] + "x" + s[1];
        }

        private function openResolutionMenu():void
        {
            var cur:int = validRes();
            var names:Array = [];
            for each (var v:int in RES_OPTIONS)
            {
                var n:String = resLabel(v);
                if (v == cur) n += "  ✓";
                names.push(n);
            }
            menuMode = M_RES;
            bridge.showMenu("Resolução (maior = mais área do jogo, itens menores)", names);
        }

        private function wantedScaleMode():String
        {
            return (isPcMode() || isVirtual()) ? StageScaleMode.SHOW_ALL : StageScaleMode.NO_SCALE;
        }

        private function applyResolution():void
        {
            var want:String = wantedScaleMode();
            if (stage.scaleMode != want) stage.scaleMode = want;
            stage.align = StageAlign.TOP_LEFT;
            applyVirtualStage();
            var rl:String = "Resolução: " + resLabel(validRes());
            if (rl != lastResLog) { lastResLog = rl; log(rl); }
            setTimeout(logStage, 300);
            if (inGame) for each (var d:int in [50, 400, 1200]) setTimeout(notifyResize, d);
        }

        // Resolução virtual (1920x1080 / 2560x1440): o jogo só reorganiza a tela se o PALCO mudar de
        // tamanho. O AIR do Android não deixa o app mudar o tamanho da tela por fora (testado: só
        // encolhe a imagem), então tentamos pelo próprio palco e CONFERIMOS o resultado.
        private function baseRatio():Number { return (loaderInfo && loaderInfo.height > 0) ? loaderInfo.width / loaderInfo.height : 2.08; }
        private function customH():int { var h:int = Prefs.customH; return (h >= CUSTOM_MIN && h <= CUSTOM_MAX) ? h : 800; }
        private function virtW(h:int):int { return Math.round(h * baseRatio()); }
        // [largura, altura, nome] da resolução virtual escolhida (Full HD, 2K ou Personalizada)
        private function virtSize():Array
        {
            var v:int = validRes();
            if (v == RES_CUSTOM) return [virtW(customH()), customH(), "Personalizada"];
            return RES_VIRT[v - RES_VIRT_BASE];
        }
        private function applyVirtualStage():void
        {
            if (!isVirtual()) return;
            var r:Array = virtSize();
            try { stage["stageWidth"] = int(r[0]); stage["stageHeight"] = int(r[1]); }
            catch (err:Error) { log("Palco virtual: " + err.message); }
        }

        // Confere se o palco ficou mesmo com o tamanho pedido. Se o aparelho/AIR não aceitar, volta para
        // o Modo PC (em vez de deixar a tela quebrada) e avisa.
        private function verifyVirtual(announce:Boolean):void
        {
            if (!isVirtual() || !stage) return;
            var r:Array = virtSize();
            if (stage.stageWidth == int(r[0]) && stage.stageHeight == int(r[1]))
            {
                log("Resolução " + r[0] + "x" + r[1] + ": ok (palco " + stage.stageWidth + "x" + stage.stageHeight + ")");
                return;
            }
            log("Resolução " + r[0] + "x" + r[1] + " NÃO aceita pelo AIR (palco ficou " + stage.stageWidth + "x" + stage.stageHeight + "). Voltando ao Padrão.");
            Prefs.resHeight = RES_BASE;
            applyResolution();
            if (!inGame) showHome();
            if (announce) bridge.showText("Resolução",
                "Este aparelho não aceitou mudar o tamanho da tela do jogo para " + r[0] + "x" + r[1] + ". Voltei para o Padrão para não quebrar a tela.\n\n" +
                "Opção mais parecida: \"Nativa\" (usa todos os pixels da tela).");
        }

        private var lastResLog:String = "";
        private var lastStageLog:String = "";
        private function logStage():void
        {
            var sc:Array = screenSize();
            var m:String = "Palco: " + stage.stageWidth + "x" + stage.stageHeight + " | tela " + sc[0] + "x" + sc[1] + " | escala " + stage.scaleMode;
            if (m != lastStageLog) { lastStageLog = m; log(m); }
        }

        // O jogo avisa que o palco mudou de tamanho (útil ao trocar de modo com o jogo aberto).
        // O jogo só posiciona alguns botões (ex.: "Explorar" no mapa dos arredores) quando recebe um RESIZE DEPOIS de montar
        // a interface. Avisar durante a montagem (v3.4/v3.5) estragou o mapa, então os avisos são poucos e espaçados
        // (3, 8, 16 e 30 s depois do jogo carregar ou de ele trocar a escala), que é o que o seu "mudar a resolução" fazia.
        private var kickGen:int = 0;
        private var kickLogN:int = 0;
        private function scheduleKicks():void
        {
            if (!Prefs.fixLayout || !inGame) return;
            var gen:int = ++kickGen;
            for each (var d:int in [3000, 8000, 16000, 30000])
                setTimeout(function():void { if (gen == kickGen) kickResize(); }, d);
        }
        private function kickResize():void
        {
            if (!inGame || !stage) return;
            try { stage.dispatchEvent(new Event(Event.RESIZE)); } catch (err:Error) {}
            if (kickLogN < 12) { kickLogN++; log("Aviso de resize ao jogo (layout) #" + kickLogN); }
        }
        private function notifyResize():void
        {
            if (!inGame || !stage) return;
            try { stage.dispatchEvent(new Event(Event.RESIZE)); } catch (err:Error) { log("aviso de resize: " + err.message); }
            if (controls) controls.layout(sw(), uiScale(), sh());
        }

        // O botão da engrenagem fica no palco (stage), por cima de tudo, e é trazido para a
        // frente de tempos em tempos: o jogo adiciona janelas no palco e o cobria.
        private function keepOnTop(e:TimerEvent):void
        {
            if (!controls || !stage) return;
            try
            {
                if (stage.scaleMode != wantedScaleMode())
                {
                    log("Escala foi alterada para " + stage.scaleMode + "; restaurando.");
                    applyResolution();
                    scheduleKicks();
                }
                if (controls.parent != stage) stage.addChild(controls);
                else if (stage.getChildIndex(controls) != stage.numChildren - 1) stage.setChildIndex(controls, stage.numChildren - 1);
                // só reposiciona a engrenagem se o tamanho da tela mudou (antes mexia na lista de exibição a cada tick)
                if (sw() != topW || sh() != topH) { topW = sw(); topH = sh(); controls.layout(topW, uiScale(), topH); }
                if (macroPanel && macroPanel.parent == stage && stage.getChildIndex(macroPanel) != stage.numChildren - 1)
                    stage.setChildIndex(macroPanel, stage.numChildren - 1);
                if (sliderPanel && sliderPanel.parent == stage && stage.getChildIndex(sliderPanel) != stage.numChildren - 1)
                    stage.setChildIndex(sliderPanel, stage.numChildren - 1);
            }
            catch (err:Error) {}
        }

        // ---------- sair do app / segundo plano ----------
        private function onKey(e:KeyboardEvent):void
        {
            if (e.keyCode != Keyboard.BACK) return;
            e.preventDefault();
            e.stopImmediatePropagation();
            if (renamePanel != null) { closeRename(); return; }
            askExit();
        }

        private function askExit():void
        {
            menuMode = M_EXIT;
            bridge.showMenu("Sair do app", ["Deixar o jogo aberto em segundo plano", "Fechar o app de vez", "Cancelar"]);
        }

        // ---------- zoom ----------
        private function zoomBy(delta:Number):void
        {
            zoomLevel = Math.max(0.5, Math.min(2, zoomLevel + delta));
            Prefs.zoom = zoomLevel;
            applyZoom();
        }
        // ---------- barra de resolução personalizada ----------
        private var sliderPanel:SliderPanel;
        private function openSlider():void
        {
            closeSlider();
            var ratio:Number = baseRatio();
            sliderPanel = new SliderPanel("Resolução personalizada", CUSTOM_MIN, CUSTOM_MAX, 10, customH(),
                function(h:int):String { return Math.round(h * ratio) + " x " + h; },
                "menor = itens maiores | maior = mais área do jogo",
                applySlider, closeSlider);
            sliderPanel.scaleX = sliderPanel.scaleY = uiScale();
            sliderPanel.x = sw() / 2;
            sliderPanel.y = sh() / 2;
            stage.addChild(sliderPanel);
        }
        private function closeSlider():void
        {
            if (sliderPanel && sliderPanel.parent) sliderPanel.parent.removeChild(sliderPanel);
            sliderPanel = null;
        }
        private function applySlider(h:int):void
        {
            closeSlider();
            Prefs.customH = h;
            Prefs.resHeight = RES_CUSTOM;
            log("Resolução personalizada: " + virtW(h) + "x" + h);
            applyResolution();
            setTimeout(function():void { verifyVirtual(true); }, 900);
            if (!inGame) showHome();
        }
        private function applyZoom():void
        {
            if (!gameLoader) return;
            gameLoader.scaleX = gameLoader.scaleY = zoomLevel;
        }

        // ---------- cache do Loading.swf (TTL em disco) ----------
        private function cacheDir():File
        {
            var d:File = File.applicationStorageDirectory.resolvePath("cache");
            if (!d.exists) d.createDirectory();
            return d;
        }
        private function cacheFile():File { return cacheDir().resolvePath("Loading.swf"); }

        private function cacheSizeText():String
        {
            var n:Number = SwfFixer.cacheSize();
            if (n <= 0) return "vazio";
            if (n >= 1048576) return (Math.round(n / 104857.6) / 10) + " MB";
            return Math.round(n / 1024) + " KB";
        }
        private function clearCache():void
        {
            SwfFixer.clearCache();
            log("Cache apagado.");
        }
        private function saveCache(b:ByteArray):void
        {
            try {
                var fs:FileStream = new FileStream();
                fs.open(cacheFile(), FileMode.WRITE);
                fs.writeBytes(b); fs.close();
            } catch (err:Error) { log("Falha ao salvar cache: " + err.message); }
        }
        private function readCacheIfFresh():ByteArray
        {
            var f:File = cacheFile();
            if (!f.exists) return null;
            if (new Date().time - f.modificationDate.time > CACHE_TTL_MS) return null;
            return readFile(f);
        }

        private function readFile(f:File):ByteArray
        {
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.READ);
            var ba:ByteArray = new ByteArray();
            fs.readBytes(ba); fs.close();
            return ba;
        }

        // ---------- sessão recebida do ANE ----------
        private function onGame(e:StatusEvent):void
        {
            try { session = JSON.parse(e.level); }
            catch (err:Error) { setStatus("Resposta de login inválida."); return; }
            saveSessionAccount();
            enterGame();
        }

        // Guarda a sessão capturada como uma conta (uma por servidor + usuário; atualiza se já existir).
        private function saveSessionAccount():void
        {
            try
            {
                var u:String = String(session.user != undefined ? session.user : (session.params ? session.params.user : ""));
                if (u == "" || u == "undefined") return;
                var ck:String = session.cookies != undefined ? JSON.stringify(session.cookies) : "";
                var old:Object = findAccount(platformIdx + ":" + u);
                Prefs.saveAccount({
                    id: platformIdx + ":" + u, name: u, label: (old != null && old.label != undefined ? String(old.label) : ""), platform: platformIdx, host: String(Platforms.LIST[platformIdx][1]),
                    session: JSON.stringify(session), cookies: (ck != "" ? ck : (old != null ? String(old.cookies) : "")),
                    savedAt: new Date().time
                });
                log("Conta salva: " + u + " (" + serverName(platformIdx) + ")");
            }
            catch (err:Error) { log("Não consegui salvar a conta: " + err.message); }
        }

        private function enterGame():void
        {
            applyResolution();   // o login pausa/recria a tela do app: reaplica a resolução
            port = bridge.startServer(session.host);
            if (port <= 0) { setStatus("Falha ao iniciar servidor local."); return; }
            bridge.keepAlive(true);
            setStatus("Baixando o jogo...");
            fbIndex = 0;
            fetchSwf();
        }

        // 1) servidor (via proxy local, tentando vários caminhos)  2) cache  3) reservas empacotadas
        private function fetchSwf():void
        {
            swfCandidates = [];
            if (session.swf) swfCandidates.push(String(session.swf));
            swfCandidates.push("/client/Loading.swf");
            swfCandidates.push("/Loading.swf");
            swfIdx = 0;
            log("Sessão: host=" + session.host + " swf=" + (session.swf ? session.swf : "(nenhum)") + " porta=" + port);
            tryServer();
        }

        private function isSwf(b:ByteArray):Boolean
        {
            if (b.length < 3) return false;
            var h:String = String.fromCharCode(b[0], b[1], b[2]);
            return h == "FWS" || h == "CWS" || h == "ZWS";
        }

        private function tryServer():void
        {
            if (swfIdx >= swfCandidates.length)
            {
                log("Servidor não respondeu; usando a cópia do app.");
                launchWith(0);
                return;
            }
            var path:String = String(swfCandidates[swfIdx++]);
            log("Tentando https://" + session.host + path);
            var code:int = 0;
            var l:URLLoader = new URLLoader();
            l.dataFormat = URLLoaderDataFormat.BINARY;
            l.addEventListener(HTTPStatusEvent.HTTP_STATUS, function(ev:HTTPStatusEvent):void { code = ev.status; });
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var b:ByteArray = ByteArray(l.data);
                log("Recebido " + b.length + " bytes (HTTP " + code + ")");
                if (!isSwf(b)) { log("A resposta não é um SWF."); tryServer(); return; }
                okPath = path;
                launchWith(b.length);
            });
            l.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                log("Falhou (HTTP " + code + "): " + ev.text);
                tryServer();
            });
            l.load(new URLRequest("http://127.0.0.1:" + port + path));
        }

        // O Loading.swf do servidor NÃO é executado: serve só para saber a versão (pelo tamanho).
        // Quem roda é a cópia modificada que vem no app (assets/game), a mesma versão do servidor.
        private function launchWith(serverLen:int):void
        {
            var name:String = "assets/game/Loading.swf";
            if (serverLen > 0 && serverLen != BRAZIL_LEN)
            {
                var alt:String = "assets/game/Loading_" + serverLen + ".swf";
                if (File.applicationDirectory.resolvePath(alt).exists)
                {
                    name = alt;
                    log("Versão deste servidor: " + serverLen + " bytes (cópia própria no app)");
                }
                else
                {
                    log("AVISO: a versão do Loading.swf deste servidor (" + serverLen + " bytes) não está no app. Usando a do Brasil.");
                }
            }
            else if (serverLen == BRAZIL_LEN)
            {
                log("Versão deste servidor: a mesma do Brasil");
            }
            var f:File = File.applicationDirectory.resolvePath(name);
            if (!f.exists)
            {
                setStatus("Faltam os arquivos do jogo no app (" + name + "). Toque em Ver log.");
                return;
            }
            setStatus("Carregando o jogo...");
            startGame(readFile(f));
        }

        private function startGame(bytes:ByteArray):void
        {
            inGame = true;
            drawBg();
            while (ui.numChildren) ui.removeChildAt(0);
            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;
            var p:String = okPath;
            var qi:int = p.indexOf("?");
            if (qi >= 0) p = p.substring(0, qi);
            var dir:String = "https://" + session.host + p.substring(0, p.lastIndexOf("/") + 1);
            var params:Object = {};
            for each (var pn:String in ["user", "key", "site", "p2", "rid", "logintype"])
            {
                if (session.params && session.params[pn] != undefined) params[pn] = String(session.params[pn]);
            }
            params["http"] = "https:";
            params["config"] = dir + "config.xml";
            params["base"] = dir;
            log("Jogo: " + bytes.length + " bytes | config " + params["config"]);
            applyResolution();
            ctx.parameters = params;
            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                SwfFixer.gameDomain = gameLoader.contentLoaderInfo.applicationDomain;
                applyResolution();
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, function(ev:Event):void {
                zoomLevel = 1; Prefs.zoom = 1;
                addChild(gameLoader);
                applyZoom();
                controls = new Controls(openSettings, openMacros);
                controls.layout(sw(), uiScale(), sh());
                topW = sw(); topH = sh();
                stage.addChild(controls);
                scheduleKicks();
                if (topTimer) topTimer.stop();
                topTimer = new Timer(1000);
                topTimer.addEventListener(TimerEvent.TIMER, keepOnTop);
                topTimer.start();
                log("Jogo carregado.");
            });
            gameLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                inGame = false; gameLoader = null; drawBg(); showHome(); setStatus("Falha ao carregar o jogo.");
            });
            gameLoader.loadBytes(bytes, ctx);
        }
    }
}
