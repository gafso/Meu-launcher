package
{
    import flash.desktop.NativeApplication;
    import flash.display.Loader;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.events.UncaughtErrorEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.net.URLLoader;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.system.ApplicationDomain;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.utils.ByteArray;

    public class Main extends Sprite
    {
        // Reservas empacotadas (você coloca os SEUS arquivos em assets/game/).
        private static const FALLBACKS:Array = [
            "assets/game/Loading.swf",
            "assets/game/Loading_270767.swf",
            "assets/game/Loading_245292.swf",
            "assets/game/Loading_243852.swf",
            "assets/game/Loading_234741.swf"
        ];
        private static const CACHE_TTL_MS:Number = 6 * 60 * 60 * 1000;   // 6 h

        // Modos do menu nativo (o evento "menu" é compartilhado).
        private static const M_PLATFORM:String = "platform";
        private static const M_SETTINGS:String = "settings";
        private static const M_QUALITY:String  = "quality";
        private static const M_FPS:String      = "fps";
        private static const M_CACHE:String    = "cache";

        private var bridge:Bridge;
        private var lastStatus:String = "";
        private var inGame:Boolean = false;
        private var platformIdx:int = 0;
        private var ui:Sprite = new Sprite();
        private var status:TextField;
        private var session:Object;
        private var port:int;
        private var fbIndex:int = 0;
        private var gameLoader:Loader;
        private var controls:Controls;
        private var menuMode:String = M_PLATFORM;
        private var logLines:Array = [];
        private var zoomLevel:Number = 1;

        public function Main()
        {
            try { init(); }
            catch (err:Error) { fatal(String(err.message) + stackOf(err)); }
        }

        private function init():void
        {
            if (loaderInfo && loaderInfo.uncaughtErrorEvents)
                loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR, onUncaught);
            stage.align = StageAlign.TOP_LEFT;
            stage.scaleMode = StageScaleMode.NO_SCALE;
            drawBg();
            bridge = new Bridge();
            platformIdx = Math.min(Prefs.platform, Platforms.LIST.length - 1);
            applyDisplayPrefs();
            addChild(ui);
            bridge.addEventListener("game", onGame);
            bridge.addEventListener("menu", onMenu);
            bridge.addEventListener("error", onError);
            log("Launcher iniciado. ANE: " + (bridge.available ? "ok" : "ausente"));
            stage.addEventListener(Event.RESIZE, onResize);
            showHome();
        }

        // Em alguns aparelhos o stage começa com tamanho 0; usa o tamanho real da tela nesse caso.
        private function sw():Number { return stage.stageWidth > 0 ? stage.stageWidth : stage.fullScreenWidth; }
        private function sh():Number { return stage.stageHeight > 0 ? stage.stageHeight : stage.fullScreenHeight; }

        private function drawBg():void
        {
            graphics.clear();
            graphics.beginFill(0x14181F);
            graphics.drawRect(0, 0, Math.max(sw(), 4096), Math.max(sh(), 4096));
            graphics.endFill();
        }

        private function onResize(e:Event):void
        {
            drawBg();
            if (!inGame) showHome();
            else if (controls) controls.layout(sw());
        }

        private function stackOf(err:Error):String
        {
            var st:String = err.getStackTrace();
            return st ? "\n" + st : "";
        }

        private function onUncaught(e:UncaughtErrorEvent):void
        {
            var m:String = (e.error is Error) ? (Error(e.error).message + stackOf(Error(e.error))) : String(e.error);
            log("ERRO: " + m);
            if (!inGame) { e.preventDefault(); fatal(m); }
        }

        // Mostra o erro na tela (fundo amarelo) em vez de ficar branco sem explicação.
        private function fatal(msg:String):void
        {
            try
            {
                var tf:TextField = new TextField();
                tf.defaultTextFormat = new TextFormat("_sans", 22, 0x000000);
                tf.background = true; tf.backgroundColor = 0xFFEE00;
                tf.multiline = true; tf.wordWrap = true;
                tf.x = 20; tf.y = 20;
                tf.width = Math.max(300, sw() - 40);
                tf.text = "ERRO NO LAUNCHER:\n" + msg;
                addChild(tf);
            }
            catch (e2:Error) {}
        }

        // ---------- log ----------
        public function log(s:String):void
        {
            var d:Date = new Date();
            logLines.push(pad(d.hours) + ":" + pad(d.minutes) + ":" + pad(d.seconds) + "  " + s);
            if (logLines.length > 200) logLines.shift();
        }
        private function pad(n:int):String { return n < 10 ? "0" + n : String(n); }

        // ---------- preferências de exibição ----------
        private function applyDisplayPrefs():void
        {
            stage.quality = Prefs.quality;     // StageQuality.LOW / MEDIUM / HIGH
            stage.frameRate = Prefs.fps;
        }

        // ---------- UI inicial ----------
        private function showHome():void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            var cx:Number = sw() / 2;
            addLabel("Meu Launcher", cx, 80, 36);
            addButton("Plataforma: " + Platforms.LIST[platformIdx][0], cx, 200, chooseTapped);
            addButton("JOGAR", cx, 300, playTapped);
            addButton("Sair da conta", cx, 400, logoutTapped);
            status = addLabel(lastStatus != "" ? lastStatus : (bridge.available ? "" : "ANE não encontrado (rodando fora do Android?)"), cx, 500, 18);
            addLabel("v1.1", cx, 580, 14);
        }

        private function addLabel(t:String, x:Number, y:Number, size:int):TextField
        {
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", size, 0xFFFFFF, true, null, null, null, null, "center");
            tf.width = 600; tf.x = x - 300; tf.y = y; tf.text = t;
            tf.selectable = false; tf.autoSize = "center"; tf.x = x - tf.width / 2;
            ui.addChild(tf);
            return tf;
        }

        private function addButton(t:String, x:Number, y:Number, fn:Function):void
        {
            var b:Sprite = new Sprite();
            b.graphics.beginFill(0x2D6CDF); b.graphics.drawRoundRect(-220, 0, 440, 70, 16); b.graphics.endFill();
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 22, 0xFFFFFF, true, null, null, null, null, "center");
            tf.width = 440; tf.x = -220; tf.y = 18; tf.text = t; tf.mouseEnabled = false;
            b.addChild(tf); b.x = x; b.y = y; b.addEventListener(MouseEvent.CLICK, fn);
            ui.addChild(b);
        }

        private function setStatus(s:String):void { lastStatus = s; if (status) status.text = s; log(s); }

        // ---------- ações da tela inicial ----------
        private function chooseTapped(e:MouseEvent):void { openPlatformMenu(); }

        private function openPlatformMenu():void
        {
            var names:Array = [];
            for each (var p:Array in Platforms.LIST) names.push(p[0]);
            menuMode = M_PLATFORM;
            bridge.showMenu("Escolha a plataforma", names);
        }

        private function playTapped(e:MouseEvent):void
        {
            setStatus("Abrindo login...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        private function logoutTapped(e:MouseEvent):void { logout(); }

        private function logout():void
        {
            bridge.clearSession();
            setStatus("Sessão apagada.");
        }

        private function onError(e:StatusEvent):void { setStatus("Erro: " + e.level); }

        // ---------- menu nativo (um evento só, roteado por menuMode) ----------
        private function onMenu(e:StatusEvent):void
        {
            var i:int = int(e.level);
            switch (menuMode)
            {
                case M_PLATFORM:
                    if (i >= 0 && i < Platforms.LIST.length)
                    {
                        platformIdx = i; Prefs.platform = i;
                        if (gameLoader) { bridge.restartApp(); } else { showHome(); }
                    }
                    break;
                case M_SETTINGS: onSettingsChoice(i); break;
                case M_QUALITY:
                    Prefs.quality = ["LOW", "MEDIUM", "HIGH"][i];
                    applyDisplayPrefs(); log("Qualidade: " + Prefs.quality);
                    break;
                case M_FPS:
                    Prefs.fps = [15, 24, 30, 60][i];
                    applyDisplayPrefs(); log("FPS: " + Prefs.fps);
                    break;
                case M_CACHE:
                    if (i == 0) clearCache();
                    break;
            }
        }

        private function openSettings():void
        {
            menuMode = M_SETTINGS;
            bridge.showMenu("Configurações", [
                "Qualidade gráfica (" + Prefs.quality + ")",
                "FPS (" + Prefs.fps + ")",
                "Controles na tela: " + (Prefs.controls ? "ligados" : "desligados"),
                "Cache do jogo",
                "Mostrar log",
                "Trocar plataforma",
                "Sair da conta",
                "Reiniciar o app",
                "Sair do app"
            ]);
        }

        private function onSettingsChoice(i:int):void
        {
            switch (i)
            {
                case 0: menuMode = M_QUALITY; bridge.showMenu("Qualidade gráfica", ["Baixa", "Média", "Alta"]); break;
                case 1: menuMode = M_FPS;     bridge.showMenu("FPS", ["15", "24", "30", "60"]); break;
                case 2:
                    Prefs.controls = !Prefs.controls;
                    if (controls) controls.visibleBar = Prefs.controls;
                    break;
                case 3:
                    menuMode = M_CACHE;
                    bridge.showMenu("Cache do jogo (" + cacheSizeText() + ")", ["Apagar cache", "Voltar"]);
                    break;
                case 4: bridge.showText("Log", logLines.join("\n")); break;
                case 5: openPlatformMenu(); break;
                case 6: logout(); break;
                case 7: bridge.restartApp(); break;
                case 8: bridge.keepAlive(false); NativeApplication.nativeApplication.exit(); break;
            }
        }

        // ---------- zoom ----------
        private function zoomBy(delta:Number):void
        {
            zoomLevel = Math.max(0.5, Math.min(2, zoomLevel + delta));
            Prefs.zoom = zoomLevel;
            applyZoom();
        }
        private function applyZoom():void
        {
            if (!gameLoader) return;
            gameLoader.scaleX = gameLoader.scaleY = zoomLevel;
        }

        // ---------- cache do Loading.swf (TTL em disco) ----------
        private function cacheDir():File
        {
            var d:File = File.applicationStorageDirectory.resolvePath("cache");
            if (!d.exists) d.createDirectory();
            return d;
        }
        private function cacheFile():File { return cacheDir().resolvePath("Loading.swf"); }

        private function cacheSizeText():String
        {
            var f:File = cacheFile();
            if (!f.exists) return "vazio";
            return Math.round(f.size / 1024) + " KB";
        }
        private function clearCache():void
        {
            var f:File = cacheFile();
            if (f.exists) f.deleteFile();
            log("Cache apagado.");
        }
        private function saveCache(b:ByteArray):void
        {
            try {
                var fs:FileStream = new FileStream();
                fs.open(cacheFile(), FileMode.WRITE);
                fs.writeBytes(b); fs.close();
            } catch (err:Error) { log("Falha ao salvar cache: " + err.message); }
        }
        private function readCacheIfFresh():ByteArray
        {
            var f:File = cacheFile();
            if (!f.exists) return null;
            if (new Date().time - f.modificationDate.time > CACHE_TTL_MS) return null;
            return readFile(f);
        }

        private function readFile(f:File):ByteArray
        {
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.READ);
            var ba:ByteArray = new ByteArray();
            fs.readBytes(ba); fs.close();
            return ba;
        }

        // ---------- sessão recebida do ANE ----------
        private function onGame(e:StatusEvent):void
        {
            try { session = JSON.parse(e.level); }
            catch (err:Error) { setStatus("Resposta de login inválida."); return; }

            port = bridge.startServer(session.host);
            if (port <= 0) { setStatus("Falha ao iniciar servidor local."); return; }
            bridge.keepAlive(true);
            setStatus("Baixando o jogo...");
            fbIndex = 0;
            fetchSwf();
        }

        // 1) servidor (via proxy local)  2) cache  3) reservas empacotadas
        private function fetchSwf():void
        {
            var path:String = session.swf ? String(session.swf) : "/Loading.swf";
            var l:URLLoader = new URLLoader();
            l.dataFormat = URLLoaderDataFormat.BINARY;
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var b:ByteArray = ByteArray(l.data);
                saveCache(b);
                startGame(b);
            });
            l.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                log("Servidor não entregou o Loading.swf: " + ev.text);
                var c:ByteArray = readCacheIfFresh();
                if (c) { log("Usando cache."); startGame(c); } else { tryFallback(); }
            });
            l.load(new URLRequest("http://127.0.0.1:" + port + path));
        }

        private function tryFallback():void
        {
            while (fbIndex < FALLBACKS.length)
            {
                var f:File = File.applicationDirectory.resolvePath(FALLBACKS[fbIndex++]);
                if (f.exists)
                {
                    setStatus("Usando reserva: " + f.name);
                    startGame(readFile(f));
                    return;
                }
            }
            setStatus("Não consegui obter o Loading.swf (servidor, cache e reservas falharam).");
        }

        private function startGame(bytes:ByteArray):void
        {
            inGame = true;
            while (ui.numChildren) ui.removeChildAt(0);
            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain());
            ctx.allowCodeImport = true;
            ctx.parameters = session.params;   // user, key, site, p2, rid, logintype...
            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, function(ev:Event):void {
                zoomLevel = Prefs.zoom;
                addChild(gameLoader);
                applyZoom();
                controls = new Controls(openSettings, zoomBy);
                controls.visibleBar = Prefs.controls;
                controls.layout(sw());
                addChild(controls);
                log("Jogo carregado.");
            });
            gameLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                inGame = false; gameLoader = null; showHome(); setStatus("Falha ao carregar o jogo.");
            });
            gameLoader.loadBytes(bytes, ctx);
        }
    }
}
