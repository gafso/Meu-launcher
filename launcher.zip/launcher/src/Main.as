package
{
    import com.meulauncher.air.Bridge;
    import flash.desktop.NativeApplication;
    import flash.desktop.SystemIdleMode;
    import flash.display.Bitmap;
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Loader;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.HTTPStatusEvent;
    import flash.events.IOErrorEvent;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.events.TimerEvent;
    import flash.events.UncaughtErrorEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.filters.DropShadowFilter;
    import flash.geom.Matrix;
    import flash.geom.Rectangle;
    import flash.net.URLLoader;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.system.ApplicationDomain;
    import flash.system.Capabilities;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.ui.Keyboard;
    import flash.utils.ByteArray;
    import flash.utils.Timer;
    import flash.utils.setTimeout;

    [SWF(width="1250", height="650", frameRate="30", backgroundColor="#080304")]
    public class Main extends Sprite
    {
        // Reservas empacotadas (você coloca os SEUS arquivos em assets/game/).
        private static const FALLBACKS:Array = [
            "assets/game/Loading.swf",
            "assets/game/Loading_270767.swf",
            "assets/game/Loading_245292.swf",
            "assets/game/Loading_243852.swf",
            "assets/game/Loading_234741.swf"
        ];
        private static const CACHE_TTL_MS:Number = 6 * 60 * 60 * 1000;   // 6 h
        private static const BG_TOP:uint = 0x080304;      // fundo: topo do degradê
        private static const BG_BOTTOM:uint = 0x1A0608;   // fundo: base do degradê
        private static const VERSION:String = "v2.6";

        // Modos do menu nativo (o evento "menu" é compartilhado).
        private static const M_PLATFORM:String = "platform";
        private static const M_SETTINGS:String = "settings";
        private static const M_QUALITY:String  = "quality";
        private static const M_FPS:String      = "fps";
        private static const M_CACHE:String    = "cache";
        private static const M_RES:String      = "res";
        private static const M_EXIT:String     = "exit";
        private static const M_FONT:String     = "font";
        // Resolução do jogo. 0 = nativa da tela; 100000+n = tamanho fixo "Modo PC" (RES_FIXED[n]),
        // centralizado com barras pretas se a proporção da tela for diferente.
        // O jogo foi feito para ~1250x650: abaixo disso as janelas dele ficam cortadas.
        private static const RES_BASE:int = 100000;
        // 200000+n = resolução "virtual" (RES_VIRT[n]): tenta dar ao palco exatamente esse tamanho
        // (SHOW_ALL) e confere o resultado; se o AIR não aceitar, volta ao Modo PC (ver verifyVirtual).
        private static const RES_VIRT_BASE:int = 200000;
        private static const RES_OPTIONS:Array = [100000, 200000, 200001, 0];
        private static const RES_FIXED:Array = [[1250, 650]];
        private static const RES_VIRT:Array = [[1920, 1080, "Full HD"], [2560, 1440, "2K"]];
        private static const FPS_OPTIONS:Array = [15, 24, 30, 60, 120];
        // Fontes do sistema Android (não precisam de arquivo). Se a fonte não existir no aparelho,
        // o Android usa a padrão. [nome no menu, nome da fonte]
        private static const FONTS:Array = [
            ["Padrão do jogo", ""],
            ["Sans-serif (sistema)", "_sans"],
            ["Serif (sistema)", "_serif"],
            ["Monoespaçada", "_typewriter"],
            ["Roboto", "Roboto"],
            ["Roboto Condensed", "Roboto Condensed"],
            ["Noto Serif", "Noto Serif"],
            ["Dancing Script (cursiva)", "Dancing Script"],
            ["Coming Soon (casual)", "Coming Soon"]
        ];

        private var bridge:Bridge;
        private var lastStatus:String = "";
        private var inGame:Boolean = false;
        private var platformIdx:int = 0;
        private var ui:Sprite = new Sprite();
        private var status:TextField;
        private var session:Object;
        private var port:int;
        private var fbIndex:int = 0;
        private var swfCandidates:Array = [];
        private var swfIdx:int = 0;
        private var okPath:String = "/client/Loading.swf";
        private static const BRAZIL_LEN:int = 244783;   // tamanho do Loading.swf do servidor do Brasil
        private var gameLoader:Loader;
        private var controls:Controls;
        private var menuMode:String = M_PLATFORM;
        private var logLines:Array = [];
        private var zoomLevel:Number = 1;
        private var topTimer:Timer;
        private var fontTimer:Timer;
        private var bgLayer:Sprite = new Sprite();   // imagem de fundo + sombra (abaixo da UI)
        private var bgBmp:Bitmap;
        private var shade:Shape = new Shape();
        private var lastW:Number = -1;
        private var lastH:Number = -1;

        public function Main()
        {
            try { init(); }
            catch (err:Error) { fatal(String(err.message) + stackOf(err)); }
        }

        private function init():void
        {
            if (loaderInfo && loaderInfo.uncaughtErrorEvents)
                loaderInfo.uncaughtErrorEvents.addEventListener(UncaughtErrorEvent.UNCAUGHT_ERROR, onUncaught);
            applyResolution();
            drawBg();
            bridge = new Bridge();
            SwfFixer.logger = log;
            SwfFixer.install();
            try { SwfFixer.modsPath = bridge.modsPath(); } catch (eMods:Error) {}
            try
            {
                var mdir:File = new File(SwfFixer.modsPath);
                var mn:int = 0;
                var sub:String = "";
                if (SwfFixer.modsPath != "" && mdir.exists)
                    for each (var mf0:File in mdir.getDirectoryListing())
                    {
                        if (mf0.isDirectory)
                            sub += " | " + mf0.name + "/: " + mf0.getDirectoryListing().length + " arquivo(s)";
                        else if (mf0.name.indexOf("_pedidos") != 0) mn++;
                    }
                log("Mods: pasta=" + (SwfFixer.modsPath != "" ? SwfFixer.modsPath : "(indisponível)") + " | raiz: " + mn + " arquivo(s)" + sub);
            }
            catch (eMods2:Error) { log("Mods: erro ao ler a pasta (" + eMods2.message + ")"); }
            SwfFixer.pruneOld();
            // Sem isto o AIR congela o jogo quando você sai do app (jogo desconecta).
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.KEEP_AWAKE; } catch (eIdle:Error) {}
            try { NativeApplication.nativeApplication["executeInBackground"] = true; } catch (eBg:Error) { log("segundo plano: " + eBg.message); }
            stage.addEventListener(KeyboardEvent.KEY_DOWN, onKey, false, 100);
            platformIdx = Math.min(Prefs.platform, Platforms.LIST.length - 1);
            applyDisplayPrefs();
            bgLayer.addChild(shade);
            addChild(bgLayer);
            loadBgImage();
            drawBg();
            addChild(ui);
            bridge.addEventListener("game", onGame);
            bridge.addEventListener("menu", onMenu);
            bridge.addEventListener("error", onError);
            log("Launcher iniciado. ANE: " + (bridge.available ? "ok" : "ausente (" + bridge.initError + ")"));
            stage.addEventListener(Event.RESIZE, onResize);
            applyResolution();
            applyDisplayPrefs();
            if (isVirtual()) setTimeout(function():void { verifyVirtual(false); }, 1500);
            showHome();
        }

        // Em alguns aparelhos o stage começa com tamanho 0; usa o tamanho real da tela nesse caso.
        private function sw():Number { return stage.stageWidth > 0 ? stage.stageWidth : stage.fullScreenWidth; }
        // Botões maiores em telas de muitos pixels (e menores se a resolução do jogo for reduzida).
        private function uiScale():Number { return Math.max(1, Math.min(2.5, sh() / 650)); }
        private function sh():Number { return stage.stageHeight > 0 ? stage.stageHeight : stage.fullScreenHeight; }

        // Fundo base (degradê preto/vinho). Fora do palco (barras do Modo PC) as cores
        // continuam iguais às pontas do degradê, então não aparece emenda.
        private function drawBg():void
        {
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            var g:Graphics = graphics;
            g.clear();
            g.beginFill(BG_TOP);    g.drawRect(-4096, -4096, w + 8192, 4096); g.endFill();
            g.beginFill(BG_BOTTOM); g.drawRect(-4096, h, w + 8192, 4096);     g.endFill();
            var m:Matrix = new Matrix();
            m.createGradientBox(w + 8192, h, Math.PI / 2, -4096, 0);
            g.beginGradientFill(GradientType.LINEAR, [BG_TOP, BG_BOTTOM], [1, 1], [0, 255], m);
            g.drawRect(-4096, 0, w + 8192, h); g.endFill();
            m = new Matrix();
            m.createGradientBox(w * 1.1, h * 1.3, 0, w * 0.3 - w * 0.55, h * 0.45 - h * 0.65);
            g.beginGradientFill(GradientType.RADIAL, [0xB3121B, 0xB3121B], [0.28, 0], [0, 255], m);
            g.drawRect(0, 0, w, h); g.endFill();
            layoutBg();
        }

        // Carrega a imagem de fundo empacotada no app (assets/fundo.jpg).
        private function loadBgImage():void
        {
            try
            {
                var l:Loader = new Loader();
                l.contentLoaderInfo.addEventListener(Event.COMPLETE, function(e:Event):void {
                    try
                    {
                        bgBmp = Bitmap(l.content);
                        bgBmp.smoothing = true;
                        bgLayer.addChildAt(bgBmp, 0);
                        layoutBg();
                    }
                    catch (e2:Error) { log("Fundo: " + e2.message); }
                });
                l.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(e:IOErrorEvent):void { log("Fundo: " + e.text); });
                l.load(new URLRequest("app:/assets/fundo.jpg"));
            }
            catch (err:Error) { log("Fundo: " + err.message); }
        }

        // A imagem preenche a tela toda (sem distorcer, cortando o excesso) e recebe uma sombra
        // mais escura à esquerda, onde ficam os botões, para o texto ficar legível.
        private function layoutBg():void
        {
            var w:Number = Math.max(sw(), 1);
            var h:Number = Math.max(sh(), 1);
            bgLayer.scrollRect = new Rectangle(0, 0, w, h);   // não vaza para as barras do Modo PC
            if (bgBmp && bgBmp.bitmapData)
            {
                var sc:Number = Math.max(w / bgBmp.bitmapData.width, h / bgBmp.bitmapData.height);
                bgBmp.scaleX = bgBmp.scaleY = sc;
                bgBmp.x = (w - bgBmp.bitmapData.width * sc) / 2;
                bgBmp.y = (h - bgBmp.bitmapData.height * sc) / 2;
            }
            var g:Graphics = shade.graphics;
            g.clear();
            var m:Matrix = new Matrix();
            m.createGradientBox(w * 0.78, h, 0, 0, 0);
            g.beginGradientFill(GradientType.LINEAR, [0x050102, 0x050102, 0x050102], [0.82, 0.55, 0], [0, 120, 255], m);
            g.drawRect(0, 0, w, h); g.endFill();
            m = new Matrix();
            m.createGradientBox(w, h, Math.PI / 2, 0, 0);
            g.beginGradientFill(GradientType.LINEAR, [0x000000, 0x000000], [0, 0.55], [140, 255], m);
            g.drawRect(0, 0, w, h); g.endFill();
        }

        private function onResize(e:Event):void
        {
            if (sw() == lastW && sh() == lastH) return;
            lastW = sw(); lastH = sh();
            drawBg();
            if (!inGame) showHome();
            else if (controls) controls.layout(sw(), uiScale());
        }

        private function stackOf(err:Error):String
        {
            var st:String = err.getStackTrace();
            return st ? "\n" + st : "";
        }

        private function onUncaught(e:UncaughtErrorEvent):void
        {
            var m:String = (e.error is Error) ? (Error(e.error).message + stackOf(Error(e.error))) : String(e.error);
            log("ERRO: " + m);
            if (!inGame) { e.preventDefault(); fatal(m); }
        }

        // Mostra o erro na tela (fundo amarelo) em vez de ficar branco sem explicação.
        private function fatal(msg:String):void
        {
            try
            {
                var tf:TextField = new TextField();
                tf.defaultTextFormat = new TextFormat("_sans", 22, 0x000000);
                tf.background = true; tf.backgroundColor = 0xFFEE00;
                tf.multiline = true; tf.wordWrap = true;
                tf.x = 20; tf.y = 20;
                tf.width = Math.max(300, sw() - 40);
                tf.text = "ERRO NO LAUNCHER:\n" + msg;
                addChild(tf);
            }
            catch (e2:Error) {}
        }

        // ---------- log ----------
        public function log(s:String):void
        {
            var d:Date = new Date();
            logLines.push(pad(d.hours) + ":" + pad(d.minutes) + ":" + pad(d.seconds) + "  " + s);
            if (logLines.length > 200) logLines.shift();
        }
        private function pad(n:int):String { return n < 10 ? "0" + n : String(n); }

        // ---------- preferências de exibição ----------
        private function applyDisplayPrefs():void
        {
            stage.quality = Prefs.quality;     // StageQuality.LOW / MEDIUM / HIGH
            stage.frameRate = Prefs.fps;
            // Pede à tela do aparelho a taxa mais próxima (60 / 90 / 120 Hz...).
            try { if (bridge && bridge.available) bridge.setRefreshRate(Prefs.fps); } catch (err:Error) {}
        }

        // Texto com a taxa de atualização real da tela (ex.: "120 Hz"), para o menu e o log.
        private function hzText():String
        {
            try
            {
                var hz:Number = (bridge && bridge.available) ? bridge.displayHz() : 0;
                if (hz > 0) return Math.round(hz) + " Hz";
            }
            catch (err:Error) {}
            return "? Hz";
        }

        // ---------- UI inicial ----------
        // Painel translúcido à esquerda (a personagem da imagem fica livre à direita).
        // Layout desenhado numa área de ~440x480 e escalado para caber em qualquer tela.
        private function showHome():void
        {
            while (ui.numChildren) ui.removeChildAt(0);
            var s:Number = Math.max(0.55, Math.min(sh() / 540, sw() / 760, 2.5));
            var box:Sprite = new Sprite();
            box.scaleX = box.scaleY = s;
            var bx:Number = Math.max(sw() * 0.24, 220 * s + 16);
            box.x = bx;
            box.y = sh() / 2 - 4 * s;
            ui.addChild(box);

            // painel "vidro": preto translúcido com borda vermelha discreta
            var panel:Shape = new Shape();
            panel.graphics.lineStyle(1.2, 0xFF4A52, 0.28);
            panel.graphics.beginFill(0x050102, 0.62);
            panel.graphics.drawRoundRect(-220, -250, 440, 508, 28, 28);
            panel.graphics.endFill();
            box.addChild(panel);

            // detalhe vermelho acima do título
            var bar:Shape = new Shape();
            bar.graphics.beginFill(Btn.ACCENT, 1);
            bar.graphics.drawRoundRect(-18, -228, 36, 4, 4, 4);
            bar.graphics.endFill();
            bar.filters = [new DropShadowFilter(0, 90, Btn.ACCENT, 0.9, 10, 10, 1, 2)];
            box.addChild(bar);

            // título em duas cores: LEGEND (branco) + MOBILE (vermelho)
            var title:TextField = homeText(box, "LEGEND MOBILE", 30, 0xFFFFFF, -214, 5);
            title.setTextFormat(new TextFormat(null, null, Btn.ACCENT_LIGHT), 7, 13);
            homeText(box, "SELECIONE O SERVIDOR E ENTRE", 11, Btn.TEXT_MUTED, -168, 2);

            var card:Btn = new Btn(Btn.CARD, 396, 60, String(Platforms.LIST[platformIdx][0]), "SERVIDOR", chooseTapped);
            card.y = -96;
            box.addChild(card);

            var play:Btn = new Btn(Btn.PRIMARY, 396, 68, "JOGAR", "", playTapped);
            play.y = -8;
            box.addChild(play);

            var cfg:Btn = new Btn(Btn.GHOST, 396, 46, "Configurações  ·  resolução, FPS, fonte", "", settingsTapped);
            cfg.y = 62;
            box.addChild(cfg);

            var out:Btn = new Btn(Btn.GHOST, 192, 46, "Sair da conta", "", logoutTapped);
            out.x = -102; out.y = 118;
            box.addChild(out);
            var lg:Btn = new Btn(Btn.GHOST, 192, 46, "Ver log", "", logTapped);
            lg.x = 102; lg.y = 118;
            box.addChild(lg);

            status = new TextField();
            status.defaultTextFormat = new TextFormat("_sans", 14, 0xC8B0B2, true, null, null, null, null, "center");
            status.width = 396; status.height = 36; status.x = -198; status.y = 152;
            status.multiline = true; status.wordWrap = true;
            status.selectable = false; status.mouseEnabled = false;
            status.text = lastStatus != "" ? lastStatus : (bridge.available ? "" : "ANE indisponível: " + bridge.initError);
            paintStatus();
            box.addChild(status);

            // amostra da fonte escolhida (escrita com a própria fonte, para você ver como fica)
            if (Prefs.font != "")
            {
                var sample:TextField = new TextField();
                sample.defaultTextFormat = new TextFormat(Prefs.font, 16, Btn.TEXT_SOFT, true, null, null, null, null, "center");
                sample.width = 396; sample.height = 24; sample.x = -198; sample.y = 188;
                sample.selectable = false; sample.mouseEnabled = false;
                sample.text = "Aa Bb Cc 0123  " + fontLabel();
                box.addChild(sample);
            }

            // linha fina + rodapé
            var line:Shape = new Shape();
            line.graphics.beginFill(0xFFFFFF, 0.1);
            line.graphics.drawRect(-176, 220, 352, 1);
            line.graphics.endFill();
            box.addChild(line);
            homeText(box, "LEGEND MOBILE  \u00B7  " + VERSION, 11, 0x8A6A6E, 232, 2);

            // entrada suave: o painel desliza um pouco e aparece
            box.alpha = 0;
            box.x = bx - 28 * s;
            var f:int = 0;
            var tick:Function = function(ev:Event):void
            {
                f++;
                var t:Number = Math.min(f / 16, 1);
                var k:Number = 1 - Math.pow(1 - t, 3);
                box.alpha = k;
                box.x = bx - 28 * s * (1 - k);
                if (t >= 1) box.removeEventListener(Event.ENTER_FRAME, tick);
            };
            box.addEventListener(Event.ENTER_FRAME, tick);
        }

        private function homeText(box:Sprite, t:String, size:int, color:uint, y:Number, spacing:Number):TextField
        {
            var tf:TextField = new TextField();
            var f:TextFormat = new TextFormat("_sans", size, color, true, null, null, null, null, "center");
            f.letterSpacing = spacing;
            tf.defaultTextFormat = f;
            tf.autoSize = "left";
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            tf.x = -tf.width / 2; tf.y = y;
            box.addChild(tf);
            return tf;
        }

        // Mensagens de erro ficam em vermelho claro; o resto em azul acinzentado.
        private function paintStatus():void
        {
            if (!status) return;
            status.textColor = /erro|falha|faltam|indispon/i.test(status.text) ? 0xFF6B6B : 0xC8B0B2;
        }

        private function setStatus(s:String):void { lastStatus = s; if (status) { status.text = s; paintStatus(); } log(s); }

        // ---------- ações da tela inicial ----------
        private function chooseTapped(e:MouseEvent):void { openPlatformMenu(); }

        private function openPlatformMenu():void
        {
            var names:Array = [];
            for each (var p:Array in Platforms.LIST) names.push(p[0]);
            menuMode = M_PLATFORM;
            bridge.showMenu("Escolha a plataforma", names);
        }

        private function settingsTapped(e:MouseEvent):void { openSettings(); }

        private function playTapped(e:MouseEvent):void
        {
            setStatus("Abrindo login...");
            bridge.login(Platforms.LIST[platformIdx][1]);
        }

        private function logoutTapped(e:MouseEvent):void { logout(); }

        private function logTapped(e:MouseEvent):void { bridge.showText("Log", logLines.join("\n")); }

        private function logout():void
        {
            bridge.clearSession();
            setStatus("Sessão apagada.");
        }

        private function onError(e:StatusEvent):void { setStatus("Erro: " + e.level); }

        // ---------- menu nativo (um evento só, roteado por menuMode) ----------
        private function onMenu(e:StatusEvent):void
        {
            var i:int = int(e.level);
            switch (menuMode)
            {
                case M_PLATFORM:
                    if (i >= 0 && i < Platforms.LIST.length)
                    {
                        platformIdx = i; Prefs.platform = i;
                        if (gameLoader) { bridge.restartApp(); } else { showHome(); }
                    }
                    break;
                case M_SETTINGS: onSettingsChoice(i); break;
                case M_QUALITY:
                    Prefs.quality = ["LOW", "MEDIUM", "HIGH"][i];
                    applyDisplayPrefs(); log("Qualidade: " + Prefs.quality);
                    break;
                case M_FPS:
                    if (i >= 0 && i < FPS_OPTIONS.length)
                    {
                        Prefs.fps = FPS_OPTIONS[i];
                        applyDisplayPrefs();
                        setTimeout(function():void { log("FPS: " + Prefs.fps + " | tela do aparelho: " + hzText()); }, 1200);
                        if (Prefs.fps > 60) bridge.showText("FPS " + Prefs.fps,
                            "O app pede " + Prefs.fps + " FPS e a tela do aparelho em " + hzText() + ".\n\n" +
                            "Só aparece diferença se a tela do aparelho suportar essa taxa (ative o modo de 120 Hz nas configurações de tela do Android). " +
                            "Se o jogo for feito para 30 FPS, as animações podem ficar mais rápidas.");
                    }
                    break;
                case M_FONT:
                    if (i >= 0 && i < FONTS.length)
                    {
                        Prefs.font = String(FONTS[i][1]);
                        log("Fonte do jogo: " + (Prefs.font != "" ? Prefs.font : "padrão"));
                        if (inGame)
                        {
                            if (Prefs.font != "") startFontPatch();
                            else bridge.showText("Fonte", "Para voltar à fonte original do jogo, reinicie o app (Configurações > Reiniciar o app).");
                        }
                        else showHome();
                    }
                    break;
                case M_CACHE:
                    if (i == 0) clearCache();
                    break;
                case M_RES:
                    if (i >= 0 && i < RES_OPTIONS.length)
                    {
                        Prefs.resHeight = RES_OPTIONS[i];
                        applyResolution();
                        if (isVirtual()) setTimeout(function():void { verifyVirtual(true); }, 900);
                        if (!inGame) showHome();
                        else bridge.showText("Resolução", "Para o jogo se reorganizar por completo, reinicie o app (Configurações > Reiniciar o app).");
                    }
                    break;
                case M_EXIT:
                    if (i == 0) { log("Indo para segundo plano"); bridge.toBackground(); }
                    else if (i == 1) { bridge.keepAlive(false); NativeApplication.nativeApplication.exit(); }
                    break;
            }
        }

        private function openSettings():void
        {
            menuMode = M_SETTINGS;
            bridge.showMenu("Configurações", [
                "Resolução (" + resLabel(Prefs.resHeight) + ")",
                "Qualidade gráfica (" + Prefs.quality + ")",
                "FPS (" + Prefs.fps + ")",
                "Fonte do jogo (" + fontLabel() + ")",
                "Cache do jogo",
                "Mostrar log",
                "Trocar plataforma",
                "Sair da conta",
                "Reiniciar o app",
                "Sair do app"
            ]);
        }

        private function onSettingsChoice(i:int):void
        {
            switch (i)
            {
                case 0: openResolutionMenu(); break;
                case 1: menuMode = M_QUALITY; bridge.showMenu("Qualidade gráfica", ["Baixa", "Média", "Alta"]); break;
                case 2: openFpsMenu(); break;
                case 3: openFontMenu(); break;
                case 4:
                    menuMode = M_CACHE;
                    bridge.showMenu("Cache do jogo (" + cacheSizeText() + ")", ["Apagar cache", "Voltar"]);
                    break;
                case 5: bridge.showText("Log", logLines.join("\n")); break;
                case 6: openPlatformMenu(); break;
                case 7: logout(); break;
                case 8: bridge.restartApp(); break;
                case 9: askExit(); break;
            }
        }

        private function openFpsMenu():void
        {
            var names:Array = [];
            for each (var f:int in FPS_OPTIONS)
                names.push(f + " FPS" + (f == Prefs.fps ? "  ✓" : "") + (f == 120 ? "  (precisa de tela 120 Hz)" : ""));
            menuMode = M_FPS;
            bridge.showMenu("FPS (tela do aparelho: " + hzText() + ")", names);
        }

        // ---------- fonte do jogo ----------
        private function fontLabel():String
        {
            for each (var f:Array in FONTS) if (String(f[1]) == Prefs.font) return String(f[0]);
            return "Padrão do jogo";
        }

        private function openFontMenu():void
        {
            var names:Array = [];
            for each (var f:Array in FONTS) names.push(String(f[0]) + (String(f[1]) == Prefs.font ? "  ✓" : ""));
            menuMode = M_FONT;
            bridge.showMenu("Fonte do jogo (escolha antes de entrar)", names);
        }

        // Troca a fonte de todos os textos do jogo. O jogo cria/atualiza textos o tempo todo,
        // então a varredura se repete (só mexe nos textos que ainda não estão com a fonte escolhida).
        private function startFontPatch():void
        {
            if (Prefs.font == "") return;
            if (!fontTimer)
            {
                fontTimer = new Timer(1500);
                fontTimer.addEventListener(TimerEvent.TIMER, function(e:TimerEvent):void { patchFonts(); });
            }
            if (!fontTimer.running) fontTimer.start();
            patchFonts();
        }

        private var fontStats:Object = {seen: 0, changed: 0, blocked: 0};
        private var fontLogs:int = 0;

        private function patchFonts():void
        {
            var name:String = Prefs.font;
            if (name == "" || !stage) return;
            fontStats = {seen: 0, changed: 0, blocked: 0};
            for (var i:int = 0; i < stage.numChildren; i++)
            {
                try { walkFont(stage.getChildAt(i), name, 0); } catch (err:Error) { fontStats.blocked++; }
            }
            // registra no log (poucas vezes) para sabermos se está pegando
            if (fontLogs < 8 && (fontStats.changed > 0 || fontLogs == 0))
            {
                fontLogs++;
                log("Fonte '" + name + "': " + fontStats.seen + " textos vistos, " + fontStats.changed + " alterados, " + fontStats.blocked + " bloqueados");
            }
        }

        private function walkFont(o:DisplayObject, name:String, depth:int):void
        {
            if (depth > 60) return;
            // não mexe na interface do próprio launcher
            if (o === bgLayer || o === ui || o === controls) return;
            var tf:TextField = o as TextField;
            if (tf) { fontStats.seen++; if (setFont(tf, name)) fontStats.changed++; return; }
            var c:DisplayObjectContainer = o as DisplayObjectContainer;
            if (!c) return;
            var n:int = c.numChildren;
            for (var i:int = 0; i < n; i++)
            {
                try { walkFont(c.getChildAt(i), name, depth + 1); } catch (err:Error) { fontStats.blocked++; }
            }
        }

        private function setFont(tf:TextField, name:String):Boolean
        {
            try
            {
                var d:TextFormat = tf.defaultTextFormat;
                var first:TextFormat = tf.length > 0 ? tf.getTextFormat(0, 1) : null;
                if (d.font == name && (first == null || first.font == name) && !tf.embedFonts) return false;
                if (tf.embedFonts) tf.embedFonts = false;   // fonte do jogo embutida não troca; desliga para usar a do sistema
                d.font = name;
                tf.defaultTextFormat = d;
                if (tf.length > 0) { var f:TextFormat = new TextFormat(); f.font = name; tf.setTextFormat(f); }
                return true;
            }
            catch (err:Error) {}
            return false;
        }

        // ---------- resolução ----------
        // A troca de resolução NÃO usa mais o Android (setFixedSize não muda o tamanho do palco do AIR).
        // Modo PC = StageScaleMode.SHOW_ALL: o palco passa a ter o tamanho do SWF (1250x650, definido em
        // [SWF(...)] / -default-size) e o AIR amplia tudo para a tela mantendo a proporção (barras pretas
        // nos lados se a tela for mais larga). O jogo vê um palco de 1250x650 e se organiza para ele.
        private function screenSize():Array
        {
            var w:int = stage.fullScreenWidth > 0 ? stage.fullScreenWidth : int(Capabilities.screenResolutionX);
            var h:int = stage.fullScreenHeight > 0 ? stage.fullScreenHeight : int(Capabilities.screenResolutionY);
            if (h > w) { var t:int = w; w = h; h = t; }
            return [w, h];
        }

        // Valor salvo que não existe mais na lista (de versões antigas) volta para o Modo PC.
        private function validRes():int
        {
            var v:int = Prefs.resHeight;
            if (RES_OPTIONS.indexOf(v) < 0) { v = RES_BASE; Prefs.resHeight = RES_BASE; }
            return v;
        }

        private function isPcMode():Boolean { var v:int = validRes(); return v >= RES_BASE && v < RES_VIRT_BASE; }
        private function isVirtual():Boolean { return validRes() >= RES_VIRT_BASE; }

        private function resLabel(v:int):String
        {
            var s:Array = screenSize();
            if (v >= RES_VIRT_BASE && v - RES_VIRT_BASE < RES_VIRT.length)
                return RES_VIRT[v - RES_VIRT_BASE][2] + " " + RES_VIRT[v - RES_VIRT_BASE][0] + "x" + RES_VIRT[v - RES_VIRT_BASE][1];
            if (v >= RES_BASE && v < RES_VIRT_BASE && v - RES_BASE < RES_FIXED.length)
                return "Modo PC " + RES_FIXED[v - RES_BASE][0] + "x" + RES_FIXED[v - RES_BASE][1];
            return "Nativa " + s[0] + "x" + s[1];
        }

        private function openResolutionMenu():void
        {
            var cur:int = validRes();
            var names:Array = [];
            for each (var v:int in RES_OPTIONS)
            {
                var n:String = resLabel(v);
                if (v == RES_BASE) n += " (padrão)";
                if (v == cur) n += "  ✓";
                names.push(n);
            }
            menuMode = M_RES;
            bridge.showMenu("Resolução (maior = mais área do jogo, itens menores)", names);
        }

        private function wantedScaleMode():String
        {
            return (isPcMode() || isVirtual()) ? StageScaleMode.SHOW_ALL : StageScaleMode.NO_SCALE;
        }

        private function applyResolution():void
        {
            var want:String = wantedScaleMode();
            if (stage.scaleMode != want) stage.scaleMode = want;
            stage.align = StageAlign.TOP_LEFT;
            applyVirtualStage();
            log("Resolução: " + resLabel(validRes()));
            setTimeout(logStage, 300);
            setTimeout(logStage, 1500);
            if (inGame) for each (var d:int in [50, 400, 1200]) setTimeout(notifyResize, d);
        }

        // Resolução virtual (1920x1080 / 2560x1440): o jogo só reorganiza a tela se o PALCO mudar de
        // tamanho. O AIR do Android não deixa o app mudar o tamanho da tela por fora (testado: só
        // encolhe a imagem), então tentamos pelo próprio palco e CONFERIMOS o resultado.
        private function applyVirtualStage():void
        {
            if (!isVirtual()) return;
            var r:Array = RES_VIRT[validRes() - RES_VIRT_BASE];
            try { stage["stageWidth"] = int(r[0]); stage["stageHeight"] = int(r[1]); }
            catch (err:Error) { log("Palco virtual: " + err.message); }
        }

        // Confere se o palco ficou mesmo com o tamanho pedido. Se o aparelho/AIR não aceitar, volta para
        // o Modo PC (em vez de deixar a tela quebrada) e avisa.
        private function verifyVirtual(announce:Boolean):void
        {
            if (!isVirtual() || !stage) return;
            var r:Array = RES_VIRT[validRes() - RES_VIRT_BASE];
            if (stage.stageWidth == int(r[0]) && stage.stageHeight == int(r[1]))
            {
                log("Resolução " + r[0] + "x" + r[1] + ": ok (palco " + stage.stageWidth + "x" + stage.stageHeight + ")");
                return;
            }
            log("Resolução " + r[0] + "x" + r[1] + " NÃO aceita pelo AIR (palco ficou " + stage.stageWidth + "x" + stage.stageHeight + "). Voltando ao Modo PC.");
            Prefs.resHeight = RES_BASE;
            applyResolution();
            if (!inGame) showHome();
            if (announce) bridge.showText("Resolução",
                "Este aparelho não aceitou mudar o tamanho da tela do jogo para " + r[0] + "x" + r[1] + ". Voltei para o Modo PC 1250x650 para não quebrar a tela.\n\n" +
                "Opção mais parecida: \"Nativa\" (usa todos os pixels da tela).");
        }

        private function logStage():void
        {
            var sc:Array = screenSize();
            log("Palco: " + stage.stageWidth + "x" + stage.stageHeight + " | tela " + sc[0] + "x" + sc[1] + " | escala " + stage.scaleMode);
        }

        // O jogo avisa que o palco mudou de tamanho (útil ao trocar de modo com o jogo aberto).
        private function notifyResize():void
        {
            if (!inGame || !stage) return;
            try { stage.dispatchEvent(new Event(Event.RESIZE)); } catch (err:Error) { log("aviso de resize: " + err.message); }
            if (controls) controls.layout(sw(), uiScale());
        }

        // O botão da engrenagem fica no palco (stage), por cima de tudo, e é trazido para a
        // frente de tempos em tempos: o jogo adiciona janelas no palco e o cobria.
        private function keepOnTop(e:TimerEvent):void
        {
            if (!controls || !stage) return;
            try
            {
                if (stage.scaleMode != wantedScaleMode()) { log("Escala foi alterada para " + stage.scaleMode + "; restaurando."); applyResolution(); }
                if (controls.parent != stage) stage.addChild(controls);
                else if (stage.getChildIndex(controls) != stage.numChildren - 1) stage.setChildIndex(controls, stage.numChildren - 1);
                controls.layout(sw(), uiScale());
            }
            catch (err:Error) {}
        }

        // ---------- sair do app / segundo plano ----------
        private function onKey(e:KeyboardEvent):void
        {
            if (e.keyCode != Keyboard.BACK) return;
            e.preventDefault();
            e.stopImmediatePropagation();
            askExit();
        }

        private function askExit():void
        {
            menuMode = M_EXIT;
            bridge.showMenu("Sair do app", ["Deixar o jogo aberto em segundo plano", "Fechar o app de vez", "Cancelar"]);
        }

        // ---------- zoom ----------
        private function zoomBy(delta:Number):void
        {
            zoomLevel = Math.max(0.5, Math.min(2, zoomLevel + delta));
            Prefs.zoom = zoomLevel;
            applyZoom();
        }
        private function applyZoom():void
        {
            if (!gameLoader) return;
            gameLoader.scaleX = gameLoader.scaleY = zoomLevel;
        }

        // ---------- cache do Loading.swf (TTL em disco) ----------
        private function cacheDir():File
        {
            var d:File = File.applicationStorageDirectory.resolvePath("cache");
            if (!d.exists) d.createDirectory();
            return d;
        }
        private function cacheFile():File { return cacheDir().resolvePath("Loading.swf"); }

        private function cacheSizeText():String
        {
            var n:Number = SwfFixer.cacheSize();
            if (n <= 0) return "vazio";
            return Math.round(n / 1024) + " KB";
        }
        private function clearCache():void
        {
            SwfFixer.clearCache();
            log("Cache apagado.");
        }
        private function saveCache(b:ByteArray):void
        {
            try {
                var fs:FileStream = new FileStream();
                fs.open(cacheFile(), FileMode.WRITE);
                fs.writeBytes(b); fs.close();
            } catch (err:Error) { log("Falha ao salvar cache: " + err.message); }
        }
        private function readCacheIfFresh():ByteArray
        {
            var f:File = cacheFile();
            if (!f.exists) return null;
            if (new Date().time - f.modificationDate.time > CACHE_TTL_MS) return null;
            return readFile(f);
        }

        private function readFile(f:File):ByteArray
        {
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.READ);
            var ba:ByteArray = new ByteArray();
            fs.readBytes(ba); fs.close();
            return ba;
        }

        // ---------- sessão recebida do ANE ----------
        private function onGame(e:StatusEvent):void
        {
            try { session = JSON.parse(e.level); }
            catch (err:Error) { setStatus("Resposta de login inválida."); return; }

            applyResolution();   // o login pausa/recria a tela do app: reaplica a resolução
            port = bridge.startServer(session.host);
            if (port <= 0) { setStatus("Falha ao iniciar servidor local."); return; }
            bridge.keepAlive(true);
            setStatus("Baixando o jogo...");
            fbIndex = 0;
            fetchSwf();
        }

        // 1) servidor (via proxy local, tentando vários caminhos)  2) cache  3) reservas empacotadas
        private function fetchSwf():void
        {
            swfCandidates = [];
            if (session.swf) swfCandidates.push(String(session.swf));
            swfCandidates.push("/client/Loading.swf");
            swfCandidates.push("/Loading.swf");
            swfIdx = 0;
            log("Sessão: host=" + session.host + " swf=" + (session.swf ? session.swf : "(nenhum)") + " porta=" + port);
            tryServer();
        }

        private function isSwf(b:ByteArray):Boolean
        {
            if (b.length < 3) return false;
            var h:String = String.fromCharCode(b[0], b[1], b[2]);
            return h == "FWS" || h == "CWS" || h == "ZWS";
        }

        private function tryServer():void
        {
            if (swfIdx >= swfCandidates.length)
            {
                log("Servidor não respondeu; usando a cópia do app.");
                launchWith(0);
                return;
            }
            var path:String = String(swfCandidates[swfIdx++]);
            log("Tentando https://" + session.host + path);
            var code:int = 0;
            var l:URLLoader = new URLLoader();
            l.dataFormat = URLLoaderDataFormat.BINARY;
            l.addEventListener(HTTPStatusEvent.HTTP_STATUS, function(ev:HTTPStatusEvent):void { code = ev.status; });
            l.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var b:ByteArray = ByteArray(l.data);
                log("Recebido " + b.length + " bytes (HTTP " + code + ")");
                if (!isSwf(b)) { log("A resposta não é um SWF."); tryServer(); return; }
                okPath = path;
                launchWith(b.length);
            });
            l.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                log("Falhou (HTTP " + code + "): " + ev.text);
                tryServer();
            });
            l.load(new URLRequest("http://127.0.0.1:" + port + path));
        }

        // O Loading.swf do servidor NÃO é executado: serve só para saber a versão (pelo tamanho).
        // Quem roda é a cópia modificada que vem no app (assets/game), a mesma versão do servidor.
        private function launchWith(serverLen:int):void
        {
            var name:String = "assets/game/Loading.swf";
            if (serverLen > 0 && serverLen != BRAZIL_LEN)
            {
                var alt:String = "assets/game/Loading_" + serverLen + ".swf";
                if (File.applicationDirectory.resolvePath(alt).exists)
                {
                    name = alt;
                    log("Versão deste servidor: " + serverLen + " bytes (cópia própria no app)");
                }
                else
                {
                    log("AVISO: a versão do Loading.swf deste servidor (" + serverLen + " bytes) não está no app. Usando a do Brasil.");
                }
            }
            else if (serverLen == BRAZIL_LEN)
            {
                log("Versão deste servidor: a mesma do Brasil");
            }
            var f:File = File.applicationDirectory.resolvePath(name);
            if (!f.exists)
            {
                setStatus("Faltam os arquivos do jogo no app (" + name + "). Toque em Ver log.");
                return;
            }
            setStatus("Carregando o jogo...");
            startGame(readFile(f));
        }

        private function startGame(bytes:ByteArray):void
        {
            inGame = true;
            while (ui.numChildren) ui.removeChildAt(0);
            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;
            var p:String = okPath;
            var qi:int = p.indexOf("?");
            if (qi >= 0) p = p.substring(0, qi);
            var dir:String = "https://" + session.host + p.substring(0, p.lastIndexOf("/") + 1);
            var params:Object = {};
            for each (var pn:String in ["user", "key", "site", "p2", "rid", "logintype"])
            {
                if (session.params && session.params[pn] != undefined) params[pn] = String(session.params[pn]);
            }
            params["http"] = "https:";
            params["config"] = dir + "config.xml";
            params["base"] = dir;
            log("Jogo: " + bytes.length + " bytes | config " + params["config"]);
            applyResolution();
            ctx.parameters = params;
            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                SwfFixer.gameDomain = gameLoader.contentLoaderInfo.applicationDomain;
                applyResolution();
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, function(ev:Event):void {
                zoomLevel = 1; Prefs.zoom = 1;
                addChild(gameLoader);
                applyZoom();
                controls = new Controls(openSettings);
                controls.layout(sw(), uiScale());
                stage.addChild(controls);
                if (topTimer) topTimer.stop();
                topTimer = new Timer(400);
                topTimer.addEventListener(TimerEvent.TIMER, keepOnTop);
                topTimer.start();
                log("Jogo carregado.");
                startFontPatch();
            });
            gameLoader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void {
                inGame = false; gameLoader = null; showHome(); setStatus("Falha ao carregar o jogo.");
            });
            gameLoader.loadBytes(bytes, ctx);
        }
    }
}
