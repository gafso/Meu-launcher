package
{
    import flash.display.DisplayObjectContainer;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.events.Event;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.filters.DropShadowFilter;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Janela de macros (pop-up por cima do jogo, arrastável pela barra de cima).
    // Fechar só esconde a janela: os macros continuam rodando. Origem (0,0) = centro da janela.
    public class MacroPanel extends Sprite
    {
        private static const PW:Number = 700;
        private static const PH:Number = 500;
        private static const MAP:Number = 260;      // lado da área do mapa
        private static const MAP_CX:Number = 175;
        private static const MAP_CY:Number = -60;

        public var logger:Function;       // recebe cada linha de log (vai para o log do app)
        public var onText:Function;       // (titulo, texto): mostra um texto grande (caixa nativa, com copiar)

        private var realAd:GamePlanesAdapter = new GamePlanesAdapter();
        private var simAd:SimPlanesAdapter = new SimPlanesAdapter();
        private var real:PlanesBot;
        private var sim:PlanesBot;
        private var opts:Object = {box: true, res: true, mon: true, boss: false};

        private var bar:Sprite = new Sprite();
        private var statusTf:TextField;
        private var mapTitle:TextField;
        private var logTf:TextField;
        private var bgMap:Shape = new Shape();
        private var markLayer:Shape = new Shape();
        private var cellTfs:Array = [];
        private var mapCols:int = -1;
        private var mapRows:int = -1;
        private var cellSize:Number = 0;
        private var mapX0:Number = 0;
        private var mapY0:Number = 0;

        private var btnReal:Btn;
        private var btnSim:Btn;
        private var btnBox:Btn;
        private var btnRes:Btn;
        private var btnMon:Btn;
        private var btnBoss:Btn;

        private var lines:Array = [];
        private var timer:Timer;

        public function MacroPanel()
        {
            real = new PlanesBot(realAd, "Planos");
            sim = new PlanesBot(simAd, "Simulação");
            real.opts = opts;
            sim.opts = opts;
            real.logger = say;
            sim.logger = say;
            build();
            addEventListener(Event.ADDED_TO_STAGE, onAdded);
            addEventListener(Event.REMOVED_FROM_STAGE, onRemoved);
        }

        // ---------- log ----------
        public function say(s:String):void
        {
            lines.push(s);
            if (lines.length > 300) lines.shift();
            if (logger != null) logger("MACRO " + s);
        }

        // ---------- construção da janela ----------
        private function text(t:String, size:int, color:uint, x:Number, y:Number, w:Number = 0):TextField
        {
            var f:TextField = new TextField();
            f.defaultTextFormat = new TextFormat("_sans", size, color, true);
            f.selectable = false;
            f.mouseEnabled = false;
            f.autoSize = TextFieldAutoSize.LEFT;
            if (w > 0) { f.multiline = true; f.wordWrap = true; f.width = w; }
            f.text = t;
            f.x = x;
            f.y = y;
            return f;
        }

        private function build():void
        {
            var bg:Shape = new Shape();
            bg.graphics.lineStyle(1.5, Btn.ACCENT, 0.55);
            bg.graphics.beginFill(Btn.SURFACE, 0.95);
            bg.graphics.drawRoundRect(-PW / 2, -PH / 2, PW, PH, 26, 26);
            bg.graphics.endFill();
            bg.filters = [new DropShadowFilter(0, 90, 0x000000, 0.8, 24, 24, 1, 2)];
            addChild(bg);

            // barra de título (arraste por aqui)
            bar.graphics.beginFill(0xFFFFFF, 0);
            bar.graphics.drawRect(-PW / 2, -PH / 2, PW, 56);
            bar.graphics.endFill();
            bar.addEventListener(MouseEvent.MOUSE_DOWN, onBarDown);
            addChild(bar);
            addChild(text("MACROS", 20, Btn.TEXT, -PW / 2 + 22, -PH / 2 + 14));
            statusTf = text("", 11, Btn.TEXT_MUTED, -170, -PH / 2 + 20);
            addChild(statusTf);

            var logBtn:Btn = new Btn(Btn.GHOST, 84, 34, "Ver log", "", function(e:MouseEvent):void { showLog(); });
            logBtn.x = PW / 2 - 118; logBtn.y = -PH / 2 + 28;
            addChild(logBtn);
            var closeBtn:Btn = new Btn(Btn.GHOST, 52, 34, "X", "", function(e:MouseEvent):void { hide(); });
            closeBtn.x = PW / 2 - 40; closeBtn.y = -PH / 2 + 28;
            addChild(closeBtn);

            // coluna esquerda: macro real
            addChild(text("PLANOS  ·  mapa em grade (jogo real)", 12, Btn.TEXT_SOFT, -330, -186));
            btnReal = new Btn(Btn.PRIMARY, 310, 50, "INICIAR", "", function(e:MouseEvent):void { toggleReal(); });
            btnReal.x = -175; btnReal.y = -132;
            addChild(btnReal);

            btnBox = new Btn(Btn.GHOST, 152, 38, "", "", function(e:MouseEvent):void { opts.box = !opts.box; refresh(); });
            btnBox.x = -253; btnBox.y = -80;
            btnRes = new Btn(Btn.GHOST, 152, 38, "", "", function(e:MouseEvent):void { opts.res = !opts.res; refresh(); });
            btnRes.x = -97; btnRes.y = -80;
            btnMon = new Btn(Btn.GHOST, 152, 38, "", "", function(e:MouseEvent):void { opts.mon = !opts.mon; refresh(); });
            btnMon.x = -253; btnMon.y = -36;
            btnBoss = new Btn(Btn.GHOST, 152, 38, "", "", function(e:MouseEvent):void { opts.boss = !opts.boss; refresh(); });
            btnBoss.x = -97; btnBoss.y = -36;
            addChild(btnBox); addChild(btnRes); addChild(btnMon); addChild(btnBoss);

            // teste e diagnóstico
            addChild(text("TESTE  ·  simulação 8x8 (sem o jogo)", 12, Btn.TEXT_SOFT, -330, -6));
            btnSim = new Btn(Btn.GHOST, 310, 40, "Iniciar simulação", "", function(e:MouseEvent):void { toggleSim(); });
            btnSim.x = -175; btnSim.y = 36;
            addChild(btnSim);
            var diag:Btn = new Btn(Btn.GHOST, 310, 40, "Diagnóstico do jogo (só lê)", "", function(e:MouseEvent):void { diagnose(); });
            diag.x = -175; diag.y = 84;
            addChild(diag);

            // coluna direita: mapa
            mapTitle = text("MAPA", 12, Btn.TEXT_SOFT, MAP_CX - MAP / 2, MAP_CY - MAP / 2 - 22);
            addChild(mapTitle);
            addChild(bgMap);
            addChild(markLayer);
            addChild(text("ouro=baú  verde=recurso  vermelho=monstro  roxo=chefe\nazul=entrada/saída  ciano=mercado  X=já feito\nO número é o EventType da casa", 10, Btn.TEXT_MUTED, MAP_CX - MAP / 2, MAP_CY + MAP / 2 + 8, MAP + 20));

            // log
            var lg:Shape = new Shape();
            lg.graphics.lineStyle(1, Btn.BORDER, 1);
            lg.graphics.beginFill(0x000000, 0.4);
            lg.graphics.drawRoundRect(-PW / 2 + 20, 118, PW - 40, 120, 10, 10);
            lg.graphics.endFill();
            addChild(lg);
            logTf = text("", 11, 0xE6D2D4, -PW / 2 + 30, 124, PW - 60);
            logTf.autoSize = TextFieldAutoSize.NONE;
            logTf.height = 108;
            addChild(logTf);
        }

        // ---------- mostrar / esconder ----------
        public function get isOpen():Boolean { return parent != null; }

        public function show(host:DisplayObjectContainer, stageW:Number, stageH:Number, uiScale:Number):void
        {
            var s:Number = Math.min(uiScale, (stageH - 16) / PH, (stageW - 16) / PW);
            s = Math.max(0.5, s);
            scaleX = scaleY = s;
            if (parent == null)
            {
                x = stageW / 2;
                y = stageH / 2;
                host.addChild(this);
            }
            refresh();
        }

        public function hide():void
        {
            stopDragging();
            if (parent != null) parent.removeChild(this);
        }

        private function onAdded(e:Event):void
        {
            if (timer == null)
            {
                timer = new Timer(500);
                timer.addEventListener(TimerEvent.TIMER, function(ev:TimerEvent):void { refresh(); });
            }
            timer.start();
        }

        private function onRemoved(e:Event):void
        {
            if (timer != null) timer.stop();
        }

        // ---------- arrastar ----------
        private function onBarDown(e:MouseEvent):void
        {
            startDrag();
            if (stage != null) stage.addEventListener(MouseEvent.MOUSE_UP, onDragUp);
        }

        private function onDragUp(e:MouseEvent):void { stopDragging(); }

        private function stopDragging():void
        {
            stopDrag();
            if (stage != null) stage.removeEventListener(MouseEvent.MOUSE_UP, onDragUp);
        }

        // ---------- ações ----------
        private function toggleReal():void
        {
            if (real.running) { real.stop("parado pelo usuário"); refresh(); return; }
            if (!realAd.ready) say("Planos: o mapa de Planos ainda não está aberto no jogo; o macro espera ele aparecer.");
            real.start();
            refresh();
        }

        private function toggleSim():void
        {
            if (sim.running) { sim.stop("parado pelo usuário"); refresh(); return; }
            simAd.reset();
            sim.start();
            refresh();
        }

        private function diagnose():void
        {
            var r:String = realAd.report();
            say("Diagnóstico executado");
            if (logger != null) logger("MACRO " + r);
            if (onText != null) onText("Diagnóstico dos macros", r);
        }

        private function showLog():void
        {
            if (onText != null) onText("Log dos macros", lines.join("\n"));
        }

        // ---------- atualização periódica ----------
        private function onOff(label:String, v:Boolean):String { return label + ": " + (v ? "SIM" : "NÃO"); }

        public function refresh():void
        {
            btnReal.setText(real.running ? "PARAR" : "INICIAR");
            btnSim.setText(sim.running ? "Parar simulação" : "Iniciar simulação");
            btnBox.setText(onOff("Baús", opts.box));
            btnRes.setText(onOff("Recursos", opts.res));
            btnMon.setText(onOff("Monstros", opts.mon));
            btnBoss.setText(onOff("Chefe", opts.boss));
            var st:String = "";
            if (real.running) st = "Planos: " + real.status;
            else if (sim.running) st = "Simulação: " + sim.status;
            else st = "parado";
            statusTf.text = st.length > 52 ? st.substr(0, 52) : st;
            logTf.text = lines.slice(Math.max(0, lines.length - 7)).join("\n");
            drawMap();
        }

        private static function cellColor(type:int, id:int):uint
        {
            if (id == 0 && type == 0) return 0x2A1215;
            var c:String = PlanesBot.category(type);
            if (c == "box") return 0xB8860B;
            if (c == "res") return 0x2E8B57;
            if (c == "mon") return 0xB5322E;
            if (c == "boss") return 0x8E2BC4;
            if (c == "exit") return 0x2F6DB5;
            if (c == "market") return 0x1E8EA3;
            if (c == "wall") return 0x0A0A0A;
            return 0x555555;
        }

        private function buildCells(cols:int, rows:int):void
        {
            var i:int;
            for (i = 0; i < cellTfs.length; i++) if (cellTfs[i].parent) cellTfs[i].parent.removeChild(cellTfs[i]);
            cellTfs = [];
            mapCols = cols; mapRows = rows;
            cellSize = Math.floor(Math.min(MAP / cols, MAP / rows));
            mapX0 = MAP_CX - cols * cellSize / 2;
            mapY0 = MAP_CY - rows * cellSize / 2;
            var size:int = Math.max(8, int(cellSize * 0.36));
            var f:TextFormat = new TextFormat("_sans", size, 0xFFFFFF, true, null, null, null, null, "center");
            for (i = 0; i < cols * rows; i++)
            {
                var t:TextField = new TextField();
                t.defaultTextFormat = f;
                t.selectable = false; t.mouseEnabled = false;
                t.width = cellSize; t.height = cellSize;
                t.x = mapX0 + int(i / rows) * cellSize;
                t.y = mapY0 + (i % rows) * cellSize + (cellSize - size * 1.3) / 2;
                cellTfs.push(t);
                addChild(t);
            }
        }

        private function drawMap():void
        {
            var ad:IPlanesAdapter;
            var bot:PlanesBot;
            if (sim.running) { ad = simAd; bot = sim; mapTitle.text = "MAPA: simulação"; }
            else if (realAd.ready) { ad = realAd; bot = real; mapTitle.text = "MAPA: jogo real"; }
            else { ad = simAd; bot = sim; mapTitle.text = "MAPA: demonstração (abra o Planos no jogo)"; }

            var cols:int = ad.cols;
            var rows:int = ad.rows;
            if (cols <= 0 || rows <= 0) return;
            if (cols != mapCols || rows != mapRows) buildCells(cols, rows);

            var byKey:Object = {};
            var list:Array = ad.cells();
            var i:int;
            var c:Object;
            for (i = 0; i < list.length; i++) { c = list[i]; byKey[c.x * 100 + c.y] = c; }

            var g:Graphics2 = null;
            bgMap.graphics.clear();
            markLayer.graphics.clear();
            var x:int;
            var y:int;
            var px:Number;
            var py:Number;
            var tf:TextField;
            for (x = 0; x < cols; x++)
            {
                for (y = 0; y < rows; y++)
                {
                    c = byKey[x * 100 + y];
                    px = mapX0 + x * cellSize;
                    py = mapY0 + y * cellSize;
                    bgMap.graphics.lineStyle(1, 0x000000, 0.6);
                    bgMap.graphics.beginFill(c == null ? 0x120709 : cellColor(c.type, c.id), 1);
                    bgMap.graphics.drawRect(px, py, cellSize, cellSize);
                    bgMap.graphics.endFill();
                    tf = cellTfs[x * rows + y];
                    if (c == null) tf.text = "";
                    else if (c.type == -1) tf.text = "#";
                    else if (c.type == 0 && c.id == 0) tf.text = "";
                    else tf.text = String(c.type);
                    if (bot.done[x * 100 + y])
                    {
                        markLayer.graphics.lineStyle(2, 0xFFFFFF, 0.8);
                        markLayer.graphics.moveTo(px + 4, py + 4); markLayer.graphics.lineTo(px + cellSize - 4, py + cellSize - 4);
                        markLayer.graphics.moveTo(px + cellSize - 4, py + 4); markLayer.graphics.lineTo(px + 4, py + cellSize - 4);
                    }
                }
            }
            if (bot.target != null)
            {
                markLayer.graphics.lineStyle(3, 0xFF3B3B, 1);
                markLayer.graphics.drawRect(mapX0 + bot.target.x * cellSize + 2, mapY0 + bot.target.y * cellSize + 2, cellSize - 4, cellSize - 4);
            }
            if (ad.posX >= 0 && ad.posY >= 0)
            {
                markLayer.graphics.lineStyle(3, 0xFFFFFF, 1);
                markLayer.graphics.drawCircle(mapX0 + (ad.posX + 0.5) * cellSize, mapY0 + (ad.posY + 0.5) * cellSize, cellSize * 0.32);
            }
        }
    }
}
