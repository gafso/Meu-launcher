package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.display.Loader;
    import flash.display.Stage;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.HTTPStatusEvent;
    import flash.net.URLLoader;
    import flash.net.URLRequest;
    import flash.utils.clearTimeout;
    import flash.utils.setTimeout;
    import flash.filesystem.File;
    import flash.filesystem.FileStream;
    import flash.system.ApplicationDomain;
    import flash.system.LoaderContext;
    import flash.utils.ByteArray;
    import flash.events.TimerEvent;
    import flash.utils.Endian;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Ponte entre o app e as cópias modificadas do Loading.swf (assets/game).
    // Essas cópias chamam, em qualquer Loader, funções que NÃO existem no AIR puro:
    //   __lofix(bytes)        -> corrige um SWF baixado (troca loadBytes por loadByteZ)
    //   loadByteZ(bytes, ctx) -> loadBytes com allowCodeImport ligado
    //   __cacheGet/Put/Del    -> cache em disco dos arquivos que o jogo baixa
    //   __dlLog/__dlTrace/__loadFail -> mensagens para o log
    // install() cria essas funções em Loader.prototype. Sem isso o jogo dá erro #1063 e fica tela preta.
    public class SwfFixer
    {
        public static var logger:Function;
        public static var gameDomain:ApplicationDomain;
        // Cada modulo do jogo (codigo) e carregado num dominio filho: as classes dele NAO aparecem em gameDomain.
        // Guardamos todos os dominios vistos para os macros acharem as classes (getDefinition).
        public static var moduleDomains:Array = [];
        public static var rootStage:Stage;
        private static var lastHarvest:int = 0;

        private static function track(d:ApplicationDomain):void
        {
            if (d == null || moduleDomains.indexOf(d) >= 0) return;
            moduleDomains.push(d);
        }

        // Varre a lista de exibicao do palco atras de dominios (cada SWF carregado tem o seu).
        private static function harvest():void
        {
            if (rootStage == null || getTimer() - lastHarvest < 2000) return;
            lastHarvest = getTimer();
            var queue:Array = [rootStage];
            var seen:int = 0;
            while (queue.length > 0 && seen < 600)
            {
                var o:DisplayObject = queue.shift();
                seen++;
                try
                {
                    if (o.loaderInfo != null) track(o.loaderInfo.applicationDomain);
                    var c:DisplayObjectContainer = o as DisplayObjectContainer;
                    if (c != null) for (var i:int = 0; i < c.numChildren && i < 40; i++) queue.push(c.getChildAt(i));
                }
                catch (err:Error) {}
            }
        }

        // Procura uma classe do jogo (ex.: "yishi.manager.PlanesWarManager") em todos os dominios conhecidos.
        public static function findClass(name:String):Object
        {
            var i:int;
            var d:ApplicationDomain;
            for (var pass:int = 0; pass < 2; pass++)
            {
                if (gameDomain != null && gameDomain.hasDefinition(name)) return gameDomain.getDefinition(name);
                for (i = moduleDomains.length - 1; i >= 0; i--)
                {
                    d = moduleDomains[i];
                    if (d.hasDefinition(name)) return d.getDefinition(name);
                }
                if (pass == 0) harvest();
            }
            return null;
        }
        private static var noFix:Object = {};       // swfs já vistos que não precisam de correção (não repetir o trabalho)
        private static var diagN:int = 0;          // linhas de diagnóstico (MISS / EXPIRADO) já enviadas ao log
        private static var statHit:int = 0;        // arquivos lidos do disco (cache)
        private static var statHitBytes:Number = 0;
        private static var statPut:int = 0;        // arquivos baixados da rede e gravados
        private static var statPutBytes:Number = 0;
        private static var statMiss:int = 0;       // pedidos que não estavam no disco
        private static var statTimer:Timer;
        private static var lastStatTot:int = 0;
        public static var cacheHits:int = 0;

        // ---- cache negativo: imagens PNG que o servidor responde 404/410 ----
        // O jogo pede de novo, a cada abertura, ícones que não existem (ex.: skillname/13106.png) e cada pedido
        // perde ~2 s. Depois de confirmar o 404 guardamos a URL (12 h) e devolvemos na hora um PNG transparente.
        public static var fastNeg:Boolean = true;
        private static var neg:Object = {};          // url sem query -> hora em que foi confirmado
        private static var statFast:int = 0;
        private static var fastLogN:int = 0;         // pedidos respondidos na hora pelo cache negativo
        private static var pendingChk:Object = {};   // verificações de status em andamento
        private static var pendingN:int = 0;
        private static const NEG_TTL:Number = 12 * 3600 * 1000;
        private static const PNG1_HEX:String = "89504E470D0A1A0A0000000D49484452000000010000000108060000001F15C4890000000B49444154789C6360000200000500017A5EAB3F0000000049454E44AE426082";
        public static var cacheMiss:int = 0;

        private static const TTL_3D:Number = 7 * 24 * 3600 * 1000;
        private static const TTL_1D:Number = 24 * 3600 * 1000;
        private static const KEEP_MS:Number = 30 * 24 * 3600 * 1000;

        private static function say(m:String):void { if (logger != null) logger(m); }

        public static function install():void
        {
            loadNeg();
            if (statTimer == null)
            {
                statTimer = new Timer(60000);
                statTimer.addEventListener(TimerEvent.TIMER, function(e:TimerEvent):void
                {
                    var tot:int = statHit + statPut + statMiss + statFast;
                    if (tot == lastStatTot) return;
                    lastStatTot = tot;
                    say("CACHE: " + statHit + " lidos do disco (" + Math.round(statHitBytes / 1048576 * 10) / 10 + " MB) | "
                        + statPut + " baixados da rede (" + Math.round(statPutBytes / 1048576 * 10) / 10 + " MB) | "
                        + statMiss + " pedidos sem arquivo no disco | "
                        + statFast + " respondidos na hora (imagens inexistentes)");
                });
                statTimer.start();
            }
            Loader.prototype["__lofix"] = function(b:ByteArray):ByteArray
            {
                return SwfFixer.fix(b);
            };
            Loader.prototype["loadByteZ"] = function(b:ByteArray, ctx:LoaderContext = null):void
            {
                if (ctx == null)
                    ctx = new LoaderContext(false, new ApplicationDomain(gameDomain || ApplicationDomain.currentDomain));
                ctx.allowCodeImport = true;
                SwfFixer.track(ctx.applicationDomain);
                var ldr:Loader = Loader(this);
                ldr.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void
                {
                    try { SwfFixer.track(ldr.contentLoaderInfo.applicationDomain); } catch (e2:Error) {}
                });
                ldr.loadBytes(b, ctx);
            };
            Loader.prototype["__cacheGet"] = function(k:String):ByteArray { return SwfFixer.cacheGet(k); };
            Loader.prototype["__cachePut"] = function(k:String, b:ByteArray):void { SwfFixer.cachePut(k, b); };
            Loader.prototype["__cacheDel"] = function(k:String):void { SwfFixer.cacheDel(k); };
            Loader.prototype["__dlLog"] = function(u:String, n:int):void
            {
                if (n >= 262144) SwfFixer.say("baixou " + Math.ceil(n / 1024) + " KB (sem cache): " + u);
                else if (u.indexOf("mapmaterial/land") >= 0) SwfFixer.say("TILE veio do servidor (download): " + u.substring(u.lastIndexOf("/") + 1) + " (" + n + " bytes)");
            };
            Loader.prototype["__dlTrace"] = function(u:String, n:int):void
            {
                SwfFixer.say("baixou " + Math.ceil(n / 1024) + " KB: " + u);
            };
            Loader.prototype["__loadFail"] = function(u:String):void { SwfFixer.onLoadFail(u); };
            var names:Array = ["__lofix", "loadByteZ", "__cacheGet", "__cachePut", "__cacheDel", "__loadFail", "__dlLog", "__dlTrace"];
            for each (var nm:String in names) Loader.prototype.setPropertyIsEnumerable(nm, false);
        }

        // ---------- cache negativo ----------
        private static function stripQ(u:String):String { return u.replace(/[?#].*$/, ""); }

        private static function isNegKey(key:String):Boolean
        {
            var i:int = key.indexOf("|");
            if (i < 0) return false;
            var base:String = stripQ(key.substring(i + 1));
            if (!/\.png$/i.test(base)) return false;
            return negFresh(base);
        }

        // true se a URL (sem query) já foi confirmada como inexistente há menos de 12 h
        private static function negFresh(base:String):Boolean
        {
            var t:* = neg[base];
            if (t == undefined) return false;
            if (new Date().time - Number(t) > NEG_TTL) { delete neg[base]; return false; }
            return true;
        }

        private static function placeholderPng():ByteArray
        {
            var b:ByteArray = new ByteArray();
            for (var i:int = 0; i < PNG1_HEX.length; i += 2) b.writeByte(parseInt(PNG1_HEX.substr(i, 2), 16));
            b.position = 0;
            return b;
        }

        private static function negFile():File { return cacheDir.resolvePath("neg.json"); }

        private static function loadNeg():void
        {
            try
            {
                var f:File = negFile();
                if (!f.exists) return;
                var b:ByteArray = readFile(f);
                if (b == null) return;
                var o:Object = JSON.parse(b.readUTFBytes(b.length));
                var now:Number = new Date().time, n:int = 0;
                for (var k:String in o)
                {
                    if (now - Number(o[k]) < NEG_TTL) { neg[k] = Number(o[k]); n++; }
                }
                if (n > 0) say("cache negativo: " + n + " imagens inexistentes lembradas");
            }
            catch (e:Error) { neg = {}; }
        }

        private static function saveNeg():void
        {
            try
            {
                var f:File = negFile();
                f.parent.createDirectory();
                var fs:FileStream = new FileStream();
                fs.open(f, "write");
                fs.writeUTFBytes(JSON.stringify(neg));
                fs.close();
            }
            catch (e:Error) {}
        }

        // O jogo avisa aqui quando um download falha. Descobrimos (em paralelo, sem travar o jogo) se foi 404 de verdade
        // ou falha de rede, e registramos o código HTTP no log.
        public static function onLoadFail(u:String):void
        {
            var base:String = stripQ(u);
            // Já confirmado antes (ex.: avatar .bswf que sempre dá 403): não gasta outra requisição só para checar.
            if (negFresh(base)) { say("FALHOU download (já conhecido: não existe no servidor): " + u); return; }
            if (pendingChk[base] || pendingN >= 4) { say("FALHOU download: " + u); return; }
            pendingChk[base] = true; pendingN++;
            var t0:int = getTimer();
            var code:int = 0;
            var done:Boolean = false;
            var l:URLLoader = new URLLoader();
            var tm:uint = 0;
            var finish:Function = function(c:int):void
            {
                if (done) return;
                done = true;
                clearTimeout(tm);
                try { l.close(); } catch (e0:Error) {}
                delete pendingChk[base]; pendingN--;
                var ms:int = getTimer() - t0;
                // Este servidor responde 403 (não 404) para arquivo inexistente; os dois contam como "não existe".
                if (c == 403 || c == 404 || c == 410)
                {
                    neg[base] = new Date().time;
                    saveNeg();
                    say("FALHOU download (HTTP " + c + ", " + ms + " ms; lembrado por 12 h" + (/\.png$/i.test(base) ? ", próximas vezes sem espera" : "") + "): " + u);
                }
                else
                {
                    say("FALHOU download (" + (c > 0 ? "HTTP " + c : "sem resposta / rede") + ", " + ms + " ms): " + u);
                }
            };
            l.addEventListener(HTTPStatusEvent.HTTP_STATUS, function(ev:HTTPStatusEvent):void { code = ev.status; finish(code); });
            l.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void { finish(code); });
            tm = setTimeout(function():void { finish(code > 0 ? code : -1); }, 8000);
            try { l.load(new URLRequest(u)); }
            catch (e:Error) { finish(0); }
        }

        // ---------- arquivos ----------
        public static function get cacheDir():File
        {
            return File.applicationStorageDirectory.resolvePath("gamecache");
        }

        private static function hash(s:String):String
        {
            var a:uint = 2166136261;
            var h:uint = 5381;
            for (var i:int = 0; i < s.length; i++)
            {
                var c:int = s.charCodeAt(i);
                a = ((a ^ c) * 16777619) >>> 0;
                h = ((h * 33) ^ c) >>> 0;
            }
            return a.toString(16) + h.toString(16);
        }

        private static function fileFor(key:String, sub:String = "dl"):File
        {
            var name:String = key.replace(/[?#].*$/, "");
            name = name.substring(name.lastIndexOf("/") + 1).replace(/[^A-Za-z0-9._-]/g, "_");
            if (name.length > 40) name = name.substring(name.length - 40);
            return cacheDir.resolvePath(sub + "/" + hash(key) + "_" + name);
        }

        private static function readFile(f:File):ByteArray
        {
            if (!f.exists) return null;
            var ba:ByteArray = new ByteArray();
            var fs:FileStream = new FileStream();
            try
            {
                fs.open(f, "read");
                fs.readBytes(ba);
                fs.close();
            }
            catch (e:Error)
            {
                try { fs.close(); } catch (e2:Error) {}
                return null;
            }
            ba.position = 0;
            return ba;
        }

        // Grava em arquivo temporário e só depois troca pelo definitivo (não deixa arquivo pela metade).
        private static function writeFileAsync(f:File, src:ByteArray):void
        {
            // Arquivos pequenos (tiles, ícones, swfs pequenos): grava na hora, sem depender de evento assíncrono,
            // e avisa no log se falhar (antes uma falha aqui era silenciosa e o arquivo era baixado de novo).
            if (src.length < 64 * 1048576)
            {
                try
                {
                    f.parent.createDirectory();
                    var tmp0:File = f.parent.resolvePath(f.name + ".tmp");
                    var fs0:FileStream = new FileStream();
                    fs0.open(tmp0, "write");
                    fs0.writeBytes(src, 0, src.length);
                    fs0.close();
                    tmp0.moveTo(f, true);
                    if (f.size != src.length) say("cache: gravação incompleta de " + f.name + " (" + f.size + " de " + src.length + " bytes)");
                }
                catch (e0:Error) { say("cache: falha ao gravar " + f.name + " (" + e0.message + ")"); }
                return;
            }
            var copy:ByteArray = new ByteArray();
            copy.writeBytes(src, 0, src.length);
            var tmp:File = f.parent.resolvePath(f.name + ".tmp");
            var fs:FileStream = new FileStream();
            fs.addEventListener(Event.CLOSE, function(ev:Event):void
            {
                try { tmp.moveTo(f, true); } catch (err:Error) {}
            });
            fs.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void
            {
                try { fs.close(); } catch (err:Error) {}
                try { tmp.deleteFile(); } catch (err2:Error) {}
            });
            try
            {
                f.parent.createDirectory();
                fs.openAsync(tmp, "write");
                fs.writeBytes(copy);
                fs.close();
            }
            catch (e:Error) {}
        }

        // ---------- cache do jogo ----------
        // Anota no log (uma vez por sessão) os arquivos de CÓDIGO do jogo (N_xxxxxxxx.png/.swf grandes),
        // para você poder colocar os links em SWF_URLS do mods.py e exportar os scripts.
        private static var codeSeen:Object = {};
        private static function noteCode(key:String, n:int):void
        {
            if (n < 400000) return;
            var u:String = key.substring(key.indexOf("|") + 1);
            var nm:String = u.substring(u.lastIndexOf("/") + 1);
            var q:int = nm.indexOf("?"); if (q >= 0) nm = nm.substring(0, q);
            if (!/^\d+_[0-9a-fA-F]{6,10}\.(png|swf)$/.test(nm) && !/\.swf$/i.test(nm)) return;
            if (codeSeen[nm]) return;
            codeSeen[nm] = true;
            say("CODIGO: " + u + " (" + Math.round(n / 1024) + " KB)");
        }

        public static function cacheGet(key:String):ByteArray
        {
            var f:File = fileFor(key);
            var ttl:Number = key.indexOf("ttl|") == 0 ? TTL_3D : (key.indexOf("ttl1|") == 0 ? TTL_1D : 0);
            var nm:String = key.substring(key.lastIndexOf("/") + 1);
            if (ttl > 0 && fastNeg && isNegKey(key))
            {
                statFast++;
                if (fastLogN < 15) { fastLogN++; say("imagem inexistente respondida na hora: " + nm); }
                return placeholderPng();
            }
            if (ttl > 0)
            {
                try
                {
                    if (f.exists)
                    {
                        var mt:Number = f.modificationDate.time;
                        var age:Number = new Date().time - mt;
                        // data de modificação absurda (antes de 2001) não vale como "arquivo velho": não apaga
                        if (mt > 946684800000 && age > ttl)
                        {
                            f.deleteFile();
                            if (diagN < 60) { diagN++; say("cache EXPIRADO (" + Math.round(age / 3600000) + " h): " + nm); }
                        }
                        else if (mt <= 946684800000 && diagN < 60) { diagN++; say("cache: data do arquivo inválida (" + mt + "): " + nm); }
                    }
                }
                catch (e:Error) { if (diagN < 60) { diagN++; say("cache: erro ao checar validade: " + e.message); } }
            }
            var t0:int = getTimer();
            var b:ByteArray = readFile(f);
            var dt:int = getTimer() - t0;
            if (dt > 120 && b) say("cache lento: " + dt + " ms para ler " + Math.round(b.length / 1024) + " KB (" + nm + ")");
            if (b) { cacheHits++; statHit++; statHitBytes += b.length; noteCode(key, b.length); } else { cacheMiss++; statMiss++; }
            if (!b && ttl > 0 && diagN < 60) { diagN++; say("cache MISS: " + nm + (f.exists ? " (arquivo existe mas não leu)" : " (não está no disco)")); }
            return b;
        }

        public static function cachePut(key:String, b:ByteArray):void
        {
            if (b == null || b.length == 0) return;
            statPut++; statPutBytes += b.length;
            noteCode(key, b.length);
            if (b.length >= 262144) say("baixou " + Math.ceil(b.length / 1024) + " KB: " + key.substring(key.indexOf("|") + 1));
            writeFileAsync(fileFor(key), b);
        }

        public static function cacheDel(key:String):void
        {
            try { fileFor(key).deleteFile(); } catch (e:Error) {}
        }

        public static function cacheSize():Number
        {
            var total:Number = 0;
            var stack:Array = [cacheDir];
            while (stack.length)
            {
                var d:File = stack.pop();
                if (!d.exists) continue;
                for each (var x:File in d.getDirectoryListing())
                {
                    if (x.isDirectory) stack.push(x); else total += x.size;
                }
            }
            return total;
        }

        public static function clearCache():void
        {
            neg = {};
            try { if (cacheDir.exists) cacheDir.deleteDirectory(true); } catch (e:Error) {}
        }

        // Apaga arquivos de cache com mais de 30 dias e restos de gravação (.tmp).
        public static function pruneOld():void
        {
            // Varrer a pasta inteira (milhares de arquivos) na abertura atrasa o app: faz no máximo 1x por dia.
            if (new Date().time - Prefs.lastPrune < 20 * 3600 * 1000) return;
            Prefs.lastPrune = new Date().time;
            var limit:Number = new Date().time - KEEP_MS;
            var n:int = 0;
            try
            {
                var stack:Array = [cacheDir];
                while (stack.length)
                {
                    var d:File = stack.pop();
                    if (!d.exists) continue;
                    for each (var x:File in d.getDirectoryListing())
                    {
                        if (x.isDirectory) { stack.push(x); continue; }
                        try
                        {
                            if (x.modificationDate.time < limit || /\.tmp$/.test(x.name)) { x.deleteFile(); n++; }
                        }
                        catch (e:Error) {}
                    }
                }
            }
            catch (err:Error) {}
            if (n > 0) say("cache: " + n + " arquivos antigos apagados");
        }

        // ---------- correção de SWF ----------
        // Assinatura barata (amostra do arquivo) só para achar a versão já corrigida no disco.
        private static function signature(b:ByteArray):String
        {
            var a:uint = 2166136261;
            var h:uint = 5381;
            var step:int = Math.max(1, b.length >> 14);
            for (var i:int = 0; i < b.length; i += step)
            {
                var c:int = b[i];
                a = ((a ^ c) * 16777619) >>> 0;
                h = ((h * 33) + c) >>> 0;
            }
            return "v3:" + b.length + ":" + a.toString(16) + h.toString(16);
        }

        public static function fix(b:ByteArray):ByteArray
        {
            var t0:int = getTimer();
            var r:ByteArray = fixInner(b);
            var dt:int = getTimer() - t0;
            if (dt > 80) say("SwfFixer: fix levou " + dt + " ms (" + (b ? Math.round(b.length / 1024) : 0) + " KB)");
            return r;
        }

        // Marca (na memória e em disco) um swf que não precisa de correção, para não descompactar e varrer de novo
        private static function markNoFix(key:String):void
        {
            noFix[key] = true;
            var m:ByteArray = new ByteArray();
            m.writeByte(1);
            writeFileAsync(fileFor(key, "nofix"), m);
        }

        private static function fixInner(b:ByteArray):ByteArray
        {
            if (b == null || b.length < 17) return b;
            if (b[1] != 87 || b[2] != 83) return b;          // não é "?WS"
            var key:String = signature(b);
            if (noFix[key]) return b;
            if (fileFor(key, "nofix").exists) { noFix[key] = true; return b; }
            var hit:ByteArray = readFile(fileFor(key, "swf"));
            if (hit)
            {
                say("SwfFixer: já corrigido, veio do cache (" + Math.round(hit.length / 1024) + " KB)");
                return hit;
            }
            var kind:int = b[0];
            var ver:int = b[3];
            var body:ByteArray = new ByteArray();
            try
            {
                if (kind == 70)                               // 'F' sem compressão
                {
                    body.writeBytes(b, 8);
                }
                else if (kind == 67)                          // 'C' zlib
                {
                    body.writeBytes(b, 8);
                    body.uncompress();
                }
                else if (kind == 90)                          // 'Z' LZMA
                {
                    b.endian = Endian.LITTLE_ENDIAN;
                    b.position = 4;
                    var total:uint = b.readUnsignedInt();
                    body.writeBytes(b, 12, 5);                // propriedades LZMA
                    body.endian = Endian.LITTLE_ENDIAN;
                    body.writeUnsignedInt(total - 8);         // tamanho descompactado
                    body.writeUnsignedInt(0);
                    body.writeBytes(b, 17);
                    body.uncompress("lzma");
                }
                else
                {
                    return b;
                }
            }
            catch (e:Error)
            {
                say("SwfFixer: não descompactou (" + e.message + ")");
                b.position = 0;
                return b;
            }
            // Procura a string "loadBytes" (tamanho 9 + letras) no SWF e troca o "s" final por "Z".
            var count:int = 0;
            var end:int = body.length - 10;
            for (var i:int = 0; i < end; i++)
            {
                if (body[i] == 9 && body[i + 1] == 108 && body[i + 2] == 111 && body[i + 3] == 97
                    && body[i + 4] == 100 && body[i + 5] == 66 && body[i + 6] == 121
                    && body[i + 7] == 116 && body[i + 8] == 101 && body[i + 9] == 115)
                {
                    body[i + 9] = 90;
                    count++;
                    i += 9;
                }
            }
            if (count == 0)
            {
                markNoFix(key);
                b.position = 0;
                return b;
            }
            var out:ByteArray = new ByteArray();
            out.writeByte(70);
            out.writeByte(87);
            out.writeByte(83);
            out.writeByte(ver);
            out.endian = Endian.LITTLE_ENDIAN;
            out.writeUnsignedInt(body.length + 8);
            out.writeBytes(body);
            out.position = 0;
            writeFileAsync(fileFor(key, "swf"), out);
            say("SwfFixer: SWF corrigido (" + count + " loadBytes, " + out.length + " bytes)");
            return out;
        }
    }
}
