package
{
    import flash.display.Loader;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileStream;
    import flash.system.ApplicationDomain;
    import flash.system.LoaderContext;
    import flash.utils.ByteArray;
    import flash.utils.Endian;

    // Ponte entre o app e as cópias modificadas do Loading.swf (assets/game).
    // Essas cópias chamam, em qualquer Loader, funções que NÃO existem no AIR puro:
    //   __lofix(bytes)        -> corrige um SWF baixado (troca loadBytes por loadByteZ)
    //   loadByteZ(bytes, ctx) -> loadBytes com allowCodeImport ligado
    //   __cacheGet/Put/Del    -> cache em disco dos arquivos que o jogo baixa
    //   __dlLog/__dlTrace/__loadFail -> mensagens para o log
    // install() cria essas funções em Loader.prototype. Sem isso o jogo dá erro #1063 e fica tela preta.
    public class SwfFixer
    {
        public static var logger:Function;
        public static var gameDomain:ApplicationDomain;
        public static var modsPath:String = "";     // pasta de mods locais (definida pelo Main)
        private static var noted:Object = {};
        private static var missed:Object = {};
        private static var seenMaps:Object = {};
        public static var cacheHits:int = 0;
        public static var cacheMiss:int = 0;

        private static const TTL_3D:Number = 3 * 24 * 3600 * 1000;
        private static const TTL_1D:Number = 24 * 3600 * 1000;
        private static const KEEP_MS:Number = 30 * 24 * 3600 * 1000;

        private static function say(m:String):void { if (logger != null) logger(m); }

        public static function install():void
        {
            Loader.prototype["__lofix"] = function(b:ByteArray):ByteArray
            {
                return SwfFixer.fix(b);
            };
            Loader.prototype["loadByteZ"] = function(b:ByteArray, ctx:LoaderContext = null):void
            {
                if (ctx == null)
                    ctx = new LoaderContext(false, new ApplicationDomain(gameDomain || ApplicationDomain.currentDomain));
                ctx.allowCodeImport = true;
                Loader(this).loadBytes(b, ctx);
            };
            Loader.prototype["__cacheGet"] = function(k:String):ByteArray { return SwfFixer.cacheGet(k); };
            Loader.prototype["__cachePut"] = function(k:String, b:ByteArray):void { SwfFixer.cachePut(k, b); };
            Loader.prototype["__cacheDel"] = function(k:String):void { SwfFixer.cacheDel(k); };
            Loader.prototype["__dlLog"] = function(u:String, n:int):void
            {
                if (n >= 262144) SwfFixer.say("baixou " + Math.ceil(n / 1024) + " KB (sem cache): " + u);
                else if (u.indexOf("mapmaterial/land") >= 0) SwfFixer.say("TILE veio do servidor (download): " + u.substring(u.lastIndexOf("/") + 1) + " (" + n + " bytes)");
            };
            Loader.prototype["__dlTrace"] = function(u:String, n:int):void
            {
                SwfFixer.say("baixou " + Math.ceil(n / 1024) + " KB: " + u);
            };
            Loader.prototype["__loadFail"] = function(u:String):void { SwfFixer.say("FALHOU download: " + u); };
            var names:Array = ["__lofix", "loadByteZ", "__cacheGet", "__cachePut", "__cacheDel", "__loadFail", "__dlLog", "__dlTrace"];
            for each (var nm:String in names) Loader.prototype.setPropertyIsEnumerable(nm, false);
        }

        // ---------- arquivos ----------
        public static function get cacheDir():File
        {
            return File.applicationStorageDirectory.resolvePath("gamecache");
        }

        private static function hash(s:String):String
        {
            var a:uint = 2166136261;
            var h:uint = 5381;
            for (var i:int = 0; i < s.length; i++)
            {
                var c:int = s.charCodeAt(i);
                a = ((a ^ c) * 16777619) >>> 0;
                h = ((h * 33) ^ c) >>> 0;
            }
            return a.toString(16) + h.toString(16);
        }

        private static function fileFor(key:String, sub:String = "dl"):File
        {
            var name:String = key.replace(/[?#].*$/, "");
            name = name.substring(name.lastIndexOf("/") + 1).replace(/[^A-Za-z0-9._-]/g, "_");
            if (name.length > 40) name = name.substring(name.length - 40);
            return cacheDir.resolvePath(sub + "/" + hash(key) + "_" + name);
        }

        private static function readFile(f:File):ByteArray
        {
            if (!f.exists) return null;
            var ba:ByteArray = new ByteArray();
            var fs:FileStream = new FileStream();
            try
            {
                fs.open(f, "read");
                fs.readBytes(ba);
                fs.close();
            }
            catch (e:Error)
            {
                try { fs.close(); } catch (e2:Error) {}
                return null;
            }
            ba.position = 0;
            return ba;
        }

        // Grava em arquivo temporário e só depois troca pelo definitivo (não deixa arquivo pela metade).
        private static function writeFileAsync(f:File, src:ByteArray):void
        {
            var copy:ByteArray = new ByteArray();
            copy.writeBytes(src, 0, src.length);
            var tmp:File = f.parent.resolvePath(f.name + ".tmp");
            var fs:FileStream = new FileStream();
            fs.addEventListener(Event.CLOSE, function(ev:Event):void
            {
                try { tmp.moveTo(f, true); } catch (err:Error) {}
            });
            fs.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void
            {
                try { fs.close(); } catch (err:Error) {}
                try { tmp.deleteFile(); } catch (err2:Error) {}
            });
            try
            {
                f.parent.createDirectory();
                fs.openAsync(tmp, "write");
                fs.writeBytes(copy);
                fs.close();
            }
            catch (e:Error) {}
        }

        // ---------- cache do jogo ----------
        // Mods locais. Tiles de mapa só valem dentro da pasta do mapa: <mods>/<id do mapa>/tile_X_Y.jpg
        // (ex.: mods/10000/tile_5_3.jpg), assim outro mapa com os mesmos nomes NÃO é afetado.
        // Outros arquivos (não-tile) podem ficar direto em <mods>/<nome>.
        // Também anota cada URL pedida em <mods>/_pedidos.txt.
        private static function findMod(dir:File, name:String):File
        {
            var f:File = dir.resolvePath(name);
            if (f.exists && !f.isDirectory) return f;
            var nh:String = name.replace(/_[0-9a-fA-F]{8}(\.[A-Za-z0-9]+)$/, "$1");   // aceita nome sem o hash
            if (nh != name)
            {
                f = dir.resolvePath(nh);
                if (f.exists && !f.isDirectory) return f;
            }
            return null;
        }

        private static function modFor(key:String):ByteArray
        {
            if (modsPath == "") return null;
            var url:String = key.indexOf("|") >= 0 ? key.substring(key.indexOf("|") + 1) : key;
            var clean:String = url.replace(/[?#].*$/, "");
            var slash:int = clean.lastIndexOf("/");
            var name:String = clean.substring(slash + 1);
            var folder:String = slash > 0 ? clean.substring(0, slash) : "";
            folder = folder.substring(folder.lastIndexOf("/") + 1);          // ex.: "10000"
            if (name == "" || name.indexOf("..") >= 0) return null;
            var isTile:Boolean = /^tile_\d+_\d+/.test(name);
            try
            {
                if (!noted[clean])
                {
                    noted[clean] = true;
                    var lf:File = new File(modsPath).resolvePath("_pedidos.txt");
                    var w:FileStream = new FileStream();
                    w.open(lf, "append");
                    w.writeUTFBytes(clean + "\n");
                    w.close();
                }
                var mf:File = null;
                if (/^[A-Za-z0-9_\-]+$/.test(folder)) mf = findMod(new File(modsPath).resolvePath(folder), name);
                if (mf == null && !isTile) mf = findMod(new File(modsPath), name);
                if (mf != null)
                {
                    var b:ByteArray = readFile(mf);
                    if (b) { say("MOD local usado: " + folder + "/" + mf.name + " (" + b.length + " bytes)"); return b; }
                }
            }
            catch (e:Error) { say("modFor erro: " + e.message); }
            if (clean.indexOf("mapmaterial/land") >= 0 && !missed[name])
            {
                missed[name] = true;
                say("TILE pedido SEM mod: " + folder + "/" + name);
            }
            return null;
        }

        public static function cacheGet(key:String):ByteArray
        {
            var mod:ByteArray = modFor(key);
            if (mod) return mod;
            var f:File = fileFor(key);
            var ttl:Number = key.indexOf("ttl|") == 0 ? TTL_3D : (key.indexOf("ttl1|") == 0 ? TTL_1D : 0);
            if (ttl > 0)
            {
                try
                {
                    if (f.exists && new Date().time - f.modificationDate.time > ttl) f.deleteFile();
                }
                catch (e:Error) {}
            }
            var b:ByteArray = readFile(f);
            if (b) cacheHits++; else cacheMiss++;
            return b;
        }

        public static function cachePut(key:String, b:ByteArray):void
        {
            if (b == null || b.length == 0) return;
            if (b.length >= 262144) say("baixou " + Math.ceil(b.length / 1024) + " KB: " + key.substring(key.indexOf("|") + 1));
            else if (key.indexOf("mapmaterial/land") >= 0) say("TILE salvo no cache (veio do servidor): " + key.substring(key.lastIndexOf("/") + 1));
            writeFileAsync(fileFor(key), b);
        }

        public static function cacheDel(key:String):void
        {
            try { fileFor(key).deleteFile(); } catch (e:Error) {}
        }

        public static function cacheSize():Number
        {
            var total:Number = 0;
            var stack:Array = [cacheDir];
            while (stack.length)
            {
                var d:File = stack.pop();
                if (!d.exists) continue;
                for each (var x:File in d.getDirectoryListing())
                {
                    if (x.isDirectory) stack.push(x); else total += x.size;
                }
            }
            return total;
        }

        public static function clearCache():void
        {
            try { if (cacheDir.exists) cacheDir.deleteDirectory(true); } catch (e:Error) {}
        }

        // Apaga arquivos de cache com mais de 30 dias e restos de gravação (.tmp).
        public static function pruneOld():void
        {
            var limit:Number = new Date().time - KEEP_MS;
            var n:int = 0;
            try
            {
                var stack:Array = [cacheDir];
                while (stack.length)
                {
                    var d:File = stack.pop();
                    if (!d.exists) continue;
                    for each (var x:File in d.getDirectoryListing())
                    {
                        if (x.isDirectory) { stack.push(x); continue; }
                        try
                        {
                            if (x.modificationDate.time < limit || /\.tmp$/.test(x.name)) { x.deleteFile(); n++; }
                        }
                        catch (e:Error) {}
                    }
                }
            }
            catch (err:Error) {}
            if (n > 0) say("cache: " + n + " arquivos antigos apagados");
        }

        // ---------- correção de SWF ----------
        // Assinatura barata (amostra do arquivo) só para achar a versão já corrigida no disco.
        private static function signature(b:ByteArray):String
        {
            var a:uint = 2166136261;
            var h:uint = 5381;
            var step:int = Math.max(1, b.length >> 14);
            for (var i:int = 0; i < b.length; i += step)
            {
                var c:int = b[i];
                a = ((a ^ c) * 16777619) >>> 0;
                h = ((h * 33) + c) >>> 0;
            }
            return "v3:" + b.length + ":" + a.toString(16) + h.toString(16);
        }

        public static function fix(b:ByteArray):ByteArray
        {
            if (b == null || b.length < 17) return b;
            if (b[1] != 87 || b[2] != 83) return b;          // não é "?WS"
            var key:String = signature(b);
            var hit:ByteArray = readFile(fileFor(key, "swf"));
            if (hit)
            {
                say("SwfFixer: já corrigido, veio do cache (" + Math.round(hit.length / 1024) + " KB)");
                return hit;
            }
            var kind:int = b[0];
            var ver:int = b[3];
            var body:ByteArray = new ByteArray();
            try
            {
                if (kind == 70)                               // 'F' sem compressão
                {
                    body.writeBytes(b, 8);
                }
                else if (kind == 67)                          // 'C' zlib
                {
                    body.writeBytes(b, 8);
                    body.uncompress();
                }
                else if (kind == 90)                          // 'Z' LZMA
                {
                    b.endian = Endian.LITTLE_ENDIAN;
                    b.position = 4;
                    var total:uint = b.readUnsignedInt();
                    body.writeBytes(b, 12, 5);                // propriedades LZMA
                    body.endian = Endian.LITTLE_ENDIAN;
                    body.writeUnsignedInt(total - 8);         // tamanho descompactado
                    body.writeUnsignedInt(0);
                    body.writeBytes(b, 17);
                    body.uncompress("lzma");
                }
                else
                {
                    return b;
                }
            }
            catch (e:Error)
            {
                say("SwfFixer: não descompactou (" + e.message + ")");
                b.position = 0;
                return b;
            }
            // Procura a string "loadBytes" (tamanho 9 + letras) no SWF e troca o "s" final por "Z".
            var count:int = 0;
            var end:int = body.length - 10;
            for (var i:int = 0; i < end; i++)
            {
                if (body[i] == 9 && body[i + 1] == 108 && body[i + 2] == 111 && body[i + 3] == 97
                    && body[i + 4] == 100 && body[i + 5] == 66 && body[i + 6] == 121
                    && body[i + 7] == 116 && body[i + 8] == 101 && body[i + 9] == 115)
                {
                    body[i + 9] = 90;
                    count++;
                    i += 9;
                }
            }
            if (count == 0)
            {
                b.position = 0;
                return b;
            }
            var out:ByteArray = new ByteArray();
            out.writeByte(70);
            out.writeByte(87);
            out.writeByte(83);
            out.writeByte(ver);
            out.endian = Endian.LITTLE_ENDIAN;
            out.writeUnsignedInt(body.length + 8);
            out.writeBytes(body);
            out.position = 0;
            writeFileAsync(fileFor(key, "swf"), out);
            say("SwfFixer: SWF corrigido (" + count + " loadBytes, " + out.length + " bytes)");
            return out;
        }
    }
}
