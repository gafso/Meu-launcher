package
{
    import flash.events.TimerEvent;
    import flash.utils.Timer;

    // Mapa 8x8 simulado (sem o jogo) para testar o painel e a lógica do macro.
    // Imita o essencial do jogo: paredes, baús, recursos, monstros com carta, chefe, energia e passos de 4 direções.
    public class SimPlanesAdapter implements IPlanesAdapter
    {
        private static const N:int = 8;
        private var data:Array = [];
        private var px:int = 0;
        private var py:int = 0;
        private var en:int = 160;
        private var isMoving:Boolean = false;
        private var route:Array = [];
        private var stepTimer:Timer;
        private var cardCell:Object = null;
        private var seed:Number = 20261022;
        private var layer:int = 1;
        private var floors:Object = {};
        private var links:Array = [];   // teleportes entre pisos: {l, x, y, tl, tx, ty}

        public function SimPlanesAdapter()
        {
            reset();
        }

        private function rnd():Number
        {
            seed = (seed * 16807) % 2147483647;
            return seed / 2147483647;
        }

        private function at(x:int, y:int):Object
        {
            if (x < 0 || y < 0 || x >= N || y >= N) return null;
            return data[x * N + y];
        }

        private function place(type:int, count:int, cost:int):void
        {
            var placed:int = 0;
            var guard:int = 0;
            while (placed < count && guard < 500)
            {
                guard++;
                var x:int = int(rnd() * N);
                var y:int = int(rnd() * N);
                var c:Object = at(x, y);
                if (c == null || (x == 0 && y == 0) || c.type != 0) continue;
                c.type = type;
                c.id = 1000 + type;
                c.cost = cost;
                placed++;
            }
        }

        // Gera o mapa de novo (sempre o mesmo, para os testes serem repetíveis).
        public function reset():void
        {
            if (stepTimer != null) { stepTimer.stop(); stepTimer = null; }
            seed = 20261022;
            data = [];
            px = 0; py = 0; en = 160; isMoving = false; route = []; cardCell = null;
            simBuys = 0; simDia = 100;
            for (var x:int = 0; x < N; x++)
                for (var y:int = 0; y < N; y++)
                    data.push({x: x, y: y, id: 0, type: 0, cost: 0, need: 0, opened: false, occupied: false, base: false});
            place(-1, 11, 0);     // paredes
            place(11, 3, 2);      // baús comuns
            place(10, 2, 3);      // baús de prata
            place(15, 1, 3);      // baú escondido
            place(5, 2, 2);       // recursos
            place(2, 3, 6);       // monstros
            place(13, 2, 8);      // monstros de prata
            place(1, 1, 10);      // monstro de ouro
            place(12, 1, 20);     // chefe
            place(62, 1, 0);      // saída
            place(3, 1, 0);       // mercado
            place(8, 1, 0);       // portal escondido (o olho)
            place(91, 1, 0);      // teleporte A
            place(92, 1, 0);      // teleporte B
            // paredes têm id 0 para não contarem como evento
            for each (var c:Object in data) if (c.type == -1) c.id = 0;
            reveal();
        }

        // Névoa: o jogo abre as casas ao redor de quem anda (aqui, raio 2).
        private function reveal():void
        {
            for each (var c:Object in data)
                if (Math.abs(c.x - px) <= 2 && Math.abs(c.y - py) <= 2) c.opened = true;
        }

        public function get ready():Boolean { return true; }
        public function get cols():int { return N; }
        public function get rows():int { return N; }
        public function get posX():int { return px; }
        public function get posY():int { return py; }
        public function get energy():int { return en; }
        public function get level():int { return 99; }
        public function get stepCost():int { return 1; }
        public function get layerId():int { return layer; }
        public function get layerNow():int { return layer; }
        public function get dead():Boolean { return false; }
        public function get moving():Boolean { return isMoving; }
        public function cells():Array { return data; }
        public function suppressFrames():void {}
        public function leavePlanes():void {}
        // compra de energia simulada: enche até 500, 10 diamantes cada, limite 5 por dia, 100 diamantes
        private var simBuys:int = 0;
        private var simDia:int = 100;
        public function get maxEnergy():int { return 500; }
        public function get buyCount():int { return simBuys; }
        public function get buyLimit():int { return 5; }
        public function get buyCost():int { return 10; }
        public function get diamonds():int { return simDia; }
        public function buyEnergy(bind:Boolean):void
        {
            if (simBuys >= 5 || simDia < 10) return;
            simBuys++; simDia -= 10; en = 500;
        }

        public function pendingCard():Array { return cardCell != null ? [cardCell.id] : null; }

        public function pickCard(p0:int, card:int):void
        {
            if (cardCell == null) return;
            cardCell.id = 0; cardCell.type = 0;
            cardCell = null;
        }

        // Busca em largura: andar em 4 direções, parede (-1) bloqueia.
        public function path(fx:int, fy:int, tx:int, ty:int):Array
        {
            var prev:Object = {};
            var queue:Array = [fx * 100 + fy];
            prev[fx * 100 + fy] = -1;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            while (queue.length > 0)
            {
                var cur:int = queue.shift();
                var cx:int = int(cur / 100);
                var cy:int = cur % 100;
                if (cx == tx && cy == ty)
                {
                    var out:Array = [];
                    var k:int = cur;
                    while (k != -1) { out.unshift({x: int(k / 100), y: k % 100}); k = int(prev[k]); }
                    return out;
                }
                for each (var d:Array in dirs)
                {
                    var nx:int = cx + d[0];
                    var ny:int = cy + d[1];
                    var cell:Object = at(nx, ny);
                    var key:int = nx * 100 + ny;
                    if (cell == null || cell.type == -1 || prev[key] !== undefined) continue;
                    prev[key] = cur;
                    queue.push(key);
                }
            }
            return null;
        }

        public function moveTo(x:int, y:int):void
        {
            if (isMoving) return;
            if (x == px && y == py) { trigger(); return; }
            var p:Array = path(px, py, x, y);
            if (p == null) return;
            p.shift();
            route = p;
            isMoving = true;
            stepTimer = new Timer(260);
            stepTimer.addEventListener(TimerEvent.TIMER, onStep);
            stepTimer.start();
        }

        private function onStep(e:TimerEvent):void
        {
            if (route.length == 0)
            {
                stepTimer.stop();
                stepTimer.removeEventListener(TimerEvent.TIMER, onStep);
                stepTimer = null;
                isMoving = false;
                trigger();
                return;
            }
            var n:Object = route.shift();
            px = n.x; py = n.y;
            reveal();
            en = Math.max(0, en - 1);
        }

        // Ao chegar: baús/recursos/etc. resolvem na hora; monstros e chefe pedem uma carta.
        // Cenário de teste: o olho (8) fica numa parte do piso 1 que só se alcança por um portal de piso (61),
        // e no piso 2 há um portal par (62) bem perto de onde se chega, que volta para o outro lado da parede.
        public function scenarioHop():void
        {
            var f1:Array = []; var f2:Array = [];
            for (var x:int = 0; x < N; x++)
                for (var y:int = 0; y < N; y++)
                {
                    f1.push({x: x, y: y, id: 0, type: (y == 3 ? -1 : 0), cost: 0, need: 0, opened: false, occupied: false, base: false});
                    f2.push({x: x, y: y, id: 0, type: 0, cost: 0, need: 0, opened: false, occupied: false, base: false});
                }
            f1[1 * N + 1].type = 61; f1[1 * N + 1].id = 1061;
            f1[6 * N + 6].type = 8;  f1[6 * N + 6].id = 1008;
            f1[3 * N + 5].type = 11; f1[3 * N + 5].id = 1011; f1[3 * N + 5].cost = 2;
            f2[3 * N + 4].type = 62; f2[3 * N + 4].id = 1062;
            floors = {1: f1, 2: f2};
            links = [{l: 1, x: 1, y: 1, tl: 2, tx: 3, ty: 3}, {l: 2, x: 3, y: 4, tl: 1, tx: 3, ty: 5}];
            layer = 1; data = f1; px = 0; py = 0; en = 200; isMoving = false; route = []; cardCell = null;
            reveal();
        }

        private function trigger():void
        {
            var c:Object = at(px, py);
            if (c == null || c.id == 0) return;
            for each (var lk:Object in links)
                if (lk.l == layer && lk.x == px && lk.y == py)
                {
                    layer = lk.tl; data = floors[layer]; px = lk.tx; py = lk.ty; reveal();
                    return;
                }
            en = Math.max(0, en - c.cost);
            if (c.type == 91 || c.type == 92)
            {
                for each (var o:Object in data) if (o.type == (c.type == 91 ? 92 : 91)) { px = o.x; py = o.y; reveal(); break; }
                return;
            }
            if (c.type == 2 || c.type == 13 || c.type == 1 || c.type == 14 || c.type == 12) cardCell = c;
            else if (c.type != 62 && c.type != 3 && c.type != 8) { c.id = 0; c.type = 0; }
        }
    }
}
