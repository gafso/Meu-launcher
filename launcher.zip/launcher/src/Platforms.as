package
{
    public class Platforms
    {
        // [nome exibido, host do site de login]
        public static const LIST:Array = [
            ["Legend Online Brasil",         "lobr.creaction-network.com"],
            ["Legend Online Español",        "loes.creaction-network.com"],
            ["Legend Online Türkiye",        "lotr.creaction-network.com"],
            ["Legend Online Reborn Türkiye", "lortr.creaction-network.com"],
            ["Legend Online Classic Brasil", "lorpt.creaction-network.com"],
            ["Wartune",                      "wartune.wan.com"]
        ];
    }
}
