package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.events.TimerEvent;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Troca de plano (modo MINAS): sai do plano, abre o Transmissor, descarta o plano usado, escolhe outro (ou usa planos da
    // bolsa) e entra. Quando já está dentro e o mapa carregou, chama onEnter (que liga a busca do olho).
    // Baseado no que o gravador viu: Transmissor = prédio "Transmissor" no castelo; lista = PlanesListView/PlanesItemView;
    // bolsa = PlanesBagFrame/PlanesBagCell; sair = op 19; entrar = op 15 [id]; descartar = op 18 [id].
    // Cada passo confere se o jogo mudou de estado; se a op não funcionar, tenta o botão da tela.
    public class PlanesCycle
    {
        public var logger:Function;
        public var onEnter:Function;
        public var running:Boolean = false;
        public var status:String = "parado";

        private var ad:GamePlanesAdapter;
        private var timer:Timer;
        private var st:String = "idle";
        private var t0:int = 0;
        private var tries:int = 0;
        private var curId:int = 0;
        private var enteredId:int = 0;      // plano em que o ciclo entrou por último
        private var markSkip:Boolean = false; // plano que deu mina: não descarta e não volta nele
        private var skipIds:Array = [];
        private var bagTried:Boolean = false;
        private var discardCur:Boolean = false;
        private var lastPress:int = 0;
        private var seenAt:int = 0;
        private var listBefore:int = 0;
        private var useTries:int = 0;
        private var lastUse:int = 0;
        private var lastLayer:int = 0;
        private var rounds:int = 0;
        private var errCount:int = 0;
        public var mode:int = 3;               // 3 = Minas | 4 = Fechar planos
        public var element:String = "";        // "" = varia o elemento; senão, só planos desse elemento
        private var elemUse:Object = {};       // quantas vezes cada elemento foi usado
        private var lastCellElem:String = "";
        private var preIds:Array = [];         // ids da lista antes de usar planos da bolsa (modo 4: acha o plano novo)
        private var wantNew:Boolean = false;
        private var fillTried:Boolean = false;

        public function PlanesCycle(a:GamePlanesAdapter) { ad = a; }

        private function say(s:String):void { if (logger != null) logger("[Troca] " + s); }

        private function go(s:String):void { st = s; t0 = getTimer(); tries = 0; seenAt = 0; alertPress = 0; status = "troca de plano: " + s; }

        private function fail(msg:String):void { say("FALHOU: " + msg); stop("falhou: " + msg); }

        private function root():DisplayObjectContainer { return SwfFixer.rootStage; }

        // Começa pelo fim de um plano: sai, abre o Transmissor, descarta (se pedido) e entra em outro.
        public function begin(discard:Boolean, layerId:int):void
        {
            if (running) return;
            discardCur = discard;
            lastLayer = layerId;
            curId = 0;
            markSkip = !discard;
            fillTried = false; wantNew = false; bagTried = false;
            say("fim do plano" + (discard ? " (vai descartar)" : "") + ": saindo para trocar");
            startTimer();
            go("leave");
        }

        // Começa já no castelo (sem plano atual): abre o Transmissor e entra em um plano.
        public function startFromCastle():void
        {
            if (running) return;
            discardCur = false; curId = 0; enteredId = 0; markSkip = false; skipIds = []; bagTried = false; fillTried = false; wantNew = false;
            say("começando pelo castelo: abrindo o Transmissor");
            startTimer();
            go("open");
        }

        private function startTimer():void
        {
            running = true;
            timer = new Timer(800);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
        }

        public function stop(reason:String = "parado"):void
        {
            if (timer != null) { timer.stop(); timer.removeEventListener(TimerEvent.TIMER, onTick); timer = null; }
            if (running) say("parou: " + reason);
            running = false;
            status = reason;
            st = "idle";
        }

        private function onTick(e:TimerEvent):void
        {
            try { step(); errCount = 0; }
            catch (err:Error)
            {
                errCount++;
                say("ERRO: " + err.message + " (" + errCount + "/5, tento de novo)");
                if (errCount >= 5) stop("erro: " + err.message);
            }
        }

        private function hasPlan(list:Array, id:int):Boolean
        {
            for (var i:int = 0; i < list.length; i++) if (int(list[i].id) == id) return true;
            return false;
        }

        private var alertPress:int = 0;

        // Aperta o botão de confirmar de um SimpleAlert (prefere o que tem texto de confirmação; senão o da esquerda;
        // se o aviso não sumir depois de alguns toques, tenta o outro botão).
        private function confirmAlert(al:DisplayObject):void
        {
            var bs:Array = [];
            UiHelper.findAll(al as DisplayObjectContainer, "IconButton", bs, 8, 6);
            if (bs.length == 0) { say("aviso sem botões"); return; }
            bs.sort(function(x:DisplayObject, y:DisplayObject):int { return UiHelper.gx(x) - UiHelper.gx(y); });
            var pick:DisplayObject = null;
            for (var i:int = 0; i < bs.length; i++)
            {
                var b:DisplayObject = bs[i];
                if (UiHelper.hasText(b, "Confirm") || UiHelper.hasText(b, "Sim") || UiHelper.hasText(b, "OK") || UiHelper.hasText(b, "Ok")) { pick = b; break; }
            }
            if (pick == null) pick = bs[int(alertPress / 3) % bs.length];
            alertPress++;
            UiHelper.press(pick);
        }

        // Descobre qual plano da lista é o que acabei de usar: pela camada em que estava; senão, o último em que o ciclo entrou.
        private function identifyCur(list:Array):int
        {
            if (lastLayer != 0)
                for (var p:int = 0; p < list.length; p++)
                    if (list[p].layers.indexOf(lastLayer) >= 0) return int(list[p].id);
            if (enteredId != 0 && hasPlan(list, enteredId)) return enteredId;
            return 0;
        }

        private function step():void
        {
            var now:int = getTimer();
            var list:Array;
            var rt:DisplayObjectContainer = root();
            if (rt == null) return;

            if (st == "leave")
            {
                if (ad.sceneName() != "PLANES_WAR_SCENE") { go("open"); return; }
                var alv:DisplayObject = UiHelper.find(rt, "SimpleAlert");
                if (alv != null)
                {
                    if (seenAt == 0) seenAt = now;
                    if (now - seenAt > 15000) { fail("o aviso de saída não fechou"); return; }
                    if (now - lastPress > 1200) { lastPress = now; say("confirmando o aviso de saída"); confirmAlert(alv); }
                    return;
                }
                seenAt = 0;
                if (tries == 0 || now - t0 > 6000)
                {
                    if (tries >= 3) { fail("não consegui sair do plano"); return; }
                    tries++; t0 = now;
                    var rb:DisplayObject = (tries <= 2) ? UiHelper.find(rt, "returnBtnMC") : null;
                    if (rb != null) { say("saindo do plano pelo botão da tela, tentativa " + tries); UiHelper.press(rb); }
                    else { say("saindo do plano (op 19), tentativa " + tries); try { ad.leavePlanes(); } catch (e1:Error) { say("erro ao sair: " + e1.message); } }
                }
                return;
            }

            if (st == "open")
            {
                if (ad.sceneName() != "CASTLE_SCENE")
                {
                    if (now - t0 > 20000) fail("o castelo não carregou");
                    return;
                }
                var lv:DisplayObject = UiHelper.find(rt, "PlanesListView");
                if (lv != null)
                {
                    if (seenAt == 0) seenAt = now;
                    if (now - seenAt > 1800) go(discardCur ? "discard" : "choose");
                    return;
                }
                if (tries == 0 || now - lastPress > 3500)
                {
                    if (tries >= 6) { fail("não achei o prédio do Transmissor no castelo"); return; }
                    tries++; lastPress = now;
                    var bl:Array = [];
                    UiHelper.findAll(rt, "CastleBuildingView", bl, 12, 40);
                    var b:DisplayObject = null;
                    for (var i:int = 0; i < bl.length; i++) if (UiHelper.hasText(bl[i], "Transmissor")) { b = bl[i]; break; }
                    if (b == null) { say("prédio do Transmissor ainda não apareceu (tentativa " + tries + ")"); return; }
                    say("abrindo o Transmissor");
                    UiHelper.press(b);
                }
                return;
            }

            if (st == "discard")
            {
                list = ad.planList();
                if (curId == 0)
                {
                    curId = identifyCur(list);
                    if (curId != 0) say("plano atual identificado: id " + curId);
                    else say("não consegui identificar qual plano é o atual; não descarto nenhum");
                }
                if (curId == 0 || !hasPlan(list, curId)) { go("choose"); return; }
                if (tries == 0)
                {
                    say("descartando o plano " + curId + " (op 18)");
                    ad.sendOp(18, [curId]);
                    tries = 1; t0 = now; listBefore = list.length;
                    return;
                }
                if (tries == 1)
                {
                    var al1:DisplayObject = UiHelper.find(rt, "SimpleAlert");
                    if (al1 != null && now - lastPress > 1200) { lastPress = now; say("confirmando o aviso de descarte"); confirmAlert(al1); }
                }
                if (tries == 1 && now - t0 > 5000)
                {
                    say("a op 18 não surtiu efeito; tentando o botão de descartar da tela");
                    var items:Array = [];
                    UiHelper.findAll(rt, "PlanesItemView", items, 12, 10);
                    if (items.length > 0)
                    {
                        var btns:Array = [];
                        UiHelper.findAll(items[0] as DisplayObjectContainer, "BaseButton", btns, 6, 6);
                        var left:DisplayObject = null;
                        for (var k:int = 0; k < btns.length; k++) if (left == null || UiHelper.gx(btns[k]) < UiHelper.gx(left)) left = btns[k];
                        if (left != null) UiHelper.press(left);
                    }
                    tries = 2; t0 = now;
                    return;
                }
                if (tries == 2)
                {
                    var al:DisplayObject = UiHelper.find(rt, "SimpleAlert");
                    if (al != null && now - lastPress > 1200)
                    {
                        lastPress = now;
                        say("confirmando o aviso de descarte");
                        confirmAlert(al);
                    }
                    if (now - t0 > 9000)
                    {
                        say("não consegui descartar o plano " + curId + ": sigo sem descartar e não volto nele");
                        skipIds.push(curId);
                        go("choose");
                    }
                }
                return;
            }

            if (st == "choose")
            {
                list = ad.planList();
                if (markSkip)
                {
                    markSkip = false;
                    var usedId:int = identifyCur(list);
                    if (usedId != 0) { skipIds.push(usedId); say("plano " + usedId + " teve a mina: fica sem descartar e não volto nele"); }
                    else say("não consegui identificar o plano que deu mina; vou pular o primeiro da lista para não repetir");
                    if (usedId == 0 && list.length > 0) skipIds.push(int(list[0].id));
                }
                var pick:int = 0;
                if (mode == 4)
                {
                    // FECHAR PLANOS: usa da bolsa um plano GRANDE do elemento escolhido e entra no plano novo que aparecer
                    if (wantNew)
                    {
                        wantNew = false;
                        for (var w:int = 0; w < list.length; w++)
                        {
                            var wid:int = int(list[w].id);
                            if (preIds.indexOf(wid) < 0 && skipIds.indexOf(wid) < 0) { pick = wid; break; }
                        }
                        if (pick == 0) { fail("usei um plano grande da bolsa, mas nenhum plano novo apareceu na lista"); return; }
                    }
                    else if (list.length < ad.maxPlans)
                    {
                        preIds = [];
                        for (var qq:int = 0; qq < list.length; qq++) preIds.push(int(list[qq].id));
                        wantNew = true; bagTried = true; listBefore = list.length; useTries = 0; lastUse = 0;
                        say("fechar planos: pegando um plano GRANDE" + (element.length > 0 ? " de " + element : " (elemento variado)") + " na bolsa");
                        go("bag");
                        return;
                    }
                    else
                    {
                        for (var z:int = 0; z < list.length; z++)
                            if (skipIds.indexOf(int(list[z].id)) < 0) { pick = int(list[z].id); break; }
                        if (pick == 0) { fail("a lista do Transmissor está cheia e todos já foram usados: descarte um plano"); return; }
                        say("lista cheia: entro no plano " + pick + " sem conferir o elemento");
                    }
                }
                else
                {
                    if (!fillTried && list.length < ad.maxPlans)
                    {
                        // MINAS: completa os espaços livres do Transmissor com planos da bolsa (elemento variado)
                        fillTried = true; bagTried = true; listBefore = list.length; useTries = 0; lastUse = 0;
                        say("completando os espaços livres do Transmissor (" + list.length + "/" + ad.maxPlans + ") com planos da bolsa");
                        go("bag");
                        return;
                    }
                    for (var c:int = 0; c < list.length; c++)
                        if (skipIds.indexOf(int(list[c].id)) < 0) { pick = int(list[c].id); break; }
                }
                if (pick == 0)
                {
                    if (bagTried || list.length >= ad.maxPlans)
                    {
                        fail(list.length == 0 ? "não há planos na lista nem na bolsa" : "todos os planos da lista já tiveram mina (descarte ou use-os à mão)");
                        return;
                    }
                    bagTried = true; listBefore = list.length; useTries = 0; lastUse = 0;
                    say("sem plano novo na lista: tentando usar planos da bolsa");
                    go("bag");
                    return;
                }
                bagTried = false;
                curId = pick;
                enteredId = pick;
                say("entrando no plano " + curId + " (de " + list.length + " na lista)");
                go("enter");
                return;
            }

            if (st == "enter")
            {
                if (ad.insidePlan) { go("ready"); return; }
                if (tries == 0)
                {
                    ad.sendOp(15, [curId]);
                    tries = 1; t0 = now;
                    return;
                }
                if (tries == 1 && now - t0 > 5000)
                {
                    say("a op 15 não surtiu efeito; tentando o botão de entrar da tela");
                    var its:Array = [];
                    UiHelper.findAll(rt, "PlanesItemView", its, 12, 10);
                    if (its.length > 0)
                    {
                        var bs:Array = [];
                        UiHelper.findAll(its[0] as DisplayObjectContainer, "BaseButton", bs, 6, 6);
                        var right:DisplayObject = null;
                        for (var q:int = 0; q < bs.length; q++) if (right == null || UiHelper.gx(bs[q]) > UiHelper.gx(right)) right = bs[q];
                        if (right != null) UiHelper.press(right);
                    }
                    tries = 2; t0 = now;
                    return;
                }
                if (tries == 2 && now - t0 > 7000) fail("não consegui entrar no plano");
                return;
            }

            if (st == "bag")
            {
                list = ad.planList();
                var frame:DisplayObject = UiHelper.find(rt, "PlanesBagFrame");
                if (frame == null)
                {
                    if (tries == 0 || now - lastPress > 3000)
                    {
                        if (tries >= 4) { fail("não consegui abrir a bolsa de planos"); return; }
                        tries++; lastPress = now;
                        var pl:DisplayObject = UiHelper.find(rt, "PlanesListView");
                        var ibs:Array = [];
                        if (pl != null) UiHelper.findAll(pl as DisplayObjectContainer, "IconButton", ibs, 8, 6);
                        if (ibs.length == 0) { say("botão da bolsa não encontrado (tentativa " + tries + ")"); return; }
                        say("abrindo a bolsa de planos");
                        UiHelper.press(ibs[0]);
                        listBefore = list.length;
                    }
                    return;
                }
                var n:int = list.length;
                var cell:DisplayObject = ad.bestBagCell(frame as DisplayObjectContainer, element, mode == 4 ? 3 : -1, elemUse);
                var gotOne:Boolean = (mode == 4 && wantNew && n > preIds.length);
                if (n >= ad.maxPlans || cell == null || useTries >= 5 || gotOne)
                {
                    var cb:DisplayObject = UiHelper.find(frame as DisplayObjectContainer, "BaseButton");
                    var elems:String = ad.bagElements(frame as DisplayObjectContainer);
                    say("fechando a bolsa (planos na lista: " + n + ")");
                    UiHelper.press(cb);
                    if (mode == 4 && !gotOne)
                    {
                        fail(cell == null ? "não há plano GRANDE" + (element.length > 0 ? " do elemento " + element : "") + " na bolsa (elementos vistos: " + (elems.length > 0 ? elems : "nenhum") + ")" : "não consegui usar o plano da bolsa");
                        return;
                    }
                    if (n == 0) { fail(cell == null ? "não há planos na bolsa" : "não consegui usar planos da bolsa"); return; }
                    go("choose");
                    return;
                }
                if (n > listBefore)
                {
                    if (lastCellElem.length > 0) elemUse[lastCellElem] = int(elemUse[lastCellElem]) + 1;
                    listBefore = n; useTries = 0;
                }
                if (now - lastUse < 1800) return;
                lastUse = now;
                useTries++;
                var menu:DisplayObject = UiHelper.find(rt, "PlanesGoodsItemMenu");
                if (menu != null)
                {
                    var tbs:Array = [];
                    UiHelper.findAll(menu as DisplayObjectContainer, "TextButton", tbs, 8, 10);
                    var usar:DisplayObject = null;
                    for (var u:int = 0; u < tbs.length; u++) if (UiHelper.hasText(tbs[u], "Usar")) { usar = tbs[u]; break; }
                    if (usar == null && tbs.length > 0) usar = tbs[0];
                    if (usar != null)
                    {
                        say("usando da bolsa: apertando Usar (toque " + useTries + ")");
                        UiHelper.press(usar);
                        lastUse = now + 600;
                        return;
                    }
                }
                var tgt:DisplayObject = UiHelper.find(cell as DisplayObjectContainer, "BaseIconView");
                if (tgt == null) tgt = cell;
                lastCellElem = ad.bagElement(cell);
                say("usando da bolsa: " + ad.bagCellName(cell) + " [" + lastCellElem + "] (toque " + useTries + ")");
                UiHelper.press(tgt);
                return;
            }

            if (st == "ready")
            {
                if (ad.ready)
                {
                    if (now - t0 > 1500)
                    {
                        rounds++;
                        say("dentro do plano (rodada " + rounds + "): iniciando a busca do olho");
                        stop("dentro do plano");
                        if (onEnter != null) onEnter();
                    }
                }
                else if (now - t0 > 25000) fail("o mapa do plano não carregou");
            }
        }
    }
}
