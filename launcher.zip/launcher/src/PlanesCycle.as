package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.events.TimerEvent;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Troca de plano (modo MINAS): sai do plano, abre o Transmissor, descarta o plano usado, escolhe outro (ou usa planos da
    // bolsa) e entra. Quando já está dentro e o mapa carregou, chama onEnter (que liga a busca do olho).
    // Baseado no que o gravador viu: Transmissor = prédio "Transmissor" no castelo; lista = PlanesListView/PlanesItemView;
    // bolsa = PlanesBagFrame/PlanesBagCell; sair = op 19; entrar = op 15 [id]; descartar = op 18 [id].
    // Cada passo confere se o jogo mudou de estado; se a op não funcionar, tenta o botão da tela.
    public class PlanesCycle
    {
        public var logger:Function;
        public var onEnter:Function;
        public var running:Boolean = false;
        public var status:String = "parado";

        private var ad:GamePlanesAdapter;
        private var timer:Timer;
        private var st:String = "idle";
        private var t0:int = 0;
        private var tries:int = 0;
        private var curId:int = 0;
        private var discardCur:Boolean = false;
        private var lastPress:int = 0;
        private var seenAt:int = 0;
        private var listBefore:int = 0;
        private var useTries:int = 0;
        private var lastUse:int = 0;
        private var lastLayer:int = 0;
        private var rounds:int = 0;

        public function PlanesCycle(a:GamePlanesAdapter) { ad = a; }

        private function say(s:String):void { if (logger != null) logger("[Troca] " + s); }

        private function go(s:String):void { st = s; t0 = getTimer(); tries = 0; seenAt = 0; status = "troca de plano: " + s; }

        private function fail(msg:String):void { say("FALHOU: " + msg); stop("falhou: " + msg); }

        private function root():DisplayObjectContainer { return SwfFixer.rootStage; }

        // Começa pelo fim de um plano: sai, abre o Transmissor, descarta (se pedido) e entra em outro.
        public function begin(discard:Boolean, layerId:int):void
        {
            if (running) return;
            discardCur = discard;
            lastLayer = layerId;
            say("fim do plano" + (discard ? " (vai descartar)" : "") + ": saindo para trocar");
            startTimer();
            go("leave");
        }

        // Começa já no castelo (sem plano atual): abre o Transmissor e entra em um plano.
        public function startFromCastle():void
        {
            if (running) return;
            discardCur = false; curId = 0;
            say("começando pelo castelo: abrindo o Transmissor");
            startTimer();
            go("open");
        }

        private function startTimer():void
        {
            running = true;
            timer = new Timer(800);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
        }

        public function stop(reason:String = "parado"):void
        {
            if (timer != null) { timer.stop(); timer.removeEventListener(TimerEvent.TIMER, onTick); timer = null; }
            if (running) say("parou: " + reason);
            running = false;
            status = reason;
            st = "idle";
        }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("ERRO: " + err.message); stop("erro: " + err.message); }
        }

        private function hasPlan(list:Array, id:int):Boolean
        {
            for (var i:int = 0; i < list.length; i++) if (int(list[i].id) == id) return true;
            return false;
        }

        private function step():void
        {
            var now:int = getTimer();
            var list:Array;
            var rt:DisplayObjectContainer = root();
            if (rt == null) return;

            if (st == "leave")
            {
                if (ad.sceneName() != "PLANES_WAR_SCENE") { go("open"); return; }
                if (tries == 0 || now - t0 > 5000)
                {
                    if (tries >= 3) { fail("não consegui sair do plano"); return; }
                    tries++; t0 = now;
                    say("saindo do plano (op 19), tentativa " + tries);
                    try { ad.leavePlanes(); } catch (e1:Error) { say("erro ao sair: " + e1.message); }
                }
                return;
            }

            if (st == "open")
            {
                if (ad.sceneName() != "CASTLE_SCENE")
                {
                    if (now - t0 > 20000) fail("o castelo não carregou");
                    return;
                }
                var lv:DisplayObject = UiHelper.find(rt, "PlanesListView");
                if (lv != null)
                {
                    if (seenAt == 0) seenAt = now;
                    if (now - seenAt > 1800) go(discardCur ? "discard" : "choose");
                    return;
                }
                if (tries == 0 || now - lastPress > 3500)
                {
                    if (tries >= 6) { fail("não achei o prédio do Transmissor no castelo"); return; }
                    tries++; lastPress = now;
                    var bl:Array = [];
                    UiHelper.findAll(rt, "CastleBuildingView", bl, 12, 40);
                    var b:DisplayObject = null;
                    for (var i:int = 0; i < bl.length; i++) if (UiHelper.hasText(bl[i], "Transmissor")) { b = bl[i]; break; }
                    if (b == null) { say("prédio do Transmissor ainda não apareceu (tentativa " + tries + ")"); return; }
                    say("abrindo o Transmissor");
                    UiHelper.press(b);
                }
                return;
            }

            if (st == "discard")
            {
                list = ad.planList();
                if (curId == 0 && lastLayer != 0)
                {
                    for (var p:int = 0; p < list.length; p++)
                        if (list[p].layers.indexOf(lastLayer) >= 0) { curId = int(list[p].id); break; }
                    if (curId != 0) say("plano atual identificado: id " + curId);
                    else say("não consegui identificar qual plano é o atual; não descarto nenhum");
                }
                if (curId == 0 || !hasPlan(list, curId)) { go("choose"); return; }
                if (tries == 0)
                {
                    say("descartando o plano " + curId + " (op 18)");
                    ad.sendOp(18, [curId]);
                    tries = 1; t0 = now; listBefore = list.length;
                    return;
                }
                if (tries == 1 && now - t0 > 5000)
                {
                    say("a op 18 não surtiu efeito; tentando o botão de descartar da tela");
                    var items:Array = [];
                    UiHelper.findAll(rt, "PlanesItemView", items, 12, 10);
                    if (items.length > 0)
                    {
                        var btns:Array = [];
                        UiHelper.findAll(items[0] as DisplayObjectContainer, "BaseButton", btns, 6, 6);
                        var left:DisplayObject = null;
                        for (var k:int = 0; k < btns.length; k++) if (left == null || UiHelper.gx(btns[k]) < UiHelper.gx(left)) left = btns[k];
                        if (left != null) UiHelper.press(left);
                    }
                    tries = 2; t0 = now;
                    return;
                }
                if (tries == 2)
                {
                    var al:DisplayObject = UiHelper.find(rt, "SimpleAlert");
                    if (al != null && now - lastPress > 1200)
                    {
                        lastPress = now;
                        var ib:DisplayObject = UiHelper.find(al as DisplayObjectContainer, "IconButton");
                        say("confirmando o aviso de descarte");
                        UiHelper.press(ib);
                    }
                    if (now - t0 > 9000) fail("não consegui descartar o plano");
                }
                return;
            }

            if (st == "choose")
            {
                list = ad.planList();
                if (list.length == 0) { listBefore = 0; useTries = 0; lastUse = 0; go("bag"); return; }
                curId = int(list[0].id);
                say("entrando no plano " + curId + " (de " + list.length + " na lista)");
                go("enter");
                return;
            }

            if (st == "enter")
            {
                if (ad.insidePlan) { go("ready"); return; }
                if (tries == 0)
                {
                    ad.sendOp(15, [curId]);
                    tries = 1; t0 = now;
                    return;
                }
                if (tries == 1 && now - t0 > 5000)
                {
                    say("a op 15 não surtiu efeito; tentando o botão de entrar da tela");
                    var its:Array = [];
                    UiHelper.findAll(rt, "PlanesItemView", its, 12, 10);
                    if (its.length > 0)
                    {
                        var bs:Array = [];
                        UiHelper.findAll(its[0] as DisplayObjectContainer, "BaseButton", bs, 6, 6);
                        var right:DisplayObject = null;
                        for (var q:int = 0; q < bs.length; q++) if (right == null || UiHelper.gx(bs[q]) > UiHelper.gx(right)) right = bs[q];
                        if (right != null) UiHelper.press(right);
                    }
                    tries = 2; t0 = now;
                    return;
                }
                if (tries == 2 && now - t0 > 7000) fail("não consegui entrar no plano");
                return;
            }

            if (st == "bag")
            {
                list = ad.planList();
                var frame:DisplayObject = UiHelper.find(rt, "PlanesBagFrame");
                if (frame == null)
                {
                    if (tries == 0 || now - lastPress > 3000)
                    {
                        if (tries >= 4) { fail("não consegui abrir a bolsa de planos"); return; }
                        tries++; lastPress = now;
                        var pl:DisplayObject = UiHelper.find(rt, "PlanesListView");
                        var ibs:Array = [];
                        if (pl != null) UiHelper.findAll(pl as DisplayObjectContainer, "IconButton", ibs, 8, 6);
                        if (ibs.length == 0) { say("botão da bolsa não encontrado (tentativa " + tries + ")"); return; }
                        say("abrindo a bolsa de planos");
                        UiHelper.press(ibs[0]);
                        listBefore = list.length;
                    }
                    return;
                }
                var n:int = list.length;
                var cell:DisplayObject = UiHelper.find(frame as DisplayObjectContainer, "PlanesBagCell");
                if (n >= ad.maxPlans || cell == null || useTries >= 5)
                {
                    var cb:DisplayObject = UiHelper.find(frame as DisplayObjectContainer, "BaseButton");
                    say("fechando a bolsa (planos na lista: " + n + ")");
                    UiHelper.press(cb);
                    if (n == 0) { fail(cell == null ? "não há planos na bolsa" : "não consegui usar planos da bolsa"); return; }
                    go("choose");
                    return;
                }
                if (n > listBefore) { listBefore = n; useTries = 0; }
                if (now - lastUse < 1800) return;
                lastUse = now;
                useTries++;
                var tgt:DisplayObject = UiHelper.find(cell as DisplayObjectContainer, "BaseIconView");
                if (tgt == null) tgt = cell;
                say("usando um plano da bolsa (toque " + useTries + ")");
                UiHelper.press(tgt, useTries >= 3);
                return;
            }

            if (st == "ready")
            {
                if (ad.ready)
                {
                    if (now - t0 > 1500)
                    {
                        rounds++;
                        say("dentro do plano (rodada " + rounds + "): iniciando a busca do olho");
                        stop("dentro do plano");
                        if (onEnter != null) onEnter();
                    }
                }
                else if (now - t0 > 25000) fail("o mapa do plano não carregou");
            }
        }
    }
}
