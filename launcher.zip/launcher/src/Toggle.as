package
{
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;

    // Caixa de seleção com legenda (ex.: "Lembrar usuário e senha"). A origem fica no centro.
    public class Toggle extends Sprite
    {
        public var checked:Boolean;
        public var onToggle:Function;   // function(checked:Boolean):void
        private var box:Sprite = new Sprite();

        public function Toggle(label:String, initial:Boolean)
        {
            checked = initial;
            mouseChildren = false;
            buttonMode = true;
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 15, Btn.TEXT_SOFT, true);
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = label;
            var total:Number = 26 + 12 + tf.width;
            box.x = -total / 2 + 13;
            tf.x = -total / 2 + 38; tf.y = -tf.height / 2;
            addChild(box); addChild(tf);
            // área de toque maior que o desenho
            graphics.beginFill(0, 0);
            graphics.drawRect(-total / 2 - 10, -22, total + 20, 44);
            graphics.endFill();
            paint();
            addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                checked = !checked; paint();
                if (onToggle != null) onToggle(checked);
            });
        }

        private function paint():void
        {
            var g:Graphics = box.graphics;
            g.clear();
            g.lineStyle(1.5, checked ? Btn.BLUE : Btn.BORDER, 1);
            g.beginFill(checked ? Btn.BLUE : 0x151B26, 1);
            g.drawRoundRect(-13, -13, 26, 26, 9, 9);
            g.endFill();
            if (checked)
            {
                g.lineStyle(3, 0xFFFFFF, 1, false, "normal", "round", "round");
                g.moveTo(-6, 0); g.lineTo(-1.5, 5); g.lineTo(7, -5);
            }
        }
    }
}
