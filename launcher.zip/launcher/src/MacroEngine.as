package
{
    import flash.display.BitmapData;
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.display.Loader;
    import flash.display.PNGEncoderOptions;
    import flash.display.Stage;
    import flash.events.Event;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.geom.Point;
    import flash.geom.Matrix;
    import flash.utils.ByteArray;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    /** Local macro recorder. Records input reaching the AIR display list, plus optional screen snapshots. */
    public class MacroEngine
    {
        private var root:DisplayObjectContainer;
        private var stageRef:Stage;
        private var game:DisplayObject;
        private var steps:Array = [];
        private var recording:Boolean = false;
        private var playing:Boolean = false;
        private var startedAt:int = 0;
        private var playIndex:int = 0;
        private var timer:Timer;
        private var statusFn:Function;
        private var lastActionTime:int = 0;
        private var captureScreens:Boolean = true;

        public function MacroEngine(stageRoot:DisplayObjectContainer, gameDisplay:DisplayObject, statusCallback:Function)
        {
            root = stageRoot; stageRef = stageRoot as Stage; game = gameDisplay; statusFn = statusCallback;
            root.addEventListener(MouseEvent.MOUSE_DOWN, onMouse, true, 1000);
            root.addEventListener(MouseEvent.MOUSE_UP, onMouse, true, 1000);
            root.addEventListener(MouseEvent.CLICK, onMouse, true, 1000);
            root.addEventListener(KeyboardEvent.KEY_DOWN, onKey, true, 1000);
            root.addEventListener(KeyboardEvent.KEY_UP, onKey, true, 1000);
        }

        public function get isRecording():Boolean { return recording; }
        public function get isPlaying():Boolean { return playing; }
        public function get count():int { return steps.length; }

        public function startRecording():void
        {
            stopPlayback(); steps = []; recording = true;
            startedAt = getTimer(); lastActionTime = startedAt;
            say("Gravando ações. Toque em Macro para parar.");
        }

        public function stopRecording():void
        {
            if (!recording) return;
            recording = false;
            say("Gravação parada: " + steps.length + " ações.");
        }

        private function onMouse(e:MouseEvent):void
        {
            if (!recording || !isGameTarget(e.target as DisplayObject)) return;
            var now:int = getTimer();
            var s:Object = {type:e.type, x:e.stageX / Math.max(1, stageRef.stageWidth), y:e.stageY / Math.max(1, stageRef.stageHeight),
                delay:Math.max(0, now - lastActionTime), button:e.buttonDown, at:now - startedAt};
            if (captureScreens && e.type == MouseEvent.CLICK) s.screen = "step_" + steps.length + ".png";
            steps.push(s); lastActionTime = now;
            if (captureScreens && e.type == MouseEvent.CLICK) saveSnapshot(steps.length - 1);
        }

        private function onKey(e:KeyboardEvent):void
        {
            if (!recording || !isGameTarget(e.target as DisplayObject)) return;
            var now:int = getTimer();
            steps.push({type:e.type, keyCode:e.keyCode, charCode:e.charCode, delay:Math.max(0, now-lastActionTime), at:now-startedAt});
            lastActionTime = now;
        }

        private function isGameTarget(d:DisplayObject):Boolean
        {
            while (d)
            {
                if (d == game) return true;
                d = d.parent;
            }
            return false;
        }

        private function macroDir():File
        {
            var d:File = File.applicationStorageDirectory.resolvePath("macros");
            if (!d.exists) d.createDirectory();
            return d;
        }

        private function saveSnapshot(index:int):void
        {
            try
            {
                if (!game || game.width < 1 || game.height < 1) return;
                var w:int = Math.min(960, Math.max(1, int(game.width)));
                var h:int = Math.max(1, int(game.height * w / game.width));
                var b:BitmapData = new BitmapData(w, h, false, 0x000000);
                var matrix:Matrix = new Matrix();
                matrix.scale(w / game.width, h / game.height);
                b.draw(game, matrix, null, null, null, true);
                var bytes:ByteArray = b.encode(b.rect, new PNGEncoderOptions());
                var fs:FileStream = new FileStream();
                fs.open(macroDir().resolvePath("step_" + index + ".png"), FileMode.WRITE);
                fs.writeBytes(bytes); fs.close(); b.dispose();
            }
            catch (err:Error) { /* snapshots are optional on AIR builds that restrict bitmap capture */ }
        }

        public function save():void
        {
            stopRecording(); stopPlayback();
            try
            {
                var data:Object = {version:1, created:new Date().time, steps:steps};
                var fs:FileStream = new FileStream();
                fs.open(macroDir().resolvePath("macro.json"), FileMode.WRITE);
                fs.writeUTFBytes(JSON.stringify(data)); fs.close();
                say("Macro salva: " + steps.length + " ações.");
            }
            catch (err:Error) { say("Erro ao salvar macro: " + err.message); }
        }

        public function load():void
        {
            try
            {
                var f:File = macroDir().resolvePath("macro.json");
                if (!f.exists) { say("Nenhuma macro salva ainda."); return; }
                var fs:FileStream = new FileStream(); fs.open(f, FileMode.READ);
                var data:Object = JSON.parse(fs.readUTFBytes(fs.bytesAvailable)); fs.close();
                if (!data || !(data.steps is Array)) { say("Arquivo de macro inválido."); return; }
                steps = data.steps as Array;
                say("Macro carregada: " + steps.length + " ações.");
            }
            catch (err:Error) { say("Erro ao carregar macro: " + err.message); }
        }

        public function play():void
        {
            if (recording) stopRecording();
            load();
            if (steps.length == 0) return;
            stopPlayback(); playing = true; playIndex = 0;
            timer = new Timer(Math.max(1, Number(steps[0].delay)), 1); timer.addEventListener(TimerEvent.TIMER, playNext); timer.start();
            say("Reproduzindo macro. Use Parar para interromper.");
        }

        private function playNext(e:TimerEvent):void
        {
            if (!playing) return;
            if (playIndex >= steps.length) { stopPlayback(); say("Macro concluída."); return; }
            var s:Object = steps[playIndex++];
            dispatchStep(s);
            if (playIndex >= steps.length) { stopPlayback(); say("Macro concluída."); return; }
            timer.delay = Math.max(1, Number(steps[playIndex].delay));
            timer.reset(); timer.start();
        }

        private function dispatchStep(s:Object):void
        {
            try
            {
                if (s.type == MouseEvent.MOUSE_DOWN || s.type == MouseEvent.MOUSE_UP || s.type == MouseEvent.CLICK)
                {
                    var p:Point = new Point(Number(s.x) * stageRef.stageWidth, Number(s.y) * stageRef.stageHeight);
                    var hits:Array = stageRef.getObjectsUnderPoint(p);
                    var target:DisplayObject = null;
                    for (var i:int = hits.length - 1; i >= 0; i--)
                    {
                        if (isGameTarget(hits[i] as DisplayObject)) { target = hits[i] as DisplayObject; break; }
                    }
                    if (target)
                    {
                        var lp:Point = target.globalToLocal(p);
                        target.dispatchEvent(new MouseEvent(String(s.type), true, false, lp.x, lp.y, null, false, false, false, false, false));
                    }
                }
                else if (s.type == KeyboardEvent.KEY_DOWN || s.type == KeyboardEvent.KEY_UP)
                    game.dispatchEvent(new KeyboardEvent(String(s.type), true, false, int(s.charCode), int(s.keyCode)));
            }
            catch (err:Error) { say("Ação ignorada: " + err.message); }
        }

        public function stopPlayback():void
        {
            playing = false;
            if (timer) { timer.stop(); timer.removeEventListener(TimerEvent.TIMER, playNext); timer = null; }
        }

        public function stopAll():void { stopRecording(); stopPlayback(); say("Macro parada."); }
        private function say(s:String):void { if (statusFn != null) statusFn(s); }
    }
}
