package
{
    import flash.geom.Point;
    import flash.utils.describeType;

    // Liga o macro ao jogo real. O jogo é outro SWF carregado em tempo de execução, então NADA aqui importa
    // classes dele: tudo é procurado pelo nome (SwfFixer.findClass) e usado de forma dinâmica.
    // Classes/membros usados (confirmados nos scripts exportados do jogo):
    //   yishi.manager.PlanesWarManager.instance .model .control .isNeedOpendEventFrame
    //   PlanesWarModel: planesWarInfo, COLUMN_NUM, ROW_NUM, energyLeft, selfArmy.isMoving, walkPath(), getEventCostEnergyByResistance()
    //   PlanesWarInfo: gridArr, posX, posY, dead, layerTempId, eventInfo{eventId,respondTpye,params}
    //   PlanesWarControler.moveGridByXY(x, y)   |   PlanesWarManager.sendPlanesOpMsg(35, [params0, carta])
    public class GamePlanesAdapter implements IPlanesAdapter
    {
        private function cls(n:String):Object { return SwfFixer.findClass(n); }

        private function single(n:String):Object
        {
            var c:Object = cls(n);
            return c != null ? c["instance"] : null;
        }

        private function mgr():Object { return single("yishi.manager.PlanesWarManager"); }
        private function model():Object { var m:Object = mgr(); return m != null ? m["model"] : null; }
        private function winfo():Object { var m:Object = model(); return m != null ? m["planesWarInfo"] : null; }

        private function scene():String
        {
            try
            {
                var s:Object = single("yishi.scene.SceneManager");
                return s != null ? String(s["currentType"]) : "?";
            }
            catch (e:Error) {}
            return "?";
        }

        private function templates(name:String):Object
        {
            var t:Object = single("yishi.manager.TempleteManager");
            return t != null ? t[name] : null;
        }

        private function layerTpl():Object
        {
            var w:Object = winfo();
            var lc:Object = templates("planesLayerTemplateCate");
            return (w != null && lc != null) ? lc.getTemplateByID(int(w["layerTempId"])) : null;
        }

        // Só leitura: lista campos simples (número/texto/booleano) e o tamanho de listas de um objeto do jogo.
        private function dump(label:String, o:Object, skip:String = ""):String
        {
            if (o == null) return label + ": (nulo)";
            var parts:Array = [];
            var seen:Object = {};
            var names:Array = [];
            var nm:String;
            try
            {
                var x:XML = describeType(o);
                var n:XML;
                for each (n in x.variable) names.push(String(n.@name));
                for each (n in x.accessor) { if (String(n.@access) != "writeonly") names.push(String(n.@name)); }
            }
            catch (e1:Error) {}
            try { for (var key:* in o) names.push(String(key)); } catch (e2:Error) {}
            for each (nm in names)
            {
                if (seen[nm] || skip.indexOf("," + nm + ",") >= 0) continue;
                seen[nm] = true;
                try
                {
                    var v:* = o[nm];
                    if (v == null || v is Number || v is String || v is Boolean) parts.push(nm + "=" + String(v).substr(0, 60));
                    else if (v is Array) parts.push(nm + "=[" + (v as Array).length + " itens: " + (v as Array).slice(0, 6).join("|").substr(0, 80) + "]");
                }
                catch (e3:Error) {}
            }
            return label + ": " + parts.join(", ");
        }

        public function get ready():Boolean
        {
            try
            {
                if (scene() != "PLANES_WAR_SCENE") return false;
                var m:Object = model();
                var w:Object = winfo();
                if (m == null || w == null) return false;
                if (int(m["COLUMN_NUM"]) <= 0 || int(m["ROW_NUM"]) <= 0) return false;
                return w["gridArr"] != null && w["gridArr"].length > 0;
            }
            catch (e:Error) {}
            return false;
        }

        public function get cols():int { try { return int(model()["COLUMN_NUM"]); } catch (e:Error) {} return 0; }
        public function get rows():int { try { return int(model()["ROW_NUM"]); } catch (e:Error) {} return 0; }
        public function get posX():int { try { return int(winfo()["posX"]); } catch (e:Error) {} return -1; }
        public function get posY():int { try { return int(winfo()["posY"]); } catch (e:Error) {} return -1; }
        public function get energy():int { try { return int(model()["energyLeft"]); } catch (e:Error) {} return 0; }
        public function get dead():Boolean { try { return Boolean(winfo()["dead"]); } catch (e:Error) {} return false; }
        public function get moving():Boolean { try { return Boolean(model()["selfArmy"]["isMoving"]); } catch (e:Error) {} return false; }

        public function get stepCost():int
        {
            try { return Math.max(1, int(model().getStepCostEnergyByResistance(layerTpl()))); } catch (e:Error) {}
            return 1;
        }

        public function get layerId():int { try { return int(winfo()["layerId"]); } catch (e:Error) {} return 0; }

        public function get level():int
        {
            try { return int(single("yishi.manager.ArmyManager")["thane"]["grades"]); } catch (e:Error) {}
            return 0;
        }

        public function cells():Array
        {
            var out:Array = [];
            var w:Object = winfo();
            var m:Object = model();
            var ec:Object = templates("planesEventsTemplateCate");
            var lt:Object = layerTpl();
            var arr:Object = w["gridArr"];
            var i:int;
            var g:Object;
            var t:Object;
            var id:int;
            var cost:int;
            for (i = 0; i < arr.length; i++)
            {
                g = arr[i];
                id = int(g["eventId"]);
                t = (id != 0 && ec != null) ? ec.getTemplateByID(id) : null;
                cost = 0;
                if (t != null)
                {
                    try { cost = int(m.getEventCostEnergyByResistance(lt, t)); }
                    catch (e:Error) { cost = int(t["EnergyCost"]); }
                }
                out.push({
                    x: int(g["x"]), y: int(g["y"]), id: id,
                    type: (id == 0) ? 0 : (t != null ? int(t["EventType"]) : -99),
                    cost: cost, need: t != null ? int(t["NeedLevel"]) : 0,
                    opened: Boolean(g["opened"]), occupied: Boolean(g["occupied"]), base: Boolean(g["frontBase"])
                });
            }
            return out;
        }

        public function pendingCard():Array
        {
            try
            {
                var ev:Object = winfo()["eventInfo"];
                if (ev != null && int(ev["eventId"]) != 0 && int(ev["respondTpye"]) == 0 && ev["params"] != null && ev["params"].length > 0)
                    return [int(ev["params"][0])];
            }
            catch (e:Error) {}
            return null;
        }

        public function path(fx:int, fy:int, tx:int, ty:int):Array
        {
            var p:Object = model().walkPath(new Point(fx, fy), new Point(tx, ty));
            if (p == null) return null;
            var out:Array = [];
            for (var i:int = 0; i < p.length; i++) out.push({x: int(p[i].x), y: int(p[i].y)});
            return out;
        }

        public function moveTo(x:int, y:int):void { mgr()["control"].moveGridByXY(x, y); }

        public function pickCard(p0:int, card:int):void { mgr().sendPlanesOpMsg(35, [p0, card]); }

        public function suppressFrames():void { try { mgr()["isNeedOpendEventFrame"] = false; } catch (e:Error) {} }

        // Op 19 = LEAVING_OP, enviada sem parâmetros pelo botão de sair do jogo (MainToolBar).
        public function leavePlanes():void { mgr().sendPlanesOpMsg(19); }

        // ---- compra de energia: mesmos dados e mesma op que a barra de energia do jogo (PlanesTopView) usa ----
        private function cfg(name:String):String
        {
            try
            {
                var c:Object = templatesMgr().getConfigInfoByConfigName(name);
                return c != null ? String(c["ConfigValue"]) : "";
            }
            catch (e:Error) {}
            return "";
        }
        private function templatesMgr():Object { return single("yishi.manager.TempleteManager"); }

        public function get maxEnergy():int { var s:String = cfg("planes_max_recover_energy"); return s.length > 0 ? int(s) : 0; }
        public function get buyCount():int { try { return int(model()["hasBuyEnergyCount"]); } catch (e:Error) {} return -1; }
        public function get buyLimit():int { var s:String = cfg("planes_buy_energy_limit"); return s.length > 0 ? int(s) : -1; }
        public function get buyCost():int { var s:String = cfg("planes_buy_energy"); if (s.length == 0) return -1; return int(s.split(",")[0]); }
        public function get diamonds():int
        {
            try { return int(single("yishi.manager.PlayerManager")["currentPlayerModel"]["playerInfo"]["allPoint"]); } catch (e:Error) {}
            return -1;
        }
        // Op 8, param [2] se "diamante vinculado prioritário" estiver marcado, senão [1] (igual ao PlanesTopView.addEnergyHandlerResult).
        public function buyEnergy(bind:Boolean):void { mgr().sendPlanesOpMsg(8, [bind ? 2 : 1]); }

        // Só LÊ: lista os planos do transmissor (bolsa) e as camadas de cada um, para o diagnóstico.
        public function planesReport():String
        {
            var L:Array = [];
            L.push("PLANOS DO TRANSMISSOR (somente leitura)");
            try
            {
                var m:Object = model();
                if (m == null) { L.push("modelo de Planos ainda não existe (abra o Transmissor uma vez)."); return L.join("\n"); }
                L.push("dentro de um plano: " + m["isInPlanesWar"] + " | energia " + m["energyLeft"] + " | máx. de planos " + m["maxPlanesCount"] + " | energia comprada " + m["hasBuyEnergyCount"]);
                var list:Array = m["planesInfoList"] as Array;
                if (list == null || list.length == 0) { L.push("nenhum plano na lista (abra o Transmissor para o jogo carregar)."); return L.join("\n"); }
                var i:int;
                var j:int;
                var p:Object;
                var ly:Object;
                var parts:Array;
                for (i = 0; i < list.length; i++)
                {
                    p = list[i];
                    L.push("plano id=" + p["planesId"] + " modelo=" + p["planesTemId"] + " progresso=" + p["planesProcess"] + " vida=" + p["lifePoint"] + " reduz=" + p["lifeReduce"]);
                    parts = [];
                    var ll:Array = p["planesLayerList"] as Array;
                    if (ll != null)
                        for (j = 0; j < ll.length; j++)
                        {
                            ly = ll[j];
                            parts.push(ly["layerId"] + "/m" + ly["layerTempId"] + (ly["isActived"] ? "*" : "") + (int(ly["iconState"]) != 0 ? "(estado " + ly["iconState"] + ")" : ""));
                        }
                    L.push("   camadas (id/modelo, *=ativa): " + (parts.length ? parts.join(", ") : "nenhuma"));
                }
            }
            catch (e:Error) { L.push("ERRO ao ler: " + e.message); }
            return L.join("\n");
        }

        // Texto do botão "Diagnóstico": só LÊ, não envia nada ao servidor.
        public function report():String
        {
            var L:Array = [];
            L.push("DIAGNÓSTICO DO JOGO (somente leitura)");
            L.push("domínios de código vistos: " + SwfFixer.moduleDomains.length + (SwfFixer.gameDomain ? " + domínio do jogo" : " (sem domínio do jogo)"));
            var names:Array = ["yishi.manager.PlanesWarManager", "yishi.manager.TempleteManager", "yishi.manager.ArmyManager",
                               "yishi.scene.SceneManager", "mvc.controler.PlanesWarControler", "mvc.module.planeswar.PlanesWarModel"];
            var missing:int = 0;
            for each (var n:String in names)
            {
                var ok:Boolean = cls(n) != null;
                if (!ok) missing++;
                L.push((ok ? "  OK     " : "  FALTA  ") + n);
            }
            if (missing > 0)
            {
                L.push("Faltam classes: o jogo ainda não terminou de carregar? Entre no jogo e tente de novo.");
                return L.join("\n");
            }
            try
            {
                L.push("cena atual: " + scene() + (scene() == "PLANES_WAR_SCENE" ? "" : "   (abra o mapa de Planos para o macro funcionar)"));
                var w:Object = winfo();
                var m:Object = model();
                if (w == null || m == null) { L.push("modelo de Planos ainda não existe."); return L.join("\n"); }
                var lt:Object = layerTpl();
                L.push("camada: layerId=" + w["layerId"] + " layerTempId=" + w["layerTempId"] + " tamanho=" + (lt != null ? lt["Size"] : "?")
                       + " -> colunas x linhas = " + m["COLUMN_NUM"] + " x " + m["ROW_NUM"]);
                L.push("posição: (" + w["posX"] + "," + w["posY"] + ") | energia " + m["energyLeft"] + " | nível " + level + " | morto: " + w["dead"]);
                L.push("ENERGIA: " + m["energyLeft"] + "/" + maxEnergy + " | compras hoje " + buyCount + "/" + buyLimit + " | custo " + buyCost + " diamantes | seus diamantes " + diamonds + "  (-1 = não consegui ler)");
                L.push("movendo: " + moving + " | casas recebidas: " + (w["gridArr"] != null ? w["gridArr"].length : 0));
                L.push(dump("TEMPLATE do piso (planesLayerTemplate)", lt));
                L.push(dump("PlanesWarInfo (sem gridArr)", w, ",gridArr,"));
                var list:Array = cells();
                var byType:Object = {};
                var unknown:int = 0;
                var opened:int = 0;
                var c:Object;
                for each (c in list)
                {
                    if (c.opened) opened++;
                    if (c.type == -99) unknown++;
                    if (c.id != 0) byType[c.type] = int(byType[c.type]) + 1;
                }
                var tl:Array = [];
                for (var k:String in byType) tl.push("tipo " + k + " x" + byType[k]);
                tl.sort();
                L.push("abertas (névoa limpa): " + opened + " | eventos por EventType: " + (tl.length ? tl.join(", ") : "nenhum"));
                if (unknown > 0) L.push("ATENÇÃO: " + unknown + " casas com eventId sem template (tabela de eventos não carregada?)");
                L.push("Compare o MAPA do painel com a tela do jogo: cada número é o EventType da casa.");
            }
            catch (e:Error) { L.push("ERRO ao ler: " + e.message); }
            return L.join("\n");
        }
    }
}
