package
{
    import flash.geom.Point;

    // Liga o macro ao jogo real. O jogo é outro SWF carregado em tempo de execução, então NADA aqui importa
    // classes dele: tudo é procurado pelo nome (SwfFixer.findClass) e usado de forma dinâmica.
    // Classes/membros usados (confirmados nos scripts exportados do jogo):
    //   yishi.manager.PlanesWarManager.instance .model .control .isNeedOpendEventFrame
    //   PlanesWarModel: planesWarInfo, COLUMN_NUM, ROW_NUM, energyLeft, selfArmy.isMoving, walkPath(), getEventCostEnergyByResistance()
    //   PlanesWarInfo: gridArr, posX, posY, dead, layerTempId, eventInfo{eventId,respondTpye,params}
    //   PlanesWarControler.moveGridByXY(x, y)   |   PlanesWarManager.sendPlanesOpMsg(35, [params0, carta])
    public class GamePlanesAdapter implements IPlanesAdapter
    {
        private function cls(n:String):Object { return SwfFixer.findClass(n); }

        private function single(n:String):Object
        {
            var c:Object = cls(n);
            return c != null ? c["instance"] : null;
        }

        private function mgr():Object { return single("yishi.manager.PlanesWarManager"); }
        private function model():Object { var m:Object = mgr(); return m != null ? m["model"] : null; }
        private function winfo():Object { var m:Object = model(); return m != null ? m["planesWarInfo"] : null; }

        private function scene():String
        {
            try
            {
                var s:Object = single("yishi.scene.SceneManager");
                return s != null ? String(s["currentType"]) : "?";
            }
            catch (e:Error) {}
            return "?";
        }

        private function templates(name:String):Object
        {
            var t:Object = single("yishi.manager.TempleteManager");
            return t != null ? t[name] : null;
        }

        private function layerTpl():Object
        {
            var w:Object = winfo();
            var lc:Object = templates("planesLayerTemplateCate");
            return (w != null && lc != null) ? lc.getTemplateByID(int(w["layerTempId"])) : null;
        }

        public function get ready():Boolean
        {
            try
            {
                if (scene() != "PLANES_WAR_SCENE") return false;
                var m:Object = model();
                var w:Object = winfo();
                if (m == null || w == null) return false;
                if (int(m["COLUMN_NUM"]) <= 0 || int(m["ROW_NUM"]) <= 0) return false;
                return w["gridArr"] != null && w["gridArr"].length > 0;
            }
            catch (e:Error) {}
            return false;
        }

        public function get cols():int { try { return int(model()["COLUMN_NUM"]); } catch (e:Error) {} return 0; }
        public function get rows():int { try { return int(model()["ROW_NUM"]); } catch (e:Error) {} return 0; }
        public function get posX():int { try { return int(winfo()["posX"]); } catch (e:Error) {} return -1; }
        public function get posY():int { try { return int(winfo()["posY"]); } catch (e:Error) {} return -1; }
        public function get energy():int { try { return int(model()["energyLeft"]); } catch (e:Error) {} return 0; }
        public function get dead():Boolean { try { return Boolean(winfo()["dead"]); } catch (e:Error) {} return false; }
        public function get moving():Boolean { try { return Boolean(model()["selfArmy"]["isMoving"]); } catch (e:Error) {} return false; }

        public function get level():int
        {
            try { return int(single("yishi.manager.ArmyManager")["thane"]["grades"]); } catch (e:Error) {}
            return 0;
        }

        public function cells():Array
        {
            var out:Array = [];
            var w:Object = winfo();
            var m:Object = model();
            var ec:Object = templates("planesEventsTemplateCate");
            var lt:Object = layerTpl();
            var arr:Object = w["gridArr"];
            var i:int;
            var g:Object;
            var t:Object;
            var id:int;
            var cost:int;
            for (i = 0; i < arr.length; i++)
            {
                g = arr[i];
                id = int(g["eventId"]);
                t = (id != 0 && ec != null) ? ec.getTemplateByID(id) : null;
                cost = 0;
                if (t != null)
                {
                    try { cost = int(m.getEventCostEnergyByResistance(lt, t)); }
                    catch (e:Error) { cost = int(t["EnergyCost"]); }
                }
                out.push({
                    x: int(g["x"]), y: int(g["y"]), id: id,
                    type: (id == 0) ? 0 : (t != null ? int(t["EventType"]) : -99),
                    cost: cost, need: t != null ? int(t["NeedLevel"]) : 0,
                    opened: Boolean(g["opened"]), occupied: Boolean(g["occupied"]), base: Boolean(g["frontBase"])
                });
            }
            return out;
        }

        public function pendingCard():Array
        {
            try
            {
                var ev:Object = winfo()["eventInfo"];
                if (ev != null && int(ev["eventId"]) != 0 && int(ev["respondTpye"]) == 0 && ev["params"] != null && ev["params"].length > 0)
                    return [int(ev["params"][0])];
            }
            catch (e:Error) {}
            return null;
        }

        public function path(fx:int, fy:int, tx:int, ty:int):Array
        {
            var p:Object = model().walkPath(new Point(fx, fy), new Point(tx, ty));
            if (p == null) return null;
            var out:Array = [];
            for (var i:int = 0; i < p.length; i++) out.push({x: int(p[i].x), y: int(p[i].y)});
            return out;
        }

        public function moveTo(x:int, y:int):void { mgr()["control"].moveGridByXY(x, y); }

        public function pickCard(p0:int, card:int):void { mgr().sendPlanesOpMsg(35, [p0, card]); }

        public function suppressFrames():void { try { mgr()["isNeedOpendEventFrame"] = false; } catch (e:Error) {} }

        // Texto do botão "Diagnóstico": só LÊ, não envia nada ao servidor.
        public function report():String
        {
            var L:Array = [];
            L.push("DIAGNÓSTICO DO JOGO (somente leitura)");
            L.push("domínios de código vistos: " + SwfFixer.moduleDomains.length + (SwfFixer.gameDomain ? " + domínio do jogo" : " (sem domínio do jogo)"));
            var names:Array = ["yishi.manager.PlanesWarManager", "yishi.manager.TempleteManager", "yishi.manager.ArmyManager",
                               "yishi.scene.SceneManager", "mvc.controler.PlanesWarControler", "mvc.module.planeswar.PlanesWarModel"];
            var missing:int = 0;
            for each (var n:String in names)
            {
                var ok:Boolean = cls(n) != null;
                if (!ok) missing++;
                L.push((ok ? "  OK     " : "  FALTA  ") + n);
            }
            if (missing > 0)
            {
                L.push("Faltam classes: o jogo ainda não terminou de carregar? Entre no jogo e tente de novo.");
                return L.join("\n");
            }
            try
            {
                L.push("cena atual: " + scene() + (scene() == "PLANES_WAR_SCENE" ? "" : "   (abra o mapa de Planos para o macro funcionar)"));
                var w:Object = winfo();
                var m:Object = model();
                if (w == null || m == null) { L.push("modelo de Planos ainda não existe."); return L.join("\n"); }
                var lt:Object = layerTpl();
                L.push("camada: layerId=" + w["layerId"] + " layerTempId=" + w["layerTempId"] + " tamanho=" + (lt != null ? lt["Size"] : "?")
                       + " -> colunas x linhas = " + m["COLUMN_NUM"] + " x " + m["ROW_NUM"]);
                L.push("posição: (" + w["posX"] + "," + w["posY"] + ") | energia " + m["energyLeft"] + " | nível " + level + " | morto: " + w["dead"]);
                L.push("movendo: " + moving + " | casas recebidas: " + (w["gridArr"] != null ? w["gridArr"].length : 0));
                var list:Array = cells();
                var byType:Object = {};
                var unknown:int = 0;
                var opened:int = 0;
                var c:Object;
                for each (c in list)
                {
                    if (c.opened) opened++;
                    if (c.type == -99) unknown++;
                    if (c.id != 0) byType[c.type] = int(byType[c.type]) + 1;
                }
                var tl:Array = [];
                for (var k:String in byType) tl.push("tipo " + k + " x" + byType[k]);
                tl.sort();
                L.push("abertas (névoa limpa): " + opened + " | eventos por EventType: " + (tl.length ? tl.join(", ") : "nenhum"));
                if (unknown > 0) L.push("ATENÇÃO: " + unknown + " casas com eventId sem template (tabela de eventos não carregada?)");
                L.push("Compare o MAPA do painel com a tela do jogo: cada número é o EventType da casa.");
            }
            catch (e:Error) { L.push("ERRO ao ler: " + e.message); }
            return L.join("\n");
        }
    }
}
