package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.events.MouseEvent;
    import flash.geom.Point;
    import flash.utils.describeType;
    import flash.utils.getQualifiedClassName;

    // Liga o macro ao jogo real. O jogo é outro SWF carregado em tempo de execução, então NADA aqui importa
    // classes dele: tudo é procurado pelo nome (SwfFixer.findClass) e usado de forma dinâmica.
    // Classes/membros usados (confirmados nos scripts exportados do jogo):
    //   yishi.manager.PlanesWarManager.instance .model .control .isNeedOpendEventFrame
    //   PlanesWarModel: planesWarInfo, COLUMN_NUM, ROW_NUM, energyLeft, selfArmy.isMoving, walkPath(), getEventCostEnergyByResistance()
    //   PlanesWarInfo: gridArr, posX, posY, dead, layerTempId, eventInfo{eventId,respondTpye,params}
    //   PlanesWarControler.moveGridByXY(x, y)   |   PlanesWarManager.sendPlanesOpMsg(35, [params0, carta])
    public class GamePlanesAdapter implements IPlanesAdapter
    {
        private function cls(n:String):Object { return SwfFixer.findClass(n); }

        private function single(n:String):Object
        {
            var c:Object = cls(n);
            return c != null ? c["instance"] : null;
        }

        private function mgr():Object { return single("yishi.manager.PlanesWarManager"); }
        private function model():Object { var m:Object = mgr(); return m != null ? m["model"] : null; }
        private function winfo():Object { var m:Object = model(); return m != null ? m["planesWarInfo"] : null; }

        private function scene():String
        {
            try
            {
                var s:Object = single("yishi.scene.SceneManager");
                return s != null ? String(s["currentType"]) : "?";
            }
            catch (e:Error) {}
            return "?";
        }

        private function templates(name:String):Object
        {
            var t:Object = single("yishi.manager.TempleteManager");
            return t != null ? t[name] : null;
        }

        private function layerTpl():Object
        {
            var w:Object = winfo();
            var lc:Object = templates("planesLayerTemplateCate");
            return (w != null && lc != null) ? lc.getTemplateByID(int(w["layerTempId"])) : null;
        }

        // Só leitura: lista campos simples (número/texto/booleano) e o tamanho de listas de um objeto do jogo.
        private function dump(label:String, o:Object, skip:String = ""):String
        {
            if (o == null) return label + ": (nulo)";
            var parts:Array = [];
            var seen:Object = {};
            var names:Array = [];
            var nm:String;
            try
            {
                var x:XML = describeType(o);
                var n:XML;
                for each (n in x.variable) names.push(String(n.@name));
                for each (n in x.accessor) { if (String(n.@access) != "writeonly") names.push(String(n.@name)); }
            }
            catch (e1:Error) {}
            try { for (var key:* in o) names.push(String(key)); } catch (e2:Error) {}
            for each (nm in names)
            {
                if (seen[nm] || skip.indexOf("," + nm + ",") >= 0) continue;
                seen[nm] = true;
                try
                {
                    var v:* = o[nm];
                    if (v == null || v is Number || v is String || v is Boolean) parts.push(nm + "=" + String(v).substr(0, 60));
                    else if (v is Array) parts.push(nm + "=[" + (v as Array).length + " itens: " + (v as Array).slice(0, 6).join("|").substr(0, 80) + "]");
                }
                catch (e3:Error) {}
            }
            return label + ": " + parts.join(", ");
        }

        public function get ready():Boolean
        {
            try
            {
                if (scene() != "PLANES_WAR_SCENE") return false;
                var m:Object = model();
                var w:Object = winfo();
                if (m == null || w == null) return false;
                if (int(m["COLUMN_NUM"]) <= 0 || int(m["ROW_NUM"]) <= 0) return false;
                return w["gridArr"] != null && w["gridArr"].length > 0;
            }
            catch (e:Error) {}
            return false;
        }

        public function get cols():int { try { return int(model()["COLUMN_NUM"]); } catch (e:Error) {} return 0; }
        public function get rows():int { try { return int(model()["ROW_NUM"]); } catch (e:Error) {} return 0; }
        public function get posX():int { try { return int(winfo()["posX"]); } catch (e:Error) {} return -1; }
        public function get posY():int { try { return int(winfo()["posY"]); } catch (e:Error) {} return -1; }
        public function get energy():int { try { return int(model()["energyLeft"]); } catch (e:Error) {} return 0; }
        public function get dead():Boolean { try { return Boolean(winfo()["dead"]); } catch (e:Error) {} return false; }
        public function get moving():Boolean { try { return Boolean(model()["selfArmy"]["isMoving"]); } catch (e:Error) {} return false; }

        public function get stepCost():int
        {
            try { return Math.max(1, int(model().getStepCostEnergyByResistance(layerTpl()))); } catch (e:Error) {}
            return 1;
        }

        public function get layerId():int { try { return int(winfo()["layerId"]); } catch (e:Error) {} return 0; }

        public function get level():int
        {
            try { return int(single("yishi.manager.ArmyManager")["thane"]["grades"]); } catch (e:Error) {}
            return 0;
        }

        public function cells():Array
        {
            var out:Array = [];
            var w:Object = winfo();
            var m:Object = model();
            var ec:Object = templates("planesEventsTemplateCate");
            var lt:Object = layerTpl();
            var arr:Object = w["gridArr"];
            var i:int;
            var g:Object;
            var t:Object;
            var id:int;
            var cost:int;
            for (i = 0; i < arr.length; i++)
            {
                g = arr[i];
                id = int(g["eventId"]);
                t = (id != 0 && ec != null) ? ec.getTemplateByID(id) : null;
                cost = 0;
                if (t != null)
                {
                    try { cost = int(m.getEventCostEnergyByResistance(lt, t)); }
                    catch (e:Error) { cost = int(t["EnergyCost"]); }
                }
                out.push({
                    x: int(g["x"]), y: int(g["y"]), id: id,
                    type: (id == 0) ? 0 : (t != null ? int(t["EventType"]) : -99),
                    cost: cost, need: t != null ? int(t["NeedLevel"]) : 0,
                    opened: Boolean(g["opened"]), occupied: Boolean(g["occupied"]), base: Boolean(g["frontBase"])
                });
            }
            return out;
        }

        public function pendingCard():Array
        {
            try
            {
                var ev:Object = winfo()["eventInfo"];
                if (ev != null && int(ev["eventId"]) != 0 && int(ev["respondTpye"]) == 0 && ev["params"] != null && ev["params"].length > 0)
                    return [int(ev["params"][0])];
            }
            catch (e:Error) {}
            return null;
        }

        public function path(fx:int, fy:int, tx:int, ty:int):Array
        {
            var p:Object = model().walkPath(new Point(fx, fy), new Point(tx, ty));
            if (p == null) return null;
            var out:Array = [];
            for (var i:int = 0; i < p.length; i++) out.push({x: int(p[i].x), y: int(p[i].y)});
            return out;
        }

        public function moveTo(x:int, y:int):void { mgr()["control"].moveGridByXY(x, y); }

        public function sceneName():String { return scene(); }
        public function get goldKeys():int { try { return int(winfo()["goldKeyCount"]); } catch (e:Error) {} return -1; }
        public function get silverKeys():int { try { return int(winfo()["silverKeyCount"]); } catch (e:Error) {} return -1; }
        public function get insidePlan():Boolean { try { return Boolean(model()["isInPlanesWar"]); } catch (e:Error) {} return false; }
        public function get maxPlans():int { try { var v:int = int(model()["maxPlanesCount"]); if (v > 0) return v; } catch (e:Error) {} return 5; }

        // Planos do Transmissor (a lista só existe depois de abrir o Transmissor): [{id, tem, layers:[layerId,...]}]
        public function planList():Array
        {
            var out:Array = [];
            try
            {
                var list:Array = model()["planesInfoList"] as Array;
                if (list == null) return out;
                for (var i:int = 0; i < list.length; i++)
                {
                    var ls:Array = [];
                    var ll:Array = list[i]["planesLayerList"] as Array;
                    if (ll != null) for (var j:int = 0; j < ll.length; j++) ls.push(int(ll[j]["layerId"]));
                    out.push({id: int(list[i]["planesId"]), tem: int(list[i]["planesTemId"]), layers: ls});
                }
            }
            catch (e:Error) {}
            return out;
        }

        public function sendOp(op:int, params:Array = null):void
        {
            if (params == null) mgr().sendPlanesOpMsg(op);
            else mgr().sendPlanesOpMsg(op, params);
        }

        public function pendingType():int
        {
            try
            {
                var ev:Object = winfo()["eventInfo"];
                if (ev == null || int(ev["eventId"]) == 0) return -1;
                var ec:Object = templates("planesEventsTemplateCate");
                var t:Object = ec != null ? ec.getTemplateByID(int(ev["eventId"])) : null;
                return t != null ? int(t["EventType"]) : -1;
            }
            catch (e:Error) {}
            return -1;
        }

        private static function shortName(o:Object):String
        {
            var n:String = getQualifiedClassName(o);
            var i:int = n.lastIndexOf("::");
            return i >= 0 ? n.substr(i + 2) : n;
        }

        private static const SHOP_RE:RegExp = /shop|market|store/i;
        private static const CLOSE_RE:RegExp = /close|btn_?x|exit/i;

        private function scanShop(c:DisplayObjectContainer, depth:int, out:Array):void
        {
            if (depth > 8 || out.length >= 4) return;
            for (var i:int = 0; i < c.numChildren; i++)
            {
                var ch:DisplayObject;
                try { ch = c.getChildAt(i); } catch (e:Error) { continue; }
                if (ch is MacroPanel || ch is Controls) continue;
                if (SHOP_RE.test(shortName(ch)) && ch.visible) { out.push(ch); continue; }
                if (ch is DisplayObjectContainer) scanShop(ch as DisplayObjectContainer, depth + 1, out);
            }
        }

        private function findClose(c:DisplayObjectContainer, depth:int):DisplayObject
        {
            if (depth > 6) return null;
            for (var i:int = 0; i < c.numChildren; i++)
            {
                var ch:DisplayObject;
                try { ch = c.getChildAt(i); } catch (e:Error) { continue; }
                if (CLOSE_RE.test(shortName(ch)) || CLOSE_RE.test(ch.name)) return ch;
                if (ch is DisplayObjectContainer)
                {
                    var r:DisplayObject = findClose(ch as DisplayObjectContainer, depth + 1);
                    if (r != null) return r;
                }
            }
            return null;
        }

        // Fecha a loja do plano sem comprar nada. 1) acha uma janela cujo nome de classe lembra loja e chama hide/dispose/close;
        // 2) se não achar mas o evento pendente é mesmo loja, clica no botão "fechar" da janela mais ao topo.
        public function closeShop():String
        {
            var st:DisplayObjectContainer = SwfFixer.rootStage;
            if (st == null) return "sem palco";
            // Loja do plano = janela PlanesBlackFrame (visto no gravador). O botão de fechar é o BaseButton SEM texto, no canto de cima à direita
            // (os botões de compra têm texto/preço, então nunca são apertados).
            var fr:DisplayObject = UiHelper.find(st, "PlanesBlackFrame");
            if (fr != null)
            {
                var bl:Array = [];
                UiHelper.findAll(fr as DisplayObjectContainer, "BaseButton", bl, 8, 20);
                var best:DisplayObject = null;
                var bestScore:Number = -1e9;
                for (var k:int = 0; k < bl.length; k++)
                {
                    var tx:Array = [];
                    UiHelper.texts(bl[k], tx);
                    if (tx.length > 0) continue;
                    var p:Point = (bl[k] as DisplayObject).localToGlobal(new Point(0, 0));
                    var sc:Number = p.x - p.y;
                    if (sc > bestScore) { bestScore = sc; best = bl[k]; }
                }
                if (best != null) { UiHelper.press(best); return "cliquei no botão de fechar da loja (PlanesBlackFrame)"; }
                return "loja aberta (PlanesBlackFrame) mas não achei o botão de fechar";
            }
            var found:Array = [];
            var i:int;
            var o:Object;
            var m:String;
            var log:Array = [];
            scanShop(st, 0, found);
            for (i = 0; i < found.length; i++)
            {
                o = found[i];
                var did:Boolean = false;
                for each (m in ["hide", "dispose", "close"])
                {
                    try { if (o[m] is Function) { o[m](); did = true; log.push(shortName(o) + "." + m + "()"); break; } } catch (e1:Error) {}
                }
                if (!did)
                {
                    var cb:DisplayObject = (o is DisplayObjectContainer) ? findClose(o as DisplayObjectContainer, 0) : null;
                    if (cb != null) { cb.dispatchEvent(new MouseEvent(MouseEvent.CLICK, true, false)); did = true; log.push(shortName(o) + " > clique em " + shortName(cb)); }
                }
            }
            if (log.length > 0) return log.join("; ");
            return "a janela da loja não está aberta (o jogo não a abriu); o evento fica pendente e eu sigo adiante";
        }

        // ---- só leitura, para o gravador de passos ----
        public function stateLine():String
        {
            var L:Array = [];
            try
            {
                L.push("cena " + scene());
                var m:Object = model();
                if (m != null)
                {
                    L.push("dentro do plano " + m["isInPlanesWar"]);
                    var list:Array = m["planesInfoList"] as Array;
                    var ids:Array = [];
                    if (list != null) for (var i:int = 0; i < list.length; i++) ids.push(list[i]["planesId"] + "/m" + list[i]["planesTemId"]);
                    L.push("planos na lista " + (list != null ? list.length : -1) + " [" + ids.join(",") + "]");
                    var w:Object = winfo();
                    if (w != null) L.push("camada " + w["layerId"] + " (modelo " + w["layerTempId"] + ")");
                }
            }
            catch (e:Error) { L.push("erro " + e.message); }
            return L.join(" | ");
        }

        private static const WIN_RE:RegExp = /frame|view|window|panel|dialog|shop|market|store|list|bag|plane|transm|alert|tip/i;

        private function collectWins(c:DisplayObjectContainer, depth:int, out:Object):void
        {
            if (depth > 5) return;
            for (var i:int = 0; i < c.numChildren; i++)
            {
                var ch:DisplayObject;
                try { ch = c.getChildAt(i); } catch (e:Error) { continue; }
                if (ch is MacroPanel || ch is Controls || !ch.visible) continue;
                var n:String = shortName(ch);
                if (WIN_RE.test(n)) out[n] = true;
                if (ch is DisplayObjectContainer) collectWins(ch as DisplayObjectContainer, depth + 1, out);
            }
        }

        // nomes das janelas/painéis visíveis no palco (para ver o que abre e fecha)
        public function windowNames():Array
        {
            var o:Object = {};
            var out:Array = [];
            try { if (SwfFixer.rootStage != null) collectWins(SwfFixer.rootStage, 0, o); } catch (e:Error) {}
            for (var k:String in o) out.push(k);
            out.sort();
            return out;
        }

        public function pickCard(p0:int, card:int):void { mgr().sendPlanesOpMsg(35, [p0, card]); }

        public function suppressFrames():void { try { mgr()["isNeedOpendEventFrame"] = false; } catch (e:Error) {} }

        // Op 19 = LEAVING_OP, enviada sem parâmetros pelo botão de sair do jogo (MainToolBar).
        public function leavePlanes():void { mgr().sendPlanesOpMsg(19); }

        // ---- compra de energia: mesmos dados e mesma op que a barra de energia do jogo (PlanesTopView) usa ----
        private function cfg(name:String):String
        {
            try
            {
                var c:Object = templatesMgr().getConfigInfoByConfigName(name);
                return c != null ? String(c["ConfigValue"]) : "";
            }
            catch (e:Error) {}
            return "";
        }
        private function templatesMgr():Object { return single("yishi.manager.TempleteManager"); }

        public function get maxEnergy():int { var s:String = cfg("planes_max_recover_energy"); return s.length > 0 ? int(s) : 0; }
        public function get buyCount():int { try { return int(model()["hasBuyEnergyCount"]); } catch (e:Error) {} return -1; }
        public function get buyLimit():int { var s:String = cfg("planes_buy_energy_limit"); return s.length > 0 ? int(s) : -1; }
        public function get buyCost():int { var s:String = cfg("planes_buy_energy"); if (s.length == 0) return -1; return int(s.split(",")[0]); }
        public function get diamonds():int
        {
            try { return int(single("yishi.manager.PlayerManager")["currentPlayerModel"]["playerInfo"]["allPoint"]); } catch (e:Error) {}
            return -1;
        }
        // Op 8, param [2] se "diamante vinculado prioritário" estiver marcado, senão [1] (igual ao PlanesTopView.addEnergyHandlerResult).
        public function buyEnergy(bind:Boolean):void { mgr().sendPlanesOpMsg(8, [bind ? 2 : 1]); }

        // Só LÊ: lista os planos do transmissor (bolsa) e as camadas de cada um, para o diagnóstico.
        public function planesReport():String
        {
            var L:Array = [];
            L.push("PLANOS DO TRANSMISSOR (somente leitura)");
            try
            {
                var m:Object = model();
                if (m == null) { L.push("modelo de Planos ainda não existe (abra o Transmissor uma vez)."); return L.join("\n"); }
                L.push("dentro de um plano: " + m["isInPlanesWar"] + " | energia " + m["energyLeft"] + " | máx. de planos " + m["maxPlanesCount"] + " | energia comprada " + m["hasBuyEnergyCount"]);
                var list:Array = m["planesInfoList"] as Array;
                if (list == null || list.length == 0) { L.push("nenhum plano na lista (abra o Transmissor para o jogo carregar)."); return L.join("\n"); }
                var i:int;
                var j:int;
                var p:Object;
                var ly:Object;
                var parts:Array;
                for (i = 0; i < list.length; i++)
                {
                    p = list[i];
                    L.push("plano id=" + p["planesId"] + " modelo=" + p["planesTemId"] + " progresso=" + p["planesProcess"] + " vida=" + p["lifePoint"] + " reduz=" + p["lifeReduce"]);
                    parts = [];
                    var ll:Array = p["planesLayerList"] as Array;
                    if (ll != null)
                        for (j = 0; j < ll.length; j++)
                        {
                            ly = ll[j];
                            parts.push(ly["layerId"] + "/m" + ly["layerTempId"] + (ly["isActived"] ? "*" : "") + (int(ly["iconState"]) != 0 ? "(estado " + ly["iconState"] + ")" : ""));
                        }
                    L.push("   camadas (id/modelo, *=ativa): " + (parts.length ? parts.join(", ") : "nenhuma"));
                }
            }
            catch (e:Error) { L.push("ERRO ao ler: " + e.message); }
            return L.join("\n");
        }

        // Nome do item (plano) de uma célula da bolsa: tenta os lugares onde o jogo costuma guardar o modelo do item.
        private function itemInfo(d:Object):Object
        {
            for each (var k:String in ["templateInfo", "template", "itemTemplate", "info"])
            {
                try { var o:Object = d[k]; if (o != null && !(o is Number) && !(o is String)) return o; } catch (e:Error) {}
            }
            return null;
        }

        private function itemName(d:Object):String
        {
            var ti:Object = itemInfo(d);
            if (ti == null) return "";
            for each (var k:String in ["TemplateNameLang", "TemplateName", "name", "Name", "templateName"])
            {
                try { var v:* = ti[k]; if (v is String && String(v).length > 0) return String(v); } catch (e:Error) {}
            }
            return "";
        }

        // Prioridade para usar planos da bolsa: atual (0) > baixo (1) > médio (2) > grande (3). 99 = não usar (vazio/desconhecido).
        public function bagRank(cell:Object):int
        {
            try
            {
                var d:Object = cell["data"];
                if (d == null || int(d["count"]) <= 0) return 99;
                var n:String = itemName(d).toLowerCase();
                if (n.indexOf("atual") >= 0) return 0;
                if (n.indexOf("baixo") >= 0) return 1;
                if (n.indexOf("médio") >= 0 || n.indexOf("medio") >= 0) return 2;
                if (n.indexOf("grande") >= 0) return 3;
            }
            catch (e:Error) {}
            return 99;
        }

        public function bagCellName(cell:Object):String
        {
            try { var d:Object = cell["data"]; return itemName(d) + " (x" + d["count"] + ")"; } catch (e:Error) {}
            return "?";
        }

        // Melhor célula da bolsa (visível dentro da janela) pela prioridade acima; empate = a primeira.
        public function bestBagCell(frame:DisplayObjectContainer):DisplayObject
        {
            var cells:Array = [];
            UiHelper.findAll(frame, "PlanesBagCell", cells, 14, 60);
            var best:DisplayObject = null;
            var br:int = 99;
            for (var i:int = 0; i < cells.length; i++)
            {
                var r:int = bagRank(cells[i]);
                if (r < br) { br = r; best = cells[i]; }
            }
            return best;
        }

        // Só leitura: lista do Transmissor e Bolsa dos Planos (precisam estar ABERTAS na tela quando apertar Diagnóstico).
        public function bagReport():String
        {
            var L:Array = ["BOLSA E LISTA DOS PLANOS (só lê; abra a bolsa/Transmissor antes de apertar Diagnóstico)"];
            try
            {
                var st:DisplayObjectContainer = SwfFixer.rootStage;
                if (st == null) return L.join("\n");
                var items:Array = [];
                UiHelper.findAll(st, "PlanesItemView", items, 14, 12);
                for (var a:int = 0; a < items.length; a++)
                {
                    var t0:Array = [];
                    UiHelper.texts(items[a], t0);
                    if (t0.length > 0) L.push("lista do Transmissor: " + t0.join(" / "));
                }
                var cells:Array = [];
                UiHelper.findAll(st, "PlanesBagCell", cells, 14, 60);
                var shown:int = 0;
                for (var i:int = 0; i < cells.length; i++)
                {
                    var d:Object = null;
                    try { d = cells[i]["data"]; } catch (e2:Error) {}
                    if (d == null) continue;
                    shown++;
                    var nm:String = itemName(d);
                    L.push("bolsa pos " + d["pos"] + ": modelo " + d["templateId"] + " | qtd " + d["count"] + " | nome: " + (nm.length > 0 ? nm : "(não achei)"));
                    if (shown == 1)
                    {
                        var ti:Object = itemInfo(d);
                        L.push("   " + (ti != null ? dump("modelo do item (" + shortName(ti) + ")", ti) : "o item não tem objeto de modelo nos campos conhecidos"));
                    }
                }
                if (shown == 0 && items.length == 0) L.push("nada aberto: abra o Transmissor e a Bolsa dos Planos e aperte Diagnóstico de novo.");
            }
            catch (e:Error) { L.push("ERRO ao ler a bolsa: " + e.message); }
            return L.join("\n");
        }

        // Texto do botão "Diagnóstico": só LÊ, não envia nada ao servidor.
        public function report():String
        {
            var L:Array = [];
            L.push("DIAGNÓSTICO DO JOGO (somente leitura)");
            L.push("domínios de código vistos: " + SwfFixer.moduleDomains.length + (SwfFixer.gameDomain ? " + domínio do jogo" : " (sem domínio do jogo)"));
            var names:Array = ["yishi.manager.PlanesWarManager", "yishi.manager.TempleteManager", "yishi.manager.ArmyManager",
                               "yishi.scene.SceneManager", "mvc.controler.PlanesWarControler", "mvc.module.planeswar.PlanesWarModel"];
            var missing:int = 0;
            for each (var n:String in names)
            {
                var ok:Boolean = cls(n) != null;
                if (!ok) missing++;
                L.push((ok ? "  OK     " : "  FALTA  ") + n);
            }
            if (missing > 0)
            {
                L.push("Faltam classes: o jogo ainda não terminou de carregar? Entre no jogo e tente de novo.");
                return L.join("\n");
            }
            try
            {
                L.push("cena atual: " + scene() + (scene() == "PLANES_WAR_SCENE" ? "" : "   (abra o mapa de Planos para o macro funcionar)"));
                var w:Object = winfo();
                var m:Object = model();
                if (w == null || m == null) { L.push("modelo de Planos ainda não existe."); return L.join("\n"); }
                var lt:Object = layerTpl();
                L.push("camada: layerId=" + w["layerId"] + " layerTempId=" + w["layerTempId"] + " tamanho=" + (lt != null ? lt["Size"] : "?")
                       + " -> colunas x linhas = " + m["COLUMN_NUM"] + " x " + m["ROW_NUM"]);
                L.push("posição: (" + w["posX"] + "," + w["posY"] + ") | energia " + m["energyLeft"] + " | nível " + level + " | morto: " + w["dead"]);
                L.push("ENERGIA: " + m["energyLeft"] + "/" + maxEnergy + " | compras hoje " + buyCount + "/" + buyLimit + " | custo " + buyCost + " diamantes | seus diamantes " + diamonds + "  (-1 = não consegui ler)");
                L.push("movendo: " + moving + " | casas recebidas: " + (w["gridArr"] != null ? w["gridArr"].length : 0));
                L.push(dump("TEMPLATE do piso (planesLayerTemplate)", lt));
                L.push(dump("PlanesWarInfo (sem gridArr)", w, ",gridArr,"));
                var list:Array = cells();
                var byType:Object = {};
                var unknown:int = 0;
                var opened:int = 0;
                var c:Object;
                for each (c in list)
                {
                    if (c.opened) opened++;
                    if (c.type == -99) unknown++;
                    if (c.id != 0) byType[c.type] = int(byType[c.type]) + 1;
                }
                var tl:Array = [];
                for (var k:String in byType) tl.push("tipo " + k + " x" + byType[k]);
                tl.sort();
                L.push("abertas (névoa limpa): " + opened + " | eventos por EventType: " + (tl.length ? tl.join(", ") : "nenhum"));
                if (unknown > 0) L.push("ATENÇÃO: " + unknown + " casas com eventId sem template (tabela de eventos não carregada?)");
                L.push("Compare o MAPA do painel com a tela do jogo: cada número é o EventType da casa.");
            }
            catch (e:Error) { L.push("ERRO ao ler: " + e.message); }
            return L.join("\n");
        }
    }
}
