package
{
    // Tudo que o macro de Planos precisa saber/fazer. Duas implementações:
    //   GamePlanesAdapter = jogo real (via reflexão, sem importar classes do jogo)
    //   SimPlanesAdapter  = mapa 8x8 simulado, para testar sem o jogo
    // cells() devolve Objects {x, y, id, type, cost, need, opened, occupied, base}:
    //   id = eventId da casa (0 = vazia) | type = EventType do template (-1 parede, -99 template desconhecido, 0 vazia)
    public interface IPlanesAdapter
    {
        function get ready():Boolean;
        function get cols():int;
        function get rows():int;
        function get posX():int;
        function get posY():int;
        function get energy():int;
        function get level():int;
        function get layerId():int;
        // energia gasta por passo (o jogo calcula pela resistência da camada)
        function get stepCost():int;
        function get dead():Boolean;
        function get moving():Boolean;
        function cells():Array;
        // null = sem carta pendente; senão o array de parâmetros do evento (params[0] vai na op 35)
        function pendingCard():Array;
        // caminho [{x,y}, ...] incluindo a casa atual, ou null se não há caminho
        function path(fx:int, fy:int, tx:int, ty:int):Array;
        function moveTo(x:int, y:int):void;
        function pickCard(p0:int, card:int):void;
        // impede a janela de evento do jogo de abrir sozinha (o macro responde as cartas)
        function suppressFrames():void;
        // sai do plano (op 19, a mesma do botão de sair do jogo)
        function leavePlanes():void;
        // ---- compra de energia (só leitura + 1 comando) ----
        // -1 = não consegui ler; maxEnergy 0 = desconhecido
        function get maxEnergy():int;
        function get buyCount():int;      // compras já feitas hoje (hasBuyEnergyCount)
        function get buyLimit():int;      // limite diário (planes_buy_energy_limit)
        function get buyCost():int;       // diamantes por compra (planes_buy_energy)
        function get diamonds():int;      // diamantes do jogador (allPoint)
        // op 8 (barra de energia de dentro do plano): [2] = diamante vinculado primeiro, [1] = não
        function buyEnergy(bind:Boolean):void;
    }
}
