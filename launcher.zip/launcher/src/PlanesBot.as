package
{
    import flash.events.TimerEvent;
    import flash.geom.Point;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Macro do evento Planos (mapa em grade). Funciona sobre um IPlanesAdapter (jogo real ou simulação).
    // A cada ~0,7 s: se há carta pendente escolhe uma (op 35); senão escolhe a casa de evento mais valiosa/perto,
    // manda o jogo andar até ela (o próprio jogo faz o caminho e dispara o evento ao chegar) e espera.
    public class PlanesBot
    {
        public static const MAX_TRIES:int = 3;

        public var adapter:IPlanesAdapter;
        public var label:String;
        public var logger:Function;
        // categorias ligadas: box = baús (10,11,15) | res = recursos (5) | mon = monstros (1,2,13,14) | boss = chefe (12)
        // portal = true: ignora baús/monstros/etc. e só procura o portal (tipo 8), explorando a névoa e usando teleportes (91/92) se precisar
        // autoBuy: compra energia sozinho (op 8) | maxBuys: limite de compras por rodada | buyBelow: compra quando a energia cair abaixo disso
        // bind: true = usa diamante vinculado primeiro (mesma caixa marcada do aviso do jogo)
        public var opts:Object = {box: true, res: true, mon: true, boss: false, portal: 0, autoBuy: false, maxBuys: 3, buyBelow: 40, bind: true};
        public var running:Boolean = false;
        public var status:String = "parado";
        public var target:Point = null;
        public var done:Object = {};
        public var counts:Object = {box: 0, res: 0, mon: 0, boss: 0};
        public var minEnergy:int = 0;
        private var timer:Timer;
        private var tries:int = 0;
        private var waitUntil:int = 0;
        private var lastCard:int = 0;
        private var targetCat:String = "";
        private var summarized:Boolean = false;
        private var cardSig:int = -1;
        private var cardPicks:int = 0;
        private var ignoreSig:int = -1;
        private var lastReason:String = "";
        private var startX:int = 0;
        private var startY:int = 0;
        private var lastLayer:int = -999;
        // compra automática de energia
        private var buysDone:int = 0;
        private var buyWait:int = 0;          // 0 = sem compra pendente; senão, até quando esperar a energia subir (ms)
        private var buyBeforeEn:int = 0;
        private var buyBeforeDia:int = 0;
        private var buyBeforeCount:int = 0;

        public function PlanesBot(adapter:IPlanesAdapter, label:String)
        {
            this.adapter = adapter;
            this.label = label;
        }

        // Categoria de um EventType (ver PlanesConstClass do jogo).
        public static function category(t:int):String
        {
            if (t == 10 || t == 11 || t == 15) return "box";
            if (t == 5) return "res";
            if (t == 1 || t == 2 || t == 13 || t == 14) return "mon";
            if (t == 12) return "boss";
            if (t == 8) return "portal";      // entrada escondida (o portal do olho)
            if (t == 61 || t == 62 || t == 71 || t == 72 || t == 91 || t == 92) return "exit";
            if (t == 3) return "market";
            if (t == -1) return "wall";
            return "";
        }

        private static function prio(cat:String):int
        {
            if (cat == "box") return 1;
            if (cat == "res") return 2;
            if (cat == "mon") return 3;
            return 9;
        }

        private function say(s:String):void
        {
            if (logger != null) logger("[" + label + "] " + s);
        }

        public function start():void
        {
            if (running) return;
            done = {};
            xpSteps = 0; refAnn = "";
            counts = {box: 0, res: 0, mon: 0, boss: 0};
            target = null;
            tries = 0;
            waitUntil = 0;
            summarized = false;
            originLayer = -999; pend = null; resetSeek();
            mineMode = false; mineTarget = null; mineTries = 0;
            cardSig = -1; cardPicks = 0; ignoreSig = -1;
            buysDone = 0; buyWait = 0;
            running = true;
            status = "iniciando";
            timer = new Timer(700);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            usedPortal = {}; floorPending = {}; backHops = 0; closeFinished = false;
            say(int(opts.portal) == 4 ? "iniciado (modo FECHAR PLANOS: torres, baús, monstros e portais de todos os andares)" : int(opts.portal) == 3 ? "iniciado (modo MINAS: procura o olho e coleta a mina)" : "iniciado (baús " + opts.box + ", recursos " + opts.res + ", monstros " + opts.mon + ", chefe " + opts.boss + ")");
        }

        public function stop(reason:String = "parado"):void
        {
            if (timer != null)
            {
                timer.stop();
                timer.removeEventListener(TimerEvent.TIMER, onTick);
                timer = null;
            }
            if (running) say("parou: " + reason + " | feitos: baús " + counts.box + ", recursos " + counts.res + ", monstros " + counts.mon + ", chefe " + counts.boss);
            var was:Boolean = running;
            running = false;
            target = null;
            status = reason;
            var k:String = endKind;
            endKind = "";
            if (was && k != "" && onEnd != null) onEnd(k);
        }

        private function stopEnd(kind:String, reason:String):void { endKind = kind; stop(reason); }

        // Compra de energia (op 8, a mesma da barra de energia do jogo). Devolve true se este ciclo foi "consumido"
        // (esperando a compra, ou o macro parou); false = nada a fazer aqui (segue o macro; se a compra estiver
        // desligada, quem chamou decide parar). Gasta diamantes, por isso: nada é enviado se faltar QUALQUER dado,
        // e uma compra que não surtir efeito PARA o macro (nunca repete sozinha).
        private function refill(a:IPlanesAdapter, why:String):Boolean
        {
            if (!opts.autoBuy) return false;
            if (buyWait != 0)
            {
                if (a.energy > buyBeforeEn && (a.buyCount > buyBeforeCount || a.energy > buyBeforeEn + 10))
                {
                    buysDone++;
                    var dia:int = a.diamonds;
                    say("COMPRA DE ENERGIA #" + buysDone + " ok: energia " + buyBeforeEn + " -> " + a.energy
                        + " | diamantes " + buyBeforeDia + " -> " + dia + (dia >= 0 && buyBeforeDia >= 0 ? " (gastou " + (buyBeforeDia - dia) + ")" : "")
                        + " | compras hoje " + a.buyCount + "/" + a.buyLimit);
                    buyWait = 0;
                    waitUntil = getTimer() + 1200;
                    return false;
                }
                if (getTimer() < buyWait) { status = "esperando a compra de energia..."; return true; }
                buyWait = 0;
                say("a compra de energia não surtiu efeito em 8 s (energia continua " + a.energy + "): parei para não gastar diamantes à toa");
                stop("compra de energia sem efeito");
                return true;
            }
            var cost:int = a.buyCost;
            var limit:int = a.buyLimit;
            var count:int = a.buyCount;
            var have:int = a.diamonds;
            if (cost < 0 || limit < 0 || count < 0 || have < 0)
            {
                say("não consegui ler os dados da compra (custo " + cost + ", limite " + limit + ", compradas " + count + ", diamantes " + have + "): nada foi gasto");
                stop("compra de energia indisponível (sem dados)");
                return true;
            }
            if (count >= limit) { say("limite diário de compras de energia atingido (" + count + "/" + limit + ")"); stop("limite diário de energia atingido"); return true; }
            if (have < cost) { say("diamantes insuficientes para energia (tem " + have + ", precisa " + cost + ")"); stop("sem diamantes para energia"); return true; }
            if (buysDone >= int(opts.maxBuys)) { say("limite de " + opts.maxBuys + " compras de energia nesta rodada atingido"); stop("limite de compras de energia da rodada"); return true; }
            buyBeforeEn = a.energy;
            buyBeforeDia = have;
            buyBeforeCount = count;
            say("comprando energia (" + why + "): custo " + cost + " diamantes, " + (opts.bind ? "vinculado primeiro" : "diamante normal") + ", compra " + (buysDone + 1) + " de " + opts.maxBuys + " desta rodada");
            a.buyEnergy(Boolean(opts.bind));
            buyWait = getTimer() + 8000;
            status = "comprando energia...";
            return true;
        }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("ERRO: " + err.message); stop("erro: " + err.message); }
        }

        private function key(p:Point):int { return int(p.x) * 100 + int(p.y); }

        private function step():void
        {
            var a:IPlanesAdapter = adapter;
            if (!a.ready) { status = "aguardando o mapa de Planos no jogo"; return; }
            if (a.dead) { status = "personagem morto: reviva manualmente"; return; }
            if (a.moving || getTimer() < waitUntil) return;
            if (a.layerId != lastLayer)
            {
                if (lastLayer != -999) { say("mudou de piso: recomeçando o mapa"); done = {}; target = null; summarized = false; }
                lastLayer = a.layerId;
            }
            if (!opts.portal || mineMode || int(opts.portal) == 3 || int(opts.portal) == 4) a.suppressFrames();   // no modo portal o jogo abre a janela dele para você confirmar

            var card:Array = a.pendingCard();
            if (card != null && a.pendingType() == 3)
            {
                // loja do plano: nunca responde carta (poderia comprar); só fecha a janela e segue
                if (!shopGaveUp)
                {
                    if (getTimer() - lastShop > 1200)
                    {
                        lastShop = getTimer();
                        shopTries++;
                        say("loja do plano: fechando sem comprar (tentativa " + shopTries + "): " + a.closeShop());
                        if (shopTries >= 3) { shopGaveUp = true; say("não consegui fechar a loja; sigo sem responder a ela"); }
                    }
                    return;
                }
                card = null;
            }
            else if (card == null) { shopTries = 0; shopGaveUp = false; }
            if (card != null)
            {
                var sig:int = int(card[0]);
                if (sig == ignoreSig) card = null;
                else
                {
                    if (sig != cardSig) { cardSig = sig; cardPicks = 0; }
                    if (cardPicks >= 4)
                    {
                        // o jogo não está aceitando a resposta: não trava o macro, segue em frente
                        say("carta (" + sig + ") não some depois de 4 respostas: ignorando e seguindo");
                        ignoreSig = sig;
                        card = null;
                    }
                    else
                    {
                        if (getTimer() - lastCard > 2500)
                        {
                            lastCard = getTimer();
                            cardPicks++;
                            var pick:int = int(Math.random() * 4);
                            a.pickCard(sig, pick);
                            say("carta " + (pick + 1) + " escolhida");
                        }
                        return;
                    }
                }
            }
            else { ignoreSig = -1; cardSig = -1; cardPicks = 0; }

            if (!summarized) { summarized = true; summary(a); }

            status = "energia " + a.energy + " | baús " + counts.box + " recursos " + counts.res + " monstros " + counts.mon + " chefe " + counts.boss;
            var lowNow:Boolean = a.energy <= minEnergy || (opts.autoBuy && a.energy < int(opts.buyBelow));
            if (buyWait != 0 || lowNow) { if (refill(a, "energia baixa (" + a.energy + ")")) return; }
            if (a.energy <= minEnergy) { stop("sem energia"); return; }

            var here:Point = new Point(a.posX, a.posY);
            if (mineMode) { mineStep(a, here); return; }
            if (opts.portal && int(opts.portal) != 4 && portalStep(a, here)) return;
            var hopped:Boolean = target != null && targetCat == "hop" && (int(here.x) != startX || int(here.y) != startY);
            if (target != null && ((int(target.x) == int(here.x) && int(target.y) == int(here.y)) || hopped))
            {
                if (targetCat == "portal")
                {
                    say("PORTAL encontrado em (" + target.x + "," + target.y + ")");
                    stop("portal encontrado em (" + target.x + "," + target.y + ")");
                    return;
                }
                done[key(target)] = true;
                if (targetCat != "") counts[targetCat] = int(counts[targetCat]) + 1;
                say("chegou em (" + target.x + "," + target.y + ")");
                target = null;
                tries = 0;
                waitUntil = getTimer() + 1200;
                return;
            }

            if (target == null)
            {
                target = choose(a, here);
                tries = 0;
                if (target == null)
                {
                    say(lastReason);
                    if (closeFinished) stopEnd("closed", "plano fechado: todos os andares percorridos");
                    else stop("sem alvos acessíveis");
                    return;
                }
                startX = int(here.x); startY = int(here.y);
                say("alvo (" + target.x + "," + target.y + ") " + (targetCat == "" ? "explorar" : targetCat));
            }

            tries++;
            if (tries > MAX_TRIES)
            {
                say("desisti de (" + target.x + "," + target.y + ")");
                done[key(target)] = true;
                target = null;
                return;
            }
            a.moveTo(int(target.x), int(target.y));
        }

        // ---------- modo PORTAL: planeja o caminho mais curto até o olho (tipo 8) ----------
        // O servidor manda o mapa inteiro (inclusive a névoa), então dá para saber ANTES de andar se o piso tem o olho.
        // Sem olho no piso: para sem gastar energia. Com olho: menor caminho (paredes bloqueiam; casas com evento custam mais
        // para serem evitadas; teleportes/entradas nunca são pisados por acidente). Se o olho não é alcançável (ilha), usa um
        // teleporte, e no piso de passagem procura o teleporte "par" mais perto para voltar.
        // opts.portal: 1 = para AO LADO do olho (você entra) | 2 = pisa no olho (o servidor entra na hora)
        private var pend:Object = null;
        private var xpSteps:int = 0;      // passos de exploração em busca do olho (limite por rodada)
        private var refAnn:String = "";
        // modo MINA: depois de entrar no portal do olho, pega a mina (tipo 5) do piso interno e para
        private var mineMode:Boolean = false;
        private var mineTarget:Point = null;
        private var mineTries:int = 0;
        private var originLayer:int = -999;
        private var tried:Object = {};
        private var hops:int = 0;
        private var lastHopType:int = 0;
        private var announced:String = "";
        // busca do olho pelos mapas de referência (MapRefs)
        private var dead:Object = {};          // referências já descartadas neste piso (chegou no ponto de vista e o olho não está lá)
        private var blockedTr:Object = {};     // casas de teleporte já usadas (não passa de novo por elas)
        private var bounces:int = 0;           // tentativas de voltar saindo e entrando na casa de chegada
        private var seekWait:int = 0;
        private var seekAnn:String = "";
        private var byKeyLast:Object = null;
        private var seekHint:Point = null;
        public var onEnd:Function = null;     // chamado quando o macro termina por um motivo de "fim de plano" (kind: noeye | nomine | mine)
        private var endKind:String = "";
        private var shopTries:int = 0;
        private var lastShop:int = 0;
        private var shopGaveUp:Boolean = false;

        private function resetSeek():void
        {
            dead = {}; blockedTr = {}; bounces = 0; seekWait = 0; seekAnn = "";
        }

        private static function isTransfer(t:int):Boolean { return t == 61 || t == 62 || t == 71 || t == 72 || t == 91 || t == 92; }

        private static function partner(t:int):int
        {
            if (t == 61) return 62;
            if (t == 62) return 61;
            if (t == 71) return 72;
            if (t == 72) return 71;
            if (t == 91) return 92;
            if (t == 92) return 91;
            return 0;
        }

        private static function rank(t:int):int { return (t == 91 || t == 92) ? 0 : ((t == 61 || t == 62) ? 1 : 2); }

        private function dijk(byKey:Object, here:Point):Object
        {
            var dist:Object = {};
            var prev:Object = {};
            var seen:Object = {};
            var st0:int = key(here);
            dist[st0] = 0;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            while (true)
            {
                var cur:int = -1;
                var best:Number = Number.MAX_VALUE;
                for (var k:String in dist)
                {
                    if (seen[k]) continue;
                    if (Number(dist[k]) < best) { best = Number(dist[k]); cur = int(k); }
                }
                if (cur < 0) break;
                seen[cur] = true;
                var cc:Object = byKey[cur];
                if (cur != st0 && cc != null && (isTransfer(cc.type) || cc.type == 8)) continue;   // entradas/saídas só como destino
                for (var d:int = 0; d < 4; d++)
                {
                    var nk:int = (int(cur / 100) + dirs[d][0]) * 100 + (cur % 100 + dirs[d][1]);
                    var n:Object = byKey[nk];
                    if (n == null || n.type == -1 || seen[nk]) continue;
                    var stepW:int = 1;
                    if (n.id != 0 && category(n.type) != "" && !isTransfer(n.type) && n.type != 8) stepW = 41;   // evento: evita se der
                    var nd:Number = Number(dist[cur]) + stepW;
                    if (dist[nk] === undefined || nd < Number(dist[nk])) { dist[nk] = nd; prev[nk] = cur; }
                }
            }
            return {dist: dist, prev: prev, start: st0};
        }

        private function pathTo(r:Object, goal:int):Array
        {
            var out:Array = [];
            var k:int = goal;
            while (k != int(r.start)) { out.unshift(k); if (r.prev[k] === undefined) return null; k = int(r.prev[k]); }
            return out;
        }

        // ---------- modo MINA: já dentro do olho, vai até a mina (tipo 5) e encerra ----------
        // Prefere a mina de maior nível exigido/custo (a elite); se só houver uma, pega essa.
        private function mineStep(a:IPlanesAdapter, here:Point):void
        {
            var hx:int = int(here.x);
            var hy:int = int(here.y);
            if (mineTarget != null && int(mineTarget.x) == hx && int(mineTarget.y) == hy)
            {
                counts.res = int(counts.res) + 1;
                say("mina coletada em (" + hx + "," + hy + ")");
                try { a.leavePlanes(); say("saindo do plano (op 19)"); }
                catch (err:Error) { say("não consegui sair do plano: " + err.message); }
                stopEnd("mine", "mina coletada");
                return;
            }
            if (mineTarget == null)
            {
                var list:Array = a.cells();
                var best:Object = null;
                var bestPath:int = 0;
                var found:int = 0;
                var i:int;
                var c:Object;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if (c.type != 5 || c.id == 0 || c.base) continue;
                    found++;
                    say("mina (tipo 5) em (" + c.x + "," + c.y + "): id " + c.id + ", nível " + c.need + ", custo " + c.cost + ", aberta " + c.opened + ", ocupada " + c.occupied);
                    if (!c.opened) continue;
                    if (a.level >= c.need && a.energy < c.cost && refill(a, "a mina precisa de " + c.cost)) return;
                    if (a.level < c.need || a.energy < c.cost) { say("sem nível/energia para a mina em (" + c.x + "," + c.y + ")"); continue; }
                    var pth:Array = a.path(hx, hy, int(c.x), int(c.y));
                    if (pth == null) continue;
                    var better:Boolean = best == null
                        || int(c.need) > int(best.need)
                        || (int(c.need) == int(best.need) && int(c.cost) > int(best.cost))
                        || (int(c.need) == int(best.need) && int(c.cost) == int(best.cost) && pth.length < bestPath);
                    if (better) { best = c; bestPath = pth.length; }
                }
                if (best == null)
                {
                    say(found == 0 ? "não há mina (tipo 5) neste piso" : "mina encontrada mas inalcançável (névoa, nível/energia ou sem caminho)");
                    stopEnd("nomine", "sem mina no olho");
                    return;
                }
                mineTarget = new Point(int(best.x), int(best.y));
                mineTries = 0;
                say("indo para a mina em (" + best.x + "," + best.y + "): " + (bestPath - 1) + " passos");
            }
            mineTries++;
            if (mineTries > MAX_TRIES + 2)
            {
                say("não consegui chegar na mina em (" + mineTarget.x + "," + mineTarget.y + ")");
                stop("travado indo à mina");
                return;
            }
            a.moveTo(int(mineTarget.x), int(mineTarget.y));
        }

        private function portalStep(a:IPlanesAdapter, here:Point):Boolean
        {
            var layer:int = a.layerId;
            var hx:int = int(here.x);
            var hy:int = int(here.y);
            var mode:int = (opts.portal === true) ? 1 : int(opts.portal);
            var wantMine:Boolean = (mode == 3);
            if (wantMine) mode = 2;
            if (originLayer == -999) { originLayer = layer; hops = 0; tried = {}; pend = null; lastHopType = 0; announced = ""; resetSeek(); refAnn = ""; xpSteps = 0; }

            // 1) o que eu estava fazendo?
            if (pend != null)
            {
                var atTarget:Boolean = layer == int(pend.layer) && hx == int(pend.x) && hy == int(pend.y);
                if (layer != int(pend.layer) && (pend.kind == "xp" || pend.kind == "bo1" || pend.kind == "bo2"))
                {
                    // o piso mudou no meio do caminho: pisei num teleporte (ou voltei por um)
                    if (pend.kind == "xp")
                    {
                        hops++;
                        if (int(pend.tr) >= 0) blockedTr[int(pend.tr)] = true;
                        if (int(pend.tr) >= 0 && byKeyLast != null && byKeyLast[int(pend.tr)] != null) lastHopType = int(byKeyLast[int(pend.tr)].type);
                        say("o caminho passou por um teleporte: agora no piso " + layer + " em (" + hx + "," + hy + "); vou voltar");
                    }
                    else say("troquei de piso ao voltar: agora no piso " + layer + " em (" + hx + "," + hy + ")");
                    pend = null;
                    waitUntil = getTimer() + 1500;
                    return true;
                }
                if (pend.kind == "bo1" && atTarget)
                {
                    pend = {kind: "bo2", x: int(pend.bx), y: int(pend.by), layer: layer, tries: 1};
                    a.moveTo(int(pend.x), int(pend.y));
                    return true;
                }
                if (pend.kind == "xp" && (hx != int(pend.lx) || hy != int(pend.ly))) { pend.tries = 0; pend.lx = hx; pend.ly = hy; }
                if (pend.kind == "hop")
                {
                    var tele:Boolean = layer != int(pend.layer) || (!atTarget && (hx != int(pend.sx) || hy != int(pend.sy)));
                    if (tele)
                    {
                        hops++;
                        lastHopType = int(pend.type);
                        say("teleporte usado: agora no piso " + layer + " em (" + hx + "," + hy + ")");
                        pend = null;
                        waitUntil = getTimer() + 1500;
                        return true;
                    }
                }
                else if (atTarget || (pend.kind == "end" && layer != int(pend.layer)))
                {
                    if (pend.kind == "end")
                    {
                        say(mode == 2 ? "entrou no portal do olho" : "PARADO AO LADO do olho, em (" + hx + "," + hy + ")");
                        if (wantMine)
                        {
                            pend = null;
                            mineMode = true; mineTarget = null; mineTries = 0;
                            waitUntil = getTimer() + 1500;
                            return true;
                        }
                        stop(mode == 2 ? "no portal do olho" : "ao lado do olho");
                        return true;
                    }
                    if (pend.kind == "xp") done[hx * 100 + hy] = true;
                    pend = null;
                    waitUntil = getTimer() + 300;
                    return true;
                }
                pend.tries = int(pend.tries) + 1;
                if (int(pend.tries) > (pend.kind == "xp" ? 8 : MAX_TRIES + 1))
                {
                    say("não consegui ir até (" + pend.x + "," + pend.y + ")");
                    stop("travado indo para (" + pend.x + "," + pend.y + ")");
                    return true;
                }
                a.moveTo(int(pend.x), int(pend.y));
                return true;
            }

            // 2) o mapa inteiro
            var list:Array = a.cells();
            var byKey:Object = {};
            var i:int;
            var c:Object;
            var eye:Object = null;
            var fogN:int = 0, fogEv:int = 0, openEv:int = 0;
            byKeyLast = byKey;
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                byKey[c.x * 100 + c.y] = c;
                if (c.type == 8) eye = c;
                if (!c.opened) { fogN++; if (c.id != 0) fogEv++; }
                else if (c.id != 0) openEv++;
            }
            var ann:String = layer + ":" + (eye != null ? "olho" : "sem") + ":" + hops;
            if (eye == null)
            {
                if (layer == originLayer)
                {
                    // 2a) mapa reconhecido pelas referências: vai pelo caminho mais curto até onde o olho estaria
                    var cands:Array = MapRefs.candidates(list, a.cols, a.rows);
                    if (cands.length > 0)
                    {
                        if (seekStep(a, here, byKey, cands, layer)) return true;
                    }
                    else if (MapRefs.candidates(list, a.cols, a.rows, false).length > 0)
                    {
                        // as paredes batem com algum mapa, mas em todos o lugar do olho já está à vista e não tem olho
                        say("o lugar do olho nos mapas conhecidos já foi visto e está vazio: este plano NÃO tem olho");
                        stopEnd("noeye", "sem olho neste piso (energia intacta)");
                        return true;
                    }
                    // 2b) mapa desconhecido (ou sem caminho): exploração geral
                    var hint:Object = MapRefs.match(list, a.cols, a.rows);
                    var hp:Point = (hint != null) ? new Point(int(hint.ex), int(hint.ey)) : (cands.length > 0 ? seekHint : null);
                    if (hint != null && refAnn != String(hint.name))
                    {
                        refAnn = String(hint.name);
                        say("mapa reconhecido (" + refAnn + "): olho esperado em (" + hint.ex + "," + hint.ey + "); explorando nessa direção");
                    }
                    if (xpSteps < 80)
                    {
                        var xd:Object = distances(byKey, here);
                        var xb:Point = explore(list, byKey, xd, here, a.cols, a.rows, hp);
                        if (xb != null)
                        {
                            if (a.energy < a.stepCost)
                            {
                                if (refill(a, "explorar até o olho")) return true;
                                stop("energia insuficiente para explorar");
                                return true;
                            }
                            xpSteps++;
                            if (hint == null && announced != "xp0") { announced = "xp0"; say("olho ainda não visível e mapa não reconhecido: explorando a névoa (máx. 80 passos)"); }
                            pend = {kind: "xp", x: int(xb.x), y: int(xb.y), layer: layer, tries: 1};
                            a.moveTo(int(pend.x), int(pend.y));
                            return true;
                        }
                    }
                    say("este piso NÃO tem o portal do olho: parei sem gastar energia");
                    stopEnd("noeye", "sem olho neste piso (energia intacta)");
                    return true;
                }
                if (announced != ann) { announced = ann; say("piso " + layer + " sem olho: procurando o teleporte para voltar"); }
                return hopStep(a, here, byKey, list, layer);
            }

            // 3) menor caminho até o olho
            var r:Object = dijk(byKey, here);
            var goals:Array = [];
            var ek:int = eye.x * 100 + eye.y;
            if (mode == 2) goals.push(ek);
            else
            {
                var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
                for (var d:int = 0; d < 4; d++)
                {
                    var nk:int = (int(eye.x) + dirs[d][0]) * 100 + (int(eye.y) + dirs[d][1]);
                    var nc:Object = byKey[nk];
                    if (nc != null && nc.type != -1 && !isTransfer(nc.type) && nc.type != 8 && nc.id == 0) goals.push(nk);
                }
                if (goals.length == 0)
                    for (d = 0; d < 4; d++)
                    {
                        nk = (int(eye.x) + dirs[d][0]) * 100 + (int(eye.y) + dirs[d][1]);
                        nc = byKey[nk];
                        if (nc != null && nc.type != -1 && !isTransfer(nc.type) && nc.type != 8) goals.push(nk);
                    }
            }
            var goal:int = -1;
            var gd:Number = Number.MAX_VALUE;
            for (i = 0; i < goals.length; i++)
                if (r.dist[goals[i]] !== undefined && Number(r.dist[goals[i]]) < gd) { gd = Number(r.dist[goals[i]]); goal = goals[i]; }

            if (goal == key(here) && mode != 2)
            {
                say("PARADO AO LADO do olho (" + eye.x + "," + eye.y + ")");
                stop("ao lado do olho");
                return true;
            }
            if (goal >= 0)
            {
                var p:Array = pathTo(r, goal);
                var evCost:int = 0;
                if (mode == 2) { var et:Object = byKey[ek]; evCost = (et != null) ? int(et.cost) : 0; }
                var need:int = p.length * a.stepCost + evCost;
                if (announced != ann + "p")
                {
                    announced = ann + "p";
                    say("OLHO em (" + eye.x + "," + eye.y + ") no piso " + layer + ": caminho mais curto = " + p.length + " passos, energia ~" + need + " (você tem " + a.energy + ")");
                }
                if (a.energy < need)
                {
                    if (refill(a, "o caminho até o olho precisa de ~" + need)) return true;
                    stop("energia insuficiente: precisa ~" + need + ", tem " + a.energy);
                    return true;
                }
                // waypoint: a casa mais longe no caminho que não tenha evento (só o ponto final dispara evento), sem passar de 1 casa na névoa
                var lim:int = 0;
                while (lim < p.length - 1 && byKey[p[lim]].opened) lim++;
                var j:int = Math.min(lim, p.length - 1);
                if (j < p.length - 1) { while (j > 0 && byKey[p[j]].id != 0) j--; }
                var wk:int = p[j];
                var last:Boolean = (j == p.length - 1);
                pend = {kind: last ? "end" : "wp", x: int(wk / 100), y: wk % 100, layer: layer, tries: 1};
                a.moveTo(int(pend.x), int(pend.y));
                return true;
            }

            // 4) sem caminho: ilha. usa um teleporte
            if (announced != ann + "h") { announced = ann + "h"; say("olho em (" + eye.x + "," + eye.y + ") mas sem caminho a pé daqui: preciso de um teleporte"); }
            return hopStep(a, here, byKey, list, layer);
        }

        // ---------- busca do olho pelos mapas de referência ----------
        // Para cada referência compatível com as casas já abertas, calcula o menor caminho (paredes bloqueiam; casas abertas
        // valem pelo que o jogo mostra, a névoa vale pela referência) até um ponto de onde o olho aparece. Vai pelo candidato
        // mais perto, atacando o que estiver no caminho. Devolve false se não houver caminho (aí vale a exploração geral).
        private function seekStep(a:IPlanesAdapter, here:Point, byKey:Object, cands:Array, layer:int):Boolean
        {
            var hx:int = int(here.x);
            var hy:int = int(here.y);
            var n:int = a.cols;
            var alive:Array = [];
            var i:int;
            for (i = 0; i < cands.length; i++) if (!dead[cands[i].name]) alive.push(cands[i]);
            var names:Array = [];
            for (i = 0; i < alive.length; i++) names.push(alive[i].name);
            if (alive.length == 0)
            {
                say("fui até onde o olho ficaria em todos os mapas possíveis e ele não apareceu: este plano NÃO tem olho");
                stopEnd("noeye", "sem olho neste piso");
                return true;
            }
            var bestRef:Object = null;
            var bestPath:Array = null;
            for (i = 0; i < alive.length; i++)
            {
                var pth:Array = seekPath(byKey, alive[i], n, hx, hy);
                if (pth == null) continue;
                if (bestPath == null || pth.length < bestPath.length) { bestPath = pth; bestRef = alive[i]; }
            }
            if (bestRef == null) return false;

            seekHint = new Point(int(bestRef.ex), int(bestRef.ey));
            var ann:String = names.join("|") + ">" + bestRef.name;
            if (seekAnn != ann)
            {
                seekAnn = ann;
                say("mapa " + (alive.length == 1 ? "reconhecido: " : "ainda ambíguo, possíveis: ") + names.join(", ")
                    + " | indo ver o olho em (" + bestRef.ex + "," + bestRef.ey + ") pelo caminho mais curto: " + bestPath.length + " passos");
            }

            if (bestPath.length == 0)
            {
                // já estou no ponto de vista: se o olho ainda não apareceu, espera um pouco e descarta esta referência
                seekWait++;
                if (seekWait >= 3)
                {
                    seekWait = 0;
                    dead[bestRef.name] = true;
                    say("cheguei perto de (" + bestRef.ex + "," + bestRef.ey + ") e não há olho (" + bestRef.name + " descartado)");
                }
                waitUntil = getTimer() + 900;
                return true;
            }
            seekWait = 0;
            if (a.energy < a.stepCost)
            {
                if (refill(a, "ir ver o olho")) return true;
                stop("energia insuficiente para ir ver o olho");
                return true;
            }

            // trecho: só até casas JÁ ABERTAS (o jogo só anda por casas abertas; a névoa abre sozinha ao chegar perto),
            // até 5 casas, sem curvas que deixem o jogo escolher outro caminho e com caminho aceito pelo jogo
            var lim:int = -1;
            while (lim + 1 < bestPath.length && byKey[bestPath[lim + 1]] != null && byKey[bestPath[lim + 1]].opened) lim++;
            if (lim < 0) return false;   // a próxima casa ainda está na névoa: exploração geral abre o caminho
            var j:int = Math.min(lim, 4);
            while (j >= 0)
            {
                var okM:Boolean = (Math.abs(int(bestPath[j] / 100) - hx) + Math.abs(bestPath[j] % 100 - hy)) == j + 1;
                if (okM)
                {
                    var gp:Array = null;
                    try { gp = a.path(hx, hy, int(bestPath[j] / 100), bestPath[j] % 100); } catch (e:Error) {}
                    if (gp != null) break;
                }
                j--;
            }
            if (j < 0) return false;
            var trk:int = -1;
            var q:int;
            for (q = 0; q <= j; q++)
            {
                var qc:Object = byKey[bestPath[q]];
                if (qc != null && isTransfer(qc.type)) { trk = bestPath[q]; break; }
            }
            var ek:Object = byKey[bestPath[j]];
            xpSteps++;
            pend = {kind: "xp", x: int(bestPath[j] / 100), y: bestPath[j] % 100, layer: layer, tries: 1, tr: trk, lx: hx, ly: hy, type: (ek != null ? int(ek.type) : 0)};
            a.moveTo(int(pend.x), int(pend.y));
            return true;
        }

        private function refWalk(byKey:Object, ref:Object, x:int, y:int, n:int):Boolean
        {
            if (x < 0 || y < 0 || x >= n || y >= n) return false;
            if (x == int(ref.ex) && y == int(ref.ey)) return false;   // o olho é só destino
            var k:int = x * 100 + y;
            if (blockedTr[k]) return false;
            var c:Object = byKey[k];
            if (c != null && c.opened) return c.type != -1;           // casa já vista: vale o que o jogo mostra
            var s:String = x + "," + y;
            return !(ref.w[s] || ref.u[s]);                           // névoa: vale a referência
        }

        // Caminho (lista de chaves x*100+y, sem a casa atual) até o ponto de vista mais perto do olho da referência; null = sem caminho.
        // Teleportes custam um tiquinho a mais só para desempatar (mesmo tamanho: prefere não trocar de piso).
        private function seekPath(byKey:Object, ref:Object, n:int, hx:int, hy:int):Array
        {
            var dist:Object = {};
            var prev:Object = {};
            var seen:Object = {};
            var st:int = hx * 100 + hy;
            dist[st] = 0;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            var d:int;
            while (true)
            {
                var cur:int = -1;
                var bd:Number = Number.MAX_VALUE;
                for (var ks:String in dist)
                {
                    if (seen[ks]) continue;
                    if (Number(dist[ks]) < bd) { bd = Number(dist[ks]); cur = int(ks); }
                }
                if (cur < 0) break;
                seen[cur] = true;
                var cx:int = int(cur / 100);
                var cy:int = cur % 100;
                for (d = 0; d < 4; d++)
                {
                    var nx:int = cx + dirs[d][0];
                    var ny:int = cy + dirs[d][1];
                    if (!refWalk(byKey, ref, nx, ny, n)) continue;
                    var nk:int = nx * 100 + ny;
                    if (seen[nk]) continue;
                    var cc:Object = byKey[nk];
                    var nd:Number = bd + ((cc != null && isTransfer(cc.type)) ? 1001 : 1000);
                    if (dist[nk] === undefined || nd < Number(dist[nk])) { dist[nk] = nd; prev[nk] = cur; }
                }
            }
            var goal:int = -1;
            var gd:Number = Number.MAX_VALUE;
            var ex:int = int(ref.ex);
            var ey:int = int(ref.ey);
            var gk:int;
            for (d = 0; d < 4; d++)
            {
                gk = (ex + dirs[d][0]) * 100 + (ey + dirs[d][1]);
                if (dist[gk] !== undefined && Number(dist[gk]) < gd) { gd = Number(dist[gk]); goal = gk; }
            }
            if (goal < 0)
            {
                // olho cercado: serve qualquer casa a até 2 de distância
                for (var dx:int = -2; dx <= 2; dx++)
                    for (var dy:int = -2; dy <= 2; dy++)
                    {
                        if (dx == 0 && dy == 0) continue;
                        gk = (ex + dx) * 100 + (ey + dy);
                        if (dist[gk] !== undefined && Number(dist[gk]) < gd) { gd = Number(dist[gk]); goal = gk; }
                    }
            }
            if (goal < 0) return null;
            var out:Array = [];
            var k:int = goal;
            while (k != st)
            {
                out.unshift(k);
                if (prev[k] === undefined) return null;
                k = int(prev[k]);
            }
            return out;
        }

        // Sem teleporte visível para voltar: sai da casa de chegada e volta nela (pode ser o que aciona o retorno).
        private function bounceStep(a:IPlanesAdapter, here:Point, byKey:Object, layer:int):Boolean
        {
            var hx:int = int(here.x);
            var hy:int = int(here.y);
            if (bounces >= 2) { stop("sem teleporte para voltar neste piso (mande o log)"); return true; }
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            var nb:Object = null;
            for (var d:int = 0; d < 4 && nb == null; d++)
            {
                var c:Object = byKey[(hx + dirs[d][0]) * 100 + (hy + dirs[d][1])];
                if (c != null && c.opened && c.type != -1 && !isTransfer(c.type) && c.type != 8 && c.id == 0) nb = c;
            }
            if (nb == null) { stop("sem teleporte para voltar e sem casa livre ao lado"); return true; }
            bounces++;
            pend = {kind: "bo1", x: int(nb.x), y: int(nb.y), layer: layer, tries: 1, bx: hx, by: hy};
            say("nenhum teleporte à vista neste piso: saio da casa de chegada e volto nela para tentar retornar (" + bounces + "/2)");
            a.moveTo(int(nb.x), int(nb.y));
            return true;
        }

        // Escolhe o teleporte mais adequado: no piso de passagem, o "par" do que usei (61<->62, 71<->72, 91<->92); senão o mais perto.
        private function hopStep(a:IPlanesAdapter, here:Point, byKey:Object, list:Array, layer:int):Boolean
        {
            if (hops >= 8) { stop("muitos teleportes sem achar caminho até o olho"); return true; }
            var r:Object = dijk(byKey, here);
            var best:Object = null;
            var bs:Number = Number.MAX_VALUE;
            for (var i:int = 0; i < list.length; i++)
            {
                var c:Object = list[i];
                if (!isTransfer(c.type) || tried[layer + "_" + c.x + "_" + c.y]) continue;
                var k:int = c.x * 100 + c.y;
                if (r.dist[k] === undefined) continue;
                var s:Number = Number(r.dist[k]) + rank(c.type) * 100;
                if (layer != originLayer && lastHopType != 0 && c.type == partner(lastHopType)) s -= 1000;
                if (s < bs) { bs = s; best = c; }
            }
            if (best == null)
            {
                if (layer != originLayer && !eyeSeen(list)) return bounceStep(a, here, byKey, layer);
                stop("sem caminho até o olho e sem teleporte novo para usar");
                return true;
            }
            tried[layer + "_" + best.x + "_" + best.y] = true;
            pend = {kind: "hop", x: int(best.x), y: int(best.y), layer: layer, sx: int(here.x), sy: int(here.y), type: int(best.type), tries: 1};
            say("usando teleporte tipo " + best.type + " em (" + best.x + "," + best.y + ") no piso " + layer);
            a.moveTo(int(best.x), int(best.y));
            return true;
        }

        private function eyeSeen(list:Array):Boolean
        {
            for (var i:int = 0; i < list.length; i++) if (list[i].type == 8) return true;
            return false;
        }

        private function summary(a:IPlanesAdapter):void
        {
            var list:Array = a.cells();
            var opened:int = 0;
            var types:Object = {};
            var c:Object;
            for (var i:int = 0; i < list.length; i++)
            {
                c = list[i];
                if (!c.opened) continue;
                opened++;
                if (c.id != 0) types[c.type] = int(types[c.type]) + 1;
            }
            var tl:Array = [];
            for (var k:String in types) tl.push("tipo " + k + " x" + types[k]);
            say("mapa " + a.cols + "x" + a.rows + ": " + opened + " casas abertas de " + list.length + " | eventos nas abertas: " + (tl.length > 0 ? tl.join(", ") : "nenhum") + " | você em (" + a.posX + "," + a.posY + ")");
        }

        // Distâncias (passos de 4 direções) só por casas ABERTAS e sem parede. Chave = x*100+y.
        private function distances(byKey:Object, here:Point):Object
        {
            var dist:Object = {};
            var queue:Array = [key(here)];
            dist[key(here)] = 0;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            while (queue.length > 0)
            {
                var cur:int = queue.shift();
                var cx:int = int(cur / 100);
                var cy:int = cur % 100;
                for (var d:int = 0; d < 4; d++)
                {
                    var nx:int = cx + dirs[d][0];
                    var ny:int = cy + dirs[d][1];
                    var k:int = nx * 100 + ny;
                    var n:Object = byKey[k];
                    if (n == null || !n.opened || n.type == -1 || dist[k] !== undefined) continue;
                    dist[k] = int(dist[cur]) + 1;
                    queue.push(k);
                }
            }
            return dist;
        }

        // Melhor casa aberta (sem evento) que encosta em névoa; null se não houver.
        private function explore(list:Array, byKey:Object, dist:Object, here:Point, cols:int, rows:int, hint:Point = null):Point
        {
            var best:Point = null;
            var c:Object;
            var k:int;
            var i:int;
            var score:Number;
            var bestFog:Number = Number.MAX_VALUE;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                k = c.x * 100 + c.y;
                if (dist[k] === undefined || done[k] || (c.x == int(here.x) && c.y == int(here.y))) continue;
                if (c.id != 0 && category(c.type) != "") continue;   // casa com evento: não pisa só para explorar
                var fog:int = 0;
                for (var d:int = 0; d < 8; d++)
                {
                    var n:Object = byKey[(c.x + dirs[d][0]) * 100 + (c.y + dirs[d][1])];
                    if (n != null && !n.opened) fog++;
                    // jogo real: casa ainda na névoa NÃO vem na lista; vizinha dentro do mapa e ausente = névoa
                    else if (n == null)
                    {
                        var ax:int = c.x + dirs[d][0];
                        var ay:int = c.y + dirs[d][1];
                        if (ax >= 0 && ay >= 0 && ax < cols && ay < rows) fog++;
                    }
                }
                if (fog == 0) continue;
                score = int(dist[k]) - fog * 0.1;
                if (hint != null) score = int(dist[k]) + (Math.abs(c.x - hint.x) + Math.abs(c.y - hint.y)) * 3 - fog * 0.1;
                if (score < bestFog) { bestFog = score; best = new Point(c.x, c.y); targetCat = ""; }
            }
            return best;
        }

        // ---------- modo FECHAR PLANOS (opts.portal == 4) ----------
        // Em cada andar: torres/guardas (tipo 14) > baús (10,11,15: dão as chaves) > monstros (1,2,13) > chefe (12); depois explora a
        // névoa; quando o andar acabou, pisa num portal de andar AINDA NÃO USADO (61/62 comum, 91/92 secundário, 71/72 dourado só com chave
        // dourada). Sem portal novo: volta por um portal já usado para um andar que ainda tinha portais. O olho (tipo 8) não é pisado.
        private var usedPortal:Object = {};
        private var floorPending:Object = {};
        private var backHops:int = 0;
        private var closeFinished:Boolean = false;

        private static function closePrio(t:int):int
        {
            if (t == 14) return 1;                          // torre primeiro
            if (t == 10 || t == 11 || t == 15) return 2;    // baús (chaves) logo depois
            return -1;                                      // monstros e chefe: só os que estiverem no caminho (ver detour)
        }

        private static function isFloorPortal(t:int):Boolean { return t == 61 || t == 62 || t == 71 || t == 72 || t == 91 || t == 92; }

        private static function isReturnPortal(t:int):Boolean { return t == 62 || t == 72 || t == 92; }

        private function goldKeys(a:IPlanesAdapter):int
        {
            try { var v:* = Object(a).goldKeys; if (v is Number) return int(v); } catch (e:Error) {}
            return -1;
        }

        // Monstros (e chefe) só são atacados se estiverem NO CAMINHO até o alvo: poupa energia.
        private static function isMonType(t:int):Boolean { return t == 1 || t == 2 || t == 13 || t == 12; }

        // Caminho mais curto até o alvo passando só por casas abertas; casas com outro evento (portal, baú, torre...) bloqueiam,
        // monstros não. Devolve o primeiro monstro vivo desse caminho (ou null se o caminho está livre / não há caminho).
        private function detour(a:IPlanesAdapter, list:Array, byKey:Object, here:Point, goal:Point):Point
        {
            var gk:int = key(goal);
            var hk:int = key(here);
            if (gk == hk) return null;
            var prev:Object = {};
            var queue:Array = [hk];
            prev[hk] = -1;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            var found:Boolean = false;
            while (queue.length > 0 && !found)
            {
                var cur:int = queue.shift();
                var cx:int = int(cur / 100);
                var cy:int = cur % 100;
                for (var d:int = 0; d < 4; d++)
                {
                    var k:int = (cx + dirs[d][0]) * 100 + (cy + dirs[d][1]);
                    var n:Object = byKey[k];
                    if (n == null || !n.opened || n.type == -1 || prev[k] !== undefined) continue;
                    if (k != gk && n.id != 0 && !n.occupied && !isMonType(n.type) && n.type != 0) continue;
                    prev[k] = cur;
                    if (k == gk) { found = true; break; }
                    queue.push(k);
                }
            }
            if (!found) return null;
            var chain:Array = [];
            var w:int = int(prev[gk]);
            while (w != -1 && w != hk) { chain.push(w); w = int(prev[w]); }
            for (var i:int = chain.length - 1; i >= 0; i--)
            {
                var c:Object = byKey[chain[i]];
                if (c != null && c.id != 0 && !c.occupied && !done[chain[i]] && isMonType(c.type))
                {
                    if (a.level < c.need || a.energy < c.cost) return null;
                    say("monstro no caminho em (" + c.x + "," + c.y + "): ataco só ele");
                    return new Point(c.x, c.y);
                }
            }
            return null;
        }

        private function chooseClose(a:IPlanesAdapter, here:Point, list:Array, byKey:Object, dist:Object):Point
        {
            var g:Point = chooseCloseGoal(a, here, list, byKey, dist);
            if (g == null || targetCat == "mon" || targetCat == "hop") return g;
            var m:Point = detour(a, list, byKey, here, g);
            if (m != null) { targetCat = "mon"; return m; }
            return g;
        }

        private function chooseCloseGoal(a:IPlanesAdapter, here:Point, list:Array, byKey:Object, dist:Object):Point
        {
            var lay:int = a.layerId;
            var best:Point = null;
            var bestScore:Number = Number.MAX_VALUE;
            var i:int;
            var c:Object;
            var k:int;
            var pr:int;
            var sc:Number;
            var skipCost:int = 0;
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                if (c.id == 0 || c.occupied || c.base || done[c.x * 100 + c.y] || !c.opened) continue;
                pr = closePrio(c.type);
                if (pr < 0) continue;
                if (a.level < c.need || a.energy < c.cost) { skipCost++; continue; }
                k = c.x * 100 + c.y;
                if (dist[k] === undefined) continue;
                sc = pr * 1000 + int(dist[k]);
                if (sc < bestScore) { bestScore = sc; best = new Point(c.x, c.y); targetCat = category(c.type); }
            }
            if (best != null) return best;

            best = explore(list, byKey, dist, here, a.cols, a.rows);
            if (best != null) { lastReason = "fechando o plano: explorando a névoa deste andar"; return best; }

            // andar limpo: portal de andar ainda não usado (o portal em que estou conta como usado)
            var gk:int = goldKeys(a);
            var bestD:Number = Number.MAX_VALUE;
            var unused:int = 0;
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                if (!isFloorPortal(c.type) || !c.opened) continue;
                var pk:String = lay + ":" + c.x + "," + c.y;
                if (int(c.x) == int(here.x) && int(c.y) == int(here.y)) usedPortal[pk] = true;
                if (usedPortal[pk]) continue;
                if ((c.type == 71 || c.type == 72) && gk == 0) continue;
                k = c.x * 100 + c.y;
                if (dist[k] === undefined) continue;
                unused++;
                if (int(dist[k]) < bestD) { bestD = int(dist[k]); best = new Point(c.x, c.y); targetCat = "hop"; }
            }
            if (best != null)
            {
                var bm:Point = detour(a, list, byKey, here, best);
                if (bm != null) { targetCat = "mon"; return bm; }
                usedPortal[lay + ":" + best.x + "," + best.y] = true;
                floorPending[lay] = unused > 1;
                say("andar limpo: indo pelo portal em (" + best.x + "," + best.y + ") ainda não usado");
                lastReason = "fechando o plano: indo para outro andar";
                return best;
            }
            floorPending[lay] = false;

            // sem portal novo aqui: volta (portal de saída já usado) para um andar que ainda tem portal novo
            var other:Boolean = false;
            for (var f:String in floorPending) { if (floorPending[f] && int(f) != lay) other = true; }
            if (other && backHops < 12)
            {
                bestD = Number.MAX_VALUE;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if (!isReturnPortal(c.type) || !c.opened) continue;
                    if (int(c.x) == int(here.x) && int(c.y) == int(here.y)) continue;
                    k = c.x * 100 + c.y;
                    if (dist[k] === undefined) continue;
                    if (int(dist[k]) < bestD) { bestD = int(dist[k]); best = new Point(c.x, c.y); targetCat = "hop"; }
                }
                if (best != null)
                {
                    var bm2:Point = detour(a, list, byKey, here, best);
                    if (bm2 != null) { targetCat = "mon"; return bm2; }
                }
                if (best != null) { backHops++; say("voltando por (" + best.x + "," + best.y + ") para um andar que ainda tem portal novo"); lastReason = "fechando o plano: voltando de andar"; return best; }
            }
            closeFinished = true;
            lastReason = "plano fechado: este andar acabou, sem portal novo e sem andar pendente" + (skipCost > 0 ? " (" + skipCost + " eventos ficaram sem nível/energia)" : "");
            return null;
        }

        // 1) melhor evento ABERTO e alcançável (categoria mais prioritária; empate = mais perto)
        // 2) sem evento: explora, indo à casa aberta mais perto que encosta em névoa (isso abre o mapa)
        private function choose(a:IPlanesAdapter, here:Point):Point
        {
            var list:Array = a.cells();
            var byKey:Object = {};
            var i:int;
            var c:Object;
            for (i = 0; i < list.length; i++) { c = list[i]; byKey[c.x * 100 + c.y] = c; }
            var dist:Object = distances(byKey, here);

            var best:Point = null;
            var bestScore:Number = Number.MAX_VALUE;
            var cat:String;
            if (int(opts.portal) == 4) return chooseClose(a, here, list, byKey, dist);
            if (opts.portal)
            {
                // 1) portal aberto e alcançável
                var pbest:Number = Number.MAX_VALUE;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if (c.type != 8 || !c.opened || dist[c.x * 100 + c.y] === undefined) continue;
                    if (int(dist[c.x * 100 + c.y]) < pbest) { pbest = int(dist[c.x * 100 + c.y]); best = new Point(c.x, c.y); targetCat = "portal"; }
                }
                if (best != null) return best;
                best = explore(list, byKey, dist, here, a.cols, a.rows);
                if (best != null) { lastReason = "procurando o portal: explorando a névoa"; return best; }
                // 2) sem borda para explorar: pisa num teleporte (91/92) ainda não usado
                var hbest:Number = Number.MAX_VALUE;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if ((c.type != 91 && c.type != 92) || !c.opened || done[c.x * 100 + c.y] || dist[c.x * 100 + c.y] === undefined) continue;
                    if (int(dist[c.x * 100 + c.y]) < hbest) { hbest = int(dist[c.x * 100 + c.y]); best = new Point(c.x, c.y); targetCat = "hop"; }
                }
                if (best == null) lastReason = "portal (tipo 8) não encontrado: mapa explorado e sem teleporte (91/92) para usar";
                return best;
            }
            var score:Number;
            var k:int;
            var skipOpen:int = 0, skipDist:int = 0, skipCost:int = 0, skipCat:int = 0;
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                if (c.id == 0 || c.occupied || c.base || done[c.x * 100 + c.y]) continue;
                if (!c.opened) { skipOpen++; continue; }
                cat = category(c.type);
                if (cat == "" || cat == "exit" || cat == "market" || cat == "wall") { skipCat++; continue; }
                if (opts[cat] != true) continue;
                if (a.level < c.need || a.energy < c.cost) { skipCost++; continue; }
                k = c.x * 100 + c.y;
                if (dist[k] === undefined) { skipDist++; continue; }
                score = prio(cat) * 1000 + int(dist[k]);
                if (score < bestScore)
                {
                    bestScore = score;
                    best = new Point(c.x, c.y);
                    targetCat = cat;
                }
            }
            if (best != null) return best;

            lastReason = "sem evento alcançável (na névoa " + skipOpen + ", tipo ignorado/desligado " + skipCat + ", sem nível/energia " + skipCost + ", sem caminho " + skipDist + ")";
            if (opts.explore == false) return null;

            best = explore(list, byKey, dist, here, a.cols, a.rows);
            if (best != null) lastReason = "explorando a névoa";
            else lastReason += "; nenhuma borda de névoa para explorar";
            return best;
        }
    }
}
