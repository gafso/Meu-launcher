package
{
    import flash.events.TimerEvent;
    import flash.geom.Point;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Macro do evento Planos (mapa em grade). Funciona sobre um IPlanesAdapter (jogo real ou simulação).
    // A cada ~0,7 s: se há carta pendente escolhe uma (op 35); senão escolhe a casa de evento mais valiosa/perto,
    // manda o jogo andar até ela (o próprio jogo faz o caminho e dispara o evento ao chegar) e espera.
    public class PlanesBot
    {
        public static const MAX_TRIES:int = 3;

        public var adapter:IPlanesAdapter;
        public var label:String;
        public var logger:Function;
        // categorias ligadas: box = baús (10,11,15) | res = recursos (5) | mon = monstros (1,2,13,14) | boss = chefe (12)
        public var opts:Object = {box: true, res: true, mon: true, boss: false};
        public var running:Boolean = false;
        public var status:String = "parado";
        public var target:Point = null;
        public var done:Object = {};
        public var counts:Object = {box: 0, res: 0, mon: 0, boss: 0};
        public var minEnergy:int = 0;
        private var timer:Timer;
        private var tries:int = 0;
        private var waitUntil:int = 0;
        private var lastCard:int = 0;
        private var targetCat:String = "";
        private var summarized:Boolean = false;
        private var cardSig:int = -1;
        private var cardPicks:int = 0;
        private var ignoreSig:int = -1;
        private var lastReason:String = "";

        public function PlanesBot(adapter:IPlanesAdapter, label:String)
        {
            this.adapter = adapter;
            this.label = label;
        }

        // Categoria de um EventType (ver PlanesConstClass do jogo).
        public static function category(t:int):String
        {
            if (t == 10 || t == 11 || t == 15) return "box";
            if (t == 5) return "res";
            if (t == 1 || t == 2 || t == 13 || t == 14) return "mon";
            if (t == 12) return "boss";
            if (t == 61 || t == 62 || t == 71 || t == 72 || t == 8 || t == 91 || t == 92) return "exit";
            if (t == 3) return "market";
            if (t == -1) return "wall";
            return "";
        }

        private static function prio(cat:String):int
        {
            if (cat == "box") return 1;
            if (cat == "res") return 2;
            if (cat == "mon") return 3;
            return 9;
        }

        private function say(s:String):void
        {
            if (logger != null) logger("[" + label + "] " + s);
        }

        public function start():void
        {
            if (running) return;
            done = {};
            counts = {box: 0, res: 0, mon: 0, boss: 0};
            target = null;
            tries = 0;
            waitUntil = 0;
            summarized = false;
            cardSig = -1; cardPicks = 0; ignoreSig = -1;
            running = true;
            status = "iniciando";
            timer = new Timer(700);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            say("iniciado (baús " + opts.box + ", recursos " + opts.res + ", monstros " + opts.mon + ", chefe " + opts.boss + ")");
        }

        public function stop(reason:String = "parado"):void
        {
            if (timer != null)
            {
                timer.stop();
                timer.removeEventListener(TimerEvent.TIMER, onTick);
                timer = null;
            }
            if (running) say("parou: " + reason + " | feitos: baús " + counts.box + ", recursos " + counts.res + ", monstros " + counts.mon + ", chefe " + counts.boss);
            running = false;
            target = null;
            status = reason;
        }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("ERRO: " + err.message); stop("erro: " + err.message); }
        }

        private function key(p:Point):int { return int(p.x) * 100 + int(p.y); }

        private function step():void
        {
            var a:IPlanesAdapter = adapter;
            if (!a.ready) { status = "aguardando o mapa de Planos no jogo"; return; }
            if (a.dead) { status = "personagem morto: reviva manualmente"; return; }
            if (a.moving || getTimer() < waitUntil) return;
            a.suppressFrames();

            var card:Array = a.pendingCard();
            if (card != null)
            {
                var sig:int = int(card[0]);
                if (sig == ignoreSig) card = null;
                else
                {
                    if (sig != cardSig) { cardSig = sig; cardPicks = 0; }
                    if (cardPicks >= 4)
                    {
                        // o jogo não está aceitando a resposta: não trava o macro, segue em frente
                        say("carta (" + sig + ") não some depois de 4 respostas: ignorando e seguindo");
                        ignoreSig = sig;
                        card = null;
                    }
                    else
                    {
                        if (getTimer() - lastCard > 2500)
                        {
                            lastCard = getTimer();
                            cardPicks++;
                            var pick:int = int(Math.random() * 4);
                            a.pickCard(sig, pick);
                            say("carta " + (pick + 1) + " escolhida");
                        }
                        return;
                    }
                }
            }
            else { ignoreSig = -1; cardSig = -1; cardPicks = 0; }

            if (!summarized) { summarized = true; summary(a); }

            status = "energia " + a.energy + " | baús " + counts.box + " recursos " + counts.res + " monstros " + counts.mon + " chefe " + counts.boss;
            if (a.energy <= minEnergy) { stop("sem energia"); return; }

            var here:Point = new Point(a.posX, a.posY);
            if (target != null && int(target.x) == int(here.x) && int(target.y) == int(here.y))
            {
                done[key(target)] = true;
                if (targetCat != "") counts[targetCat] = int(counts[targetCat]) + 1;
                say("chegou em (" + target.x + "," + target.y + ")");
                target = null;
                tries = 0;
                waitUntil = getTimer() + 1200;
                return;
            }

            if (target == null)
            {
                target = choose(a, here);
                tries = 0;
                if (target == null) { say(lastReason); stop("sem alvos acessíveis"); return; }
                say("alvo (" + target.x + "," + target.y + ") " + targetCat);
            }

            tries++;
            if (tries > MAX_TRIES)
            {
                say("desisti de (" + target.x + "," + target.y + ")");
                done[key(target)] = true;
                target = null;
                return;
            }
            a.moveTo(int(target.x), int(target.y));
        }

        private function summary(a:IPlanesAdapter):void
        {
            var list:Array = a.cells();
            var opened:int = 0;
            var types:Object = {};
            var c:Object;
            for (var i:int = 0; i < list.length; i++)
            {
                c = list[i];
                if (!c.opened) continue;
                opened++;
                if (c.id != 0) types[c.type] = int(types[c.type]) + 1;
            }
            var tl:Array = [];
            for (var k:String in types) tl.push("tipo " + k + " x" + types[k]);
            say("mapa " + a.cols + "x" + a.rows + ": " + opened + " casas abertas de " + list.length + " | eventos nas abertas: " + (tl.length > 0 ? tl.join(", ") : "nenhum") + " | você em (" + a.posX + "," + a.posY + ")");
        }

        // Distâncias (passos de 4 direções) só por casas ABERTAS e sem parede. Chave = x*100+y.
        private function distances(byKey:Object, here:Point):Object
        {
            var dist:Object = {};
            var queue:Array = [key(here)];
            dist[key(here)] = 0;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            while (queue.length > 0)
            {
                var cur:int = queue.shift();
                var cx:int = int(cur / 100);
                var cy:int = cur % 100;
                for (var d:int = 0; d < 4; d++)
                {
                    var nx:int = cx + dirs[d][0];
                    var ny:int = cy + dirs[d][1];
                    var k:int = nx * 100 + ny;
                    var n:Object = byKey[k];
                    if (n == null || !n.opened || n.type == -1 || dist[k] !== undefined) continue;
                    dist[k] = int(dist[cur]) + 1;
                    queue.push(k);
                }
            }
            return dist;
        }

        // 1) melhor evento ABERTO e alcançável (categoria mais prioritária; empate = mais perto)
        // 2) sem evento: explora, indo à casa aberta mais perto que encosta em névoa (isso abre o mapa)
        private function choose(a:IPlanesAdapter, here:Point):Point
        {
            var list:Array = a.cells();
            var byKey:Object = {};
            var i:int;
            var c:Object;
            for (i = 0; i < list.length; i++) { c = list[i]; byKey[c.x * 100 + c.y] = c; }
            var dist:Object = distances(byKey, here);

            var best:Point = null;
            var bestScore:Number = Number.MAX_VALUE;
            var cat:String;
            var score:Number;
            var k:int;
            var skipOpen:int = 0, skipDist:int = 0, skipCost:int = 0, skipCat:int = 0;
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                if (c.id == 0 || c.occupied || c.base || done[c.x * 100 + c.y]) continue;
                if (!c.opened) { skipOpen++; continue; }
                cat = category(c.type);
                if (cat == "" || cat == "exit" || cat == "market" || cat == "wall") { skipCat++; continue; }
                if (opts[cat] != true) continue;
                if (a.level < c.need || a.energy < c.cost) { skipCost++; continue; }
                k = c.x * 100 + c.y;
                if (dist[k] === undefined) { skipDist++; continue; }
                score = prio(cat) * 1000 + int(dist[k]);
                if (score < bestScore)
                {
                    bestScore = score;
                    best = new Point(c.x, c.y);
                    targetCat = cat;
                }
            }
            if (best != null) return best;

            lastReason = "sem evento alcançável (na névoa " + skipOpen + ", tipo ignorado/desligado " + skipCat + ", sem nível/energia " + skipCost + ", sem caminho " + skipDist + ")";
            if (opts.explore == false) return null;

            var bestFog:Number = Number.MAX_VALUE;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                k = c.x * 100 + c.y;
                if (dist[k] === undefined || done[k] || (c.x == int(here.x) && c.y == int(here.y))) continue;
                if (c.id != 0 && category(c.type) != "") continue;   // casa com evento: não pisa só para explorar
                var fog:int = 0;
                for (var d:int = 0; d < 8; d++)
                {
                    var n:Object = byKey[(c.x + dirs[d][0]) * 100 + (c.y + dirs[d][1])];
                    if (n != null && !n.opened) fog++;
                }
                if (fog == 0) continue;
                score = int(dist[k]) - fog * 0.1;
                if (score < bestFog) { bestFog = score; best = new Point(c.x, c.y); targetCat = ""; }
            }
            if (best != null) lastReason = "explorando a névoa";
            else lastReason += "; nenhuma borda de névoa para explorar";
            return best;
        }
    }
}
