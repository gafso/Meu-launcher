package
{
    import flash.events.TimerEvent;
    import flash.geom.Point;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Macro do evento Planos (mapa em grade). Funciona sobre um IPlanesAdapter (jogo real ou simulação).
    // A cada ~0,7 s: se há carta pendente escolhe uma (op 35); senão escolhe a casa de evento mais valiosa/perto,
    // manda o jogo andar até ela (o próprio jogo faz o caminho e dispara o evento ao chegar) e espera.
    public class PlanesBot
    {
        public static const MAX_TRIES:int = 3;

        public var adapter:IPlanesAdapter;
        public var label:String;
        public var logger:Function;
        // categorias ligadas: box = baús (10,11,15) | res = recursos (5) | mon = monstros (1,2,13,14) | boss = chefe (12)
        // portal = true: ignora baús/monstros/etc. e só procura o portal (tipo 8), explorando a névoa e usando teleportes (91/92) se precisar
        public var opts:Object = {box: true, res: true, mon: true, boss: false, portal: 0};
        public var running:Boolean = false;
        public var status:String = "parado";
        public var target:Point = null;
        public var done:Object = {};
        public var counts:Object = {box: 0, res: 0, mon: 0, boss: 0};
        public var minEnergy:int = 0;
        private var timer:Timer;
        private var tries:int = 0;
        private var waitUntil:int = 0;
        private var lastCard:int = 0;
        private var targetCat:String = "";
        private var summarized:Boolean = false;
        private var cardSig:int = -1;
        private var cardPicks:int = 0;
        private var ignoreSig:int = -1;
        private var lastReason:String = "";
        private var startX:int = 0;
        private var startY:int = 0;
        private var lastLayer:int = -999;

        public function PlanesBot(adapter:IPlanesAdapter, label:String)
        {
            this.adapter = adapter;
            this.label = label;
        }

        // Categoria de um EventType (ver PlanesConstClass do jogo).
        public static function category(t:int):String
        {
            if (t == 10 || t == 11 || t == 15) return "box";
            if (t == 5) return "res";
            if (t == 1 || t == 2 || t == 13 || t == 14) return "mon";
            if (t == 12) return "boss";
            if (t == 8) return "portal";      // entrada escondida (o portal do olho)
            if (t == 61 || t == 62 || t == 71 || t == 72 || t == 91 || t == 92) return "exit";
            if (t == 3) return "market";
            if (t == -1) return "wall";
            return "";
        }

        private static function prio(cat:String):int
        {
            if (cat == "box") return 1;
            if (cat == "res") return 2;
            if (cat == "mon") return 3;
            return 9;
        }

        private function say(s:String):void
        {
            if (logger != null) logger("[" + label + "] " + s);
        }

        public function start():void
        {
            if (running) return;
            done = {};
            counts = {box: 0, res: 0, mon: 0, boss: 0};
            target = null;
            tries = 0;
            waitUntil = 0;
            summarized = false;
            originLayer = -999; pend = null;
            mineMode = false; mineTarget = null; mineTries = 0;
            cardSig = -1; cardPicks = 0; ignoreSig = -1;
            running = true;
            status = "iniciando";
            timer = new Timer(700);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            say("iniciado (baús " + opts.box + ", recursos " + opts.res + ", monstros " + opts.mon + ", chefe " + opts.boss + ")");
        }

        public function stop(reason:String = "parado"):void
        {
            if (timer != null)
            {
                timer.stop();
                timer.removeEventListener(TimerEvent.TIMER, onTick);
                timer = null;
            }
            if (running) say("parou: " + reason + " | feitos: baús " + counts.box + ", recursos " + counts.res + ", monstros " + counts.mon + ", chefe " + counts.boss);
            running = false;
            target = null;
            status = reason;
        }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("ERRO: " + err.message); stop("erro: " + err.message); }
        }

        private function key(p:Point):int { return int(p.x) * 100 + int(p.y); }

        private function step():void
        {
            var a:IPlanesAdapter = adapter;
            if (!a.ready) { status = "aguardando o mapa de Planos no jogo"; return; }
            if (a.dead) { status = "personagem morto: reviva manualmente"; return; }
            if (a.moving || getTimer() < waitUntil) return;
            if (a.layerId != lastLayer)
            {
                if (lastLayer != -999) { say("mudou de piso: recomeçando o mapa"); done = {}; target = null; summarized = false; }
                lastLayer = a.layerId;
            }
            if (!opts.portal || mineMode) a.suppressFrames();   // no modo portal o jogo abre a janela dele para você confirmar

            var card:Array = a.pendingCard();
            if (card != null)
            {
                var sig:int = int(card[0]);
                if (sig == ignoreSig) card = null;
                else
                {
                    if (sig != cardSig) { cardSig = sig; cardPicks = 0; }
                    if (cardPicks >= 4)
                    {
                        // o jogo não está aceitando a resposta: não trava o macro, segue em frente
                        say("carta (" + sig + ") não some depois de 4 respostas: ignorando e seguindo");
                        ignoreSig = sig;
                        card = null;
                    }
                    else
                    {
                        if (getTimer() - lastCard > 2500)
                        {
                            lastCard = getTimer();
                            cardPicks++;
                            var pick:int = int(Math.random() * 4);
                            a.pickCard(sig, pick);
                            say("carta " + (pick + 1) + " escolhida");
                        }
                        return;
                    }
                }
            }
            else { ignoreSig = -1; cardSig = -1; cardPicks = 0; }

            if (!summarized) { summarized = true; summary(a); }

            status = "energia " + a.energy + " | baús " + counts.box + " recursos " + counts.res + " monstros " + counts.mon + " chefe " + counts.boss;
            if (a.energy <= minEnergy) { stop("sem energia"); return; }

            var here:Point = new Point(a.posX, a.posY);
            if (mineMode) { mineStep(a, here); return; }
            if (opts.portal && portalStep(a, here)) return;
            var hopped:Boolean = target != null && targetCat == "hop" && (int(here.x) != startX || int(here.y) != startY);
            if (target != null && ((int(target.x) == int(here.x) && int(target.y) == int(here.y)) || hopped))
            {
                if (targetCat == "portal")
                {
                    say("PORTAL encontrado em (" + target.x + "," + target.y + ")");
                    stop("portal encontrado em (" + target.x + "," + target.y + ")");
                    return;
                }
                done[key(target)] = true;
                if (targetCat != "") counts[targetCat] = int(counts[targetCat]) + 1;
                say("chegou em (" + target.x + "," + target.y + ")");
                target = null;
                tries = 0;
                waitUntil = getTimer() + 1200;
                return;
            }

            if (target == null)
            {
                target = choose(a, here);
                tries = 0;
                if (target == null) { say(lastReason); stop("sem alvos acessíveis"); return; }
                startX = int(here.x); startY = int(here.y);
                say("alvo (" + target.x + "," + target.y + ") " + (targetCat == "" ? "explorar" : targetCat));
            }

            tries++;
            if (tries > MAX_TRIES)
            {
                say("desisti de (" + target.x + "," + target.y + ")");
                done[key(target)] = true;
                target = null;
                return;
            }
            a.moveTo(int(target.x), int(target.y));
        }

        // ---------- modo PORTAL: planeja o caminho mais curto até o olho (tipo 8) ----------
        // O servidor manda o mapa inteiro (inclusive a névoa), então dá para saber ANTES de andar se o piso tem o olho.
        // Sem olho no piso: para sem gastar energia. Com olho: menor caminho (paredes bloqueiam; casas com evento custam mais
        // para serem evitadas; teleportes/entradas nunca são pisados por acidente). Se o olho não é alcançável (ilha), usa um
        // teleporte, e no piso de passagem procura o teleporte "par" mais perto para voltar.
        // opts.portal: 1 = para AO LADO do olho (você entra) | 2 = pisa no olho (o servidor entra na hora)
        private var pend:Object = null;
        // modo MINA: depois de entrar no portal do olho, pega a mina (tipo 5) do piso interno e para
        private var mineMode:Boolean = false;
        private var mineTarget:Point = null;
        private var mineTries:int = 0;
        private var originLayer:int = -999;
        private var tried:Object = {};
        private var hops:int = 0;
        private var lastHopType:int = 0;
        private var announced:String = "";

        private static function isTransfer(t:int):Boolean { return t == 61 || t == 62 || t == 71 || t == 72 || t == 91 || t == 92; }

        private static function partner(t:int):int
        {
            if (t == 61) return 62;
            if (t == 62) return 61;
            if (t == 71) return 72;
            if (t == 72) return 71;
            if (t == 91) return 92;
            if (t == 92) return 91;
            return 0;
        }

        private static function rank(t:int):int { return (t == 91 || t == 92) ? 0 : ((t == 61 || t == 62) ? 1 : 2); }

        private function dijk(byKey:Object, here:Point):Object
        {
            var dist:Object = {};
            var prev:Object = {};
            var seen:Object = {};
            var st0:int = key(here);
            dist[st0] = 0;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            while (true)
            {
                var cur:int = -1;
                var best:Number = Number.MAX_VALUE;
                for (var k:String in dist)
                {
                    if (seen[k]) continue;
                    if (Number(dist[k]) < best) { best = Number(dist[k]); cur = int(k); }
                }
                if (cur < 0) break;
                seen[cur] = true;
                var cc:Object = byKey[cur];
                if (cur != st0 && cc != null && (isTransfer(cc.type) || cc.type == 8)) continue;   // entradas/saídas só como destino
                for (var d:int = 0; d < 4; d++)
                {
                    var nk:int = (int(cur / 100) + dirs[d][0]) * 100 + (cur % 100 + dirs[d][1]);
                    var n:Object = byKey[nk];
                    if (n == null || n.type == -1 || seen[nk]) continue;
                    var stepW:int = 1;
                    if (n.id != 0 && category(n.type) != "" && !isTransfer(n.type) && n.type != 8) stepW = 41;   // evento: evita se der
                    var nd:Number = Number(dist[cur]) + stepW;
                    if (dist[nk] === undefined || nd < Number(dist[nk])) { dist[nk] = nd; prev[nk] = cur; }
                }
            }
            return {dist: dist, prev: prev, start: st0};
        }

        private function pathTo(r:Object, goal:int):Array
        {
            var out:Array = [];
            var k:int = goal;
            while (k != int(r.start)) { out.unshift(k); if (r.prev[k] === undefined) return null; k = int(r.prev[k]); }
            return out;
        }

        // ---------- modo MINA: já dentro do olho, vai até a mina (tipo 5) e encerra ----------
        // Prefere a mina de maior nível exigido/custo (a elite); se só houver uma, pega essa.
        private function mineStep(a:IPlanesAdapter, here:Point):void
        {
            var hx:int = int(here.x);
            var hy:int = int(here.y);
            if (mineTarget != null && int(mineTarget.x) == hx && int(mineTarget.y) == hy)
            {
                counts.res = int(counts.res) + 1;
                say("mina coletada em (" + hx + "," + hy + ")");
                try { a.leavePlanes(); say("saindo do plano (op 19)"); }
                catch (err:Error) { say("não consegui sair do plano: " + err.message); }
                stop("mina coletada");
                return;
            }
            if (mineTarget == null)
            {
                var list:Array = a.cells();
                var best:Object = null;
                var bestPath:int = 0;
                var found:int = 0;
                var i:int;
                var c:Object;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if (c.type != 5 || c.id == 0 || c.base) continue;
                    found++;
                    say("mina (tipo 5) em (" + c.x + "," + c.y + "): id " + c.id + ", nível " + c.need + ", custo " + c.cost + ", aberta " + c.opened + ", ocupada " + c.occupied);
                    if (!c.opened) continue;
                    if (a.level < c.need || a.energy < c.cost) { say("sem nível/energia para a mina em (" + c.x + "," + c.y + ")"); continue; }
                    var pth:Array = a.path(hx, hy, int(c.x), int(c.y));
                    if (pth == null) continue;
                    var better:Boolean = best == null
                        || int(c.need) > int(best.need)
                        || (int(c.need) == int(best.need) && int(c.cost) > int(best.cost))
                        || (int(c.need) == int(best.need) && int(c.cost) == int(best.cost) && pth.length < bestPath);
                    if (better) { best = c; bestPath = pth.length; }
                }
                if (best == null)
                {
                    say(found == 0 ? "não há mina (tipo 5) neste piso" : "mina encontrada mas inalcançável (névoa, nível/energia ou sem caminho)");
                    stop("sem mina no olho");
                    return;
                }
                mineTarget = new Point(int(best.x), int(best.y));
                mineTries = 0;
                say("indo para a mina em (" + best.x + "," + best.y + "): " + (bestPath - 1) + " passos");
            }
            mineTries++;
            if (mineTries > MAX_TRIES + 2)
            {
                say("não consegui chegar na mina em (" + mineTarget.x + "," + mineTarget.y + ")");
                stop("travado indo à mina");
                return;
            }
            a.moveTo(int(mineTarget.x), int(mineTarget.y));
        }

        private function portalStep(a:IPlanesAdapter, here:Point):Boolean
        {
            var layer:int = a.layerId;
            var hx:int = int(here.x);
            var hy:int = int(here.y);
            var mode:int = (opts.portal === true) ? 1 : int(opts.portal);
            var wantMine:Boolean = (mode == 3);
            if (wantMine) mode = 2;
            if (originLayer == -999) { originLayer = layer; hops = 0; tried = {}; pend = null; lastHopType = 0; announced = ""; }

            // 1) o que eu estava fazendo?
            if (pend != null)
            {
                var atTarget:Boolean = layer == int(pend.layer) && hx == int(pend.x) && hy == int(pend.y);
                if (pend.kind == "hop")
                {
                    var tele:Boolean = layer != int(pend.layer) || (!atTarget && (hx != int(pend.sx) || hy != int(pend.sy)));
                    if (tele)
                    {
                        hops++;
                        lastHopType = int(pend.type);
                        say("teleporte usado: agora no piso " + layer + " em (" + hx + "," + hy + ")");
                        pend = null;
                        waitUntil = getTimer() + 1500;
                        return true;
                    }
                }
                else if (atTarget || (pend.kind == "end" && layer != int(pend.layer)))
                {
                    if (pend.kind == "end")
                    {
                        say(mode == 2 ? "entrou no portal do olho" : "PARADO AO LADO do olho, em (" + hx + "," + hy + ")");
                        if (wantMine)
                        {
                            pend = null;
                            mineMode = true; mineTarget = null; mineTries = 0;
                            waitUntil = getTimer() + 1500;
                            return true;
                        }
                        stop(mode == 2 ? "no portal do olho" : "ao lado do olho");
                        return true;
                    }
                    pend = null;
                    waitUntil = getTimer() + 300;
                    return true;
                }
                pend.tries = int(pend.tries) + 1;
                if (int(pend.tries) > MAX_TRIES + 1)
                {
                    say("não consegui ir até (" + pend.x + "," + pend.y + ")");
                    stop("travado indo para (" + pend.x + "," + pend.y + ")");
                    return true;
                }
                a.moveTo(int(pend.x), int(pend.y));
                return true;
            }

            // 2) o mapa inteiro
            var list:Array = a.cells();
            var byKey:Object = {};
            var i:int;
            var c:Object;
            var eye:Object = null;
            var fogN:int = 0, fogEv:int = 0, openEv:int = 0;
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                byKey[c.x * 100 + c.y] = c;
                if (c.type == 8) eye = c;
                if (!c.opened) { fogN++; if (c.id != 0) fogEv++; }
                else if (c.id != 0) openEv++;
            }
            var ann:String = layer + ":" + (eye != null ? "olho" : "sem") + ":" + hops;
            if (eye == null)
            {
                if (layer == originLayer)
                {
                    say("este piso NÃO tem o portal do olho: parei sem gastar energia");
                    stop("sem olho neste piso (energia intacta)");
                    return true;
                }
                if (announced != ann) { announced = ann; say("piso " + layer + " sem olho: procurando o teleporte para voltar"); }
                return hopStep(a, here, byKey, list, layer);
            }

            // 3) menor caminho até o olho
            var r:Object = dijk(byKey, here);
            var goals:Array = [];
            var ek:int = eye.x * 100 + eye.y;
            if (mode == 2) goals.push(ek);
            else
            {
                var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
                for (var d:int = 0; d < 4; d++)
                {
                    var nk:int = (int(eye.x) + dirs[d][0]) * 100 + (int(eye.y) + dirs[d][1]);
                    var nc:Object = byKey[nk];
                    if (nc != null && nc.type != -1 && !isTransfer(nc.type) && nc.type != 8 && nc.id == 0) goals.push(nk);
                }
                if (goals.length == 0)
                    for (d = 0; d < 4; d++)
                    {
                        nk = (int(eye.x) + dirs[d][0]) * 100 + (int(eye.y) + dirs[d][1]);
                        nc = byKey[nk];
                        if (nc != null && nc.type != -1 && !isTransfer(nc.type) && nc.type != 8) goals.push(nk);
                    }
            }
            var goal:int = -1;
            var gd:Number = Number.MAX_VALUE;
            for (i = 0; i < goals.length; i++)
                if (r.dist[goals[i]] !== undefined && Number(r.dist[goals[i]]) < gd) { gd = Number(r.dist[goals[i]]); goal = goals[i]; }

            if (goal == key(here) && mode != 2)
            {
                say("PARADO AO LADO do olho (" + eye.x + "," + eye.y + ")");
                stop("ao lado do olho");
                return true;
            }
            if (goal >= 0)
            {
                var p:Array = pathTo(r, goal);
                var evCost:int = 0;
                if (mode == 2) { var et:Object = byKey[ek]; evCost = (et != null) ? int(et.cost) : 0; }
                var need:int = p.length * a.stepCost + evCost;
                if (announced != ann + "p")
                {
                    announced = ann + "p";
                    say("OLHO em (" + eye.x + "," + eye.y + ") no piso " + layer + ": caminho mais curto = " + p.length + " passos, energia ~" + need + " (você tem " + a.energy + ")");
                }
                if (a.energy < need) { stop("energia insuficiente: precisa ~" + need + ", tem " + a.energy); return true; }
                // waypoint: a casa mais longe no caminho que não tenha evento (só o ponto final dispara evento), sem passar de 1 casa na névoa
                var lim:int = 0;
                while (lim < p.length - 1 && byKey[p[lim]].opened) lim++;
                var j:int = Math.min(lim, p.length - 1);
                if (j < p.length - 1) { while (j > 0 && byKey[p[j]].id != 0) j--; }
                var wk:int = p[j];
                var last:Boolean = (j == p.length - 1);
                pend = {kind: last ? "end" : "wp", x: int(wk / 100), y: wk % 100, layer: layer, tries: 1};
                a.moveTo(int(pend.x), int(pend.y));
                return true;
            }

            // 4) sem caminho: ilha. usa um teleporte
            if (announced != ann + "h") { announced = ann + "h"; say("olho em (" + eye.x + "," + eye.y + ") mas sem caminho a pé daqui: preciso de um teleporte"); }
            return hopStep(a, here, byKey, list, layer);
        }

        // Escolhe o teleporte mais adequado: no piso de passagem, o "par" do que usei (61<->62, 71<->72, 91<->92); senão o mais perto.
        private function hopStep(a:IPlanesAdapter, here:Point, byKey:Object, list:Array, layer:int):Boolean
        {
            if (hops >= 8) { stop("muitos teleportes sem achar caminho até o olho"); return true; }
            var r:Object = dijk(byKey, here);
            var best:Object = null;
            var bs:Number = Number.MAX_VALUE;
            for (var i:int = 0; i < list.length; i++)
            {
                var c:Object = list[i];
                if (!isTransfer(c.type) || tried[layer + "_" + c.x + "_" + c.y]) continue;
                var k:int = c.x * 100 + c.y;
                if (r.dist[k] === undefined) continue;
                var s:Number = Number(r.dist[k]) + rank(c.type) * 100;
                if (layer != originLayer && lastHopType != 0 && c.type == partner(lastHopType)) s -= 1000;
                if (s < bs) { bs = s; best = c; }
            }
            if (best == null) { stop("sem caminho até o olho e sem teleporte novo para usar"); return true; }
            tried[layer + "_" + best.x + "_" + best.y] = true;
            pend = {kind: "hop", x: int(best.x), y: int(best.y), layer: layer, sx: int(here.x), sy: int(here.y), type: int(best.type), tries: 1};
            say("usando teleporte tipo " + best.type + " em (" + best.x + "," + best.y + ") no piso " + layer);
            a.moveTo(int(best.x), int(best.y));
            return true;
        }

        private function summary(a:IPlanesAdapter):void
        {
            var list:Array = a.cells();
            var opened:int = 0;
            var types:Object = {};
            var c:Object;
            for (var i:int = 0; i < list.length; i++)
            {
                c = list[i];
                if (!c.opened) continue;
                opened++;
                if (c.id != 0) types[c.type] = int(types[c.type]) + 1;
            }
            var tl:Array = [];
            for (var k:String in types) tl.push("tipo " + k + " x" + types[k]);
            say("mapa " + a.cols + "x" + a.rows + ": " + opened + " casas abertas de " + list.length + " | eventos nas abertas: " + (tl.length > 0 ? tl.join(", ") : "nenhum") + " | você em (" + a.posX + "," + a.posY + ")");
        }

        // Distâncias (passos de 4 direções) só por casas ABERTAS e sem parede. Chave = x*100+y.
        private function distances(byKey:Object, here:Point):Object
        {
            var dist:Object = {};
            var queue:Array = [key(here)];
            dist[key(here)] = 0;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1]];
            while (queue.length > 0)
            {
                var cur:int = queue.shift();
                var cx:int = int(cur / 100);
                var cy:int = cur % 100;
                for (var d:int = 0; d < 4; d++)
                {
                    var nx:int = cx + dirs[d][0];
                    var ny:int = cy + dirs[d][1];
                    var k:int = nx * 100 + ny;
                    var n:Object = byKey[k];
                    if (n == null || !n.opened || n.type == -1 || dist[k] !== undefined) continue;
                    dist[k] = int(dist[cur]) + 1;
                    queue.push(k);
                }
            }
            return dist;
        }

        // Melhor casa aberta (sem evento) que encosta em névoa; null se não houver.
        private function explore(list:Array, byKey:Object, dist:Object, here:Point):Point
        {
            var best:Point = null;
            var c:Object;
            var k:int;
            var i:int;
            var score:Number;
            var bestFog:Number = Number.MAX_VALUE;
            var dirs:Array = [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]];
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                k = c.x * 100 + c.y;
                if (dist[k] === undefined || done[k] || (c.x == int(here.x) && c.y == int(here.y))) continue;
                if (c.id != 0 && category(c.type) != "") continue;   // casa com evento: não pisa só para explorar
                var fog:int = 0;
                for (var d:int = 0; d < 8; d++)
                {
                    var n:Object = byKey[(c.x + dirs[d][0]) * 100 + (c.y + dirs[d][1])];
                    if (n != null && !n.opened) fog++;
                }
                if (fog == 0) continue;
                score = int(dist[k]) - fog * 0.1;
                if (score < bestFog) { bestFog = score; best = new Point(c.x, c.y); targetCat = ""; }
            }
            return best;
        }

        // 1) melhor evento ABERTO e alcançável (categoria mais prioritária; empate = mais perto)
        // 2) sem evento: explora, indo à casa aberta mais perto que encosta em névoa (isso abre o mapa)
        private function choose(a:IPlanesAdapter, here:Point):Point
        {
            var list:Array = a.cells();
            var byKey:Object = {};
            var i:int;
            var c:Object;
            for (i = 0; i < list.length; i++) { c = list[i]; byKey[c.x * 100 + c.y] = c; }
            var dist:Object = distances(byKey, here);

            var best:Point = null;
            var bestScore:Number = Number.MAX_VALUE;
            var cat:String;
            if (opts.portal)
            {
                // 1) portal aberto e alcançável
                var pbest:Number = Number.MAX_VALUE;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if (c.type != 8 || !c.opened || dist[c.x * 100 + c.y] === undefined) continue;
                    if (int(dist[c.x * 100 + c.y]) < pbest) { pbest = int(dist[c.x * 100 + c.y]); best = new Point(c.x, c.y); targetCat = "portal"; }
                }
                if (best != null) return best;
                best = explore(list, byKey, dist, here);
                if (best != null) { lastReason = "procurando o portal: explorando a névoa"; return best; }
                // 2) sem borda para explorar: pisa num teleporte (91/92) ainda não usado
                var hbest:Number = Number.MAX_VALUE;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if ((c.type != 91 && c.type != 92) || !c.opened || done[c.x * 100 + c.y] || dist[c.x * 100 + c.y] === undefined) continue;
                    if (int(dist[c.x * 100 + c.y]) < hbest) { hbest = int(dist[c.x * 100 + c.y]); best = new Point(c.x, c.y); targetCat = "hop"; }
                }
                if (best == null) lastReason = "portal (tipo 8) não encontrado: mapa explorado e sem teleporte (91/92) para usar";
                return best;
            }
            var score:Number;
            var k:int;
            var skipOpen:int = 0, skipDist:int = 0, skipCost:int = 0, skipCat:int = 0;
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                if (c.id == 0 || c.occupied || c.base || done[c.x * 100 + c.y]) continue;
                if (!c.opened) { skipOpen++; continue; }
                cat = category(c.type);
                if (cat == "" || cat == "exit" || cat == "market" || cat == "wall") { skipCat++; continue; }
                if (opts[cat] != true) continue;
                if (a.level < c.need || a.energy < c.cost) { skipCost++; continue; }
                k = c.x * 100 + c.y;
                if (dist[k] === undefined) { skipDist++; continue; }
                score = prio(cat) * 1000 + int(dist[k]);
                if (score < bestScore)
                {
                    bestScore = score;
                    best = new Point(c.x, c.y);
                    targetCat = cat;
                }
            }
            if (best != null) return best;

            lastReason = "sem evento alcançável (na névoa " + skipOpen + ", tipo ignorado/desligado " + skipCat + ", sem nível/energia " + skipCost + ", sem caminho " + skipDist + ")";
            if (opts.explore == false) return null;

            best = explore(list, byKey, dist, here);
            if (best != null) lastReason = "explorando a névoa";
            else lastReason += "; nenhuma borda de névoa para explorar";
            return best;
        }
    }
}
