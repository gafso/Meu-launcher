package
{
    import flash.events.TimerEvent;
    import flash.geom.Point;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Macro do evento Planos (mapa em grade). Funciona sobre um IPlanesAdapter (jogo real ou simulação).
    // A cada ~0,7 s: se há carta pendente escolhe uma (op 35); senão escolhe a casa de evento mais valiosa/perto,
    // manda o jogo andar até ela (o próprio jogo faz o caminho e dispara o evento ao chegar) e espera.
    public class PlanesBot
    {
        public static const MAX_TRIES:int = 3;

        public var adapter:IPlanesAdapter;
        public var label:String;
        public var logger:Function;
        // categorias ligadas: box = baús (10,11,15) | res = recursos (5) | mon = monstros (1,2,13,14) | boss = chefe (12)
        public var opts:Object = {box: true, res: true, mon: true, boss: false};
        public var running:Boolean = false;
        public var status:String = "parado";
        public var target:Point = null;
        public var done:Object = {};
        public var counts:Object = {box: 0, res: 0, mon: 0, boss: 0};
        public var minEnergy:int = 0;
        private var timer:Timer;
        private var tries:int = 0;
        private var waitUntil:int = 0;
        private var lastCard:int = 0;
        private var targetCat:String = "";

        public function PlanesBot(adapter:IPlanesAdapter, label:String)
        {
            this.adapter = adapter;
            this.label = label;
        }

        // Categoria de um EventType (ver PlanesConstClass do jogo).
        public static function category(t:int):String
        {
            if (t == 10 || t == 11 || t == 15) return "box";
            if (t == 5) return "res";
            if (t == 1 || t == 2 || t == 13 || t == 14) return "mon";
            if (t == 12) return "boss";
            if (t == 61 || t == 62 || t == 71 || t == 72 || t == 8 || t == 91 || t == 92) return "exit";
            if (t == 3) return "market";
            if (t == -1) return "wall";
            return "";
        }

        private static function prio(cat:String):int
        {
            if (cat == "box") return 1;
            if (cat == "res") return 2;
            if (cat == "mon") return 3;
            return 9;
        }

        private function say(s:String):void
        {
            if (logger != null) logger("[" + label + "] " + s);
        }

        public function start():void
        {
            if (running) return;
            done = {};
            counts = {box: 0, res: 0, mon: 0, boss: 0};
            target = null;
            tries = 0;
            waitUntil = 0;
            running = true;
            status = "iniciando";
            timer = new Timer(700);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            say("iniciado (baús " + opts.box + ", recursos " + opts.res + ", monstros " + opts.mon + ", chefe " + opts.boss + ")");
        }

        public function stop(reason:String = "parado"):void
        {
            if (timer != null)
            {
                timer.stop();
                timer.removeEventListener(TimerEvent.TIMER, onTick);
                timer = null;
            }
            if (running) say("parou: " + reason + " | feitos: baús " + counts.box + ", recursos " + counts.res + ", monstros " + counts.mon + ", chefe " + counts.boss);
            running = false;
            target = null;
            status = reason;
        }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("ERRO: " + err.message); stop("erro: " + err.message); }
        }

        private function key(p:Point):int { return int(p.x) * 100 + int(p.y); }

        private function step():void
        {
            var a:IPlanesAdapter = adapter;
            if (!a.ready) { status = "aguardando o mapa de Planos no jogo"; return; }
            if (a.dead) { status = "personagem morto: reviva manualmente"; return; }
            if (a.moving || getTimer() < waitUntil) return;
            a.suppressFrames();

            var card:Array = a.pendingCard();
            if (card != null)
            {
                if (getTimer() - lastCard > 1500)
                {
                    lastCard = getTimer();
                    var pick:int = int(Math.random() * 4);
                    a.pickCard(int(card[0]), pick);
                    say("carta " + (pick + 1) + " escolhida");
                }
                return;
            }

            status = "energia " + a.energy + " | baús " + counts.box + " recursos " + counts.res + " monstros " + counts.mon + " chefe " + counts.boss;
            if (a.energy <= minEnergy) { stop("sem energia"); return; }

            var here:Point = new Point(a.posX, a.posY);
            if (target != null && int(target.x) == int(here.x) && int(target.y) == int(here.y))
            {
                done[key(target)] = true;
                if (targetCat != "") counts[targetCat] = int(counts[targetCat]) + 1;
                say("chegou em (" + target.x + "," + target.y + ")");
                target = null;
                tries = 0;
                waitUntil = getTimer() + 1200;
                return;
            }

            if (target == null)
            {
                target = choose(a, here);
                tries = 0;
                if (target == null) { stop("sem alvos acessíveis"); return; }
                say("alvo (" + target.x + "," + target.y + ") " + targetCat);
            }

            tries++;
            if (tries > MAX_TRIES)
            {
                say("desisti de (" + target.x + "," + target.y + ")");
                done[key(target)] = true;
                target = null;
                return;
            }
            a.moveTo(int(target.x), int(target.y));
        }

        // Melhor casa: categoria mais prioritária; empate = mais perto. Ignora o que não dá (nível, energia, sem caminho).
        private function choose(a:IPlanesAdapter, here:Point):Point
        {
            var best:Point = null;
            var bestScore:Number = Number.MAX_VALUE;
            var list:Array = a.cells();
            var i:int;
            var c:Object;
            var cat:String;
            var p:Array;
            var score:Number;
            for (i = 0; i < list.length; i++)
            {
                c = list[i];
                if (c.id == 0 || c.occupied || c.base || done[c.x * 100 + c.y]) continue;
                cat = category(c.type);
                if (cat == "" || cat == "exit" || cat == "market" || cat == "wall") continue;
                if (opts[cat] != true) continue;
                if (a.level < c.need || a.energy < c.cost) continue;
                p = (c.x == int(here.x) && c.y == int(here.y)) ? [{x: c.x, y: c.y}] : a.path(int(here.x), int(here.y), c.x, c.y);
                if (p == null) continue;
                score = prio(cat) * 1000 + p.length;
                if (score < bestScore)
                {
                    bestScore = score;
                    best = new Point(c.x, c.y);
                    targetCat = cat;
                }
            }
            return best;
        }
    }
}
