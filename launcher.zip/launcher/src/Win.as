package
{
    import flash.display.Graphics;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;

    // Peças visuais de "programa de PC": janela com barra de título, grupos, campos, menu e barra de status.
    public class Win
    {
        public static const BG:uint      = 0x1E1E1E;   // fundo da janela
        public static const TITLE:uint   = 0x2D2D30;   // barra de título / menu
        public static const FIELD:uint   = 0x1B1B1C;   // campos (mapa, log, lista)
        public static const LINE:uint    = 0x3F3F46;   // bordas
        public static const HOVER:uint   = 0x3E3E42;   // item sob o mouse
        public static const STATUS:uint  = 0x007ACC;   // barra de status (azul)

        // Janela: moldura + barra de título. (x, y) = canto superior esquerdo.
        public static function frame(s:Sprite, x:Number, y:Number, w:Number, h:Number, titleH:Number = 30):void
        {
            var g:Graphics = s.graphics;
            g.lineStyle(1, LINE, 1);
            g.beginFill(BG, 1);
            g.drawRect(x, y, w, h);
            g.endFill();
            g.lineStyle(0, 0, 0);
            g.beginFill(TITLE, 1);
            g.drawRect(x + 1, y + 1, w - 2, titleH - 1);
            g.endFill();
            g.beginFill(LINE, 1);
            g.drawRect(x + 1, y + titleH, w - 2, 1);
            g.endFill();
        }

        // Faixa horizontal lisa (menu, barra de status).
        public static function band(s:Sprite, x:Number, y:Number, w:Number, h:Number, color:uint, lineBelow:Boolean = false):void
        {
            var g:Graphics = s.graphics;
            g.lineStyle(0, 0, 0);
            g.beginFill(color, 1);
            g.drawRect(x, y, w, h);
            g.endFill();
            if (lineBelow) { g.beginFill(LINE, 1); g.drawRect(x, y + h - 1, w, 1); g.endFill(); }
        }

        // Campo rebaixado (área de log, mapa).
        public static function field(s:Sprite, x:Number, y:Number, w:Number, h:Number):void
        {
            var g:Graphics = s.graphics;
            g.lineStyle(1, LINE, 1);
            g.beginFill(FIELD, 1);
            g.drawRect(x, y, w, h);
            g.endFill();
        }

        public static function label(parent:Sprite, t:String, size:int, color:uint, x:Number, y:Number, bold:Boolean = false):TextField
        {
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            tf.x = x; tf.y = y;
            parent.addChild(tf);
            return tf;
        }

        // Caixa de grupo clássica: borda fina com o título "cortando" a linha de cima.
        public static function group(s:Sprite, x:Number, y:Number, w:Number, h:Number, caption:String):void
        {
            var g:Graphics = s.graphics;
            g.lineStyle(1, LINE, 1);
            g.drawRect(x, y + 7, w, h - 7);
            var tf:TextField = label(s, caption, 11, Btn.TEXT_SOFT, x + 10, y - 1, true);
            g.lineStyle(0, 0, 0);
            g.beginFill(BG, 1);
            g.drawRect(x + 6, y + 5, tf.width + 8, 5);
            g.endFill();
            s.setChildIndex(tf, s.numChildren - 1);
        }

        // Divisor com título de seção (ex.: "PLANOS") — linha fina até o fim.
        public static function section(s:Sprite, t:String, x:Number, y:Number, w:Number):void
        {
            var tf:TextField = label(s, t, 11, Btn.TEXT_SOFT, x, y, true);
            var g:Graphics = s.graphics;
            g.lineStyle(1, LINE, 1);
            g.moveTo(x + tf.width + 8, y + 9);
            g.lineTo(x + w, y + 9);
        }

        // Ícone do programa (quadrado azul com "L").
        public static function icon(size:Number = 16):Sprite
        {
            var s:Sprite = new Sprite();
            s.graphics.beginFill(Btn.ACCENT, 1);
            s.graphics.drawRect(0, 0, size, size);
            s.graphics.endFill();
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", int(size * 0.7), 0xFFFFFF, true);
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = "L";
            tf.x = (size - tf.width) / 2; tf.y = (size - tf.height) / 2;
            s.addChild(tf);
            s.mouseChildren = false; s.mouseEnabled = false;
            return s;
        }

        // Botão "fechar" da barra de título (vermelho ao passar o mouse). Origem no canto superior esquerdo.
        public static function closeButton(w:Number, h:Number, onClick:Function):Sprite
        {
            var s:Sprite = new Sprite();
            var draw:Function = function(hot:Boolean):void
            {
                s.graphics.clear();
                s.graphics.beginFill(0xE81123, hot ? 1 : 0);
                s.graphics.drawRect(0, 0, w, h);
                s.graphics.endFill();
                s.graphics.lineStyle(1.4, 0xFFFFFF, 0.9);
                var cx:Number = w / 2;
                var cy:Number = h / 2;
                s.graphics.moveTo(cx - 5, cy - 5); s.graphics.lineTo(cx + 5, cy + 5);
                s.graphics.moveTo(cx + 5, cy - 5); s.graphics.lineTo(cx - 5, cy + 5);
            };
            draw(false);
            s.buttonMode = true;
            s.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { draw(true); });
            s.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { draw(false); });
            s.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            return s;
        }

        // Item da barra de menu (texto que acende ao passar o mouse). Origem no canto superior esquerdo.
        public static function menuItem(t:String, h:Number, onClick:Function):Sprite
        {
            var s:Sprite = new Sprite();
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 12, Btn.TEXT_SOFT, false);
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            tf.x = 10; tf.y = (h - tf.height) / 2;
            var w:Number = tf.width + 20;
            var draw:Function = function(hot:Boolean):void
            {
                s.graphics.clear();
                s.graphics.beginFill(HOVER, hot ? 1 : 0);
                s.graphics.drawRect(0, 0, w, h);
                s.graphics.endFill();
            };
            draw(false);
            s.addChild(tf);
            s.mouseChildren = false;
            s.buttonMode = true;
            s.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { draw(true); });
            s.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { draw(false); });
            s.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            return s;
        }
    }
}
