package
{
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.geom.Matrix;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;

    // Peças visuais do tema violeta: janelas, cartões, itens da barra lateral, ícones vetoriais.
    public class Win
    {
        public static const BG:uint      = 0x0B0A1E;   // fundo geral
        public static const TITLE:uint   = 0x12112E;   // barras / painéis
        public static const FIELD:uint   = 0x0E0D26;   // campos (mapa, log)
        public static const LINE:uint    = 0x2A2955;   // bordas
        public static const HOVER:uint   = 0x1D1B4A;   // item sob o dedo/mouse
        public static const STATUS:uint  = 0x7C3AED;   // destaque

        // Janela flutuante: moldura arredondada + faixa de título. (x, y) = canto superior esquerdo.
        public static function frame(s:Sprite, x:Number, y:Number, w:Number, h:Number, titleH:Number = 30):void
        {
            var g:Graphics = s.graphics;
            g.lineStyle(1, LINE, 1);
            g.beginFill(BG, 1);
            g.drawRoundRect(x, y, w, h, 18, 18);
            g.endFill();
            g.lineStyle(0, 0, 0);
            var m:Matrix = new Matrix();
            m.createGradientBox(w - 2, titleH, Math.PI / 2, x + 1, y + 1);
            g.beginGradientFill(GradientType.LINEAR, [0x1C1A4A, TITLE], [1, 1], [0, 255], m);
            g.drawRoundRectComplex(x + 1, y + 1, w - 2, titleH, 17, 17, 0, 0);
            g.endFill();
            g.beginFill(LINE, 1);
            g.drawRect(x + 1, y + titleH, w - 2, 1);
            g.endFill();
        }

        // Cartão arredondado (painéis da tela inicial).
        public static function card(s:Sprite, x:Number, y:Number, w:Number, h:Number, r:Number = 16, fill:uint = 0x10102A, line:uint = 0x2A2955):void
        {
            var g:Graphics = s.graphics;
            g.lineStyle(1, line, 1);
            g.beginFill(fill, 1);
            g.drawRoundRect(x, y, w, h, r * 2, r * 2);
            g.endFill();
        }

        // Faixa horizontal lisa.
        public static function band(s:Sprite, x:Number, y:Number, w:Number, h:Number, color:uint, lineBelow:Boolean = false):void
        {
            var g:Graphics = s.graphics;
            g.lineStyle(0, 0, 0);
            g.beginFill(color, 1);
            g.drawRect(x, y, w, h);
            g.endFill();
            if (lineBelow) { g.beginFill(LINE, 1); g.drawRect(x, y + h - 1, w, 1); g.endFill(); }
        }

        // Campo rebaixado (área de log, mapa).
        public static function field(s:Sprite, x:Number, y:Number, w:Number, h:Number):void
        {
            var g:Graphics = s.graphics;
            g.lineStyle(1, LINE, 1);
            g.beginFill(FIELD, 1);
            g.drawRoundRect(x, y, w, h, 12, 12);
            g.endFill();
        }

        public static function label(parent:Sprite, t:String, size:int, color:uint, x:Number, y:Number, bold:Boolean = false):TextField
        {
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            tf.x = x; tf.y = y;
            parent.addChild(tf);
            return tf;
        }

        // Rótulo que diminui a fonte até caber em maxW (a fonte do aparelho pode ser mais larga que o previsto).
        public static function fitLabel(parent:Sprite, t:String, size:int, color:uint, x:Number, y:Number, maxW:Number, bold:Boolean = false):TextField
        {
            var tf:TextField = label(parent, t, size, color, x, y, bold);
            var sz:int = size;
            while (tf.width > maxW && sz > 8)
            {
                sz--;
                var f:TextFormat = new TextFormat("_sans", sz, color, bold);
                tf.defaultTextFormat = f;
                tf.setTextFormat(f);
            }
            return tf;
        }

        // Texto com quebra de linha em largura w; corta com "…" se passar de maxLines.
        public static function wrapLabel(parent:Sprite, t:String, size:int, color:uint, x:Number, y:Number, w:Number, maxLines:int, bold:Boolean = false):TextField
        {
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            tf.multiline = true; tf.wordWrap = true;
            tf.width = w;
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            var n:int = t.length;
            while (tf.numLines > maxLines && n > 4)
            {
                n -= 3;
                tf.text = t.substr(0, n) + "\u2026";
            }
            tf.x = x; tf.y = y;
            parent.addChild(tf);
            return tf;
        }

        // Título de cartão com ícone: ex. "Acesso Rápido".
        public static function heading(parent:Sprite, glyphName:String, t:String, x:Number, y:Number):void
        {
            var gs:Shape = new Shape();
            glyph(gs.graphics, glyphName, x + 11, y + 11, 20, Btn.ACCENT_LIGHT);
            parent.addChild(gs);
            label(parent, t, 15, Btn.TEXT, x + 30, y, true);
        }

        // Divisor com título de seção (ex.: "PLANOS") — linha fina até o fim.
        public static function section(s:Sprite, t:String, x:Number, y:Number, w:Number):void
        {
            var tf:TextField = label(s, t, 11, Btn.ACCENT_LIGHT, x, y, true);
            var g:Graphics = s.graphics;
            g.lineStyle(1, LINE, 1);
            g.moveTo(x + tf.width + 8, y + 9);
            g.lineTo(x + w, y + 9);
        }

        // Ícone do programa (o da imagem do app, se já carregou; senão um raio violeta).
        public static function icon(size:Number = 16):Sprite
        {
            var s:Sprite = new Sprite();
            s.graphics.beginFill(Btn.ACCENT, 1);
            s.graphics.drawRoundRect(0, 0, size, size, size * 0.4, size * 0.4);
            s.graphics.endFill();
            glyph(s.graphics, "bolt", size / 2, size / 2, size * 0.7, 0xFFFFFF);
            s.mouseChildren = false; s.mouseEnabled = false;
            return s;
        }

        // Botão "fechar" da barra de título. Origem no canto superior esquerdo.
        public static function closeButton(w:Number, h:Number, onClick:Function):Sprite
        {
            var s:Sprite = new Sprite();
            var draw:Function = function(hot:Boolean):void
            {
                s.graphics.clear();
                s.graphics.beginFill(0xE5484D, hot ? 1 : 0);
                s.graphics.drawRoundRect(0, 0, w, h, 10, 10);
                s.graphics.endFill();
                s.graphics.lineStyle(1.6, hot ? 0xFFFFFF : Btn.TEXT_SOFT, 0.95, false, "normal", "round", "round");
                var cx:Number = w / 2;
                var cy:Number = h / 2;
                s.graphics.moveTo(cx - 5, cy - 5); s.graphics.lineTo(cx + 5, cy + 5);
                s.graphics.moveTo(cx + 5, cy - 5); s.graphics.lineTo(cx - 5, cy + 5);
            };
            draw(false);
            s.buttonMode = true;
            s.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { draw(true); });
            s.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { draw(false); });
            s.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            return s;
        }

        // Item da barra lateral: ícone + texto; o ativo ganha degradê violeta. Origem no canto superior esquerdo.
        public static function navItem(glyphName:String, t:String, w:Number, h:Number, active:Boolean, onClick:Function):Sprite
        {
            var s:Sprite = new Sprite();
            var draw:Function = function(hot:Boolean):void
            {
                var g:Graphics = s.graphics;
                g.clear();
                if (active)
                {
                    var m:Matrix = new Matrix();
                    m.createGradientBox(w, h, 0, 0, 0);
                    g.lineStyle(1, 0x6D4BD8, 1);
                    g.beginGradientFill(GradientType.LINEAR, [0x6D28D9, 0x1C1650], [1, 1], [0, 255], m);
                    g.drawRoundRect(0, 0, w, h, 16, 16);
                    g.endFill();
                }
                else if (hot)
                {
                    g.lineStyle(0, 0, 0);
                    g.beginFill(HOVER, 1);
                    g.drawRoundRect(0, 0, w, h, 16, 16);
                    g.endFill();
                }
                glyph(g, glyphName, 28, h / 2, 22, active ? 0xFFFFFF : Btn.TEXT_SOFT);
            };
            draw(false);
            var tf:TextField = fitLabel(s, t, 14, active ? 0xFFFFFF : Btn.TEXT, 50, 0, w - 58, active);
            tf.y = (h - tf.height) / 2;
            s.mouseChildren = false;
            s.buttonMode = true;
            s.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { draw(true); });
            s.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { draw(false); });
            s.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            return s;
        }

        // Cartão clicável (Acesso Rápido): faixa colorida com ícone, título, legenda e botão redondo com seta.
        public static function tile(glyphName:String, accent:uint, t:String, cap:String, w:Number, h:Number, onClick:Function):Sprite
        {
            var s:Sprite = new Sprite();
            var draw:Function = function(hot:Boolean):void
            {
                var g:Graphics = s.graphics;
                g.clear();
                card(s, 0, 0, w, h, 14, hot ? 0x17163C : 0x10102A, hot ? Btn.ACCENT_LIGHT : LINE);
                var m:Matrix = new Matrix();
                m.createGradientBox(w - 2, 66, Math.PI / 2, 1, 1);
                g.lineStyle(0, 0, 0);
                g.beginGradientFill(GradientType.LINEAR, [accent, 0x10102A], [0.85, 1], [0, 255], m);
                g.drawRoundRectComplex(1, 1, w - 2, 66, 26, 26, 0, 0);
                g.endFill();
                glyph(g, glyphName, w / 2, 34, 34, 0xFFFFFF);
                // botão redondo com seta
                g.beginFill(hot ? Btn.ACCENT_LIGHT : Btn.ACCENT, 1);
                g.drawCircle(24, h - 26, 15);
                g.endFill();
                g.lineStyle(2, 0xFFFFFF, 1, false, "normal", "round", "round");
                g.moveTo(17, h - 26); g.lineTo(31, h - 26);
                g.moveTo(26, h - 32); g.lineTo(32, h - 26); g.lineTo(26, h - 20);
            };
            draw(false);
            label(s, t, 14, Btn.TEXT, 12, 74, true);
            var c:TextField = label(s, cap, 11, Btn.TEXT_MUTED, 12, 94);
            c.width = w - 20; c.wordWrap = true; c.autoSize = TextFieldAutoSize.LEFT;
            s.mouseChildren = false;
            s.buttonMode = true;
            s.addEventListener(MouseEvent.ROLL_OVER, function(e:MouseEvent):void { draw(true); });
            s.addEventListener(MouseEvent.ROLL_OUT, function(e:MouseEvent):void { draw(false); });
            s.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            return s;
        }

        // Ícones vetoriais (centro em cx,cy; tamanho aproximado = size). Nomes: home play gear doc exit bolt user server.
        public static function glyph(g:Graphics, name:String, cx:Number, cy:Number, size:Number, color:uint):void
        {
            var k:Number = size / 24;
            g.lineStyle(0, 0, 0);
            g.beginFill(color, 1);
            if (name == "home")
            {
                g.moveTo(cx, cy - 11 * k); g.lineTo(cx + 12 * k, cy); g.lineTo(cx + 8 * k, cy);
                g.lineTo(cx + 8 * k, cy + 10 * k); g.lineTo(cx + 2.5 * k, cy + 10 * k); g.lineTo(cx + 2.5 * k, cy + 3 * k);
                g.lineTo(cx - 2.5 * k, cy + 3 * k); g.lineTo(cx - 2.5 * k, cy + 10 * k); g.lineTo(cx - 8 * k, cy + 10 * k);
                g.lineTo(cx - 8 * k, cy); g.lineTo(cx - 12 * k, cy); g.lineTo(cx, cy - 11 * k);
            }
            else if (name == "play")
            {
                g.moveTo(cx - 7 * k, cy - 10 * k); g.lineTo(cx + 10 * k, cy); g.lineTo(cx - 7 * k, cy + 10 * k); g.lineTo(cx - 7 * k, cy - 10 * k);
            }
            else if (name == "bolt")
            {
                g.moveTo(cx + 3 * k, cy - 12 * k); g.lineTo(cx - 8 * k, cy + 2 * k); g.lineTo(cx - 1 * k, cy + 2 * k);
                g.lineTo(cx - 4 * k, cy + 12 * k); g.lineTo(cx + 8 * k, cy - 3 * k); g.lineTo(cx + 1 * k, cy - 3 * k);
                g.lineTo(cx + 3 * k, cy - 12 * k);
            }
            else if (name == "gear")
            {
                var teeth:int = 8;
                var step:Number = Math.PI * 2 / teeth;
                var half:Number = step * 0.22;
                var first:Boolean = true;
                for (var i:int = 0; i < teeth; i++)
                {
                    var a:Number = i * step;
                    var pts:Array = [[a - half * 1.8, 8 * k], [a - half, 11.5 * k], [a + half, 11.5 * k], [a + half * 1.8, 8 * k]];
                    for each (var q:Array in pts)
                    {
                        var px:Number = cx + Math.cos(q[0]) * q[1];
                        var py:Number = cy + Math.sin(q[0]) * q[1];
                        if (first) { g.moveTo(px, py); first = false; } else g.lineTo(px, py);
                    }
                }
                g.endFill();
                g.beginFill(BG, 1);
                g.drawCircle(cx, cy, 3.6 * k);
            }
            else if (name == "doc")
            {
                g.drawRoundRect(cx - 9 * k, cy - 11 * k, 18 * k, 22 * k, 5 * k, 5 * k);
                g.endFill();
                g.beginFill(BG, 1);
                g.drawRect(cx - 5 * k, cy - 6 * k, 10 * k, 2 * k);
                g.drawRect(cx - 5 * k, cy - 1.5 * k, 10 * k, 2 * k);
                g.drawRect(cx - 5 * k, cy + 3 * k, 7 * k, 2 * k);
            }
            else if (name == "exit")
            {
                g.drawRoundRect(cx - 11 * k, cy - 10 * k, 10 * k, 20 * k, 3 * k, 3 * k);
                g.endFill();
                g.beginFill(color, 1);
                g.moveTo(cx + 1 * k, cy - 4 * k); g.lineTo(cx + 5 * k, cy - 4 * k); g.lineTo(cx + 5 * k, cy - 8 * k);
                g.lineTo(cx + 12 * k, cy); g.lineTo(cx + 5 * k, cy + 8 * k); g.lineTo(cx + 5 * k, cy + 4 * k);
                g.lineTo(cx + 1 * k, cy + 4 * k); g.lineTo(cx + 1 * k, cy - 4 * k);
            }
            else if (name == "user")
            {
                g.drawCircle(cx, cy - 5 * k, 5 * k);
                g.endFill();
                g.beginFill(color, 1);
                g.drawRoundRectComplex(cx - 9 * k, cy + 2 * k, 18 * k, 10 * k, 9 * k, 9 * k, 2 * k, 2 * k);
            }
            else if (name == "server")
            {
                g.drawRoundRect(cx - 11 * k, cy - 10 * k, 22 * k, 8 * k, 4 * k, 4 * k);
                g.drawRoundRect(cx - 11 * k, cy + 2 * k, 22 * k, 8 * k, 4 * k, 4 * k);
                g.endFill();
                g.beginFill(BG, 1);
                g.drawCircle(cx - 6 * k, cy - 6 * k, 1.4 * k);
                g.drawCircle(cx - 6 * k, cy + 6 * k, 1.4 * k);
            }
            else
            {
                g.drawCircle(cx, cy, 8 * k);
            }
            g.endFill();
        }
    }
}
