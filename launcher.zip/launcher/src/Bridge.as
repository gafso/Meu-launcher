package
{
    import flash.events.EventDispatcher;
    import flash.events.StatusEvent;
    import flash.external.ExtensionContext;

    // Ponte com o ANE (Java). Eventos nativos chegam como StatusEvent:
    //   code "game"  -> level = JSON {host, user, key, swf, params:{...}}
    //   code "menu"  -> level = índice escolhido
    //   code "error" -> level = mensagem
    public class Bridge extends EventDispatcher
    {
        public static const EXT_ID:String = "com.meulauncher.air.bridge";
        private var ctx:ExtensionContext;

        public function Bridge()
        {
            ctx = ExtensionContext.createExtensionContext(EXT_ID, "");
            if (ctx) ctx.addEventListener(StatusEvent.STATUS, onStatus);
        }

        public function get available():Boolean { return ctx != null; }

        private function onStatus(e:StatusEvent):void
        {
            dispatchEvent(new StatusEvent(e.code, false, false, e.code, e.level));
        }

        public function login(host:String):void            { call("login", host); }
        public function startServer(host:String):int       { return int(call("startServer", host)); }
        public function showMenu(title:String, items:Array):void { call("showMenu", title, items.join("|")); }
        public function keepAlive(on:Boolean):void         { call("keepAlive", on); }
        public function restartApp():void                  { call("restartApp"); }
        public function clearSession():void                { call("clearSession"); }
        public function setSurfaceSize(w:int, h:int):void  { call("setSurfaceSize", w, h); }
        public function showText(title:String, text:String):void { call("showText", title, text); }

        private function call(name:String, ...args):Object
        {
            if (!ctx) return null;
            return ctx.call.apply(ctx, [name].concat(args));
        }
    }
}
