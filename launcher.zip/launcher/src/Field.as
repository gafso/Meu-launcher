package
{
    import flash.display.Sprite;
    import flash.events.Event;
    import flash.events.FocusEvent;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFieldType;
    import flash.text.TextFormat;
    import flash.ui.Keyboard;

    // Campo de texto do launcher (usuário / senha). A origem (0,0) fica no CENTRO do campo.
    public class Field extends Sprite
    {
        public var input:TextField;
        private var hint:TextField;
        private var fw:Number;
        private var fh:Number;
        public var onChange:Function;   // function():void
        public var onEnter:Function;    // function():void

        public function Field(w:Number, h:Number, hintText:String, password:Boolean = false)
        {
            fw = w; fh = h;
            draw(false);

            var fmt:TextFormat = new TextFormat("_sans", 20, 0xFFFFFF, true);
            input = new TextField();
            input.defaultTextFormat = fmt;
            input.type = TextFieldType.INPUT;
            input.displayAsPassword = password;
            input.multiline = false;
            input.maxChars = 80;
            input.width = w - 44;
            input.height = 30;
            input.x = -w / 2 + 22;
            input.y = -15;
            input.needsSoftKeyboard = true;
            addChild(input);

            hint = new TextField();
            hint.defaultTextFormat = new TextFormat("_sans", 20, Btn.TEXT_MUTED, false);
            hint.text = hintText;
            hint.selectable = false; hint.mouseEnabled = false;
            hint.width = w - 44; hint.height = 30;
            hint.x = input.x; hint.y = input.y;
            addChild(hint);

            input.addEventListener(Event.CHANGE, onInput);
            input.addEventListener(FocusEvent.FOCUS_IN,  function(e:FocusEvent):void { draw(true); });
            input.addEventListener(FocusEvent.FOCUS_OUT, function(e:FocusEvent):void { draw(false); });
            input.addEventListener(KeyboardEvent.KEY_DOWN, function(e:KeyboardEvent):void {
                if (e.keyCode == Keyboard.ENTER && onEnter != null) onEnter();
            });
            // tocar na margem do campo também foca o texto
            addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { focus(); });
        }

        public function focus():void
        {
            if (stage) stage.focus = input;
            try { input.requestSoftKeyboard(); } catch (err:Error) {}
        }

        public function get text():String { return input.text; }
        public function set text(v:String):void { input.text = v; hint.visible = (v == ""); }

        private function onInput(e:Event):void
        {
            hint.visible = (input.text == "");
            if (onChange != null) onChange();
        }

        private function draw(focused:Boolean):void
        {
            graphics.clear();
            graphics.lineStyle(focused ? 2 : 1.5, focused ? Btn.BLUE : Btn.BORDER, 1);
            graphics.beginFill(0x151B26, 1);
            graphics.drawRoundRect(-fw / 2, -fh / 2, fw, fh, 28, 28);
            graphics.endFill();
        }
    }
}
