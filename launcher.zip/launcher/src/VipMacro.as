package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Point;
    import flash.utils.describeType;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Macro da Moeda VIP (feito a partir da gravação do jogador):
    //   1) acha a "Moeda VIP" na mochila (confere todas as páginas) e aperta Usar;
    //   2) na janela VipBoxFrame aperta ELEVAR até aparecer o item desejado (Pedra secreta);
    //   3) aperta HABILITAR, que gira sozinho até coletar o item;
    //   4) volta a elevar até achar de novo, e repete. Para sozinho quando acabam as moedas.
    public class VipMacro
    {
        public var logger:Function;
        public var onFinish:Function;          // (código, motivo): parada definitiva (noCoin | limit | fail)
        public var running:Boolean = false;
        public var status:String = "parado";
        public var target:String = "pedra secreta";
        public var goal:int = 100;             // meta: quantidade de ITENS (ex.: 100 Pedras secretas), não de vezes
        public var perCollect:int = 5;         // quantos itens cada coleta rende (lido da janela; 5 se não conseguir ler)
        public var collected:int = 0;          // itens coletados
        public var collects:int = 0;           // vezes que coletou

        private var ad:GamePlanesAdapter = new GamePlanesAdapter();
        private var timer:Timer;
        private var st:String = "idle";
        private var t0:int = 0;
        private var lastPress:int = 0;
        private var tries:int = 0;
        private var pageIdx:int = -1;
        private var scanned:Boolean = false;
        private var elevarCount:int = 0;
        private var coinCell:DisplayObject = null;
        private var lastItem:String = "";
        private var lastHint:int = 0;
        private var diagDone:Boolean = false;
        private var seenSigs:Array = [];
        private var lastSig:String = "";
        private var pageMethod:int = 0;
        private var acted:Boolean = false;
        private var pressN:int = 0;
        private var noAlertTicked:Boolean = false;
        private var lastAlert:int = 0;
        private var diagAlert:Boolean = false;
        private var targetIdx:int = -1;

        private function say(s:String):void { if (logger != null) logger("[VIP] " + s); }
        private function go(s:String):void { st = s; t0 = getTimer(); tries = 0; }
        private function root():DisplayObjectContainer { return SwfFixer.rootStage; }

        public function start():void
        {
            if (running) return;
            running = true; collected = 0; collects = 0; noAlertTicked = false; diagAlert = false; targetIdx = -1; elevarCount = 0; pageIdx = -1; scanned = false; diagDone = false; seenSigs = []; lastSig = ""; pageMethod = 0; acted = false;
            lastItem = "";
            timer = new Timer(700);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            say("iniciado: meta de " + goal + " x " + target + " (Moeda VIP > Elevar > Habilitar)");
            go(UiHelper.find(root(), "VipBoxFrame") != null ? "elevar" : "findbag");
        }

        public function stop(reason:String = "parado", code:String = ""):void
        {
            if (timer != null) { timer.stop(); timer.removeEventListener(TimerEvent.TIMER, onTick); timer = null; }
            var was:Boolean = running;
            if (was) say("parou: " + reason + " | coletadas: " + collected + " / " + goal);
            running = false; status = reason; st = "idle";
            if (was && code != "" && onFinish != null) onFinish(code, reason);
        }

        private function fail(msg:String):void { say("FALHOU: " + msg); stop("falhou: " + msg, "fail"); }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("ERRO: " + err.message); tries++; if (tries > 8) fail(err.message); }
        }

        // ---------- ajudantes ----------
        private static function clean(s:String):String { return GamePlanesAdapter.norm(s).split("\r").join(" ").split("\n").join(" "); }

        // Botão visível (de qualquer tipo comum) dentro de "from" cujo texto contém "label".
        private function findButton(from:DisplayObjectContainer, label:String):DisplayObject
        {
            var want:String = clean(label);
            for each (var cls:String in ["TextButton", "IconButton", "BaseButton", "MovieButton", "SelectedIconButton"])
            {
                var arr:Array = [];
                UiHelper.findAll(from, cls, arr, 12, 40);
                for (var i:int = 0; i < arr.length; i++)
                {
                    var tx:Array = [];
                    UiHelper.texts(arr[i], tx);
                    if (clean(tx.join(" ")).indexOf(want) >= 0) return arr[i];
                }
            }
            return null;
        }

        private function buttonsSeen(from:DisplayObjectContainer):String
        {
            var out:Array = [];
            for each (var cls:String in ["TextButton", "IconButton", "BaseButton", "MovieButton"])
            {
                var arr:Array = [];
                UiHelper.findAll(from, cls, arr, 12, 20);
                for (var i:int = 0; i < arr.length; i++)
                {
                    var tx:Array = [];
                    UiHelper.texts(arr[i], tx);
                    out.push(cls + "[" + tx.join("/") + "]");
                }
            }
            return out.join(" ");
        }

        // Nomes dos itens mostrados na janela VIP (VipBoxItem); cai para os textos se o jogo não expõe o nome.
        private function readItemsArr(vip:DisplayObjectContainer):Array
        {
            var its:Array = [];
            UiHelper.findAll(vip, "VipBoxItem", its, 12, 12);
            var names:Array = [];
            for (var i:int = 0; i < its.length; i++)
            {
                var n:String = "";
                try { n = ad.bagCellName(its[i]); } catch (e0:Error) {}
                if (n == "?" || n.length == 0 || n.indexOf("(x") == 0)
                {
                    var bi:DisplayObject = UiHelper.find(its[i] as DisplayObjectContainer, "BaseItemView");
                    if (bi != null) { try { n = ad.bagCellName(bi); } catch (e1:Error) {} }
                }
                if (n == "?" || n.length == 0 || n.indexOf("(x") == 0)
                {
                    var tx:Array = [];
                    UiHelper.texts(its[i], tx);
                    n = tx.join("/");
                }
                names.push(n);
            }
            return names;
        }

        private function readItems(vip:DisplayObjectContainer):String { return readItemsArr(vip).join(" | "); }

        private function indexOfTarget(names:Array):int
        {
            for (var i:int = 0; i < names.length; i++) if (clean(String(names[i])).indexOf(clean(target)) >= 0) return i;
            return -1;
        }

        // Soma a coleta à meta (em ITENS). Devolve true se a meta foi atingida (e o macro parou).
        private function gain(amount:int):Boolean
        {
            if (amount <= 0) amount = perCollect;
            collects++;
            collected += amount;
            say("coletou +" + amount + " " + target + " | total " + collected + " / " + goal + " (" + collects + " coletas)");
            if (goal > 0 && collected >= goal) { stop("meta atingida: " + collected + " " + target, "goal"); return true; }
            return false;
        }

        // Caixa "Ao atualizar redefinirá todos os itens da Roleta, continuar?": marca "Não alertar mais" (1ª vez) e confirma.
        private function handleAlert(al:DisplayObject, now:int):void
        {
            if (now - lastAlert < 800) return;
            lastAlert = now;
            var ac:DisplayObjectContainer = al as DisplayObjectContainer;
            if (!noAlertTicked)
            {
                noAlertTicked = true;
                var cb:DisplayObject = UiHelper.find(ac, 'SelectedCheckButton');
                var already:Boolean = false;
                try { already = (cb['selected'] == true); } catch (e0:Error) {}
                if (cb != null && !already) { say('marcando "Não alertar mais" na caixa da Roleta'); UiHelper.press(cb); return; }
            }
            var ok:DisplayObject = UiHelper.findButtonByText(ac, 'confirmar');
            if (ok == null) ok = UiHelper.findButtonByText(ac, 'confirm');
            if (ok == null)
            {
                var bs:Array = [];
                UiHelper.findAll(ac, 'IconButton', bs, 8, 6);
                bs.sort(function(a:DisplayObject, b:DisplayObject):int { return int(UiHelper.gx(a) - UiHelper.gx(b)); });
                if (bs.length > 0) ok = bs[0];   // Confirmar fica à esquerda de Cancelar
            }
            if (ok != null) { say('confirmando o aviso da Roleta'); UiHelper.press(ok); }
            else if (!diagAlert) { diagAlert = true; say('aviso da Roleta sem botão Confirmar visível: ' + buttonsSeen(ac)); }
        }

        // As 6 abas numeradas da mochila: SelectedIconButton logo acima da lista de itens, dentro da largura dela.
        private function bagTabs(bag:DisplayObjectContainer):Array
        {
            var out:Array = [];
            var host:DisplayObject = UiHelper.find(root(), "ArmyFrameII");
            if (host == null) return out;
            var all:Array = [];
            UiHelper.findAll(host as DisplayObjectContainer, "SelectedIconButton", all, 12, 60);
            var bp:Point = bag.localToGlobal(new Point(0, 0));
            for (var i:int = 0; i < all.length; i++)
            {
                var b:DisplayObject = all[i];
                if (!b.visible) continue;
                var p:Point = b.localToGlobal(new Point(0, 0));
                if (p.x >= bp.x - 40 && p.x <= bp.x + bag.width + 90 && p.y >= bp.y - 130 && p.y <= bp.y + 4) out.push(b);
            }
            out.sort(function(a:DisplayObject, c:DisplayObject):int { return int(UiHelper.gx(a) - UiHelper.gx(c)); });
            return out;
        }

        private function coinCells(frame:DisplayObjectContainer):Array
        {
            var cells:Array = [];
            UiHelper.findAll(frame, "PlayerBagCell", cells, 14, 80);
            var out:Array = [];
            for (var i:int = 0; i < cells.length; i++)
            {
                var n:String = "";
                try { n = clean(ad.bagCellName(cells[i])); } catch (e:Error) {}
                if (n.indexOf("moeda vip") >= 0) out.push(cells[i]);
            }
            return out;
        }

        // Botões de imagem da janela VIP: não têm texto; pela gravação, ELEVAR é o da direita e HABILITAR o da esquerda.
        private function vipButtons(vc:DisplayObjectContainer):Object
        {
            var arr:Array = [];
            UiHelper.findAll(vc, "IconButton", arr, 12, 10);
            arr.sort(function(a:DisplayObject, b:DisplayObject):int { return int(UiHelper.gx(a) - UiHelper.gx(b)); });
            if (arr.length < 2) return null;
            return {habilitar: arr[0], elevar: arr[arr.length - 1], n: arr.length};
        }

        private function pos(o:DisplayObject):String
        {
            try { var p:Point = o.localToGlobal(new Point(0, 0)); return "(" + int(p.x) + "," + int(p.y) + ")"; } catch (e:Error) {}
            return "(?)";
        }

        // Assinatura da página atual da mochila: nomes dos itens das células (muda quando a página vira).
        private function bagSig(frame:DisplayObjectContainer):String
        {
            var cells:Array = [];
            UiHelper.findAll(frame, "PlayerBagCell", cells, 14, 120);
            var out:Array = [];
            for (var i:int = 0; i < cells.length; i++)
            {
                var n:String = "";
                try { n = ad.bagCellName(cells[i]); } catch (e:Error) {}
                out.push(n);
            }
            return out.join("|");
        }

        // Tenta virar a página SEM apertar botões desconhecidos. 0 = métodos do próprio jogo (se existirem); 1 = roda do mouse na lista.
        private function turnPage(frame:DisplayObjectContainer, method:int):Boolean
        {
            var list:DisplayObject = UiHelper.find(frame, "SimpleTileList");
            if (list == null) return false;
            if (method == 0)
            {
                for each (var nm:String in ["nextPage", "pageDown", "next", "gotoNextPage", "nextPageHandler"])
                {
                    try { if (list[nm] is Function) { list[nm](); say("virei a página pelo método " + nm + "()"); return true; } } catch (e0:Error) {}
                }
                for each (var pn:String in ["currentPage", "curPage", "pageIndex", "page", "currentIndex"])
                {
                    try { var v:* = list[pn]; if (v is Number) { list[pn] = int(v) + 1; say("virei a página pela propriedade " + pn + " -> " + (int(v) + 1)); return true; } } catch (e1:Error) {}
                }
                return false;
            }
            if (method == 1)
            {
                try
                {
                    list.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_WHEEL, true, false, 5, 5, null, false, false, false, false, -3));
                    say("rolei a lista com a roda do mouse");
                    return true;
                } catch (e2:Error) {}
            }
            return false;
        }

        private function api(o:Object):String
        {
            var out:Array = [];
            try
            {
                var x:XML = describeType(o);
                for each (var n:XML in x..*)
                {
                    var tag:String = n.name().toString();
                    if (tag != "variable" && tag != "accessor" && tag != "method") continue;
                    var nm:String = String(n.@name);
                    if (/page|scroll|index|next|prev|turn|goto|total|count/i.test(nm)) out.push(tag.charAt(0) + ":" + nm);
                }
            } catch (e:Error) {}
            return out.join(",");
        }

        private function tree(o:DisplayObjectContainer, maxDepth:int, maxNodes:int):Array
        {
            var lines:Array = [];
            var queue:Array = [o, 0];
            while (queue.length > 0 && lines.length < maxNodes)
            {
                var c:DisplayObjectContainer = queue.shift();
                var d:int = queue.shift();
                var pad:String = "";
                for (var k:int = 0; k < d; k++) pad += "  ";
                var tx:Array = [];
                if (c.numChildren < 4) UiHelper.texts(c, tx);
                lines.push(pad + UiHelper.sn(c) + " " + pos(c) + " " + int(c.width) + "x" + int(c.height) + (tx.length > 0 ? " [" + tx.slice(0, 3).join("/") + "]" : ""));
                if (d >= maxDepth) continue;
                for (var i:int = 0; i < c.numChildren; i++)
                {
                    try
                    {
                        var ch:DisplayObject = c.getChildAt(i);
                        if (ch is DisplayObjectContainer && ch.visible) { queue.push(ch); queue.push(d + 1); }
                    } catch (e:Error) {}
                }
            }
            return lines;
        }

        // Diagnóstico (só leitura): estrutura da mochila e da janela VIP, para o log.
        public function diagnose():void
        {
            var rt:DisplayObjectContainer = root();
            var bag:DisplayObject = UiHelper.find(rt, "EquipBagII");
            if (bag != null)
            {
                say("DIAG mochila (EquipBagII) " + pos(bag) + " api: " + api(bag));
                var tl:DisplayObject = UiHelper.find(bag as DisplayObjectContainer, "SimpleTileList");
                if (tl != null) say("DIAG SimpleTileList " + pos(tl) + " api: " + api(tl) + " | assinatura: " + bagSig(bag as DisplayObjectContainer).substr(0, 200));
                var ls:Array = tree(bag as DisplayObjectContainer, 4, 60);
                for (var i:int = 0; i < ls.length; i++) say("DIAG " + ls[i]);
            }
            else say("DIAG: mochila não está aberta");
            var vp:DisplayObject = UiHelper.find(rt, "VipBoxFrame");
            if (vp != null)
            {
                var vb:Object = vipButtons(vp as DisplayObjectContainer);
                say("DIAG VipBoxFrame " + pos(vp) + (vb != null ? " | Elevar " + pos(vb.elevar) + " | Habilitar " + pos(vb.habilitar) : " | botões IconButton: menos de 2"));
                var lv:Array = tree(vp as DisplayObjectContainer, 3, 40);
                for (var j:int = 0; j < lv.length; j++) say("DIAG " + lv[j]);
            }
            else say("DIAG: janela VIP não está aberta");
        }

        // ---------- máquina de estados ----------
        private function step():void
        {
            var rt:DisplayObjectContainer = root();
            var now:int = getTimer();
            var i:int;

            var alertWin:DisplayObject = UiHelper.find(rt, "TodayNotAlertFrame");
            if (alertWin != null) { handleAlert(alertWin, now); return; }

            if (st == "findbag")
            {
                if (UiHelper.find(rt, "VipBoxFrame") != null) { go("elevar"); return; }
                var frame:DisplayObject = UiHelper.find(rt, "EquipBagII");
                if (frame == null)
                {
                    status = "abra a mochila (personagem > mochila)";
                    if (now - lastHint > 6000) { lastHint = now; say("abra a mochila do personagem: preciso da tela com os itens"); }
                    if (now - t0 > 90000) fail("a mochila não foi aberta em 90 s");
                    return;
                }
                pageIdx = -1; scanned = false;
                go("scan");
                return;
            }

            if (st == "scan")
            {
                var bag:DisplayObject = UiHelper.find(rt, "EquipBagII");
                if (bag == null) { go("findbag"); return; }
                if (now - lastPress < 900) return;
                var bc:DisplayObjectContainer = bag as DisplayObjectContainer;
                var cells:Array = coinCells(bc);
                if (cells.length > 0)
                {
                    coinCell = cells[0];
                    say("Moeda VIP encontrada (" + ad.bagCellName(coinCell) + ")");
                    go("usecell");
                    return;
                }
                // sem moeda nesta aba: abre a próxima aba numerada da mochila (1 a 6)
                var tabs:Array = bagTabs(bc);
                if (tabs.length == 0)
                {
                    say('não achei as abas numeradas da mochila. Aperte "Diagnóstico da mochila" com ela aberta e mande o log.');
                    diagnose();
                    stop("não achei as abas da mochila", "fail");
                    return;
                }
                pageIdx++;
                if (pageIdx >= tabs.length)
                {
                    say("passei pelas " + tabs.length + " abas da mochila: não há mais Moeda VIP");
                    stop("acabaram as moedas VIP", "noCoin");
                    return;
                }
                status = "procurando a Moeda VIP (aba " + (pageIdx + 1) + " de " + tabs.length + ")";
                say("abrindo a aba " + (pageIdx + 1) + " de " + tabs.length + " da mochila");
                UiHelper.press(tabs[pageIdx]);
                lastPress = now;
                return;
            }

            if (st == "usecell")
            {
                status = "usando a Moeda VIP";
                if (UiHelper.find(rt, "VipBoxFrame") != null) { go("elevar"); return; }
                if (tries >= 5) { fail("não consegui usar a Moeda VIP (menu Usar não apareceu)"); return; }
                var menu:DisplayObject = UiHelper.find(rt, "GoodsItemMenu");
                var useBtn:DisplayObject = menu != null ? findButton(menu as DisplayObjectContainer, "usar") : null;
                if (useBtn != null)
                {
                    say("apertando Usar na Moeda VIP");
                    UiHelper.press(useBtn);
                    go("waitvip");
                    return;
                }
                if (now - lastPress > 1500)
                {
                    lastPress = now; tries++;
                    var ic:DisplayObject = coinCell is DisplayObjectContainer ? UiHelper.find(coinCell as DisplayObjectContainer, "BaseIconView") : null;
                    UiHelper.press(ic != null ? ic : coinCell);
                }
                return;
            }

            if (st == "waitvip")
            {
                status = "esperando a janela VIP";
                if (UiHelper.find(rt, "VipBoxFrame") != null) { elevarCount = 0; go("elevar"); return; }
                if (now - t0 > 15000) { say("a janela VIP não abriu: tentando usar a moeda de novo"); go("scan"); }
                return;
            }

            if (st == "elevar")
            {
                var vip:DisplayObject = UiHelper.find(rt, "VipBoxFrame");
                if (vip == null)
                {
                    // a janela fechou: gastou a moeda -> pega outra na mochila
                    say("a janela VIP fechou: procurando outra Moeda VIP");
                    go("findbag");
                    return;
                }
                var vc:DisplayObjectContainer = vip as DisplayObjectContainer;
                var items:String = readItems(vc);
                if (items != lastItem) { lastItem = items; say("itens na janela VIP: " + items); }
                if (clean(items).indexOf(clean(target)) >= 0) { say("achei \"" + target + "\": apertando Habilitar"); go("enable"); return; }
                if (now - lastPress < 600) return;
                var vb:Object = vipButtons(vc);
                if (vb == null)
                {
                    status = "botões da janela VIP não encontrados";
                    if (!diagDone) { diagDone = true; say("não achei os dois botões (Habilitar/Elevar) da janela VIP. Botões vistos: " + buttonsSeen(vc)); diagnose(); }
                    if (now - t0 > 25000) fail("botões da janela VIP não encontrados (mande o log)");
                    return;
                }
                var el:DisplayObject = vb.elevar;
                if (!diagDone) { diagDone = true; say("Elevar em " + pos(vb.elevar) + " | Habilitar em " + pos(vb.habilitar)); }
                t0 = now;
                elevarCount++;
                status = "elevando (" + elevarCount + " toques) · " + collected + "/" + goal;
                lastPress = now;
                UiHelper.press(el);
                return;
            }

            if (st == "enable")
            {
                var vip2:DisplayObject = UiHelper.find(rt, "VipBoxFrame");
                if (vip2 == null) { go("findbag"); return; }
                var vb2:Object = vipButtons(vip2 as DisplayObjectContainer);
                if (vb2 == null) { fail("botão Habilitar não encontrado (mande o log)"); return; }
                targetIdx = indexOfTarget(readItemsArr(vip2 as DisplayObjectContainer));
                pressN = 1;
                say("apertando Habilitar em " + pos(vb2.habilitar));
                UiHelper.press(vb2.habilitar);
                lastPress = now;
                go("enabling");
                return;
            }

            if (st == "enabling")
            {
                var vip3:DisplayObject = UiHelper.find(rt, "VipBoxFrame");
                if (vip3 == null) { say("janela VIP fechou depois do Habilitar"); if (gain(perCollect)) return; go("findbag"); return; }
                var arr3:Array = readItemsArr(vip3 as DisplayObjectContainer);
                var now3:String = arr3.join(" | ");
                status = "habilitando (toque " + pressN + ") · " + collected + "/" + goal;
                if (clean(now3).indexOf(clean(target)) < 0)
                {
                    // o slot da pedra passa a mostrar a quantidade ganha (ex.: 5)
                    var amt:int = 0;
                    if (targetIdx >= 0 && targetIdx < arr3.length && /^\d+$/.test(String(arr3[targetIdx]))) amt = int(arr3[targetIdx]);
                    if (gain(amt)) return;
                    elevarCount = 0; lastItem = "";
                    go("elevar");
                    return;
                }
                // ainda está lá: aperta Habilitar de novo a cada ~2,5 s (cada toque gira uma vez)
                if (now - lastPress > 2500)
                {
                    if (pressN >= 60) { stop("Habilitar não coletou em 60 toques", "limit"); return; }
                    var vb3:Object = vipButtons(vip3 as DisplayObjectContainer);
                    if (vb3 != null) { pressN++; lastPress = now; UiHelper.press(vb3.habilitar); }
                }
                return;
            }
        }
    }
}
