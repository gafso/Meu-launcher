package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.events.TimerEvent;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Macro da Moeda VIP (feito a partir da gravação do jogador):
    //   1) acha a "Moeda VIP" na mochila (confere todas as páginas) e aperta Usar;
    //   2) na janela VipBoxFrame aperta ELEVAR até aparecer o item desejado (Pedra secreta);
    //   3) aperta HABILITAR, que gira sozinho até coletar o item;
    //   4) volta a elevar até achar de novo, e repete. Para sozinho quando acabam as moedas.
    public class VipMacro
    {
        public var logger:Function;
        public var onFinish:Function;          // (código, motivo): parada definitiva (noCoin | limit | fail)
        public var running:Boolean = false;
        public var status:String = "parado";
        public var target:String = "pedra secreta";
        public var maxElevar:int = 400;        // trava de segurança: máximo de toques em Elevar por moeda usada
        public var collected:int = 0;

        private var ad:GamePlanesAdapter = new GamePlanesAdapter();
        private var timer:Timer;
        private var st:String = "idle";
        private var t0:int = 0;
        private var lastPress:int = 0;
        private var tries:int = 0;
        private var pageIdx:int = -1;
        private var scanned:Boolean = false;
        private var elevarCount:int = 0;
        private var coinCell:DisplayObject = null;
        private var lastItem:String = "";
        private var lastHint:int = 0;
        private var diagDone:Boolean = false;

        private function say(s:String):void { if (logger != null) logger("[VIP] " + s); }
        private function go(s:String):void { st = s; t0 = getTimer(); tries = 0; }
        private function root():DisplayObjectContainer { return SwfFixer.rootStage; }

        public function start():void
        {
            if (running) return;
            running = true; collected = 0; elevarCount = 0; pageIdx = -1; scanned = false; diagDone = false;
            lastItem = "";
            timer = new Timer(700);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            say("iniciado: procurando \"" + target + "\" (Moeda VIP > Elevar > Habilitar)");
            go(UiHelper.find(root(), "VipBoxFrame") != null ? "elevar" : "findbag");
        }

        public function stop(reason:String = "parado", code:String = ""):void
        {
            if (timer != null) { timer.stop(); timer.removeEventListener(TimerEvent.TIMER, onTick); timer = null; }
            var was:Boolean = running;
            if (was) say("parou: " + reason + " | coletados: " + collected);
            running = false; status = reason; st = "idle";
            if (was && code != "" && onFinish != null) onFinish(code, reason);
        }

        private function fail(msg:String):void { say("FALHOU: " + msg); stop("falhou: " + msg, "fail"); }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("ERRO: " + err.message); tries++; if (tries > 8) fail(err.message); }
        }

        // ---------- ajudantes ----------
        private static function clean(s:String):String { return GamePlanesAdapter.norm(s).split("\r").join(" ").split("\n").join(" "); }

        // Botão visível (de qualquer tipo comum) dentro de "from" cujo texto contém "label".
        private function findButton(from:DisplayObjectContainer, label:String):DisplayObject
        {
            var want:String = clean(label);
            for each (var cls:String in ["TextButton", "IconButton", "BaseButton", "MovieButton", "SelectedIconButton"])
            {
                var arr:Array = [];
                UiHelper.findAll(from, cls, arr, 12, 40);
                for (var i:int = 0; i < arr.length; i++)
                {
                    var tx:Array = [];
                    UiHelper.texts(arr[i], tx);
                    if (clean(tx.join(" ")).indexOf(want) >= 0) return arr[i];
                }
            }
            return null;
        }

        private function buttonsSeen(from:DisplayObjectContainer):String
        {
            var out:Array = [];
            for each (var cls:String in ["TextButton", "IconButton", "BaseButton", "MovieButton"])
            {
                var arr:Array = [];
                UiHelper.findAll(from, cls, arr, 12, 20);
                for (var i:int = 0; i < arr.length; i++)
                {
                    var tx:Array = [];
                    UiHelper.texts(arr[i], tx);
                    out.push(cls + "[" + tx.join("/") + "]");
                }
            }
            return out.join(" ");
        }

        // Nomes dos itens mostrados na janela VIP (VipBoxItem); cai para os textos se o jogo não expõe o nome.
        private function readItems(vip:DisplayObjectContainer):String
        {
            var its:Array = [];
            UiHelper.findAll(vip, "VipBoxItem", its, 12, 12);
            var names:Array = [];
            for (var i:int = 0; i < its.length; i++)
            {
                var n:String = "";
                try { n = ad.bagCellName(its[i]); } catch (e0:Error) {}
                if (n == "?" || n.length == 0 || n.indexOf("(x") == 0)
                {
                    var bi:DisplayObject = UiHelper.find(its[i] as DisplayObjectContainer, "BaseItemView");
                    if (bi != null) { try { n = ad.bagCellName(bi); } catch (e1:Error) {} }
                }
                if (n == "?" || n.length == 0 || n.indexOf("(x") == 0)
                {
                    var tx:Array = [];
                    UiHelper.texts(its[i], tx);
                    n = tx.join("/");
                }
                names.push(n);
            }
            return names.join(" | ");
        }

        private function coinCells(frame:DisplayObjectContainer):Array
        {
            var cells:Array = [];
            UiHelper.findAll(frame, "PlayerBagCell", cells, 14, 80);
            var out:Array = [];
            for (var i:int = 0; i < cells.length; i++)
            {
                var n:String = "";
                try { n = clean(ad.bagCellName(cells[i])); } catch (e:Error) {}
                if (n.indexOf("moeda vip") >= 0) out.push(cells[i]);
            }
            return out;
        }

        // ---------- máquina de estados ----------
        private function step():void
        {
            var rt:DisplayObjectContainer = root();
            var now:int = getTimer();
            var i:int;

            if (st == "findbag")
            {
                if (UiHelper.find(rt, "VipBoxFrame") != null) { go("elevar"); return; }
                var frame:DisplayObject = UiHelper.find(rt, "EquipBagII");
                if (frame == null)
                {
                    status = "abra a mochila (personagem > mochila)";
                    if (now - lastHint > 6000) { lastHint = now; say("abra a mochila do personagem: preciso da tela com os itens"); }
                    if (now - t0 > 90000) fail("a mochila não foi aberta em 90 s");
                    return;
                }
                pageIdx = -1; scanned = false;
                go("scan");
                return;
            }

            if (st == "scan")
            {
                var bag:DisplayObject = UiHelper.find(rt, "EquipBagII");
                if (bag == null) { go("findbag"); return; }
                if (now - lastPress < 700) return;
                var cells:Array = coinCells(bag as DisplayObjectContainer);
                if (cells.length > 0)
                {
                    coinCell = cells[0];
                    say("Moeda VIP encontrada na página " + (pageIdx + 1) + " (" + ad.bagCellName(coinCell) + ")");
                    go("usecell");
                    return;
                }
                // não achou nesta página: passa para a próxima aba/página da mochila
                var host:DisplayObject = UiHelper.find(rt, "ArmyFrameII");
                var tabs:Array = [];
                if (host != null) UiHelper.findAll(host as DisplayObjectContainer, "SelectedIconButton", tabs, 10, 14);
                tabs.sort(function(a:DisplayObject, b:DisplayObject):int { return int(UiHelper.gx(a) - UiHelper.gx(b)); });
                pageIdx++;
                status = "procurando a Moeda VIP (página " + (pageIdx + 1) + ")";
                if (pageIdx >= tabs.length)
                {
                    say("passei por " + tabs.length + " páginas da mochila e não há mais Moeda VIP");
                    stop("acabaram as moedas VIP", "noCoin");
                    return;
                }
                say("Moeda VIP não está nesta página: abrindo a página " + (pageIdx + 1) + " de " + tabs.length);
                UiHelper.press(tabs[pageIdx]);
                lastPress = now;
                return;
            }

            if (st == "usecell")
            {
                status = "usando a Moeda VIP";
                if (UiHelper.find(rt, "VipBoxFrame") != null) { go("elevar"); return; }
                if (tries >= 5) { fail("não consegui usar a Moeda VIP (menu Usar não apareceu)"); return; }
                var menu:DisplayObject = UiHelper.find(rt, "GoodsItemMenu");
                var useBtn:DisplayObject = menu != null ? findButton(menu as DisplayObjectContainer, "usar") : null;
                if (useBtn != null)
                {
                    say("apertando Usar na Moeda VIP");
                    UiHelper.press(useBtn);
                    go("waitvip");
                    return;
                }
                if (now - lastPress > 1500)
                {
                    lastPress = now; tries++;
                    var ic:DisplayObject = coinCell is DisplayObjectContainer ? UiHelper.find(coinCell as DisplayObjectContainer, "BaseIconView") : null;
                    UiHelper.press(ic != null ? ic : coinCell);
                }
                return;
            }

            if (st == "waitvip")
            {
                status = "esperando a janela VIP";
                if (UiHelper.find(rt, "VipBoxFrame") != null) { elevarCount = 0; go("elevar"); return; }
                if (now - t0 > 8000) { say("a janela VIP não abriu: tentando usar a moeda de novo"); go("scan"); }
                return;
            }

            if (st == "elevar")
            {
                var vip:DisplayObject = UiHelper.find(rt, "VipBoxFrame");
                if (vip == null)
                {
                    // a janela fechou: gastou a moeda -> pega outra na mochila
                    say("a janela VIP fechou: procurando outra Moeda VIP");
                    go("findbag");
                    return;
                }
                var vc:DisplayObjectContainer = vip as DisplayObjectContainer;
                var items:String = readItems(vc);
                if (items != lastItem) { lastItem = items; say("itens na janela VIP: " + items); }
                if (clean(items).indexOf(clean(target)) >= 0) { say("achei \"" + target + "\": apertando Habilitar"); go("enable"); return; }
                if (now - lastPress < 600) return;
                var el:DisplayObject = findButton(vc, "elevar");
                if (el == null)
                {
                    status = "botão Elevar não encontrado";
                    if (!diagDone) { diagDone = true; say("não achei o botão Elevar. Botões vistos: " + buttonsSeen(vc)); }
                    if (now - t0 > 25000) fail("botão Elevar não encontrado (mande o log)");
                    return;
                }
                t0 = now;
                elevarCount++;
                if (elevarCount > maxElevar) { stop("limite de segurança: " + maxElevar + " toques em Elevar", "limit"); return; }
                status = "elevando (" + elevarCount + ")";
                lastPress = now;
                UiHelper.press(el);
                return;
            }

            if (st == "enable")
            {
                var vip2:DisplayObject = UiHelper.find(rt, "VipBoxFrame");
                if (vip2 == null) { go("findbag"); return; }
                var hb:DisplayObject = findButton(vip2 as DisplayObjectContainer, "habilitar");
                if (hb == null)
                {
                    if (!diagDone) { diagDone = true; say("não achei o botão Habilitar. Botões vistos: " + buttonsSeen(vip2 as DisplayObjectContainer)); }
                    if (now - t0 > 15000) fail("botão Habilitar não encontrado (mande o log)");
                    return;
                }
                UiHelper.press(hb);
                lastPress = now;
                go("enabling");
                return;
            }

            if (st == "enabling")
            {
                var vip3:DisplayObject = UiHelper.find(rt, "VipBoxFrame");
                if (vip3 == null) { collected++; say("janela VIP fechou depois do Habilitar (coletados: " + collected + ")"); go("findbag"); return; }
                var now3:String = readItems(vip3 as DisplayObjectContainer);
                status = "habilitado: girando até coletar (" + collected + " coletados)";
                if (clean(now3).indexOf(clean(target)) < 0)
                {
                    collected++;
                    say("item coletado (" + collected + " no total); voltando a elevar");
                    elevarCount = 0; lastItem = "";
                    go("elevar");
                    return;
                }
                if (now - t0 > 90000) { say("o Habilitar passou de 90 s sem coletar: volto a elevar"); go("elevar"); }
                return;
            }
        }
    }
}
