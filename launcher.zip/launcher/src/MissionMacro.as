package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.geom.Point;
    import flash.geom.Rectangle;
    import flash.text.TextField;
    import flash.utils.Timer;
    import flash.utils.getTimer;

    // Macro do Ciclo de missões (v1, montado a partir da gravação do jogador).
    // O que ele sabe fazer:
    //   - Lê o painel de missões (TaskTraceView) e acha a missão de ciclo (a que tem "ciclos" no texto).
    //   - "(Entregar)": toca no título da missão para ir entregar.
    //   - Mata-Rato: toca no objetivo para abrir o minijogo e fica tocando nos buracos (HamsterGameFrame);
    //     quando a rodada acaba sem bater a meta, aperta o botão de tentar de novo.
    //   - Qualquer outra missão: avisa no log que ainda não sabe e espera você fazer à mão (não toca em nada).
    public class MissionMacro
    {
        public var logger:Function;
        public var running:Boolean = false;
        public var status:String = "parado";
        public var ratRounds:int = 0;        // rodadas de rato jogadas desde que iniciou
        public var ratTotal:int = 0;         // vezes que o minijogo foi aberto

        // Buracos do minijogo (coordenadas de palco tiradas da gravação; referência: botão X em ~(988,170)).
        private static const HOLES:Array = [
            [595, 255], [585, 425], [595, 395], [635, 390], [700, 325], [705, 360], [765, 250],
            [775, 375], [835, 320], [870, 325], [878, 380], [905, 405], [920, 245], [955, 248]
        ];
        private static const REF_X:Number = 988;
        private static const REF_Y:Number = 170;
        private static const MAX_ROUNDS:int = 15;   // tentativas seguidas de uma mesma missão de rato

        private var timer:Timer;
        private var frame:DisplayObject = null;      // janela do rato aberta (guardada para não procurar a cada toque)
        private var gback:DisplayObject = null;
        private var closeBtn:DisplayObject = null;
        private var dx:Number = 0;
        private var dy:Number = 0;
        private var holeIdx:int = 0;
        private var lastFind:int = 0;
        private var lastTrace:int = 0;
        private var lastPress:int = 0;
        private var lastRetry:int = 0;
        private var lastRatLog:int = 0;
        private var roundsThisWindow:int = 0;
        private var lastSig:String = "";
        private var lastWarn:String = "";
        private var qteSeen:Boolean = false;

        private function say(s:String):void { if (logger != null) logger("[MISSÕES] " + s); }
        private function root():DisplayObjectContainer { return SwfFixer.rootStage; }

        public function start():void
        {
            if (running) return;
            running = true;
            status = "procurando a missão de ciclo...";
            frame = null; gback = null; closeBtn = null;
            roundsThisWindow = 0; lastSig = ""; lastWarn = ""; qteSeen = false;
            ratRounds = 0; ratTotal = 0;
            timer = new Timer(60);
            timer.addEventListener(TimerEvent.TIMER, onTick);
            timer.start();
            say("ligado");
        }

        public function stop(reason:String = "parado"):void
        {
            if (!running) return;
            running = false;
            status = reason;
            if (timer != null) { timer.stop(); timer.removeEventListener(TimerEvent.TIMER, onTick); timer = null; }
            frame = null; gback = null; closeBtn = null;
            say(reason);
        }

        private function onTick(e:TimerEvent):void
        {
            try { step(); }
            catch (err:Error) { say("erro: " + err.message); }
        }

        private function step():void
        {
            var r:DisplayObjectContainer = root();
            if (r == null) return;
            var now:int = getTimer();

            // 1) minijogo do rato aberto: toca nos buracos (usa a referência guardada; só procura de novo a cada 0,4 s)
            if (frame != null && (frame.stage == null || !frame.visible)) { frame = null; gback = null; closeBtn = null; onRatClosed(); }
            if (frame == null && now - lastFind > 400)
            {
                lastFind = now;
                var f:DisplayObject = UiHelper.find(r, "HamsterGameFrame", 6);
                if (f != null) onRatOpened(f);
            }
            if (frame != null) { ratStep(now); return; }

            // 2) treino QTE: ainda não sei ler as setas; descreve a janela uma vez para eu montar depois
            if (now - lastTrace > 1000)
            {
                lastTrace = now;
                var q:DisplayObject = UiHelper.find(r, "QTETraining", 6);
                if (q != null)
                {
                    status = "QTE aberto: faça à mão (botões WASD)";
                    if (!qteSeen) { qteSeen = true; say("QTE aberto. Descrevendo a janela para o log:"); dump(q as DisplayObjectContainer, 0, 5, [0]); }
                    return;
                }
                qteSeen = false;
                traceStep(r, now);
            }
        }

        // ---------- rato ----------
        private function onRatOpened(f:DisplayObject):void
        {
            frame = f;
            ratTotal++;
            gback = UiHelper.find(f as DisplayObjectContainer, "GameBack", 6);
            closeBtn = null;
            dx = 0; dy = 0;
            if (gback != null)
            {
                // acha o botão X (BaseButton dentro do GameBack) para corrigir a posição se a janela estiver deslocada
                closeBtn = UiHelper.find(gback as DisplayObjectContainer, "BaseButton", 4);
                if (closeBtn != null && closeBtn.stage != null)
                {
                    var rc:Rectangle = closeBtn.getBounds(closeBtn.stage);
                    var ddx:Number = rc.x + rc.width / 2 - REF_X;
                    var ddy:Number = rc.y + rc.height / 2 - REF_Y;
                    if (Math.abs(ddx) <= 300 && Math.abs(ddy) <= 300) { dx = ddx; dy = ddy; }
                    say("rato aberto: botão X em (" + int(rc.x + rc.width / 2) + "," + int(rc.y + rc.height / 2) + "), deslocamento (" + int(dx) + "," + int(dy) + ")");
                }
                else say("rato aberto (sem botão X reconhecido; uso as posições da gravação)");
            }
            else say("rato aberto, mas não achei o GameBack para tocar");
            roundsThisWindow = 0;
            lastRetry = getTimer();
        }

        private function onRatClosed():void
        {
            say("janela do rato fechou (rodadas nesta missão: " + (roundsThisWindow + 1) + ")");
            roundsThisWindow = 0;
            lastPress = getTimer();   // dá um tempo para o painel de missões atualizar antes de mexer nele
            lastTrace = getTimer();
        }

        private function readRat(out:Object):void
        {
            var tx:Array = [];
            scanTexts(frame, tx, 0);
            out.score = -1; out.goal = -1; out.secs = -1;
            var re:RegExp = /^\s*(\d+)\s*\/\s*(\d+)\s*$/;
            var re2:RegExp = /^\s*(\d{1,2})\s*$/;
            for (var i:int = 0; i < tx.length; i++)
            {
                var s:String = String(tx[i]);
                var m:Object = re.exec(s);
                if (m != null && out.score < 0) { out.score = int(m[1]); out.goal = int(m[2]); continue; }
                var m2:Object = re2.exec(s);
                if (m2 != null && out.secs < 0) out.secs = int(m2[1]);
            }
        }

        private function ratStep(now:int):void
        {
            var info:Object = {};
            readRat(info);
            status = "Mata-Rato: " + (info.score >= 0 ? info.score + "/" + info.goal : "?") + (info.secs >= 0 ? " · " + info.secs + "s" : "") + " · rodada " + (roundsThisWindow + 1);
            if (now - lastRatLog > 3000) { lastRatLog = now; say(status); }

            // fim da rodada: botão "tentar de novo" (IconButton direto na janela) aparece quando o tempo zera
            var retry:DisplayObject = null;
            if (info.secs == 0 || info.secs < 0)
            {
                var arr:Array = [];
                UiHelper.findAll(frame as DisplayObjectContainer, "IconButton", arr, 3, 4);
                if (arr.length > 0) retry = arr[0];
            }
            if (retry != null && info.secs == 0 && now - lastRetry > 1500)
            {
                lastRetry = now;
                roundsThisWindow++;
                ratRounds++;
                if (roundsThisWindow >= MAX_ROUNDS) { stop("Mata-Rato: " + MAX_ROUNDS + " rodadas sem bater a meta; parei"); return; }
                say("rodada acabou em " + info.score + "/" + info.goal + "; tentando de novo (" + roundsThisWindow + ")");
                UiHelper.press(retry);
                return;
            }
            if (info.secs == 0) return;   // fim de rodada sem botão ainda: espera

            if (gback == null || gback.stage == null) return;
            // 2 toques por ciclo (~33 por segundo), passando pelos buracos em sequência
            for (var k:int = 0; k < 2; k++)
            {
                var h:Array = HOLES[holeIdx % HOLES.length] as Array;
                holeIdx++;
                tap(gback, Number(h[0]) + dx, Number(h[1]) + dy);
            }
        }

        private function tap(target:DisplayObject, sx:Number, sy:Number):void
        {
            var p:Point = target.globalToLocal(new Point(sx, sy));
            target.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_DOWN, true, false, p.x, p.y));
            target.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_UP, true, false, p.x, p.y));
            target.dispatchEvent(new MouseEvent(MouseEvent.CLICK, true, false, p.x, p.y));
        }

        // ---------- painel de missões ----------
        private function traceStep(r:DisplayObjectContainer, now:int):void
        {
            var items:Array = [];
            UiHelper.findAll(r, "TaskTraceItem", items, 16, 12);
            if (items.length == 0)
            {
                status = "painel de missões vazio ou fechado";
                warnOnce("não achei o painel de missões (TaskTraceView). Abra a lista de missões do lado direito.");
                return;
            }
            var cyc:DisplayObject = null;
            var cycText:String = "";
            var sig:Array = [];
            for (var i:int = 0; i < items.length; i++)
            {
                var tx:Array = [];
                scanTexts(items[i], tx, 0);
                var joined:String = tx.join(" / ");
                sig.push(joined);
                if (cyc == null && GamePlanesAdapter.norm(joined).indexOf("ciclo") >= 0) { cyc = items[i]; cycText = joined; }
            }
            var sg:String = sig.join(" || ");
            if (sg != lastSig) { lastSig = sg; say("painel: " + (sg.length > 200 ? sg.substr(0, 200) : sg)); }

            if (cyc == null)
            {
                status = "sem missão de ciclo no painel: pegue no NPC";
                warnOnce("não vejo a missão de ciclo no painel (procuro o texto \"ciclos\"). Pegue a missão com o NPC.");
                return;
            }
            var n:String = GamePlanesAdapter.norm(cycText);
            var shortTxt:String = cycText.length > 60 ? cycText.substr(0, 60) : cycText;

            if (n.indexOf("entregar") >= 0)
            {
                status = "entregando: " + shortTxt;
                if (now - lastPress > 8000)
                {
                    lastPress = now;
                    var head:DisplayObject = UiHelper.find(cyc as DisplayObjectContainer, "Scale9CornerImage", 4);
                    say("missão pronta, tocando para entregar: " + shortTxt);
                    UiHelper.press(head != null ? head : cyc);
                }
                return;
            }
            if (/mata.?rato/.test(n))
            {
                status = "abrindo o Mata-Rato: " + shortTxt;
                if (now - lastPress > 8000)
                {
                    lastPress = now;
                    var tg:DisplayObject = UiHelper.find(cyc as DisplayObjectContainer, "TraceTaskTargetItem", 8);
                    say("tocando no objetivo do Mata-Rato");
                    UiHelper.press(tg != null ? tg : cyc);
                }
                return;
            }
            status = "missão ainda não automatizada: " + shortTxt;
            warnOnce("missão que ainda não sei fazer: " + shortTxt + ". Faça à mão; o macro espera e continua quando mudar.");
        }

        private function warnOnce(s:String):void
        {
            if (s == lastWarn) return;
            lastWarn = s;
            say(s);
        }

        // ---------- utilidades ----------
        private function scanTexts(o:DisplayObject, out:Array, depth:int):void
        {
            if (o == null || depth > 8 || out.length >= 40) return;
            if (o is TextField)
            {
                var t:String = TextField(o).text;
                if (t != null && t.length > 0) out.push(t);
                return;
            }
            if (o is DisplayObjectContainer)
            {
                var c:DisplayObjectContainer = o as DisplayObjectContainer;
                for (var i:int = 0; i < c.numChildren; i++)
                {
                    try { scanTexts(c.getChildAt(i), out, depth + 1); } catch (e:Error) {}
                }
            }
        }

        // Descreve a árvore de uma janela (classe, posição no palco e texto) para o log.
        private function dump(o:DisplayObjectContainer, depth:int, maxDepth:int, count:Array):void
        {
            if (o == null || depth > maxDepth || count[0] >= 50) return;
            var n:int = 0;
            try { n = o.numChildren; } catch (e0:Error) { return; }
            for (var i:int = 0; i < n && count[0] < 50; i++)
            {
                try
                {
                    var ch:DisplayObject = o.getChildAt(i);
                    if (ch == null || !ch.visible) continue;
                    var rc:Rectangle = ch.getBounds(ch.stage);
                    var tx:String = (ch is TextField) ? (" \"" + TextField(ch).text + "\"") : "";
                    var pad:String = "";
                    for (var d:int = 0; d < depth; d++) pad += " ";
                    say(pad + UiHelper.sn(ch) + " @" + int(rc.x) + "," + int(rc.y) + " " + int(rc.width) + "x" + int(rc.height) + tx);
                    count[0]++;
                    if (ch is DisplayObjectContainer) dump(ch as DisplayObjectContainer, depth + 1, maxDepth, count);
                }
                catch (e:Error) {}
            }
        }
    }
}
