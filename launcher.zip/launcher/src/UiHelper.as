package
{
    import flash.display.DisplayObject;
    import flash.display.DisplayObjectContainer;
    import flash.events.MouseEvent;
    import flash.geom.Point;
    import flash.text.TextField;
    import flash.utils.getQualifiedClassName;

    // Ajudantes para achar e "apertar" botões/janelas do jogo pela árvore de exibição (palco).
    public class UiHelper
    {
        public static function sn(o:Object):String
        {
            var n:String = getQualifiedClassName(o);
            var i:int = n.lastIndexOf("::");
            return i >= 0 ? n.substr(i + 2) : n;
        }

        // Primeiro objeto VISÍVEL com esse nome de classe (busca em largura: acha o mais raso primeiro).
        public static function find(from:DisplayObjectContainer, cls:String, maxDepth:int = 12):DisplayObject
        {
            var out:Array = [];
            findAll(from, cls, out, maxDepth, 1);
            return out.length > 0 ? out[0] : null;
        }

        public static function findAll(from:DisplayObjectContainer, cls:String, out:Array, maxDepth:int = 12, limit:int = 60):void
        {
            if (from == null) return;
            var queue:Array = [from, 0];
            var seen:int = 0;
            while (queue.length > 0 && seen < 4000 && out.length < limit)
            {
                var c:DisplayObjectContainer = queue.shift();
                var d:int = queue.shift();
                for (var i:int = 0; i < c.numChildren; i++)
                {
                    var ch:DisplayObject;
                    try { ch = c.getChildAt(i); } catch (e:Error) { continue; }
                    seen++;
                    if (!ch.visible) continue;
                    if (sn(ch) == cls) { out.push(ch); if (out.length >= limit) return; }
                    if (ch is DisplayObjectContainer && d < maxDepth) { queue.push(ch); queue.push(d + 1); }
                }
            }
        }

        public static function texts(o:DisplayObject, out:Array, depth:int = 0):void
        {
            if (depth > 6 || out.length > 12) return;
            if (o is TextField) { var t:String = TextField(o).text; if (t != null && t.length > 0) out.push(t); return; }
            if (o is DisplayObjectContainer)
            {
                var c:DisplayObjectContainer = o as DisplayObjectContainer;
                for (var i:int = 0; i < c.numChildren; i++)
                {
                    try { texts(c.getChildAt(i), out, depth + 1); } catch (e:Error) {}
                }
            }
        }

        public static function hasText(o:DisplayObject, s:String):Boolean
        {
            var t:Array = [];
            texts(o, t);
            return t.join("|").indexOf(s) >= 0;
        }

        // Posição X global (para distinguir botão da esquerda/direita).
        public static function gx(o:DisplayObject):Number
        {
            try { return o.localToGlobal(new Point(0, 0)).x; } catch (e:Error) {}
            return 0;
        }

        // Simula o toque: apertar, soltar, clicar (e, se pedido, duplo clique).
        public static function press(o:DisplayObject, dbl:Boolean = false):void
        {
            if (o == null) return;
            o.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_DOWN, true, false, 5, 5));
            o.dispatchEvent(new MouseEvent(MouseEvent.MOUSE_UP, true, false, 5, 5));
            o.dispatchEvent(new MouseEvent(MouseEvent.CLICK, true, false, 5, 5));
            if (dbl) o.dispatchEvent(new MouseEvent(MouseEvent.DOUBLE_CLICK, true, false, 5, 5));
        }
    }
}
