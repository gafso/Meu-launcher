package
{
    import flash.net.SharedObject;

    // Preferências salvas no aparelho (SharedObject).
    public class Prefs
    {
        private static var so:SharedObject = SharedObject.getLocal("meulauncher");

        public static function get platform():int      { return int(so.data.platform); }
        public static function set platform(v:int):void { so.data.platform = v; so.flush(); }

        // "LOW" | "MEDIUM" | "HIGH"
        public static function get quality():String    { return so.data.quality ? String(so.data.quality) : "MEDIUM"; }
        public static function set quality(v:String):void { so.data.quality = v; so.flush(); }

        public static function get fps():int           { return so.data.fps ? int(so.data.fps) : 30; }
        public static function set fps(v:int):void     { so.data.fps = v; so.flush(); }

        public static function get controls():Boolean  { return so.data.controls === undefined ? true : Boolean(so.data.controls); }
        public static function set controls(v:Boolean):void { so.data.controls = v; so.flush(); }

        // Altura da resolução do jogo em pixels (0 = nativa da tela).
        // Padrão: Modo PC 1250x650 (100000). Valores salvos por versões antigas (< v1.7) são descartados.
        public static function get resHeight():int
        {
            if (so.data.resVer != 2) { so.data.resVer = 2; so.data.resHeight = 100000; so.flush(); }
            return so.data.resHeight === undefined ? 100000 : int(so.data.resHeight);
        }
        public static function set resHeight(v:int):void { so.data.resVer = 2; so.data.resHeight = v; so.flush(); }

        // Fonte aplicada aos textos do jogo ("" = a do próprio jogo).
        public static function get font():String       { return so.data.font ? String(so.data.font) : ""; }
        public static function set font(v:String):void { so.data.font = v; so.flush(); }

        public static function get zoom():Number       { return so.data.zoom ? Number(so.data.zoom) : 1; }
        public static function set zoom(v:Number):void { so.data.zoom = v; so.flush(); }
    }
}
