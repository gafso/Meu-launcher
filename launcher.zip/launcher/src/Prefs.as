package
{
    import flash.net.SharedObject;

    // Preferências salvas no aparelho (SharedObject).
    public class Prefs
    {
        private static var so:SharedObject = SharedObject.getLocal("meulauncher");

        public static function get platform():int      { return int(so.data.platform); }
        public static function set platform(v:int):void { so.data.platform = v; so.flush(); }

        // "LOW" | "MEDIUM" | "HIGH"
        public static function get quality():String    { return so.data.quality ? String(so.data.quality) : "MEDIUM"; }
        public static function set quality(v:String):void { so.data.quality = v; so.flush(); }

        public static function get fps():int           { return so.data.fps ? int(so.data.fps) : 30; }
        public static function set fps(v:int):void     { so.data.fps = v; so.flush(); }

        public static function get controls():Boolean  { return so.data.controls === undefined ? true : Boolean(so.data.controls); }
        public static function set controls(v:Boolean):void { so.data.controls = v; so.flush(); }

        public static function get zoom():Number       { return so.data.zoom ? Number(so.data.zoom) : 1; }
        public static function set zoom(v:Number):void { so.data.zoom = v; so.flush(); }
    }
}
