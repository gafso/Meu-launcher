package
{
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
        import flash.geom.Matrix;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;

    // Botão do launcher. A origem (0,0) fica no CENTRO do botão.
    //   PRIMARY = botão de destaque (JOGAR)      CARD = cartão com legenda + seta (plataforma)
    //   GHOST   = botão discreto (ações secundárias)
    public class Btn extends Sprite
    {
        public static const PRIMARY:int = 0;
        public static const CARD:int    = 1;
        public static const GHOST:int   = 2;

        // Paleta do launcher (tema escuro de programa de PC; usada também pela tela inicial).
        public static const ACCENT:uint      = 0x0E7AD1;
        public static const ACCENT_LIGHT:uint = 0x2B95EA;
        public static const ACCENT_DARK:uint = 0x0B5A9C;
        public static const TEXT:uint        = 0xF0F0F0;
        public static const TEXT_SOFT:uint   = 0xD0D0D0;
        public static const TEXT_MUTED:uint  = 0x9A9A9A;
        public static const SURFACE:uint     = 0x252526;
        public static const BORDER:uint      = 0x3F3F46;

        private var over:Boolean = false;
        private var down:Boolean = false;
        private var kind:int;
        private var lbl:TextField;
        private var lblDx:Number = 0;
        private var bw:Number;
        private var bh:Number;

        public function Btn(kind:int, w:Number, h:Number, text:String, caption:String = "", onClick:Function = null)
        {
            this.kind = kind; bw = w; bh = h;
            mouseChildren = false;
            buttonMode = true;
            draw();
            if (kind == PRIMARY) addPrimaryLabel(text);
            else if (kind == CARD) addCardLabel(text, caption);
            else addCenterLabel(text, 13, TEXT_SOFT);
            if (onClick != null) addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            addEventListener(MouseEvent.MOUSE_DOWN, onDown);
            addEventListener(MouseEvent.MOUSE_UP, onUp);
            addEventListener(MouseEvent.ROLL_OVER, onOver);
            addEventListener(MouseEvent.ROLL_OUT, onOut);
        }

        private function onDown(e:MouseEvent):void { down = true; draw(); }
        private function onUp(e:MouseEvent):void   { down = false; draw(); }
        private function onOver(e:MouseEvent):void { over = true; draw(); }
        private function onOut(e:MouseEvent):void  { over = false; down = false; draw(); }

        // ---------- desenho do fundo ----------
        private function draw():void
        {
            var g:Graphics = graphics;
            g.clear();
            filters = [];
            if (kind == PRIMARY)
            {
                g.lineStyle(1, ACCENT_DARK, 1);
                g.beginFill(down ? ACCENT_DARK : (over ? ACCENT_LIGHT : ACCENT), 1);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, 6, 6);
                g.endFill();
            }
            else if (kind == CARD)
            {
                g.lineStyle(1, (over || down) ? ACCENT : BORDER, 1);
                g.beginFill(down ? 0x2A2A2D : (over ? 0x252526 : 0x1B1B1C), 1);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, 4, 4);
                g.endFill();
                // seta de lista suspensa (v) à direita
                var cx:Number = bw / 2 - 22;
                g.lineStyle(2, TEXT_SOFT, 1, false, "normal", "none", "miter");
                g.moveTo(cx - 5, -2); g.lineTo(cx, 3); g.lineTo(cx + 5, -2);
            }
            else
            {
                g.lineStyle(1, (over || down) ? 0x6E6E76 : 0x4A4A50, 1);
                g.beginFill(down ? 0x2A2A2D : (over ? 0x3E3E42 : 0x333337), 1);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, 6, 6);
                g.endFill();
            }
        }

        // ---------- textos ----------
        private function makeText(t:String, size:int, color:uint, spacing:Number = 0):TextField
        {
            var tf:TextField = new TextField();
            var f:TextFormat = new TextFormat("_sans", size, color, true);
            f.letterSpacing = spacing;
            tf.defaultTextFormat = f;
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            return tf;
        }

        private function addCenterLabel(t:String, size:int, color:uint):void
        {
            var tf:TextField = makeText(t, size, color);
            tf.x = -tf.width / 2; tf.y = -tf.height / 2;
            addChild(tf);
            lbl = tf; lblDx = 0;
        }

        // Troca o texto de um botão GHOST ou PRIMARY (o texto fica centralizado).
        public function setText(t:String):void
        {
            if (lbl == null || lbl.text == t) return;
            lbl.text = t;
            var tfm:TextFormat = lbl.defaultTextFormat;
            var sz:int = int(tfm.size);
            while (lbl.width > 142 && sz > 8)
            {
                sz--;
                tfm.size = sz;
                lbl.defaultTextFormat = tfm;
                lbl.setTextFormat(tfm);
            }
            lbl.x = -lbl.width / 2 + lblDx;
            lbl.y = -lbl.height / 2;
        }

        // Texto do botão principal: maiúsculas com espaçamento largo, centralizado.
        private function addPrimaryLabel(t:String):void
        {
            var tf:TextField = makeText(t, 16, TEXT, 0);
            tf.x = -tf.width / 2; tf.y = -tf.height / 2;
            addChild(tf);
            lbl = tf; lblDx = 0;
        }

        // Legenda pequena (ex.: SERVIDOR) + nome em destaque.
        private function addCardLabel(name:String, caption:String):void
        {
            var cap:TextField = makeText(caption, 10, TEXT_MUTED, 0);
            var nm:TextField = makeText(name, 15, TEXT);
            var total:Number = cap.height + nm.height - 2;
            cap.x = -bw / 2 + 20; cap.y = -total / 2;
            nm.x = -bw / 2 + 20;  nm.y = cap.y + cap.height - 2;
            addChild(cap); addChild(nm);
        }
    }
}
