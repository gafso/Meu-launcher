package
{
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.filters.DropShadowFilter;
    import flash.geom.Matrix;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;

    // Botão do launcher. A origem (0,0) fica no CENTRO do botão.
    //   PRIMARY = botão de destaque (JOGAR)      CARD = cartão com legenda + seta (plataforma)
    //   GHOST   = botão discreto (ações secundárias)
    public class Btn extends Sprite
    {
        public static const PRIMARY:int = 0;
        public static const CARD:int    = 1;
        public static const GHOST:int   = 2;

        // Paleta do launcher (usada também pela tela inicial).
        public static const ACCENT:uint      = 0xE5262F;
        public static const ACCENT_LIGHT:uint = 0xF2434B;
        public static const ACCENT_DARK:uint = 0x8C0F17;
        public static const TEXT:uint        = 0xFFFFFF;
        public static const TEXT_SOFT:uint   = 0xF2DCDC;
        public static const TEXT_MUTED:uint  = 0xB59A9D;
        public static const SURFACE:uint     = 0x120709;
        public static const BORDER:uint      = 0x5A1B22;

        private var kind:int;
        private var bw:Number;
        private var bh:Number;

        public function Btn(kind:int, w:Number, h:Number, text:String, caption:String = "", onClick:Function = null)
        {
            this.kind = kind; bw = w; bh = h;
            mouseChildren = false;
            buttonMode = true;
            draw();
            if (kind == PRIMARY) addPrimaryLabel(text);
            else if (kind == CARD) addCardLabel(text, caption);
            else addCenterLabel(text, 13, TEXT_SOFT);
            if (onClick != null) addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            addEventListener(MouseEvent.MOUSE_DOWN, onDown);
            addEventListener(MouseEvent.MOUSE_UP, onUp);
            addEventListener(MouseEvent.ROLL_OUT, onUp);
        }

        private function onDown(e:MouseEvent):void { scaleX = scaleY = 0.96; alpha = 0.88; }
        private function onUp(e:MouseEvent):void   { scaleX = scaleY = 1; alpha = 1; }

        // ---------- desenho do fundo ----------
        private function draw():void
        {
            var g:Graphics = graphics;
            g.clear();
            var r:Number = kind == GHOST ? 12 : 14;
            if (kind == PRIMARY)
            {
                var m:Matrix = new Matrix();
                m.createGradientBox(bw, bh, Math.PI / 2, -bw / 2, -bh / 2);
                g.beginGradientFill(GradientType.LINEAR, [ACCENT_LIGHT, ACCENT_DARK], [1, 1], [0, 255], m);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, r * 2, r * 2);
                g.endFill();
                // brilho fino no topo
                g.beginFill(0xFFFFFF, 0.14);
                g.drawRoundRect(-bw / 2 + 3, -bh / 2 + 3, bw - 6, bh * 0.4, r * 1.4, r * 1.4);
                g.endFill();
                filters = [new DropShadowFilter(0, 90, ACCENT, 0.6, 24, 24, 1, 3)];
            }
            else if (kind == CARD)
            {
                g.lineStyle(1.5, BORDER, 1);
                g.beginFill(SURFACE, 0.82);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, r * 2, r * 2);
                g.endFill();
                // marca vermelha na lateral esquerda
                g.lineStyle(0, 0, 0);
                g.beginFill(ACCENT, 1);
                g.drawRoundRect(-bw / 2 + 1, -bh / 2 + 13, 4, bh - 26, 4, 4);
                g.endFill();
                // seta (chevron) à direita
                var cx:Number = bw / 2 - 28;
                g.lineStyle(3, ACCENT_LIGHT, 1, false, "normal", "round", "round");
                g.moveTo(cx - 5, -8); g.lineTo(cx + 3, 0); g.lineTo(cx - 5, 8);
            }
            else
            {
                g.lineStyle(1.2, 0xFF5A63, 0.35);
                g.beginFill(0x000000, 0.45);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, r * 2, r * 2);
                g.endFill();
            }
        }

        // ---------- textos ----------
        private function makeText(t:String, size:int, color:uint, spacing:Number = 0):TextField
        {
            var tf:TextField = new TextField();
            var f:TextFormat = new TextFormat("_sans", size, color, true);
            f.letterSpacing = spacing;
            tf.defaultTextFormat = f;
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            return tf;
        }

        private function addCenterLabel(t:String, size:int, color:uint):void
        {
            var tf:TextField = makeText(t, size, color);
            tf.x = -tf.width / 2; tf.y = -tf.height / 2;
            addChild(tf);
        }

        // Texto do botão principal: maiúsculas com espaçamento largo, centralizado.
        private function addPrimaryLabel(t:String):void
        {
            var tf:TextField = makeText(t, 22, TEXT, 6);
            tf.x = -tf.width / 2 + 3; tf.y = -tf.height / 2;
            addChild(tf);
        }

        // Legenda pequena (ex.: SERVIDOR) + nome em destaque.
        private function addCardLabel(name:String, caption:String):void
        {
            var cap:TextField = makeText(caption, 10, TEXT_MUTED, 3);
            var nm:TextField = makeText(name, 17, TEXT);
            var total:Number = cap.height + nm.height - 2;
            cap.x = -bw / 2 + 20; cap.y = -total / 2;
            nm.x = -bw / 2 + 20;  nm.y = cap.y + cap.height - 2;
            addChild(cap); addChild(nm);
        }
    }
}
