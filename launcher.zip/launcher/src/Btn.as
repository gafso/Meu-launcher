package
{
    import flash.display.GradientType;
    import flash.display.Graphics;
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.filters.DropShadowFilter;
    import flash.geom.Matrix;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;

    // Botão do launcher. A origem (0,0) fica no CENTRO do botão.
    //   PRIMARY = botão de destaque (JOGAR)      CARD = cartão com legenda + seta (plataforma)
    //   GHOST   = botão discreto (ações secundárias)
    public class Btn extends Sprite
    {
        public static const PRIMARY:int = 0;
        public static const CARD:int    = 1;
        public static const GHOST:int   = 2;

        // Paleta do launcher (usada também pela tela inicial).
        public static const BLUE:uint       = 0x4C8DFF;
        public static const BLUE_DARK:uint  = 0x2559C9;
        public static const TEXT:uint       = 0xFFFFFF;
        public static const TEXT_SOFT:uint  = 0xC9D3E6;
        public static const TEXT_MUTED:uint = 0x7F8CA3;
        public static const SURFACE:uint    = 0x1E2634;
        public static const BORDER:uint     = 0x34425A;

        private var kind:int;
        private var bw:Number;
        private var bh:Number;

        public function Btn(kind:int, w:Number, h:Number, text:String, caption:String = "", onClick:Function = null)
        {
            this.kind = kind; bw = w; bh = h;
            mouseChildren = false;
            buttonMode = true;
            draw();
            if (kind == PRIMARY) addPrimaryLabel(text);
            else if (kind == CARD) addCardLabel(text, caption);
            else addCenterLabel(text, 16, TEXT_SOFT);
            if (onClick != null) addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onClick(e); });
            addEventListener(MouseEvent.MOUSE_DOWN, onDown);
            addEventListener(MouseEvent.MOUSE_UP, onUp);
            addEventListener(MouseEvent.ROLL_OUT, onUp);
        }

        private function onDown(e:MouseEvent):void { scaleX = scaleY = 0.96; alpha = 0.88; }
        private function onUp(e:MouseEvent):void   { scaleX = scaleY = 1; alpha = 1; }

        // ---------- desenho do fundo ----------
        private function draw():void
        {
            var g:Graphics = graphics;
            g.clear();
            var r:Number = kind == GHOST ? 14 : 18;
            if (kind == PRIMARY)
            {
                var m:Matrix = new Matrix();
                m.createGradientBox(bw, bh, Math.PI / 2, -bw / 2, -bh / 2);
                g.beginGradientFill(GradientType.LINEAR, [BLUE, BLUE_DARK], [1, 1], [0, 255], m);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, r * 2, r * 2);
                g.endFill();
                // brilho fino no topo
                g.beginFill(0xFFFFFF, 0.14);
                g.drawRoundRect(-bw / 2 + 3, -bh / 2 + 3, bw - 6, bh * 0.42, r * 1.6, r * 1.6);
                g.endFill();
                filters = [new DropShadowFilter(0, 90, BLUE, 0.55, 26, 26, 1, 3)];
            }
            else if (kind == CARD)
            {
                g.lineStyle(1.5, BORDER, 1);
                g.beginFill(SURFACE, 1);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, r * 2, r * 2);
                g.endFill();
                // seta (chevron) à direita
                var cx:Number = bw / 2 - 28;
                g.lineStyle(3, BLUE, 1, false, "normal", "round", "round");
                g.moveTo(cx - 5, -8); g.lineTo(cx + 3, 0); g.lineTo(cx - 5, 8);
            }
            else
            {
                g.lineStyle(1.2, 0xFFFFFF, 0.16);
                g.beginFill(0xFFFFFF, 0.06);
                g.drawRoundRect(-bw / 2, -bh / 2, bw, bh, r * 2, r * 2);
                g.endFill();
            }
        }

        // ---------- textos ----------
        private function makeText(t:String, size:int, color:uint, spacing:Number = 0):TextField
        {
            var tf:TextField = new TextField();
            var f:TextFormat = new TextFormat("_sans", size, color, true);
            f.letterSpacing = spacing;
            tf.defaultTextFormat = f;
            tf.autoSize = TextFieldAutoSize.LEFT;
            tf.selectable = false; tf.mouseEnabled = false;
            tf.text = t;
            return tf;
        }

        private function addCenterLabel(t:String, size:int, color:uint):void
        {
            var tf:TextField = makeText(t, size, color);
            tf.x = -tf.width / 2; tf.y = -tf.height / 2;
            addChild(tf);
        }

        // "▶  JOGAR": triângulo desenhado + texto, centralizados juntos.
        private function addPrimaryLabel(t:String):void
        {
            var tf:TextField = makeText(t, 28, TEXT, 4);
            var tri:Number = 20, gap:Number = 16;
            var total:Number = tri + gap + tf.width;
            var x0:Number = -total / 2;
            graphics.beginFill(0xFFFFFF, 1);
            graphics.moveTo(x0, -tri / 2 - 1);
            graphics.lineTo(x0 + tri * 0.9, 0);
            graphics.lineTo(x0, tri / 2 + 1);
            graphics.endFill();
            tf.x = x0 + tri + gap; tf.y = -tf.height / 2;
            addChild(tf);
        }

        // Legenda pequena (ex.: SERVIDOR) + nome em destaque.
        private function addCardLabel(name:String, caption:String):void
        {
            var cap:TextField = makeText(caption, 11, TEXT_MUTED, 2);
            var nm:TextField = makeText(name, 20, TEXT);
            var total:Number = cap.height + nm.height - 2;
            cap.x = -bw / 2 + 22; cap.y = -total / 2;
            nm.x = -bw / 2 + 22;  nm.y = cap.y + cap.height - 2;
            addChild(cap); addChild(nm);
        }
    }
}
