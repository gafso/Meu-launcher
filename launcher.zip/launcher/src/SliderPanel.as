package
{
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.events.Event;
    import flash.events.MouseEvent;
    import flash.filters.DropShadowFilter;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;

    // Painel com uma barra deslizante (usado na resolução "Personalizada").
    // A origem (0,0) fica no CENTRO do painel. Arraste a bolinha (ou toque na barra) e toque em Aplicar.
    public class SliderPanel extends Sprite
    {
        private static const PW:Number = 460;
        private static const PH:Number = 270;
        private static const TW:Number = 380;     // comprimento da barra

        private var minV:int;
        private var maxV:int;
        private var stepV:int;
        private var val:int;
        private var fmt:Function;
        private var apply:Function;
        private var hit:Sprite;
        private var fill:Shape;
        private var thumb:Sprite;
        private var valueTf:TextField;
        private var dragging:Boolean = false;

        public function SliderPanel(title:String, minV:int, maxV:int, stepV:int, value:int,
                                    fmt:Function, hint:String, onApply:Function, onCancel:Function)
        {
            this.minV = minV; this.maxV = maxV; this.stepV = stepV;
            this.fmt = fmt; this.apply = onApply;

            // fundo
            var bg:Shape = new Shape();
            bg.graphics.lineStyle(1.5, Btn.ACCENT, 0.55);
            bg.graphics.beginFill(Btn.SURFACE, 0.96);
            bg.graphics.drawRoundRect(-PW / 2, -PH / 2, PW, PH, 26, 26);
            bg.graphics.endFill();
            bg.filters = [new DropShadowFilter(0, 90, 0x000000, 0.8, 24, 24, 1, 2)];
            addChild(bg);

            addChild(label(title, 20, Btn.TEXT, -PH / 2 + 18));
            valueTf = label("", 30, Btn.ACCENT_LIGHT, -PH / 2 + 56);
            addChild(valueTf);
            addChild(label(hint, 12, Btn.TEXT_MUTED, -PH / 2 + 104));

            // barra
            var track:Shape = new Shape();
            track.graphics.beginFill(0x3A1418, 1);
            track.graphics.drawRoundRect(-TW / 2, -4, TW, 8, 8, 8);
            track.graphics.endFill();
            track.y = 8;
            addChild(track);
            fill = new Shape();
            fill.y = 8;
            addChild(fill);

            // bolinha
            thumb = new Sprite();
            thumb.graphics.lineStyle(2, 0xFFFFFF, 0.9);
            thumb.graphics.beginFill(Btn.ACCENT, 1);
            thumb.graphics.drawCircle(0, 0, 17);
            thumb.graphics.endFill();
            thumb.y = 8;
            thumb.mouseEnabled = false;
            addChild(thumb);

            // área de toque (alta, para facilitar com o dedo)
            hit = new Sprite();
            hit.graphics.beginFill(0xFFFFFF, 0);
            hit.graphics.drawRect(-TW / 2 - 24, -34, TW + 48, 68);
            hit.graphics.endFill();
            hit.y = 8;
            hit.addEventListener(MouseEvent.MOUSE_DOWN, onDown);
            addChild(hit);

            // botões
            var ok:Btn = new Btn(Btn.PRIMARY, 200, 54, "APLICAR", "", function(e:MouseEvent):void { apply(val); });
            ok.x = -108; ok.y = PH / 2 - 44;
            addChild(ok);
            var cancel:Btn = new Btn(Btn.GHOST, 190, 50, "Cancelar", "", function(e:MouseEvent):void { onCancel(); });
            cancel.x = 112; cancel.y = PH / 2 - 44;
            addChild(cancel);

            setVal(value);
        }

        private function label(t:String, size:int, color:uint, y:Number):TextField
        {
            var tf:TextField = new TextField();
            tf.selectable = false; tf.mouseEnabled = false;
            tf.autoSize = TextFieldAutoSize.CENTER;
            tf.defaultTextFormat = new TextFormat("_sans", size, color, true);
            tf.text = t;
            tf.x = -tf.width / 2;
            tf.y = y;
            return tf;
        }

        private function setVal(v:int):void
        {
            v = Math.max(minV, Math.min(maxV, Math.round(v / stepV) * stepV));
            val = v;
            var x:Number = (v - minV) / (maxV - minV) * TW - TW / 2;
            thumb.x = x;
            fill.graphics.clear();
            fill.graphics.beginFill(Btn.ACCENT, 1);
            fill.graphics.drawRoundRect(-TW / 2, -4, x + TW / 2, 8, 8, 8);
            fill.graphics.endFill();
            valueTf.text = String(fmt(v));
            valueTf.x = -valueTf.width / 2;
        }

        private function fromMouse():void
        {
            var lx:Number = Math.max(-TW / 2, Math.min(TW / 2, mouseX));
            setVal(minV + (lx + TW / 2) / TW * (maxV - minV));
        }

        private function onDown(e:MouseEvent):void
        {
            dragging = true;
            fromMouse();
            if (stage)
            {
                stage.addEventListener(MouseEvent.MOUSE_MOVE, onMove);
                stage.addEventListener(MouseEvent.MOUSE_UP, onUp);
            }
        }
        private function onMove(e:MouseEvent):void { if (dragging) fromMouse(); }
        private function onUp(e:MouseEvent):void
        {
            dragging = false;
            if (stage)
            {
                stage.removeEventListener(MouseEvent.MOUSE_MOVE, onMove);
                stage.removeEventListener(MouseEvent.MOUSE_UP, onUp);
            }
        }
    }
}
