package
{
    import flash.display.Sprite;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFormat;

    // Só a engrenagem (abre o menu de configurações), no canto superior direito.
    // Os atalhos Mochila/Missão/Mapa e o zoom foram removidos.
    public class Controls extends Sprite
    {
        private var gear:Sprite;

        public function Controls(onGear:Function)
        {
            gear = new Sprite();
            gear.graphics.beginFill(0x000000, 0.55);
            gear.graphics.lineStyle(1, 0xFFFFFF, 0.5);
            gear.graphics.drawRoundRect(0, 0, 64, 52, 12);
            gear.graphics.endFill();
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 18, 0xFFFFFF, true, null, null, null, null, "center");
            tf.width = 64; tf.y = 12; tf.text = "⚙"; tf.selectable = false; tf.mouseEnabled = false;
            gear.addChild(tf);
            gear.y = 10;
            gear.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onGear(); });
            addChild(gear);
        }

        // Posiciona a engrenagem no canto superior direito (scale > 1 aumenta o botão em telas grandes).
        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = scale;
            gear.x = stageW / scale - 74;
        }
    }
}
