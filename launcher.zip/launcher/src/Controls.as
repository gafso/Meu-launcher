package
{
    import flash.display.Sprite;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.text.TextFormatAlign;
    import flash.ui.Keyboard;

    // Só a engrenagem (abre o menu de configurações), no canto superior direito.
    // Botão redondo translúcido com o ícone desenhado em vetor (não depende de fonte/emoji).
    public class Controls extends Sprite
    {
        private static const SIZE:Number = 56;
        private static const GEAR_Y:Number = 134;  // distância do topo (era 56): desce para a área livre abaixo dos ícones do jogo
        private var gear:Sprite;
        private var macro:Sprite;
        private var toggle:Sprite;   // botão que mostra/esconde o teclado W A S D
        private var pad:Sprite;      // teclado W A S D na tela
        private static const KEY:Number = 66;
        private static const GAP:Number = 8;

        public function Controls(onGear:Function, onMacro:Function = null)
        {
            gear = new Sprite();
            gear.graphics.lineStyle(1, 0x7C3AED, 0.9);
            gear.graphics.beginFill(0x12112E, 0.85);
            gear.graphics.drawRoundRect(0, 0, SIZE, SIZE, 18, 18);
            gear.graphics.endFill();
            drawGear(gear, SIZE / 2, SIZE / 2);
            gear.mouseChildren = false;
            gear.buttonMode = true;
            gear.y = GEAR_Y;
            gear.addEventListener(MouseEvent.MOUSE_DOWN, function(e:MouseEvent):void { gear.alpha = 0.7; });
            var up:Function = function(e:MouseEvent):void { gear.alpha = 1; };
            gear.addEventListener(MouseEvent.MOUSE_UP, up);
            gear.addEventListener(MouseEvent.ROLL_OUT, up);
            gear.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onGear(); });
            addChild(gear);

            if (onMacro != null)
            {
                macro = new Sprite();
                macro.graphics.lineStyle(1, 0x7C3AED, 0.9);
                macro.graphics.beginFill(0x12112E, 0.85);
                macro.graphics.drawRoundRect(0, 0, SIZE, SIZE, 18, 18);
                macro.graphics.endFill();
                // triangulo de "play" (macros)
                macro.graphics.lineStyle(0, 0, 0);
                macro.graphics.beginFill(0xFFFFFF, 0.95);
                macro.graphics.moveTo(SIZE / 2 - 7, SIZE / 2 - 11);
                macro.graphics.lineTo(SIZE / 2 + 11, SIZE / 2);
                macro.graphics.lineTo(SIZE / 2 - 7, SIZE / 2 + 11);
                macro.graphics.lineTo(SIZE / 2 - 7, SIZE / 2 - 11);
                macro.graphics.endFill();
                macro.mouseChildren = false;
                macro.buttonMode = true;
                macro.y = GEAR_Y;
                macro.addEventListener(MouseEvent.MOUSE_DOWN, function(e:MouseEvent):void { macro.alpha = 0.7; });
                var up2:Function = function(e:MouseEvent):void { macro.alpha = 1; };
                macro.addEventListener(MouseEvent.MOUSE_UP, up2);
                macro.addEventListener(MouseEvent.ROLL_OUT, up2);
                macro.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onMacro(); });
                addChild(macro);
            }

            // botão WASD (liga/desliga o teclado na tela, útil para o treino QTE e outras missões)
            toggle = roundBtn("WASD", 11);
            toggle.y = GEAR_Y;
            toggle.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void
            {
                pad.visible = !pad.visible;
                toggle.alpha = pad.visible ? 1 : 0.85;
                toggle.graphics.clear();
                toggle.graphics.lineStyle(1, pad.visible ? 0xFFFFFF : 0x7C3AED, 0.9);
                toggle.graphics.beginFill(pad.visible ? 0x4B3AA8 : 0x12112E, 0.9);
                toggle.graphics.drawRoundRect(0, 0, SIZE, SIZE, 18, 18);
                toggle.graphics.endFill();
            });
            addChild(toggle);

            pad = new Sprite();
            pad.visible = false;
            pad.addChild(keyBtn("W", Keyboard.W, 119, KEY + GAP, 0));
            pad.addChild(keyBtn("A", Keyboard.A, 97, 0, KEY + GAP));
            pad.addChild(keyBtn("S", Keyboard.S, 115, KEY + GAP, KEY + GAP));
            pad.addChild(keyBtn("D", Keyboard.D, 100, (KEY + GAP) * 2, KEY + GAP));
            addChild(pad);
        }

        private function roundBtn(t:String, size:int):Sprite
        {
            var b:Sprite = new Sprite();
            b.graphics.lineStyle(1, 0x7C3AED, 0.9);
            b.graphics.beginFill(0x12112E, 0.85);
            b.graphics.drawRoundRect(0, 0, SIZE, SIZE, 18, 18);
            b.graphics.endFill();
            var tf:TextField = new TextField();
            tf.selectable = false; tf.mouseEnabled = false;
            tf.defaultTextFormat = new TextFormat("_sans", size, 0xFFFFFF, true, null, null, null, null, TextFormatAlign.CENTER);
            tf.text = t;
            tf.width = SIZE; tf.height = 20; tf.y = (SIZE - 18) / 2;
            b.addChild(tf);
            b.buttonMode = true;
            b.mouseChildren = false;
            return b;
        }

        // Tecla na tela: ao tocar manda KEY_DOWN para o palco do jogo e ao soltar manda KEY_UP.
        private function keyBtn(label:String, keyCode:uint, charCode:uint, x:Number, y:Number):Sprite
        {
            var b:Sprite = new Sprite();
            b.x = x; b.y = y;
            b.graphics.lineStyle(2, 0x7C3AED, 0.95);
            b.graphics.beginFill(0x12112E, 0.78);
            b.graphics.drawRoundRect(0, 0, KEY, KEY, 16, 16);
            b.graphics.endFill();
            var tf:TextField = new TextField();
            tf.selectable = false; tf.mouseEnabled = false;
            tf.defaultTextFormat = new TextFormat("_sans", 28, 0xFFFFFF, true, null, null, null, null, TextFormatAlign.CENTER);
            tf.text = label;
            tf.width = KEY; tf.height = 36; tf.y = (KEY - 34) / 2;
            b.addChild(tf);
            b.mouseChildren = false;
            b.buttonMode = true;
            var held:Boolean = false;
            var send:Function = function(type:String):void
            {
                try
                {
                    var stg:Object = (SwfFixer.rootStage != null && SwfFixer.rootStage.stage != null) ? SwfFixer.rootStage.stage : stage;
                    if (type == KeyboardEvent.KEY_DOWN) { try { stg.focus = null; } catch (e0:Error) {} }
                    stg.dispatchEvent(new KeyboardEvent(type, true, false, charCode, keyCode));
                }
                catch (e1:Error) {}
            };
            b.addEventListener(MouseEvent.MOUSE_DOWN, function(e:MouseEvent):void
            {
                if (held) return;
                held = true; b.alpha = 0.6; send(KeyboardEvent.KEY_DOWN);
            });
            var release:Function = function(e:MouseEvent):void
            {
                if (!held) return;
                held = false; b.alpha = 1; send(KeyboardEvent.KEY_UP);
            };
            b.addEventListener(MouseEvent.MOUSE_UP, release);
            b.addEventListener(MouseEvent.ROLL_OUT, release);
            return b;
        }

        // Engrenagem de 8 dentes com furo no meio.
        private function drawGear(s:Sprite, cx:Number, cy:Number):void
        {
            var teeth:int = 8;
            var rOut:Number = 13, rIn:Number = 9.5;
            var step:Number = Math.PI * 2 / teeth;
            var half:Number = step * 0.22;       // meia largura do dente (rad)
            var first:Boolean = true;
            s.graphics.lineStyle(0, 0, 0);
            s.graphics.beginFill(0xFFFFFF, 0.95);
            for (var i:int = 0; i < teeth; i++)
            {
                var a:Number = i * step;
                var pts:Array = [
                    [a - half * 1.8, rIn], [a - half, rOut], [a + half, rOut], [a + half * 1.8, rIn]
                ];
                for each (var p:Array in pts)
                {
                    var px:Number = cx + Math.cos(p[0]) * p[1];
                    var py:Number = cy + Math.sin(p[0]) * p[1];
                    if (first) { s.graphics.moveTo(px, py); first = false; }
                    else s.graphics.lineTo(px, py);
                }
            }
            s.graphics.endFill();
            // furo (círculo no mesmo tom do fundo do botão)
            s.graphics.beginFill(0x12112E, 1);
            s.graphics.drawCircle(cx, cy, 4.2);
            s.graphics.endFill();
        }

        // Posiciona a engrenagem no canto superior direito (scale > 1 aumenta o botão em telas grandes).
        public function layout(stageW:Number, scale:Number = 1, stageH:Number = 0):void
        {
            scaleX = scaleY = scale;
            gear.x = stageW / scale - SIZE - 14;
            var lastX:Number = gear.x;
            if (macro != null) { macro.x = gear.x - SIZE - 12; lastX = macro.x; }
            if (toggle != null) toggle.x = lastX - SIZE - 12;
            if (pad != null)
            {
                pad.x = 24;
                if (stageH > 0) pad.y = stageH / scale - (KEY * 2 + GAP) - 24;
            }
        }
    }
}
