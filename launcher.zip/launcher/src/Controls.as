package
{
    import flash.display.Sprite;
    import flash.events.MouseEvent;

    // Só a engrenagem (abre o menu de configurações), no canto superior direito.
    // Botão redondo translúcido com o ícone desenhado em vetor (não depende de fonte/emoji).
    public class Controls extends Sprite
    {
        private static const SIZE:Number = 56;
        private var gear:Sprite;

        public function Controls(onGear:Function)
        {
            gear = new Sprite();
            gear.graphics.lineStyle(1.5, 0xFF4A52, 0.6);
            gear.graphics.beginFill(0x0C0405, 0.62);
            gear.graphics.drawCircle(SIZE / 2, SIZE / 2, SIZE / 2);
            gear.graphics.endFill();
            drawGear(gear, SIZE / 2, SIZE / 2);
            gear.mouseChildren = false;
            gear.buttonMode = true;
            gear.y = 12;
            gear.addEventListener(MouseEvent.MOUSE_DOWN, function(e:MouseEvent):void { gear.alpha = 0.7; });
            var up:Function = function(e:MouseEvent):void { gear.alpha = 1; };
            gear.addEventListener(MouseEvent.MOUSE_UP, up);
            gear.addEventListener(MouseEvent.ROLL_OUT, up);
            gear.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { onGear(); });
            addChild(gear);
        }

        // Engrenagem de 8 dentes com furo no meio.
        private function drawGear(s:Sprite, cx:Number, cy:Number):void
        {
            var teeth:int = 8;
            var rOut:Number = 13, rIn:Number = 9.5;
            var step:Number = Math.PI * 2 / teeth;
            var half:Number = step * 0.22;       // meia largura do dente (rad)
            var first:Boolean = true;
            s.graphics.lineStyle(0, 0, 0);
            s.graphics.beginFill(0xFFFFFF, 0.95);
            for (var i:int = 0; i < teeth; i++)
            {
                var a:Number = i * step;
                var pts:Array = [
                    [a - half * 1.8, rIn], [a - half, rOut], [a + half, rOut], [a + half * 1.8, rIn]
                ];
                for each (var p:Array in pts)
                {
                    var px:Number = cx + Math.cos(p[0]) * p[1];
                    var py:Number = cy + Math.sin(p[0]) * p[1];
                    if (first) { s.graphics.moveTo(px, py); first = false; }
                    else s.graphics.lineTo(px, py);
                }
            }
            s.graphics.endFill();
            // furo (círculo no mesmo tom do fundo do botão)
            s.graphics.beginFill(0x0C0405, 1);
            s.graphics.drawCircle(cx, cy, 4.2);
            s.graphics.endFill();
        }

        // Posiciona a engrenagem no canto superior direito (scale > 1 aumenta o botão em telas grandes).
        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = scale;
            gear.x = stageW / scale - SIZE - 14;
        }
    }
}
