package
{
    import flash.display.Sprite;
    import flash.events.KeyboardEvent;
    import flash.events.MouseEvent;
    import flash.text.TextField;
    import flash.text.TextFormat;

    // Barra de atalhos na tela (Mochila B, Missão L, Mapa M), lupas de zoom e engrenagem.
    public class Controls extends Sprite
    {
        // [rótulo, keyCode]. Edite/adicione atalhos aqui.
        public static const KEYS:Array = [
            ["Mochila", 66],   // B
            ["Missão",  76],   // L
            ["Mapa",    77]    // M
        ];

        private var onGear:Function;
        private var onZoom:Function;
        private var bar:Sprite = new Sprite();

        public function Controls(onGear:Function, onZoom:Function)
        {
            this.onGear = onGear;
            this.onZoom = onZoom;
            addChild(bar);

            var x0:Number = 10;
            for each (var k:Array in KEYS)
            {
                bar.addChild(makeBtn(k[0], x0, 10, 96, makeKeyHandler(int(k[1]))));
                x0 += 104;
            }
            bar.addChild(makeBtn("+", x0, 10, 52, function(e:MouseEvent):void { onZoom(0.1); }));
            x0 += 60;
            bar.addChild(makeBtn("-", x0, 10, 52, function(e:MouseEvent):void { onZoom(-0.1); }));

            var gear:Sprite = makeBtn("⚙", 0, 10, 64, function(e:MouseEvent):void { onGear(); });
            gear.name = "gear";
            addChild(gear);
            visibleBar = true;
        }

        public function set visibleBar(v:Boolean):void { bar.visible = v; }

        // Posiciona a engrenagem no canto superior direito.
        // scale > 1 aumenta os botões em telas grandes.
        public function layout(stageW:Number, scale:Number = 1):void
        {
            scaleX = scaleY = scale;
            getChildByName("gear").x = stageW / scale - 74;
        }

        private function makeKeyHandler(code:int):Function
        {
            return function(e:MouseEvent):void
            {
                if (!stage) return;
                stage.dispatchEvent(new KeyboardEvent(KeyboardEvent.KEY_DOWN, true, false, 0, code));
                stage.dispatchEvent(new KeyboardEvent(KeyboardEvent.KEY_UP,   true, false, 0, code));
            };
        }

        private function makeBtn(t:String, x:Number, y:Number, w:Number, fn:Function):Sprite
        {
            var b:Sprite = new Sprite();
            b.graphics.beginFill(0x000000, 0.55);
            b.graphics.lineStyle(1, 0xFFFFFF, 0.5);
            b.graphics.drawRoundRect(0, 0, w, 52, 12);
            b.graphics.endFill();
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", 18, 0xFFFFFF, true, null, null, null, null, "center");
            tf.width = w; tf.y = 12; tf.text = t; tf.selectable = false; tf.mouseEnabled = false;
            b.addChild(tf);
            b.x = x; b.y = y;
            b.addEventListener(MouseEvent.CLICK, fn);
            return b;
        }
    }
}
