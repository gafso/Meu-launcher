package
{
    // Mapas de referência (pisos 8x8 completos, feitos a partir dos prints do jogador).
    // Só serve para DESCOBRIR onde o olho está quando o piso ainda está quase todo na névoa:
    // compara as casas já abertas (parede ou não) com cada referência; se só restar uma
    // (ou todas as que restarem tiverem o olho no mesmo lugar), devolve a posição do olho.
    // Coordenadas: x = coluna (0 = esquerda), y = linha (0 = topo).
    public class MapRefs
    {
        private static var DATA:Array = null;

        private static function mk(name:String, walls:String, unk:String, ex:int, ey:int):Object
        {
            var w:Object = {};
            var u:Object = {};
            var s:String;
            for each (s in walls.split(";")) w[s] = true;
            if (unk != "") for each (s in unk.split(";")) u[s] = true;
            return {name: name, w: w, u: u, ex: ex, ey: ey};
        }

        private static function init():void
        {
            if (DATA != null) return;
            DATA = [
                mk("água A", "1,0;3,0;4,0;4,1;5,1;7,1;0,3;4,3;5,3;6,3;5,4;6,4;0,5;2,5;3,5;6,5;1,6;6,6;1,7;6,7;7,7", "0,6;0,7", 7, 6),
                mk("água B", "0,0;1,2;4,2;1,3;5,3;4,4;2,5;1,6;0,7;5,7;6,7", "0,3", 1, 7),
                mk("lava A", "0,0;1,0;6,0;5,1;6,1;1,2;4,2;5,2;0,4;1,4;2,4;6,4;4,5;5,5;0,6;3,6;4,6;7,6;1,7;2,7;6,7", "0,7;7,7", 7, 5),
                mk("lava B", "0,0;3,1;4,1;6,1;7,1;0,2;1,2;2,2;7,2;2,3;4,3;6,3;0,4;2,4;2,5;5,5;7,5;4,6;0,7;2,7;6,7;7,7", "", 7, 0),
                mk("lava C", "1,0;2,0;3,0;5,0;1,2;4,2;5,2;7,2;1,3;3,3;5,3;1,4;3,4;4,4;5,4;6,4;0,6;2,6;4,6;0,7;2,7;5,7;6,7;7,7", "4,3", 1, 7)
            ];
        }

        // list = a.cells(). Devolve {name, ex, ey} ou null (nenhuma referência, ou ambíguo, ou casas abertas demais poucas).
        public static function match(list:Array, cols:int, rows:int):Object
        {
            if (cols != 8 || rows != 8) return null;
            init();
            var cand:Array = [];
            var r:int;
            var i:int;
            var ref:Object;
            var c:Object;
            var k:String;
            var ok:Boolean;
            var used:int;
            var maxUsed:int = 0;
            for (r = 0; r < DATA.length; r++)
            {
                ref = DATA[r];
                ok = true;
                used = 0;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if (!c.opened) continue;
                    k = c.x + "," + c.y;
                    if (ref.u[k]) continue;
                    used++;
                    if ((c.type == -1) != (ref.w[k] == true)) { ok = false; break; }
                    if (c.type == 8 && !(c.x == ref.ex && c.y == ref.ey)) { ok = false; break; }
                    if (c.x == ref.ex && c.y == ref.ey && c.type != 8) { ok = false; break; }
                }
                if (ok) { cand.push(ref); if (used > maxUsed) maxUsed = used; }
            }
            if (cand.length == 0 || maxUsed < 6) return null;
            var names:Array = [];
            for (i = 0; i < cand.length; i++)
            {
                if (cand[i].ex != cand[0].ex || cand[i].ey != cand[0].ey) return null;
                names.push(cand[i].name);
            }
            return {name: names.join(" ou "), ex: cand[0].ex, ey: cand[0].ey};
        }
    }
}
