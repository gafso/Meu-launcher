#!/usr/bin/env bash
# Compila ANE + APK (arm64) com o Harman AIR SDK 51.
# Variáveis: AIR_SDK, ANDROID_JAR, KEYSTORE (p12), STOREPASS, [ARCH=armv8]
set -euo pipefail
: "${AIR_SDK:?defina AIR_SDK}"
: "${ANDROID_JAR:?defina ANDROID_JAR}"
KEYSTORE="${KEYSTORE:-keystore.p12}"
STOREPASS="${STOREPASS:-changeit}"
ARCH="${ARCH:-armv8}"
cd "$(dirname "$0")"
ROOT="$PWD"
chmod +x "$AIR_SDK"/bin/* 2>/dev/null || true
ADT="java -jar $AIR_SDK/lib/adt.jar"

# --- versão do SDK -> namespace dos descritores e checagem de 64 bits ---
SDK_VER=$(sed -n 's:.*<version>\(.*\)</version>.*:\1:p' "$AIR_SDK/air-sdk-description.xml" | head -1)
SDK_MAJOR="${SDK_VER%%.*}"
rest="${SDK_VER#*.}"; SDK_MINOR="${rest%%.*}"
NS="$SDK_MAJOR.$SDK_MINOR"
echo "AIR SDK $SDK_VER (namespace $NS)"
if [ "$ARCH" = "armv8" ] && [ "$SDK_MAJOR" -lt 33 ]; then
  echo "ERRO: AIR SDK $SDK_VER não gera APK 64 bits (armv8). Use o SDK 51." >&2
  exit 1
fi

# --- ferramentas nativas do Android que o ADT espera dentro do SDK (o zip do SDK pode vir sem elas) ---
AB="$AIR_SDK/lib/android/bin"
mkdir -p "$AB"
echo "Conteúdo de lib/android: $(ls "$AIR_SDK/lib/android" 2>/dev/null | tr '\n' ' ')"
echo "Conteúdo de lib/android/bin: $(ls "$AB" 2>/dev/null | tr '\n' ' ')"
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-${ANDROID_JAR%/platforms/*}}}"
for tool in aapt zipalign; do
  if [ ! -f "$AB/$tool" ]; then
    src=$(ls -d "$SDK_ROOT"/build-tools/*/"$tool" 2>/dev/null | sort -V | tail -1 || true)
    if [ -n "$src" ]; then
      cp "$src" "$AB/$tool"; chmod +x "$AB/$tool"
      [ -d "$(dirname "$src")/lib64" ] && cp -r "$(dirname "$src")/lib64" "$AB/lib64" || true
      echo "Copiado $tool de $src"
    else
      echo "AVISO: $tool não encontrado em $SDK_ROOT/build-tools" >&2
    fi
  fi
done

rm -rf build && mkdir -p build/classes build/swc build/ane_android build/ane_default build/ext build/app
sed "s/NS_VERSION/$NS/" app.xml > build/app/app.xml
sed "s/NS_VERSION/$NS/" ane/extension.xml > build/extension.xml

echo "==> 1/4 Java do ANE"
javac -source 8 -target 8 -Xlint:-options -d build/classes \
  -cp "$AIR_SDK/lib/android/FlashRuntimeExtensions.jar:$ANDROID_JAR" \
  ane/android/src/com/meulauncher/air/*.java
jar cf build/ane_android/bridge.jar -C build/classes .

echo "==> 2/4 SWC stub do ANE"
cat > build/swc/Stub.as <<'EOF'
package { public class Stub {} }
EOF
"$AIR_SDK/bin/acompc" -source-path build/swc -include-classes Stub -output build/bridge.swc
unzip -o -q build/bridge.swc library.swf -d build/ane_android
cp build/ane_android/library.swf build/ane_default/library.swf

echo "==> 3/4 Empacotando o ANE"
$ADT -package -target ane build/ext/bridge.ane build/extension.xml \
  -swc build/bridge.swc \
  -platform Android-ARM   -C build/ane_android bridge.jar library.swf \
  -platform Android-ARM64 -C build/ane_android bridge.jar library.swf \
  -platform default       -C build/ane_default library.swf

echo "==> 4/4 Main.swf e APK ($ARCH)"
"$AIR_SDK/bin/amxmlc" -source-path src -output build/app/Main.swf src/Main.as
cp -r assets build/app/assets
$ADT -package -target apk-captive-runtime -arch "$ARCH" \
  -storetype pkcs12 -keystore "$KEYSTORE" -storepass "$STOREPASS" \
  build/MeuLauncher.apk build/app/app.xml \
  -C build/app Main.swf -C build/app assets \
  -extdir build/ext

ls -la build/MeuLauncher.apk
echo "Pronto: build/MeuLauncher.apk"
