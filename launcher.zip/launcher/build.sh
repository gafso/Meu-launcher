#!/usr/bin/env bash
# Compila ANE + APK (arm64) com o Harman AIR SDK 51.
# Variáveis: AIR_SDK, ANDROID_JAR, KEYSTORE (p12), STOREPASS, [ARCH=armv8]
set -euo pipefail
: "${AIR_SDK:?defina AIR_SDK}"
: "${ANDROID_JAR:?defina ANDROID_JAR}"
KEYSTORE="${KEYSTORE:-keystore.p12}"
STOREPASS="${STOREPASS:-changeit}"
ARCH="${ARCH:-armv8}"
cd "$(dirname "$0")"
ROOT="$PWD"
chmod +x "$AIR_SDK"/bin/* 2>/dev/null || true
ADT="java -jar $AIR_SDK/lib/adt.jar"

# --- versão do SDK -> namespace dos descritores e checagem de 64 bits ---
SDK_VER=$(sed -n 's:.*<version>\(.*\)</version>.*:\1:p' "$AIR_SDK/air-sdk-description.xml" | head -1)
SDK_MAJOR="${SDK_VER%%.*}"
rest="${SDK_VER#*.}"; SDK_MINOR="${rest%%.*}"
NS="$SDK_MAJOR.$SDK_MINOR"
echo "AIR SDK $SDK_VER (namespace $NS)"
if [ "$ARCH" = "armv8" ] && [ "$SDK_MAJOR" -lt 33 ]; then
  echo "ERRO: AIR SDK $SDK_VER não gera APK 64 bits (armv8). Use o SDK 51." >&2
  exit 1
fi

# --- aapt: o do SDK dá "symbol lookup error" (libc++) neste servidor; usa o do Android build-tools,
#     que traz a própria libc++ ao lado. O ADT procura "aapt" dentro do SDK, então vira um atalho. ---
AB="$AIR_SDK/lib/android/bin"
mkdir -p "$AB"
chmod +x "$AB"/* 2>/dev/null || true
case "$(uname -m)" in aarch64|arm64) SUF=linux_arm64 ;; *) SUF=linux64 ;; esac
SDK_ROOT="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-${ANDROID_JAR%/platforms/*}}}"
BT=""
for d in $(ls -d "$SDK_ROOT"/build-tools/*/ 2>/dev/null | sort -rV); do
  if [ -x "${d%/}/aapt" ]; then BT="${d%/}"; break; fi
done
echo "build-tools usado: ${BT:-nenhum}"
echo "lib64 do SDK: $(ls "$AB/lib64" 2>/dev/null | tr '\n' ' ')"
for tool in aapt aapt2; do
  rm -f "$AB/$tool"
  if [ -n "$BT" ] && [ -x "$BT/$tool" ]; then
    printf '#!/bin/sh\nexec "%s" "$@"\n' "$BT/$tool" > "$AB/$tool"
    chmod +x "$AB/$tool"
    echo "$tool -> $BT/$tool"
  elif [ -f "$AB/${tool}_$SUF" ]; then
    cp "$AB/${tool}_$SUF" "$AB/$tool"; chmod +x "$AB/$tool"
    echo "$tool -> ${tool}_$SUF (do SDK)"
  else
    echo "AVISO: $tool não encontrado" >&2
  fi
done
echo "Teste aapt: $("$AB/aapt" version 2>&1 | head -2 | tr '\n' ' ')"

rm -rf build && mkdir -p build/classes build/swc build/ane_android build/ane_default build/ext build/app
sed "s/NS_VERSION/$NS/" app.xml > build/app/app.xml
sed "s/NS_VERSION/$NS/" ane/extension.xml > build/extension.xml

echo "==> 1/4 Java do ANE"
javac -source 8 -target 8 -Xlint:-options -d build/classes \
  -cp "$AIR_SDK/lib/android/FlashRuntimeExtensions.jar:$ANDROID_JAR" \
  ane/android/src/com/meulauncher/air/*.java
jar cf build/ane_android/bridge.jar -C build/classes .

echo "==> 2/4 SWC do ANE (com a classe Bridge dentro)"
"$AIR_SDK/bin/acompc" -source-path ane/as -include-classes com.meulauncher.air.Bridge -output build/bridge.swc
unzip -o -q build/bridge.swc library.swf -d build/ane_android
cp build/ane_android/library.swf build/ane_default/library.swf

echo "==> 3/4 Empacotando o ANE"
$ADT -package -target ane build/ext/bridge.ane build/extension.xml \
  -swc build/bridge.swc \
  -platform Android-ARM   -C build/ane_android bridge.jar library.swf \
  -platform Android-ARM64 -C build/ane_android bridge.jar library.swf \
  -platform default       -C build/ane_default library.swf

echo "==> 4/4 Main.swf e APK ($ARCH)"
"$AIR_SDK/bin/amxmlc" -source-path src -external-library-path+=build/bridge.swc -output build/app/Main.swf src/Main.as
cp -r assets build/app/assets
$ADT -package -target apk-captive-runtime -arch "$ARCH" \
  -storetype pkcs12 -keystore "$KEYSTORE" -storepass "$STOREPASS" \
  build/MeuLauncher.apk build/app/app.xml \
  -C build/app Main.swf -C build/app assets \
  -extdir build/ext

ls -la build/MeuLauncher.apk
echo "Pronto: build/MeuLauncher.apk"
