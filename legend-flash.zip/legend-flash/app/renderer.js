'use strict';
const { ipcRenderer } = require('electron');

const HOST = 'https://lobr.creaction-network.com/';
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36';
const $ = (id) => document.getElementById(id);

let tabs = [];          // {id, name, wv, el, muted}
let active = null;
let zoom = parseFloat(localStorage.getItem('zoom') || '1');
let flash = { found: false };

function save() {
  localStorage.setItem('tabs', JSON.stringify(tabs.map((t) => ({ id: t.id, name: t.name }))));
  localStorage.setItem('active', active ? active.id : '');
}

// ---------- abas ----------
function addTab(id, name) {
  id = id || ('a' + Date.now().toString(36));
  name = name || ('Conta ' + (tabs.length + 1));
  const wv = document.createElement('webview');
  wv.setAttribute('partition', 'persist:acc-' + id);
  wv.setAttribute('plugins', '');
  wv.setAttribute('allowpopups', '');
  wv.setAttribute('useragent', UA);
  wv.setAttribute('src', HOST);
  $('views').appendChild(wv);

  const el = document.createElement('div');
  el.className = 'tab';
  el.innerHTML = '<span class="nm"></span><span class="x" title="Fechar">&times;</span>';
  $('tabs').appendChild(el);

  const t = { id, name, wv, el, muted: false };
  tabs.push(t);
  el.querySelector('.nm').textContent = name;
  el.addEventListener('click', (e) => { if (e.target.classList.contains('x')) closeTab(t); else select(t); });
  el.addEventListener('dblclick', () => renameTab(t));

  wv.addEventListener('dom-ready', () => { try { wv.setZoomFactor(zoom); } catch (e) {} });
  wv.addEventListener('new-window', (e) => { try { wv.loadURL(e.url); } catch (x) {} });
  const onNav = (e) => {
    try {
      const u = new URL(e.url);
      const user = u.searchParams.get('user');
      if (user && /^Conta \d+$/.test(t.name)) { t.name = user; el.querySelector('.nm').textContent = user; save(); refreshAcc(); }
    } catch (x) {}
  };
  wv.addEventListener('did-navigate', onNav);
  wv.addEventListener('did-navigate-in-page', onNav);
  select(t);
  save();
  return t;
}

function select(t) {
  active = t;
  for (const x of tabs) {
    x.wv.classList.toggle('act', x === t);
    x.el.classList.toggle('act', x === t);
  }
  refreshAcc();
  save();
}

function closeTab(t) {
  if (tabs.length === 1) { alert2('Esta é a única conta aberta. Use "Sair desta conta" ou abra outra antes de fechar.'); return; }
  const i = tabs.indexOf(t);
  tabs.splice(i, 1);
  t.wv.remove();
  t.el.remove();
  if (active === t) select(tabs[Math.max(0, i - 1)]);
  save();
}

function renameTab(t) {
  modal('<h3>Nome da conta</h3><input class="txt" id="rn" value="' + esc(t.name) + '"><div style="margin-top:10px;display:flex;gap:8px;justify-content:flex-end"><button class="btn" id="rnC">Cancelar</button><button class="btn or" id="rnOk">Salvar</button></div>');
  $('rn').focus();
  const ok = () => { const v = $('rn').value.trim(); if (v) { t.name = v; t.el.querySelector('.nm').textContent = v; save(); refreshAcc(); } closeModal(); };
  $('rnOk').onclick = ok;
  $('rnC').onclick = closeModal;
  $('rn').onkeydown = (e) => { if (e.key === 'Enter') ok(); };
}

function refreshAcc() { $('accName').textContent = active ? active.name : 'Sem conta'; }
function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

// ---------- janelas de diálogo ----------
function modal(html) { $('modalCard').innerHTML = html; $('modal').classList.remove('hidden'); }
function closeModal() { $('modal').classList.add('hidden'); }
function alert2(msg) { modal('<h3>Aviso</h3><p>' + esc(msg) + '</p><div style="text-align:right"><button class="btn or" id="okB">OK</button></div>'); $('okB').onclick = closeModal; }
$('modal').addEventListener('mousedown', (e) => { if (e.target === $('modal')) closeModal(); });

function showTabs() {
  let h = '<h3>Contas abertas</h3>';
  tabs.forEach((t, i) => {
    h += '<div class="row"><span class="grow">' + esc(t.name) + (t === active ? '  ✓' : '') + '</span>' +
      '<button class="btn" data-a="go" data-i="' + i + '">Ir</button>' +
      '<button class="btn" data-a="rn" data-i="' + i + '">Nome</button>' +
      '<button class="btn" data-a="x" data-i="' + i + '">Fechar</button></div>';
  });
  h += '<div style="display:flex;gap:8px;margin-top:10px"><button class="btn or" id="mNew">+ Nova conta</button><button class="btn" id="mClose" style="margin-left:auto">Fechar</button></div>';
  modal(h);
  $('mNew').onclick = () => { closeModal(); addTab(); };
  $('mClose').onclick = closeModal;
  $('modalCard').querySelectorAll('button[data-a]').forEach((b) => {
    b.onclick = () => {
      const t = tabs[+b.dataset.i];
      closeModal();
      if (b.dataset.a === 'go') select(t); else if (b.dataset.a === 'rn') renameTab(t); else closeTab(t);
    };
  });
}

function showKeys() {
  modal('<h3>Atalhos</h3>' +
    '<div class="row"><span class="grow">Nova conta (aba)</span><kbd>Ctrl+T</kbd></div>' +
    '<div class="row"><span class="grow">Fechar a aba</span><kbd>Ctrl+W</kbd></div>' +
    '<div class="row"><span class="grow">Próxima aba</span><kbd>Ctrl+Tab</kbd></div>' +
    '<div class="row"><span class="grow">Recarregar</span><kbd>F5</kbd></div>' +
    '<div class="row"><span class="grow">Tela cheia</span><kbd>F11</kbd></div>' +
    '<div class="row"><span class="grow">Esconder/mostrar a barra</span><kbd>F10</kbd></div>' +
    '<div style="text-align:right;margin-top:8px"><button class="btn or" id="okB">OK</button></div>');
  $('okB').onclick = closeModal;
}

function showCfg() {
  const sizes = [['HD 1280x720', 1280, 720], ['Full HD 1920x1080', 1920, 1080], ['2K 2560x1440', 2560, 1440], ['4K 3840x2160', 3840, 2160]];
  let h = '<h3>Configurações e tela</h3><div class="small">Tamanho da janela (área do jogo)</div><div class="chips">';
  sizes.forEach((s, i) => { h += '<button class="btn" data-s="' + i + '">' + s[0] + '</button>'; });
  h += '</div><div class="small">Zoom do jogo: <b id="zv">' + Math.round(zoom * 100) + '%</b></div><div class="chips">' +
    '<button class="btn" id="zm">&minus;</button><button class="btn" id="z1">100%</button><button class="btn" id="zp">+</button></div>' +
    '<div class="small">Flash: ' + (flash.found ? esc(flash.path) + ' (v' + esc(flash.version) + ')' : 'não encontrado') + '</div>' +
    '<div class="chips"><button class="btn" id="oF">Abrir pasta flash</button><button class="btn" id="rS">Reiniciar o app</button></div>' +
    '<div style="text-align:right"><button class="btn or" id="okB">OK</button></div>';
  modal(h);
  $('modalCard').querySelectorAll('button[data-s]').forEach((b) => {
    b.onclick = () => { const s = sizes[+b.dataset.s]; ipcRenderer.invoke('set-size', s[1], s[2]); };
  });
  const setZ = (z) => { zoom = Math.max(0.25, Math.min(3, Math.round(z * 100) / 100)); localStorage.setItem('zoom', String(zoom)); $('zv').textContent = Math.round(zoom * 100) + '%'; tabs.forEach((t) => { try { t.wv.setZoomFactor(zoom); } catch (e) {} }); };
  $('zm').onclick = () => setZ(zoom - 0.1);
  $('zp').onclick = () => setZ(zoom + 0.1);
  $('z1').onclick = () => setZ(1);
  $('oF').onclick = () => ipcRenderer.invoke('open-flash-dir');
  $('rS').onclick = () => ipcRenderer.invoke('restart');
  $('okB').onclick = closeModal;
}

// ---------- ações ----------
function enter() { if (active) active.wv.loadURL(HOST); }
async function signOut() {
  if (!active) return;
  await ipcRenderer.invoke('clear-account', 'persist:acc-' + active.id);
  if (/^Conta \d+$/.test(active.name) === false) { active.name = 'Conta'; active.el.querySelector('.nm').textContent = active.name; }
  save(); refreshAcc();
  active.wv.loadURL(HOST);
}
function toggleSide(force) {
  const off = force !== undefined ? !force : !$('side').classList.contains('off');
  $('side').classList.toggle('off', off);
  $('showSide').classList.toggle('on', off);
}
function toggleMute() {
  if (!active) return;
  active.muted = !active.muted;
  try { active.wv.setAudioMuted(active.muted); } catch (e) {}
  $('muteState').textContent = active.muted ? 'mudo' : '';
}
async function toggleFps() {
  const info = await ipcRenderer.invoke('flash-info');
  await ipcRenderer.invoke('set-highfps', !info.highFps);
  modal('<h3>Alto FPS</h3><p>' + (!info.highFps ? 'Ligado' : 'Desligado') + '. Reinicie o app para aplicar.</p><div style="text-align:right"><button class="btn" id="mC">Depois</button> <button class="btn or" id="mR">Reiniciar agora</button></div>');
  $('mC').onclick = closeModal;
  $('mR').onclick = () => ipcRenderer.invoke('restart');
}

$('btnEnter').onclick = enter;
$('nHome').onclick = enter;
$('accCard').onclick = showTabs;
$('nTabs').onclick = showTabs;
$('nNew').onclick = () => addTab();
$('nOut').onclick = signOut;
$('nFps').onclick = toggleFps;
$('nMute').onclick = toggleMute;
$('nKeys').onclick = showKeys;
$('nCfg').onclick = showCfg;
$('nFull').onclick = () => ipcRenderer.invoke('fullscreen');
$('nHide').onclick = () => toggleSide();
$('showSide').onclick = () => toggleSide(true);
$('addTab').onclick = () => addTab();
$('openFlash').onclick = () => ipcRenderer.invoke('open-flash-dir');
$('dismissFlash').onclick = () => $('noflash').classList.add('hidden');

window.addEventListener('keydown', (e) => {
  if (e.key === 'F10') { e.preventDefault(); toggleSide(); }
  else if (e.key === 'F11') { e.preventDefault(); ipcRenderer.invoke('fullscreen'); }
  else if (e.key === 'F5') { e.preventDefault(); if (active) active.wv.reload(); }
  else if (e.ctrlKey && e.key.toLowerCase() === 't') { e.preventDefault(); addTab(); }
  else if (e.ctrlKey && e.key.toLowerCase() === 'w') { e.preventDefault(); if (active) closeTab(active); }
  else if (e.ctrlKey && e.key === 'Tab') { e.preventDefault(); if (tabs.length > 1) select(tabs[(tabs.indexOf(active) + 1) % tabs.length]); }
  else if (e.key === 'Escape') closeModal();
});

// ---------- início ----------
(async function init() {
  flash = await ipcRenderer.invoke('flash-info');
  $('flashDot').className = 'dot ' + (flash.found ? 'ok' : 'bad');
  $('flashTxt').textContent = flash.found ? 'Flash ' + flash.version : 'Flash ausente';
  $('fpsState').textContent = flash.highFps ? 'ligado' : '';
  if (!flash.found) $('noflash').classList.remove('hidden');
  let saved = [];
  try { saved = JSON.parse(localStorage.getItem('tabs') || '[]'); } catch (e) {}
  if (!saved.length) saved = [{ id: 'main', name: 'Conta 1' }];
  saved.forEach((s) => addTab(s.id, s.name));
  const a = localStorage.getItem('active');
  const t = tabs.find((x) => x.id === a) || tabs[0];
  select(t);
})();
