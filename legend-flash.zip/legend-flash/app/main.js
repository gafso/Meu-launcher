'use strict';
// Legend Flash: janela única com abas (uma conta por aba, cookies separados) e Flash Player (Pepper Flash).
// O Flash NÃO vem junto (a Adobe não permite redistribuir): ponha o pepflashplayer64_*.dll na pasta "flash".
const { app, BrowserWindow, ipcMain, session, shell } = require('electron');
const fs = require('fs');
const path = require('path');

const APP_DIR = app.isPackaged ? path.dirname(process.execPath) : __dirname;
const CFG_FILE = path.join(app.getPath('userData'), 'config.json');

function readCfg() { try { return JSON.parse(fs.readFileSync(CFG_FILE, 'utf8')); } catch (e) { return {}; } }
function writeCfg(c) { try { fs.mkdirSync(path.dirname(CFG_FILE), { recursive: true }); fs.writeFileSync(CFG_FILE, JSON.stringify(c)); } catch (e) {} }
const cfg = readCfg();

function listDlls(dir) {
  try { return fs.readdirSync(dir).filter((n) => /^pepflashplayer.*\.dll$/i.test(n)).map((n) => path.join(dir, n)); } catch (e) { return []; }
}

function findFlash() {
  const dirs = [path.join(APP_DIR, 'flash'), path.join(__dirname, 'flash'), path.join(__dirname, '..', 'flash')];
  const win = process.env.windir || 'C:\\Windows';
  dirs.push(path.join(win, 'System32', 'Macromed', 'Flash'));
  dirs.push(path.join(win, 'SysWOW64', 'Macromed', 'Flash'));
  for (const d of dirs) {
    const l = listDlls(d);
    // este app é 64 bits: prefere o dll de 64 bits
    const pick = l.find((x) => /64/.test(path.basename(x))) || l[0];
    if (pick) return pick;
  }
  return null;
}

const flashPath = findFlash();
let flashVersion = '32.0.0.465';
if (flashPath) {
  const m = path.basename(flashPath).match(/(\d+)_(\d+)_(\d+)_(\d+)/);
  if (m) flashVersion = m.slice(1, 5).join('.');
  app.commandLine.appendSwitch('ppapi-flash-path', flashPath);
  app.commandLine.appendSwitch('ppapi-flash-version', flashVersion);
}
if (cfg.highFps) {
  app.commandLine.appendSwitch('disable-frame-rate-limit');
  app.commandLine.appendSwitch('disable-gpu-vsync');
}
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

let win = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1366, height: 800, minWidth: 960, minHeight: 600,
    backgroundColor: '#0B0D1E',
    title: 'Legend Flash',
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      webviewTag: true,
      plugins: true,
      backgroundThrottling: false
    }
  });
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'index.html'));
  win.on('closed', () => { win = null; });
}

ipcMain.handle('flash-info', () => ({ found: !!flashPath, path: flashPath, version: flashVersion, dir: path.join(APP_DIR, 'flash'), highFps: !!cfg.highFps }));
ipcMain.handle('set-size', (e, w, h) => {
  if (!win) return;
  try { if (win.isMaximized()) win.unmaximize(); win.setFullScreen(false); win.setContentSize(w, h); win.center(); } catch (err) {}
});
ipcMain.handle('fullscreen', () => { if (win) win.setFullScreen(!win.isFullScreen()); });
ipcMain.handle('clear-account', async (e, part) => {
  try { const s = session.fromPartition(part); await s.clearStorageData(); await s.clearCache(); } catch (err) {}
});
ipcMain.handle('open-flash-dir', () => {
  const d = path.join(APP_DIR, 'flash');
  try { fs.mkdirSync(d, { recursive: true }); } catch (err) {}
  return shell.openPath(d);
});
ipcMain.handle('set-highfps', (e, v) => { cfg.highFps = !!v; writeCfg(cfg); });
ipcMain.handle('restart', () => { app.relaunch(); app.exit(0); });

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
