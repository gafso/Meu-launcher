package com.meulauncher.air;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

// Copia uma imagem PNG do app para a Galeria (Pictures/LegendMinas), para aparecer no celular sem gerenciador de arquivos.
final class GalleryUtil {
    private GalleryUtil() {}

    static String save(Context ctx, String srcPath, String name) throws Exception {
        File src = new File(srcPath);
        if (!src.exists()) return "erro: arquivo de origem nao existe";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, "image/png");
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/LegendMinas");
            ContentResolver r = ctx.getContentResolver();
            Uri uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return "erro: a Galeria recusou o arquivo";
            OutputStream os = r.openOutputStream(uri);
            if (os == null) return "erro: nao consegui abrir a Galeria para gravar";
            copy(src, os);
            return "ok: Galeria > Pictures/LegendMinas";
        }
        File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "LegendMinas");
        dir.mkdirs();
        File dst = new File(dir, name);
        copy(src, new FileOutputStream(dst));
        ctx.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(dst)));
        return "ok: Galeria > Pictures/LegendMinas";
    }

    private static void copy(File src, OutputStream os) throws Exception {
        InputStream in = new FileInputStream(src);
        try {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            os.flush();
        } finally {
            try { in.close(); } catch (Exception ignored) {}
            try { os.close(); } catch (Exception ignored) {}
        }
    }
}
