package
{
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;

    // Mapas de referência (pisos completos 8x8 e 10x10, feitos a partir dos prints do jogador; 12x12 ainda falta).
    // Só serve para DESCOBRIR onde o olho está quando o piso ainda está quase todo na névoa:
    // compara as casas já abertas (parede ou não) com cada referência; se só restar uma
    // (ou todas as que restarem tiverem o olho no mesmo lugar), devolve a posição do olho.
    // Coordenadas: x = coluna (0 = esquerda), y = linha (0 = topo).
    public class MapRefs
    {
        private static var DATA:Array = null;
        // Remake: os mapas de lá são outros. Em vez das referências do Online, usa os que o próprio macro aprendeu
        // (paredes vistas + onde estava o olho) e vai guardando no aparelho a cada plano.
        public static var useBuiltin:Boolean = true;
        private static var RAW:Array = null;
        private static var LEARNED:Array = [];

        private static function loadRaw():void
        {
            if (RAW != null) return;
            RAW = Prefs.remakeMaps;
            if (dedupe() > 0) Prefs.remakeMaps = RAW;   // tira repetidos que já estavam salvos
            rebuild();
        }

        private static function rebuild():void
        {
            LEARNED = [];
            for (var i:int = 0; i < RAW.length; i++)
            {
                var r:Object = RAW[i];
                var n:int = int(r.n);
                var w:Object = {};
                var u:Object = {};
                var k:String;
                var known:int = 0;
                for (k in r.c) { known++; if (int(r.c[k]) == -1) w[k] = true; }
                for (var x:int = 0; x < n; x++)
                    for (var y:int = 0; y < n; y++)
                    {
                        k = x + "," + y;
                        if (r.c[k] === undefined) u[k] = true;
                    }
                LEARNED.push({name: "Remake #" + (i + 1), n: n, w: w, u: u, ex: int(r.ex), ey: int(r.ey), learned: true, known: known, noeye: stOf(r) == -1});
            }
        }

        public static function learnedCount():int { loadRaw(); return RAW.length; }
        public static function records():Array { loadRaw(); return RAW; }

        // Estado do olho de um mapa salvo: 1 = olho achado | 0 = olho não visto (mapa parcial, ainda na névoa) | -1 = sem olho (piso todo explorado).
        private static function stOf(r:Object):int
        {
            if (r.st !== undefined) return int(r.st);
            return int(r.ex) >= 0 ? 1 : -1;
        }

        // Guarda o que foi visto no piso (obs: "x,y" -> -1 parede | 8 olho | tipo do evento | 0 vazio), com o estado do olho (st).
        // Junta com um mapa já salvo se for o MESMO piso (mesmo tamanho, mesmas paredes nas casas em comum, olho compatível);
        // senão cria outro. Assim o mesmo piso vai se completando a cada plano em que aparece.
        // Os dois registros são o MESMO piso? (mesmo tamanho, mesmas paredes nas casas em comum, olho compatível)
        private static function same(r:Object, o:Object):Boolean
        {
            if (int(r.n) != int(o.n)) return false;
            var rs:int = stOf(r);
            var os:int = stOf(o);
            // olhos conhecidos dos dois lados têm que estar no mesmo lugar; "sem olho" não junta com "olho achado"
            if (rs == 1 && os == 1 && (int(r.ex) != int(o.ex) || int(r.ey) != int(o.ey))) return false;
            if ((rs == 1 && os == -1) || (rs == -1 && os == 1)) return false;
            var k:String;
            var overlap:int = 0;
            for (k in o.c)
            {
                if (r.c[k] === undefined) continue;
                overlap++;
                if ((int(r.c[k]) == -1) != (int(o.c[k]) == -1)) return false;
            }
            // o olho de um lado não pode cair numa casa que o outro lado já viu e é outra coisa
            if (os == 1 && r.c[o.ex + "," + o.ey] !== undefined && int(r.c[o.ex + "," + o.ey]) != 8) return false;
            if (rs == 1 && o.c[r.ex + "," + r.ey] !== undefined && int(o.c[r.ex + "," + r.ey]) != 8) return false;
            return overlap >= ((rs == os) ? 6 : 8);   // estados diferentes: exige mais casas em comum
        }

        // Junta o registro o dentro do r (casas que faltam + estado do olho).
        private static function mergeInto(r:Object, o:Object):void
        {
            var k:String;
            for (k in o.c) if (r.c[k] === undefined) r.c[k] = o.c[k];
            var cur:int = stOf(r);
            var os:int = stOf(o);
            if (os == 1 && cur != 1) { r.ex = int(o.ex); r.ey = int(o.ey); r.st = 1; }
            else if (os == -1 && cur == 0) { r.st = -1; r.ex = -1; r.ey = -1; }
            else if (r.st === undefined) r.st = cur;
        }

        // Funde pisos repetidos que ficaram separados (um mapa parcial que depois se completou, por exemplo). Devolve quantos juntou.
        private static function dedupe():int
        {
            var merged:int = 0;
            var again:Boolean = true;
            while (again)
            {
                again = false;
                for (var i:int = 0; i < RAW.length && !again; i++)
                    for (var j:int = i + 1; j < RAW.length && !again; j++)
                        if (same(RAW[i], RAW[j]))
                        {
                            mergeInto(RAW[i], RAW[j]);
                            RAW.splice(j, 1);
                            merged++;
                            again = true;
                        }
            }
            return merged;
        }

        public static function learn(n:int, obs:Object, ex:int, ey:int, st:int = 1):String
        {
            loadRaw();
            var k:String;
            var idx:int = -1;
            var c0:Object = {};
            for (k in obs) c0[k] = obs[k];
            var o:Object = {n: n, ex: ex, ey: ey, st: st, c: c0};
            for (var i:int = 0; i < RAW.length && idx < 0; i++) if (same(RAW[i], o)) idx = i;
            var created:Boolean = false;
            if (idx < 0) { RAW.push(o); idx = RAW.length - 1; created = true; }
            else mergeInto(RAW[idx], o);
            var joined:int = dedupe();
            if (joined > 0) { idx = Math.min(idx, RAW.length - 1); created = false; }
            Prefs.remakeMaps = RAW;
            rebuild();
            var cnt:int = 0;
            for (k in RAW[idx].c) cnt++;
            var fs:int = stOf(RAW[idx]);
            return (created ? "mapa NOVO salvo" : "mapa já conhecido, atualizado" + (joined > 0 ? " (juntei " + joined + " repetido)" : "")) + " (#" + (idx + 1) + ", " + cnt + " casas conhecidas, "
                + (fs == 1 ? "olho em " + RAW[idx].ex + "," + RAW[idx].ey : (fs == -1 ? "SEM olho" : "olho não visto")) + "); mapas salvos: " + RAW.length;
        }

        public static function learnNoEye(n:int, obs:Object):String
        {
            if (obs == null) return "mapa sem olho não salvo (nada visto)";
            return learn(n, obs, -1, -1, -1);
        }

        // Piso que o macro deixou sem ver o olho (parte ainda na névoa): guarda mesmo assim, como mapa parcial.
        public static function learnPartial(n:int, obs:Object):String
        {
            if (obs == null) return "mapa parcial não salvo (nada visto)";
            return learn(n, obs, -1, -1, 0);
        }

        // Símbolo de cada casa na referência escrita.
        private static function sym(t:int):String
        {
            if (t == 0) return ".";
            if (t == 8) return "O";
            var c:String = PlanesBot.category(t);
            if (c == "wall") return "#";
            if (c == "res") return "M";
            if (c == "box") return "B";
            if (c == "mon") return "X";
            if (c == "boss") return "C";
            if (c == "exit") return "T";
            if (c == "market") return "$";
            return "E";
        }

        // Texto de referência de todos os mapas salvos (para copiar/guardar e procurar as minas à mão).
        public static function exportLearned():String
        {
            loadRaw();
            if (RAW.length == 0) return "Nenhum mapa salvo ainda. Rode o macro de Minas no Remake: cada plano visitado vira uma referência (com olho, sem olho ou parcial).";
            var nEye:int = 0, nNo:int = 0, nPar:int = 0;
            var i:int;
            for (i = 0; i < RAW.length; i++) { var q:int = stOf(RAW[i]); if (q == 1) nEye++; else if (q == -1) nNo++; else nPar++; }
            var out:Array = [];
            out.push("MAPAS DO REMAKE: " + RAW.length + " salvos (" + nEye + " com olho, " + nNo + " sem olho, " + nPar + " parciais)");
            out.push("Legenda: # parede  O olho  M mina  B baú  X monstro  C chefe  T entrada/saída  $ loja  E outro evento  . vazio  ? ainda não visto");
            out.push("Colunas e linhas começam em 0 (x = coluna, y = linha).");
            out.push("");
            for (i = 0; i < RAW.length; i++)
            {
                var r:Object = RAW[i];
                var n:int = int(r.n);
                var st:int = stOf(r);
                var cnt:int = 0;
                var k:String;
                for (k in r.c) cnt++;
                var tag:String = st == 1 ? "OLHO em (" + r.ex + "," + r.ey + ")" : (st == -1 ? "SEM OLHO" : "olho NÃO visto (mapa parcial)");
                out.push("REFERÊNCIA #" + (i + 1) + "  " + n + "x" + n + "  " + tag + "  (" + cnt + " de " + (n * n) + " casas vistas)");
                var head:String = "    ";
                var x:int, y:int;
                for (x = 0; x < n; x++) head += (x % 10);
                out.push(head);
                var mines:Array = [];
                var evs:Array = [];
                for (y = 0; y < n; y++)
                {
                    var line:String = (y < 10 ? " " : "") + y + "  ";
                    for (x = 0; x < n; x++)
                    {
                        k = x + "," + y;
                        var t:* = r.c[k];
                        if (t === undefined) line += "?";
                        else
                        {
                            var sy:String = sym(int(t));
                            line += sy;
                            if (sy == "M") mines.push(x + "," + y);
                            else if (sy == "E" || sy == "C" || sy == "T" || sy == "$") evs.push(sy + int(t) + "@" + x + "," + y);
                        }
                    }
                    out.push(line);
                }
                if (mines.length > 0) out.push("minas vistas em (x,y): " + mines.join("  "));
                if (evs.length > 0) out.push("outros eventos (símbolo+tipo@x,y): " + evs.join("  "));
                out.push("");
            }
            out.push("----- dados brutos (para me enviar) -----");
            out.push(JSON.stringify(RAW));
            return out.join("\n");
        }

        // Grava o texto das referências num arquivo da pasta "mods" do app (mapas_remake.txt). Devolve o caminho ou "".
        public static function writeExport(dir:String):String
        {
            if (dir == null || dir == "") return "";
            try
            {
                var f:File = new File(dir).resolvePath("mapas_remake.txt");
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.WRITE);
                fs.writeUTFBytes(exportLearned());
                fs.close();
                return f.nativePath;
            }
            catch (e:Error) {}
            return "";
        }

        private static function mk(name:String, n:int, walls:String, unk:String, ex:int, ey:int):Object
        {
            var w:Object = {};
            var u:Object = {};
            var s:String;
            for each (s in walls.split(";")) w[s] = true;
            if (unk != "") for each (s in unk.split(";")) u[s] = true;
            return {name: name, n: n, w: w, u: u, ex: ex, ey: ey};
        }

        private static function init():void
        {
            if (DATA != null) return;
            DATA = [
                mk("Básico água A", 8, "1,0;3,0;4,0;4,1;5,1;7,1;0,3;4,3;5,3;6,3;5,4;6,4;0,5;2,5;3,5;6,5;1,6;6,6;1,7;6,7;7,7", "0,6;0,7", 7, 6),
                mk("Básico água B", 8, "0,0;1,2;4,2;1,3;5,3;4,4;2,5;1,6;0,7;5,7;6,7", "0,3", 1, 7),
                mk("Básico lava A", 8, "0,0;1,0;6,0;5,1;6,1;1,2;4,2;5,2;0,4;1,4;2,4;6,4;4,5;5,5;0,6;3,6;4,6;7,6;1,7;2,7;6,7", "0,7;7,7", 7, 5),
                mk("Básico lava B", 8, "0,0;3,1;4,1;6,1;7,1;0,2;1,2;2,2;7,2;2,3;4,3;6,3;0,4;2,4;2,5;5,5;7,5;4,6;0,7;2,7;6,7;7,7", "", 7, 0),
                mk("Básico lava C", 8, "1,0;2,0;3,0;5,0;1,2;4,2;5,2;7,2;1,3;3,3;5,3;1,4;3,4;4,4;5,4;6,4;0,6;2,6;4,6;0,7;2,7;5,7;6,7;7,7", "4,3", 1, 7),
                mk("Intermediário A", 10, "1,0;4,0;5,0;6,0;0,1;2,1;6,1;8,1;1,2;3,2;5,2;8,2;1,3;2,3;5,3;8,3;9,3;8,4;1,5;2,5;5,5;6,5;8,5;0,6;1,6;2,6;7,6;9,6;5,7;0,8;5,8;6,8;7,8;9,8;3,9;6,9;7,9;9,9", "0,0;1,1;2,2;9,4;9,5", 9, 7),
                mk("Intermediário B", 10, "2,0;4,0;5,0;6,0;8,0;1,1;9,1;0,2;9,2;0,3;2,3;4,3;5,3;9,3;0,4;6,4;9,4;0,5;5,5;8,5;0,6;3,6;9,6;2,7;0,8;1,8;6,8;7,8;2,9;4,9;6,9;8,9;9,9", "0,0;1,0;9,0;0,1;9,5;0,9;1,9;7,9", 2, 8),
                mk("Intermediário C", 10, "0,0;2,0;5,0;0,1;5,1;8,1;9,1;1,2;2,2;3,2;5,2;6,2;8,2;1,3;2,3;3,3;5,3;9,3;0,4;7,4;0,5;2,5;3,5;4,5;5,5;6,5;9,5;3,6;5,6;9,6;3,7;5,7;6,7;0,8;1,8;2,8;3,8;7,8;9,8;1,9;5,9", "0,2;9,2;0,3;0,9", 2, 9),
                mk("Intermediário D", 10, "0,0;2,0;3,0;6,0;9,0;1,2;2,2;3,2;4,2;6,2;7,2;8,2;2,3;7,3;8,3;1,4;2,4;4,4;5,4;8,4;9,4;2,5;4,5;8,5;9,5;1,6;2,6;4,6;5,6;4,7;5,7;8,7;4,8;5,8;7,8;8,8;0,9;1,9;3,9;5,9;7,9;8,9", "4,9", 0, 8),
                mk("Intermediário E", 10, "3,0;6,0;0,1;2,1;5,1;8,1;9,1;3,2;4,2;5,2;6,2;8,2;9,2;1,3;1,4;3,4;4,4;5,4;7,4;8,4;0,5;4,5;7,5;8,5;2,6;4,6;6,6;8,6;1,7;2,7;3,7;4,7;7,7;8,7;9,7;0,8;1,8;3,8;9,8;0,9;5,9;6,9;7,9;9,9", "4,0;5,0;3,1;4,1;7,6", 9, 0)
            ];
        }

        // Referências do tamanho n x n que ainda são compatíveis com as casas JÁ ABERTAS (parede/olho coincidem).
        // Casas na névoa não entram na conta. Se nenhuma referência existe para o tamanho, devolve [].
        public static function candidates(list:Array, cols:int, rows:int, useEye:Boolean = true):Array
        {
            var out:Array = [];
            if (cols != rows) return out;
            init();
            loadRaw();
            var all:Array = useBuiltin ? DATA.concat(LEARNED) : LEARNED;
            var r:int, i:int;
            var ref:Object, c:Object;
            var k:String;
            var ok:Boolean;
            for (r = 0; r < all.length; r++)
            {
                ref = all[r];
                if (int(ref.n) != cols) continue;
                ok = true;
                for (i = 0; i < list.length; i++)
                {
                    c = list[i];
                    if (!c.opened) continue;
                    k = c.x + "," + c.y;
                    if (ref.u[k]) continue;
                    if ((c.type == -1) != (ref.w[k] == true)) { ok = false; break; }
                    if (useEye && c.type == 8 && !(c.x == ref.ex && c.y == ref.ey)) { ok = false; break; }
                    if (useEye && c.x == ref.ex && c.y == ref.ey && c.type != 8) { ok = false; break; }
                }
                if (ok) out.push(ref);
            }
            return out;
        }

        // Só para o log: devolve {name, ex, ey} quando todas as referências compatíveis têm o olho no mesmo lugar.
        public static function match(list:Array, cols:int, rows:int):Object
        {
            var cand:Array = [];
            var all:Array = candidates(list, cols, rows);
            for (var ci:int = 0; ci < all.length; ci++) if (int(all[ci].ex) >= 0) cand.push(all[ci]);
            if (cand.length == 0) return null;
            var names:Array = [];
            for (var i:int = 0; i < cand.length; i++)
            {
                if (cand[i].ex != cand[0].ex || cand[i].ey != cand[0].ey) return null;
                names.push(cand[i].name);
            }
            return {name: names.join(" ou "), ex: cand[0].ex, ey: cand[0].ey};
        }
    }
}
