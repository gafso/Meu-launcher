package
{
    public class Platforms
    {
        // Este app é só do Legend Remake: o macro de Minas usa sempre o caminhar controlado.
        public static var remake:Boolean = true;
    }
}
