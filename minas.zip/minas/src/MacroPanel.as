package
{
    import flash.display.DisplayObjectContainer;
    import flash.display.Sprite;
    import flash.events.Event;
    import flash.events.MouseEvent;
    import flash.events.TimerEvent;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;
    import flash.utils.Timer;

    // Painel do macro de MINAS (só Remake). Leve: sem imagens, sem filtros, sem mapa desenhado.
    // Só atualiza a cada 1 s e SÓ enquanto está aberto. Fechar só esconde: o macro continua rodando.
    // Origem (0,0) = centro da janela.
    public class MacroPanel extends Sprite
    {
        private static const PW:Number = 470;
        private static const PH:Number = 430;

        public var logger:Function;       // recebe cada linha de log (vai para o log do app)
        public var onText:Function;       // (titulo, texto): caixa nativa com texto grande
        public var onWake:Function;       // reabre a janela quando o macro para sozinho com ela fechada
        public var onFps:Function;        // alterna 30 <-> 60 FPS (o Main aplica)
        public var onSleep:Function;      // apaga a tela (economia)

        private var realAd:GamePlanesAdapter = new GamePlanesAdapter();
        private var real:PlanesBot;
        private var cycle:PlanesCycle;
        private var opts:Object = {cycle: true, element: "", discardClosed: true, box: true, res: true, mon: true, boss: false, portal: 3, autoBuy: false, maxBuys: 0, buyBelow: 40, bind: true, rmBox: false, rmMon: false};

        private var bar:Sprite = new Sprite();
        private var statusTf:TextField;
        private var logTf:TextField;
        private var btnGo:Btn;
        private var btnElem:Btn;
        private var btnBox:Btn;
        private var btnMon:Btn;
        private var btnBuy:Btn;
        private var btnFps:Btn;
        private var btnMaps:Btn;
        private var popup:Sprite = new Sprite();
        private var pendingPopup:Array = null;
        private var lines:Array = [];
        private var timer:Timer;

        public function MacroPanel()
        {
            real = new PlanesBot(realAd, "Minas");
            real.opts = opts;
            real.logger = say;
            cycle = new PlanesCycle(realAd);
            cycle.logger = say;
            cycle.mode = 3;
            cycle.onEnter = function():void { real.start(); refresh(); };
            // MINAS: achou a mina -> NÃO descarta o plano, só sai e vai para o próximo; sem olho / sem mina -> descarta este
            real.onEnd = function(kind:String):void
            {
                cycle.mode = 3; cycle.element = String(opts.element);
                cycle.begin(kind != "mine", realAd.layerId);
                refresh();
            };
            cycle.onFinish = function(code:String, reason:String):void
            {
                if (code == "minesFull") alertStop("Macro parado", "Espaços de minas completos");
                refresh();
            };
            real.onStopped = function(reason:String):void
            {
                if (/sem energia|energia insuficiente|limite diário de energia|sem diamantes|limite de compras/.test(reason)) alertStop("Macro parado", "Acabaram os passos");
                refresh();
            };
            build();
            addEventListener(Event.ADDED_TO_STAGE, onAdded);
            addEventListener(Event.REMOVED_FROM_STAGE, onRemoved);
        }

        public function say(s:String):void
        {
            lines.push(s);
            if (lines.length > 200) lines.shift();
            if (logger != null) logger("MACRO " + s);
        }

        private function text(t:String, size:int, color:uint, x:Number, y:Number, w:Number = 0, bold:Boolean = true):TextField
        {
            var f:TextField = new TextField();
            f.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            f.selectable = false;
            f.mouseEnabled = false;
            f.autoSize = TextFieldAutoSize.LEFT;
            if (w > 0) { f.multiline = true; f.wordWrap = true; f.width = w; }
            f.text = t;
            f.x = x;
            f.y = y;
            return f;
        }

        private function build():void
        {
            var L:Number = -PW / 2;
            var T:Number = -PH / 2;
            var bg:Sprite = new Sprite();
            Win.glass(bg, L, T, PW, PH, 0.94);
            addChild(bg);

            // cabeçalho (arraste por ele)
            bar.graphics.beginFill(0xFFFFFF, 0);
            bar.graphics.drawRect(L, T, PW, 56);
            bar.graphics.endFill();
            bar.addEventListener(MouseEvent.MOUSE_DOWN, onBarDown);
            addChild(bar);
            addChild(text("MINAS", 22, Btn.ACCENT_LIGHT, L + 20, T + 12));
            addChild(text("Legend Remake", 11, Btn.TEXT_MUTED, L + 112, T + 22));
            var closeX:Sprite = Win.closeButton(36, 36, function(e:MouseEvent):void { hide(); });
            closeX.x = PW / 2 - 46; closeX.y = T + 10;
            addChild(closeX);

            // status e log curto
            statusTf = text("parado", 14, 0xFFFFFF, L + 20, T + 66, PW - 40);
            addChild(statusTf);
            var lg:Sprite = new Sprite();
            Win.field(lg, L + 20, T + 94, PW - 40, 78);
            addChild(lg);
            logTf = text("", 10, 0xD0D0D0, L + 28, T + 98, PW - 56, false);
            logTf.defaultTextFormat = new TextFormat("_typewriter", 10, 0xD0D0D0);
            logTf.autoSize = TextFieldAutoSize.NONE;
            logTf.height = 70;
            addChild(logTf);

            // opções
            var cx1:Number = L + 20 + (PW - 40) / 4;
            var cx2:Number = L + 20 + (PW - 40) * 3 / 4;
            var bw:Number = (PW - 40) / 2 - 6;
            var y1:Number = T + 196;
            addChild(text("OPÇÕES (sempre com foco em chegar no olho)", 10, Btn.ACCENT_LIGHT, L + 20, y1 - 18));
            btnBox = new Btn(Btn.GHOST, bw, 34, "", "", function(e:MouseEvent):void { opts.rmBox = !opts.rmBox; refresh(); });
            btnMon = new Btn(Btn.GHOST, bw, 34, "", "", function(e:MouseEvent):void { opts.rmMon = !opts.rmMon; refresh(); });
            btnElem = new Btn(Btn.GHOST, bw, 34, "", "", function(e:MouseEvent):void { cycleElement(); });
            btnBuy = new Btn(Btn.GHOST, bw, 34, "", "", function(e:MouseEvent):void { toggleBuy(); });
            btnBox.x = cx1; btnBox.y = y1 + 17;
            btnMon.x = cx2; btnMon.y = y1 + 17;
            btnElem.x = cx1; btnElem.y = y1 + 57;
            btnBuy.x = cx2; btnBuy.y = y1 + 57;
            addChild(btnBox); addChild(btnMon); addChild(btnElem); addChild(btnBuy);

            // economia / ferramentas
            var y2:Number = y1 + 92;
            addChild(text("ECONOMIA E FERRAMENTAS", 10, Btn.ACCENT_LIGHT, L + 20, y2 - 4));
            btnFps = new Btn(Btn.GHOST, bw, 34, "", "", function(e:MouseEvent):void { if (onFps != null) onFps(); refresh(); });
            var sleep:Btn = new Btn(Btn.GHOST, bw, 34, "Apagar a tela (economiza)", "", function(e:MouseEvent):void { if (onSleep != null) { hide(); onSleep(); } });
            btnMaps = new Btn(Btn.GHOST, bw, 34, "", "", function(e:MouseEvent):void { if (onText != null) onText("Mapas do Remake (" + MapRefs.learnedCount() + ")", MapRefs.exportLearned()); });
            var logBtn:Btn = new Btn(Btn.GHOST, bw, 34, "Ver log do macro", "", function(e:MouseEvent):void { if (onText != null) onText("Log do macro", lines.join("\n")); });
            btnFps.x = cx1; btnFps.y = y2 + 30;
            sleep.x = cx2;  sleep.y = y2 + 30;
            btnMaps.x = cx1; btnMaps.y = y2 + 70;
            logBtn.x = cx2;  logBtn.y = y2 + 70;
            addChild(btnFps); addChild(sleep); addChild(btnMaps); addChild(logBtn);

            btnGo = new Btn(Btn.PRIMARY, PW - 40, 50, "INICIAR", "", function(e:MouseEvent):void { toggleReal(); });
            btnGo.x = 0; btnGo.y = PH / 2 - 38;
            addChild(btnGo);

            addChild(popup);
            popup.visible = false;
            refresh();
        }

        // ---------- aviso de parada (janelinha com o motivo) ----------
        private function alertStop(title:String, msg:String):void
        {
            say("AVISO: " + msg);
            if (!isOpen) { pendingPopup = [title, msg]; if (onWake != null) onWake(); return; }
            showPopup(title, msg);
        }

        private function showPopup(title:String, msg:String):void
        {
            pendingPopup = null;
            while (popup.numChildren) popup.removeChildAt(0);
            popup.graphics.clear();
            popup.graphics.beginFill(0x000000, 0.55);
            popup.graphics.drawRect(-PW / 2, -PH / 2, PW, PH);
            popup.graphics.endFill();
            var box:Sprite = new Sprite();
            Win.card(box, -170, -80, 340, 160, 18, 0x262626, 0xFF7E28);
            popup.addChild(box);
            popup.addChild(text(title, 12, Btn.TEXT_MUTED, -150, -66));
            popup.addChild(text(msg, 20, 0xFFFFFF, -150, -38, 300));
            var ok:Btn = new Btn(Btn.PRIMARY, 140, 40, "OK", "", function(e:MouseEvent):void { popup.visible = false; });
            ok.x = 0; ok.y = 50;
            popup.addChild(ok);
            popup.visible = true;
            setChildIndex(popup, numChildren - 1);
        }

        // ---------- mostrar / esconder ----------
        public function get isOpen():Boolean { return parent != null; }

        public function show(host:DisplayObjectContainer, stageW:Number, stageH:Number, uiScale:Number):void
        {
            var s:Number = Math.min(uiScale, (stageH - 16) / PH, (stageW - 16) / PW);
            s = Math.max(0.5, s);
            scaleX = scaleY = s;
            if (parent == null)
            {
                x = stageW / 2;
                y = stageH / 2;
                host.addChild(this);
            }
            refresh();
            if (pendingPopup != null) showPopup(String(pendingPopup[0]), String(pendingPopup[1]));
        }

        public function stopAll():void
        {
            try { real.stop("parado (relogando)"); } catch (e1:Error) {}
            try { cycle.stop("parado (relogando)"); } catch (e2:Error) {}
            hide();
        }

        public function hide():void
        {
            stopDragging();
            if (parent != null) parent.removeChild(this);
        }

        public function get running():Boolean { return real.running || cycle.running; }

        private function onAdded(e:Event):void
        {
            if (timer == null)
            {
                timer = new Timer(1000);
                timer.addEventListener(TimerEvent.TIMER, function(ev:TimerEvent):void { refresh(); });
            }
            timer.start();
        }

        private function onRemoved(e:Event):void
        {
            if (timer != null) timer.stop();
        }

        // ---------- arrastar ----------
        private function onBarDown(e:MouseEvent):void
        {
            startDrag();
            if (stage != null) stage.addEventListener(MouseEvent.MOUSE_UP, onDragUp);
        }
        private function onDragUp(e:MouseEvent):void { stopDragging(); }
        private function stopDragging():void
        {
            stopDrag();
            if (stage != null) stage.removeEventListener(MouseEvent.MOUSE_UP, onDragUp);
        }

        // ---------- ações ----------
        private function toggleReal():void
        {
            if (real.running || cycle.running) { real.stop("parado pelo usuário"); cycle.stop("parado pelo usuário"); refresh(); return; }
            if (!realAd.ready && realAd.sceneName() == "CASTLE_SCENE")
            {
                // fora do plano: o ciclo abre o Transmissor, escolhe um plano e entra
                cycle.mode = 3; cycle.element = String(opts.element);
                cycle.startFromCastle(); refresh(); return;
            }
            if (!realAd.ready) say("Minas: o mapa do plano ainda não está aberto no jogo; o macro espera ele aparecer.");
            if (stage != null) say("FPS do app: " + int(stage.frameRate));
            real.start();
            refresh();
        }

        private function toggleBuy():void
        {
            opts.autoBuy = !opts.autoBuy;
            opts.maxBuys = opts.autoBuy ? 99 : 0;
            say(opts.autoBuy ? "Compra de passos LIGADA: só compra quando vê uma mina e faltam passos para pegá-la (gasta diamantes)" : "Compra de passos desligada");
            refresh();
        }

        // Escolhe o elemento do plano: VARIA -> elementos conhecidos -> VARIA...
        private function cycleElement():void
        {
            var seq:Array = [""];
            var base:Array = ["luz", "trevas", "fogo", "choque", "vento", "água"];
            var i:int;
            for (i = 0; i < base.length; i++) seq.push(base[i]);
            for (i = 0; i < GamePlanesAdapter.seenElements.length; i++)
            {
                var e:String = String(GamePlanesAdapter.seenElements[i]);
                var dup:Boolean = false;
                for (var j:int = 0; j < seq.length; j++) if (GamePlanesAdapter.norm(String(seq[j])) == e) dup = true;
                if (!dup) seq.push(e);
            }
            var cur:int = 0;
            for (i = 0; i < seq.length; i++) if (String(seq[i]) == String(opts.element)) cur = i;
            opts.element = String(seq[(cur + 1) % seq.length]);
            say("Elemento do plano: " + (String(opts.element).length > 0 ? String(opts.element) : "varia entre os da bolsa"));
            refresh();
        }

        private function onOff(label:String, v:Boolean):String { return label + ": " + (v ? "SIM" : "NÃO"); }

        public function refresh():void
        {
            var run:Boolean = real.running || cycle.running;
            btnGo.setText(run ? "PARAR" : "INICIAR");
            btnBox.setText(onOff("Pegar baús", opts.rmBox)); btnBox.selected = Boolean(opts.rmBox);
            btnMon.setText(onOff("Atacar monstros", opts.rmMon)); btnMon.selected = Boolean(opts.rmMon);
            btnElem.setText("Elemento: " + (String(opts.element).length > 0 ? String(opts.element) : "VARIA"));
            btnBuy.setText("Comprar passos: " + (opts.autoBuy ? "SIM" : "NÃO")); btnBuy.selected = Boolean(opts.autoBuy);
            var f:int = Prefs.fps;
            btnFps.setText(f >= 60 ? "FPS: 60 (fluido)" : "FPS: " + f + " (economia)");
            btnFps.selected = f >= 60;
            btnMaps.setText("Mapas salvos: " + MapRefs.learnedCount());
            var st:String = "parado";
            if (real.running) st = real.status;
            else if (cycle.running) st = cycle.status;
            statusTf.text = st.length > 60 ? st.substr(0, 60) : st;
            var ln:Array = lines.slice(Math.max(0, lines.length - 5));
            logTf.text = ln.join("\n");
        }
    }
}
