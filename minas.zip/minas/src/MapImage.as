package
{
    import flash.display.BitmapData;
    import flash.display.PNGEncoderOptions;
    import flash.display.Sprite;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.geom.Rectangle;
    import flash.text.TextField;
    import flash.text.TextFieldAutoSize;
    import flash.text.TextFormat;
    import flash.utils.ByteArray;

    // Desenha os mapas dos planos como imagem (PNG): o plano aberto no jogo ou os mapas salvos pelo macro.
    // Cada casa vira um quadrado colorido com a letra do que é (M mina, B baú, X monstro, O olho...).
    public class MapImage
    {
        private static function colorOf(type:int, id:int, opened:Boolean):uint
        {
            var c:uint;
            var cat:String = PlanesBot.category(type);
            if (cat == "wall") return 0x101010;
            if (type == 0 && id == 0) return opened ? 0x3A3A3A : 0x1A1A1A;
            if (cat == "box") c = 0xB8860B;
            else if (cat == "res") c = 0x2E8B57;
            else if (cat == "mon") c = 0xB5322E;
            else if (cat == "boss") c = 0xF56200;
            else if (cat == "portal") c = 0xE8D44D;
            else if (cat == "exit") c = 0x2F6FDB;
            else if (cat == "market") c = 0x1E8EA3;
            else c = 0x7A7A7A;
            if (!opened)
            {
                var r:uint = uint(((c >> 16) & 0xFF) * 0.5);
                var g:uint = uint(((c >> 8) & 0xFF) * 0.5);
                var b:uint = uint((c & 0xFF) * 0.5);
                c = (r << 16) | (g << 8) | b;
            }
            return c;
        }

        private static function symOf(type:int, id:int, opened:Boolean):String
        {
            if (type == 0 && id == 0) return opened ? "" : "?";
            var cat:String = PlanesBot.category(type);
            if (cat == "wall") return "#";
            if (cat == "res") return "M";
            if (cat == "box") return "B";
            if (cat == "mon") return "X";
            if (cat == "boss") return "C";
            if (cat == "portal") return "O";
            if (cat == "exit") return "T";
            if (cat == "market") return "$";
            return "E";
        }

        private static function tx(s:Sprite, t:String, size:int, color:uint, x:Number, y:Number, w:Number = 0, center:Boolean = false):TextField
        {
            var f:TextField = new TextField();
            var fmt:TextFormat = new TextFormat("_sans", size, color, true);
            if (center) fmt.align = "center";
            f.defaultTextFormat = fmt;
            f.selectable = false; f.mouseEnabled = false;
            if (w > 0) { f.width = w; f.height = size * 1.6; }
            else f.autoSize = TextFieldAutoSize.LEFT;
            f.text = t;
            f.x = x; f.y = y;
            s.addChild(f);
            return f;
        }

        // Desenha a grade cols x rows em (x0, y0). get(x, y) devolve {type, id, opened} ou null (casa não vista).
        private static function drawGrid(s:Sprite, x0:Number, y0:Number, cs:int, cols:int, rows:int, cellAt:Function, posX:int, posY:int, eyeX:int, eyeY:int):void
        {
            var fs:int = Math.max(8, int(cs * 0.42));
            var x:int, y:int;
            for (x = 0; x < cols; x++)
                if (cs >= 30) tx(s, String(x), 10, 0x9F9F9F, x0 + x * cs, y0 - 15, cs, true);
            for (y = 0; y < rows; y++)
            {
                if (cs >= 30) tx(s, String(y), 10, 0x9F9F9F, x0 - 22, y0 + y * cs + cs / 2 - 8, 18, true);
                for (x = 0; x < cols; x++)
                {
                    var c:Object = cellAt(x, y);
                    var px:Number = x0 + x * cs;
                    var py:Number = y0 + y * cs;
                    var type:int = c == null ? 0 : int(c.type);
                    var id:int = c == null ? 0 : int(c.id);
                    var op:Boolean = c == null ? false : Boolean(c.opened);
                    s.graphics.lineStyle(1, 0x000000, 0.7);
                    s.graphics.beginFill(c == null ? 0x1A1A1A : colorOf(type, id, op), 1);
                    s.graphics.drawRect(px, py, cs, cs);
                    s.graphics.endFill();
                    var sy:String = c == null ? "?" : symOf(type, id, op);
                    if (sy != "")
                    {
                        var col:uint = (sy == "?") ? 0x555555 : (sy == "O" ? 0x000000 : 0xFFFFFF);
                        tx(s, sy, fs, col, px, py + (cs - fs * 1.35) / 2, cs, true);
                    }
                }
            }
            if (eyeX >= 0 && eyeY >= 0)
            {
                s.graphics.lineStyle(3, 0xFFEE00, 1);
                s.graphics.drawRect(x0 + eyeX * cs + 2, y0 + eyeY * cs + 2, cs - 4, cs - 4);
            }
            if (posX >= 0 && posY >= 0)
            {
                s.graphics.lineStyle(3, 0xFFFFFF, 1);
                s.graphics.drawCircle(x0 + (posX + 0.5) * cs, y0 + (posY + 0.5) * cs, cs * 0.34);
            }
        }

        private static function legend(s:Sprite, x:Number, y:Number, w:Number):void
        {
            tx(s, "# parede  O olho  M mina  B baú  X monstro  C chefe  T entrada/saída  $ loja  E outro  ? não visto", 11, 0xBBBBBB, x, y, w);
            tx(s, "Casa escura = ainda na névoa.  Círculo branco = você.  Quadro amarelo = olho.", 11, 0x888888, x, y + 18, w);
        }

        // Plano aberto no jogo agora: todas as casas que o jogo informa (as da névoa saem escurecidas).
        public static function fromCells(list:Array, cols:int, rows:int, posX:int, posY:int, title:String):BitmapData
        {
            var byKey:Object = {};
            var eyeX:int = -1, eyeY:int = -1;
            var i:int;
            for (i = 0; i < list.length; i++)
            {
                byKey[int(list[i].x) * 100 + int(list[i].y)] = list[i];
                if (int(list[i].type) == 8) { eyeX = int(list[i].x); eyeY = int(list[i].y); }
            }
            var cs:int = 48;
            var left:int = 30, top:int = 56;
            var W:int = Math.max(left + cols * cs + 14, 600);
            var H:int = top + rows * cs + 14 + 52;
            var s:Sprite = new Sprite();
            tx(s, title + (eyeX >= 0 ? "   |   OLHO em (" + eyeX + "," + eyeY + ")" : "   |   olho não visível"), 16, 0xFF8844, 14, 8, W - 28);
            drawGrid(s, left, top, cs, cols, rows, function(x:int, y:int):Object { return byKey[x * 100 + y]; }, posX, posY, eyeX, eyeY);
            legend(s, 14, top + rows * cs + 12, W - 28);
            var bd:BitmapData = new BitmapData(W, H, false, 0x0A0A0A);
            bd.draw(s);
            return bd;
        }

        // Mapas salvos pelo macro: até 'perPage' mapas por imagem (3 por linha). page começa em 0.
        public static function pages(perPage:int = 6):int
        {
            var n:int = MapRefs.learnedCount();
            return n == 0 ? 0 : int(Math.ceil(n / perPage));
        }

        public static function fromSaved(page:int, perPage:int = 6):BitmapData
        {
            var recs:Array = MapRefs.records();
            var from:int = page * perPage;
            var to:int = Math.min(recs.length, from + perPage);
            var perRow:int = 3;
            var cs:int = 26;
            var maxN:int = 8;
            var i:int;
            for (i = from; i < to; i++) maxN = Math.max(maxN, int(recs[i].n));
            var cellW:int = 30 + maxN * cs + 20;
            var cellH:int = 40 + maxN * cs + 14;
            var cnt:int = to - from;
            var rowsN:int = int(Math.ceil(cnt / perRow));
            var W:int = Math.max(cellW * Math.min(perRow, cnt) + 10, 620);
            var H:int = 34 + rowsN * cellH + 52;
            var s:Sprite = new Sprite();
            tx(s, "MAPAS SALVOS DO REMAKE  (página " + (page + 1) + "/" + pages(perPage) + ", " + recs.length + " no total)", 15, 0xFF8844, 12, 8, W - 24);
            for (i = from; i < to; i++)
            {
                var r:Object = recs[i];
                var n:int = int(r.n);
                var k:int = i - from;
                var ox:Number = 5 + (k % perRow) * cellW;
                var oy:Number = 34 + int(k / perRow) * cellH;
                var st:int = r.st !== undefined ? int(r.st) : (int(r.ex) >= 0 ? 1 : -1);
                var tag:String = st == 1 ? "olho (" + r.ex + "," + r.ey + ")" : (st == -1 ? "SEM OLHO" : "olho não visto");
                tx(s, "#" + (i + 1) + "  " + n + "x" + n + "  " + tag, 12, st == 1 ? 0xE8D44D : (st == -1 ? 0xFF6B4D : 0xBBBBBB), ox + 4, oy, cellW - 8);
                var cc:Object = r.c;
                drawGrid(s, ox + 28, oy + 36, cs, n, n, function(x:int, y:int):Object
                {
                    var v:* = cc[x + "," + y];
                    if (v === undefined) return null;
                    return {type: int(v), id: (int(v) > 0 ? 1 : 0), opened: true};
                }, -1, -1, st == 1 ? int(r.ex) : -1, st == 1 ? int(r.ey) : -1);
            }
            legend(s, 12, H - 46, W - 24);
            var bd:BitmapData = new BitmapData(W, H, false, 0x0A0A0A);
            bd.draw(s);
            return bd;
        }

        // Grava o PNG em <dir>/mapas/<name>. Devolve o caminho ou "".
        public static function save(bd:BitmapData, dir:String, name:String):String
        {
            if (dir == null || dir == "" || bd == null) return "";
            try
            {
                var folder:File = new File(dir).resolvePath("mapas");
                if (!folder.exists) folder.createDirectory();
                var f:File = folder.resolvePath(name);
                var bytes:ByteArray = bd.encode(new Rectangle(0, 0, bd.width, bd.height), new PNGEncoderOptions());
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.WRITE);
                fs.writeBytes(bytes);
                fs.close();
                return f.nativePath;
            }
            catch (e:Error) {}
            return "";
        }
    }
}
