package
{
    import com.orbit.air.Bridge;
    import flash.desktop.NativeApplication;
    import flash.desktop.SystemIdleMode;
    import flash.display.Loader;
    import flash.display.Shape;
    import flash.display.Sprite;
    import flash.display.StageAlign;
    import flash.display.StageQuality;
    import flash.display.StageScaleMode;
    import flash.events.Event;
    import flash.events.IOErrorEvent;
    import flash.events.MouseEvent;
    import flash.events.StatusEvent;
    import flash.filesystem.File;
    import flash.filesystem.FileMode;
    import flash.filesystem.FileStream;
    import flash.net.URLLoader;
    import flash.net.URLLoaderDataFormat;
    import flash.net.URLRequest;
    import flash.system.ApplicationDomain;
    import flash.system.LoaderContext;
    import flash.text.TextField;
    import flash.text.TextFormat;
    import flash.utils.ByteArray;

    [SWF(width="1280", height="720", frameRate="30", backgroundColor="#05070A")]
    public class Main extends Sprite
    {
        private static const VERSION:String = "Orbit 1.0";
        private static const HOST:String = "lobr.creaction-network.com";

        private var bridge:Bridge;
        private var session:Object;
        private var accounts:Array = [];
        private var rootUI:Sprite = new Sprite();
        private var gameLoader:Loader;
        private var inGame:Boolean = false;
        private var port:int = 0;
        private var vipMacro:VipMacro;
        private var planesBot:PlanesBot;
        private var controlBar:Sprite;

        public function Main()
        {
            stage.align = StageAlign.TOP_LEFT;
            stage.scaleMode = StageScaleMode.NO_SCALE;
            stage.quality = StageQuality.LOW;
            stage.frameRate = 30;
            try { NativeApplication.nativeApplication.systemIdleMode = SystemIdleMode.NORMAL; } catch (e:Error) {}

            bridge = new Bridge();
            bridge.addEventListener("game", onSession);
            bridge.addEventListener("error", onNativeError);

            loadAccounts();
            SwfFixer.install();

            addChild(rootUI);
            buildHome();
        }

        // ---------- HOME (layout vertical, cards grandes, estilo diferente) ----------
        private function buildHome():void
        {
            clearUI();
            paintBg(0x05070A);

            // Header
            var header:Sprite = new Sprite();
            header.graphics.beginFill(0x0E1218);
            header.graphics.drawRect(0, 0, stage.stageWidth, 90);
            header.graphics.endFill();
            rootUI.addChild(header);

            var logo:TextField = label("ORBIT", 32, 0x7C5CFF, true);
            logo.x = 32; logo.y = 24;
            header.addChild(logo);

            var ver:TextField = label(VERSION, 14, 0x6B7280);
            ver.x = stage.stageWidth - 120; ver.y = 36;
            header.addChild(ver);

            // Contas em cards horizontais
            var y:Number = 120;
            if (accounts.length == 0)
            {
                var empty:TextField = label("Nenhuma conta salva", 18, 0x9CA3AF);
                empty.x = 40; empty.y = y;
                rootUI.addChild(empty);
                y += 50;
            }
            else
            {
                for (var i:int = 0; i < accounts.length; i++)
                {
                    var card:Sprite = accountCard(accounts[i]);
                    card.x = 32; card.y = y;
                    rootUI.addChild(card);
                    y += 88;
                }
            }

            // Botão principal grande
            var loginBtn:Sprite = bigButton("ENTRAR COM NOVA CONTA", 0x7C5CFF, 0xFFFFFF);
            loginBtn.x = 32; loginBtn.y = y + 16;
            loginBtn.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { bridge.login(HOST); });
            rootUI.addChild(loginBtn);

            // Botão secundário
            var setBtn:Sprite = bigButton("AJUSTES", 0x1F2937, 0xD1D5DB);
            setBtn.x = 32; setBtn.y = y + 90;
            setBtn.addEventListener(MouseEvent.CLICK, openSettings);
            rootUI.addChild(setBtn);
        }

        private function accountCard(acc:Object):Sprite
        {
            var s:Sprite = new Sprite();
            s.graphics.beginFill(0x111827);
            s.graphics.lineStyle(1, 0x374151);
            s.graphics.drawRoundRect(0, 0, 420, 72, 16);
            s.graphics.endFill();

            var nameTf:TextField = label(acc.name || "Conta", 18, 0xF9FAFB, true);
            nameTf.x = 20; nameTf.y = 14;
            s.addChild(nameTf);

            var hostTf:TextField = label(acc.host || HOST, 13, 0x9CA3AF);
            hostTf.x = 20; hostTf.y = 40;
            s.addChild(hostTf);

            var play:TextField = label("JOGAR", 14, 0x7C5CFF, true);
            play.x = 340; play.y = 26;
            s.addChild(play);

            s.buttonMode = true;
            s.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                try {
                    session = JSON.parse(String(acc.session));
                    launchGame();
                } catch (err:Error) {}
            });
            return s;
        }

        private function bigButton(text:String, bg:uint, fg:uint):Sprite
        {
            var s:Sprite = new Sprite();
            s.graphics.beginFill(bg);
            s.graphics.drawRoundRect(0, 0, 420, 58, 14);
            s.graphics.endFill();
            var t:TextField = label(text, 16, fg, true);
            t.x = 24; t.y = 18;
            s.addChild(t);
            s.buttonMode = true;
            return s;
        }

        // ---------- GAME ----------
        private function onSession(e:StatusEvent):void
        {
            try {
                session = JSON.parse(e.level);
                persistAccount();
                launchGame();
            } catch (err:Error) {}
        }

        private function launchGame():void
        {
            if (!session || !session.host) return;
            port = bridge.startServer(session.host);
            if (port <= 0) return;
            loadSwf();
        }

        private function loadSwf():void
        {
            var loader:URLLoader = new URLLoader();
            loader.dataFormat = URLLoaderDataFormat.BINARY;
            loader.addEventListener(Event.COMPLETE, function(ev:Event):void {
                var b:ByteArray = ByteArray(loader.data);
                if (b.length > 500) startGame(b);
                else loadPacked();
            });
            loader.addEventListener(IOErrorEvent.IO_ERROR, function(ev:IOErrorEvent):void { loadPacked(); });
            loader.load(new URLRequest("http://127.0.0.1:" + port + "/client/Loading.swf"));
        }

        private function loadPacked():void
        {
            var f:File = File.applicationDirectory.resolvePath("assets/game/Loading.swf");
            if (!f.exists) return;
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.READ);
            var b:ByteArray = new ByteArray();
            fs.readBytes(b);
            fs.close();
            startGame(b);
        }

        private function startGame(bytes:ByteArray):void
        {
            inGame = true;
            clearUI();

            var ctx:LoaderContext = new LoaderContext(false, new ApplicationDomain(ApplicationDomain.currentDomain));
            ctx.allowCodeImport = true;
            var params:Object = {};
            if (session.params) {
                for (var k:String in session.params) params[k] = String(session.params[k]);
            }
            params.http = "https:";
            params.config = "https://" + session.host + "/client/config.xml";
            params.base = "https://" + session.host + "/client/";
            ctx.parameters = params;

            gameLoader = new Loader();
            gameLoader.contentLoaderInfo.addEventListener(Event.INIT, function(ev:Event):void {
                SwfFixer.gameDomain = gameLoader.contentLoaderInfo.applicationDomain;
            });
            gameLoader.contentLoaderInfo.addEventListener(Event.COMPLETE, function(ev:Event):void {
                setupMacros();
                showControlBar();
            });
            gameLoader.loadBytes(bytes, ctx);
            addChild(gameLoader);
        }

        private function setupMacros():void
        {
            vipMacro = new VipMacro();
            vipMacro.logger = function(s:String):void { trace("VIP: " + s); };

            var ad:GamePlanesAdapter = new GamePlanesAdapter();
            planesBot = new PlanesBot(ad, "Orbit-Minas");
            planesBot.logger = function(s:String):void { trace("MINAS: " + s); };
            if (planesBot.opts) planesBot.opts.portal = 3;
        }

        // Barra de controle flutuante no topo (estilo diferente do original)
        private function showControlBar():void
        {
            if (controlBar && controlBar.parent) controlBar.parent.removeChild(controlBar);
            controlBar = new Sprite();
            controlBar.y = 12;

            var bar:Shape = new Shape();
            bar.graphics.beginFill(0x111827, 0.92);
            bar.graphics.drawRoundRect(0, 0, 520, 52, 26);
            bar.graphics.endFill();
            controlBar.addChild(bar);

            var vip:Sprite = pill("VIP", 0x7C5CFF);
            vip.x = 16; vip.y = 10;
            vip.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                if (vipMacro && !vipMacro.running) vipMacro.start();
            });
            controlBar.addChild(vip);

            var mines:Sprite = pill("MINAS", 0x10B981);
            mines.x = 140; mines.y = 10;
            mines.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                if (planesBot && !planesBot.running) {
                    if (planesBot.opts) planesBot.opts.portal = 3;
                    planesBot.start();
                }
            });
            controlBar.addChild(mines);

            var fps:Sprite = pill("60 FPS", 0xF59E0B);
            fps.x = 280; fps.y = 10;
            fps.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { stage.frameRate = 60; });
            controlBar.addChild(fps);

            var back:Sprite = pill("SAIR", 0x374151);
            back.x = 400; back.y = 10;
            back.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void {
                if (gameLoader && gameLoader.parent) removeChild(gameLoader);
                if (controlBar && controlBar.parent) controlBar.parent.removeChild(controlBar);
                inGame = false;
                buildHome();
            });
            controlBar.addChild(back);

            controlBar.x = (stage.stageWidth - 520) / 2;
            stage.addChild(controlBar);
        }

        private function pill(text:String, color:uint):Sprite
        {
            var s:Sprite = new Sprite();
            s.graphics.beginFill(color);
            s.graphics.drawRoundRect(0, 0, 110, 32, 16);
            s.graphics.endFill();
            var t:TextField = label(text, 13, 0xFFFFFF, true);
            t.x = 18; t.y = 7;
            s.addChild(t);
            s.buttonMode = true;
            return s;
        }

        private function openSettings():void
        {
            var panel:Sprite = new Sprite();
            panel.graphics.beginFill(0x0E1218, 0.96);
            panel.graphics.drawRoundRect(180, 140, 480, 320, 20);
            panel.graphics.endFill();

            var title:TextField = label("Ajustes", 24, 0x7C5CFF, true);
            title.x = 210; title.y = 160;
            panel.addChild(title);

            var f30:Sprite = pill("30 FPS", 0x374151);
            f30.x = 210; f30.y = 230;
            f30.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { stage.frameRate = 30; });
            panel.addChild(f30);

            var f60:Sprite = pill("60 FPS", 0x7C5CFF);
            f60.x = 340; f60.y = 230;
            f60.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { stage.frameRate = 60; });
            panel.addChild(f60);

            var low:Sprite = pill("Qualidade Baixa", 0x1F2937);
            low.x = 210; low.y = 290;
            low.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { stage.quality = StageQuality.LOW; });
            panel.addChild(low);

            var close:Sprite = pill("Fechar", 0x374151);
            close.x = 210; close.y = 380;
            close.addEventListener(MouseEvent.CLICK, function(e:MouseEvent):void { rootUI.removeChild(panel); });
            panel.addChild(close);

            rootUI.addChild(panel);
        }

        // ---------- helpers ----------
        private function paintBg(color:uint):void
        {
            var s:Shape = new Shape();
            s.graphics.beginFill(color);
            s.graphics.drawRect(0, 0, stage.stageWidth || 1280, stage.stageHeight || 720);
            s.graphics.endFill();
            rootUI.addChild(s);
        }

        private function clearUI():void
        {
            while (rootUI.numChildren) rootUI.removeChildAt(0);
        }

        private function label(txt:String, size:int, color:uint, bold:Boolean = false):TextField
        {
            var tf:TextField = new TextField();
            tf.defaultTextFormat = new TextFormat("_sans", size, color, bold);
            tf.text = txt;
            tf.selectable = false;
            tf.mouseEnabled = false;
            tf.autoSize = "left";
            return tf;
        }

        private function loadAccounts():void
        {
            var f:File = File.applicationStorageDirectory.resolvePath("orbit_accounts.json");
            if (!f.exists) return;
            try {
                var fs:FileStream = new FileStream();
                fs.open(f, FileMode.READ);
                var raw:String = fs.readUTFBytes(fs.bytesAvailable);
                fs.close();
                var p:* = JSON.parse(raw);
                accounts = p is Array ? p : [];
            } catch (e:Error) { accounts = []; }
        }

        private function persistAccount():void
        {
            if (!session) return;
            var user:String = session.user || (session.params && session.params.user) || "Conta";
            var entry:Object = {
                name: user,
                host: session.host,
                session: JSON.stringify(session),
                ts: new Date().time
            };
            var idx:int = -1;
            for (var i:int = 0; i < accounts.length; i++) {
                if (accounts[i].name == user) { idx = i; break; }
            }
            if (idx >= 0) accounts[idx] = entry;
            else accounts.push(entry);
            saveAccounts();
        }

        private function saveAccounts():void
        {
            var f:File = File.applicationStorageDirectory.resolvePath("orbit_accounts.json");
            var fs:FileStream = new FileStream();
            fs.open(f, FileMode.WRITE);
            fs.writeUTFBytes(JSON.stringify(accounts));
            fs.close();
        }

        private function onNativeError(e:StatusEvent):void
        {
            trace("Erro: " + e.level);
        }
    }
}
