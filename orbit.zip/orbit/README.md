# Orbit Launcher

Projeto completamente novo.

- Nome: Orbit
- ID: com.orbit.launcher
- Pacote ANE: com.orbit.air
- Interface própria
- Macros VIP e Minas
- 60 FPS
- Contas salvas

## Compilar
1. Suba esta pasta no GitHub.
2. Vá em Actions → Build Orbit APK → Run workflow.
3. Baixe o artifact `Orbit-apk`.

O `build.sh` e o workflow são independentes do projeto antigo.
